source("R/fonctions.R")

#2/

# Histogramme de la distribution des âges

sect1_harvestw4 <- read_dta("data/raw/NGA-GHSP-W4/sect1_harvestw4.dta")
ggplot(sect1_harvestw4, aes(x = s1q4)) +                                 #on indique la variable à représenter
  geom_histogram(binwidth = 5, fill = "steelblue", color = "orange") +   #classes de 5 ans  # fill: couleur des barres
  labs(
    title = "Distribution de l'âge des membres du ménage",
    x = "Âge",
    y = "Nombre d'individus"
  ) +
  theme_minimal()                                                      #style propre pour rapport

# Boxplot de l'âge
ggplot(sect1_harvestw4, aes(y = s1q4)) +
  geom_boxplot(fill = "green") +
  labs(
    title = "Boîte à moustaches de l'âge",
    y = "Âge"
  ) +
  theme_minimal()

#Vérification du nombre de valeur supérieur à 100 pour l'age

sect1_harvestw4 %>%
  filter(s1q4 > 100) %>%
  select(hhid, indiv, s1q4)


# Statistiques descriptives pour la variable age
stats_age <- sect1_harvestw4 %>%
  summarise(
    moyenne = mean(s1q4, na.rm = TRUE),                       #na.rm = TRUE
    mediane = median(s1q4, na.rm = TRUE),
    Q1 = quantile(s1q4, 0.25, na.rm = TRUE),                   #quantile():calcule les quartiles.
    Q3 = quantile(s1q4, 0.75, na.rm = TRUE),
    ecart_type = sd(s1q4, na.rm = TRUE)
  )

stats_age

#Coefficient de variation
cv_age <- sd(sect1_harvestw4$s1q4, na.rm = TRUE) /
  mean(sect1_harvestw4$s1q4, na.rm = TRUE)

cv_age

#Asymétrie

coef_asymetrie <-skewness(sect1_harvestw4$s1q4, na.rm = TRUE)

coef_asymetrie


#Test de Shapiro-Wilk
age_sample <- sect1_harvestw4 %>%
  slice_sample(n = 5000)

test_shapiro <- shapiro.test(age_sample$s1q4)

test_shapiro




#3/

#Pyramide des ages avec ggplot

#Creer des groupes d'ages

table(sect1_harvestw4$s1q2) #Vérifier les modalités pour s1q2(sexe) et le nombre d'observations par modalités

sect1_age <- sect1_harvestw4 %>%
  filter(!is.na(s1q4), !is.na(s1q2))  #Dégager les valeurs manquantes

sect1_age <- sect1_age %>%
  mutate(
    age_group = cut(                                    #cut()→ transforme l’âge en classes
      s1q4,
      breaks = seq(0, 100, 5),                          #seq(0,100,5)   → classes de 5 ans
      right = FALSE
    )
  )

#Compter les individus par sexe et age

pyramid_data <- sect1_age %>%
  group_by(age_group, s1q2) %>%
  summarise(n = n(), .groups = "drop")                 #n() → nombre d’individus

#Inverser les hommes pour la pyramide
pyramid_data <- pyramid_data %>%
  mutate(
    n = ifelse(s1q2 == 1, -n, n)                       #hommes(1) → valeurs négatives
  )

#Pyramide  

ggplot(pyramid_data, aes(x = age_group, y = n, fill = factor(s1q2))) +
  geom_bar(stat = "identity") +
  coord_flip() +
  labs(
    title = "Pyramide des âges - Nigeria GHS (Vague 4)",
    x = "Groupe d'âge",
    y = "Population",
    fill = "Sexe"
  ) +
  scale_fill_manual(
    values = c("blue", "red"),
    labels = c("Hommes", "Femmes")
  ) +
  theme_minimal()


#4/
# =============================================================================
# FRÉQUENCES DU LIEN DE PARENTÉ - sect1_harvestw4
# Variable : s1q3
# Diagramme en barres horizontales ordonné + IC à 95%
# =============================================================================

# -----------------------------------------------------------------------------
# 1. CHARGEMENT ET RECODAGE
# -----------------------------------------------------------------------------
sect1 <-  read_dta("data/raw/NGA-GHSP-W4/sect1_harvestw4.dta")

parenté <- sect1 %>%
  filter(!is.na(s1q3)) %>%
  mutate(
    lien = case_when(
      as.numeric(s1q3) == 1              ~ "Chef de ménage",
      as.numeric(s1q3) == 2              ~ "Conjoint(e)",
      as.numeric(s1q3) %in% c(3, 4, 5)  ~ "Enfant",
      TRUE                               ~ "Autre"
    )
  )

N_total <- nrow(parenté)
cat("N total (hors NA) :", N_total, "\n")


# -----------------------------------------------------------------------------
# 2. CALCUL DES PROPORTIONS ET IC À 95% AVEC binom.test()
# -----------------------------------------------------------------------------
freq <- parenté %>%
  count(lien) %>%
  arrange(desc(n))

# Appliquer binom.test() sur chaque modalité
resultats <- freq %>%
  rowwise() %>%
  mutate(
    test      = list(binom.test(n, N_total, conf.level = 0.95)),
    proportion = test$estimate,
    ic_bas     = test$conf.int[1],
    ic_haut    = test$conf.int[2]
  ) %>%
  ungroup() %>%
  select(lien, n, proportion, ic_bas, ic_haut) %>%
  # Ordonner par fréquence croissante pour le coord_flip
  mutate(lien = factor(lien, levels = lien[order(proportion)]))

# Affichage console
cat("\n==============================================\n")
cat("   PROPORTIONS ET IC 95% - Lien de parenté\n")
cat("==============================================\n")
resultats %>%
  mutate(
    `%`      = paste0(round(proportion * 100, 1), "%"),
    `IC 95%` = paste0("[", round(ic_bas * 100, 1), "% ; ",
                      round(ic_haut * 100, 1), "%]")
  ) %>%
  select(Modalité = lien, Effectif = n, `%`, `IC 95%`) %>%
  print()


# -----------------------------------------------------------------------------
# 3. DIAGRAMME EN BARRES HORIZONTALES
# -----------------------------------------------------------------------------
ggplot(resultats,
       aes(x = lien, y = proportion)) +
  
  # Barres
  geom_bar(stat = "identity",
           fill = "#2C9BB6",
           alpha = 0.85,
           width = 0.6) +
  
  # Intervalles de confiance
  geom_errorbar(aes(ymin = ic_bas, ymax = ic_haut),
                width  = 0.2,
                color  = "#D7991C",
                linewidth = 0.8) +
  
  # Étiquettes : % + effectif
  geom_text(aes(label = paste0(round(proportion * 100, 1), "%\n(n=",
                               scales::comma(n), ")")),
            hjust  = -0.15,
            size   = 3.5,
            color  = "grey20") +
  
  # Axe Y en pourcentage
  scale_y_continuous(
    labels = scales::percent_format(accuracy = 1),
    limits = c(0, max(resultats$ic_haut) * 1.25)
  ) +
  
  # Barres horizontales
  coord_flip() +
  
  labs(
    title    = "Lien de parenté avec le chef de ménage",
    subtitle = paste0("n = ", scales::comma(N_total),
                      " individus | Barres d'erreur = IC à 95%"),
    x        = NULL,
    y        = "Proportion (%)",
    caption  = "Source : NBS Nigeria, GHSP-Panel Wave 4 (2018/19)"
  ) +
  
  theme_minimal(base_size = 12) +
  theme(
    plot.title      = element_text(face = "bold", size = 14),
    plot.subtitle   = element_text(color = "grey40", size = 11),
    plot.caption    = element_text(color = "grey50", size = 9),
    panel.grid.major.y = element_blank(),
    panel.grid.minor   = element_blank(),
    axis.text.y     = element_text(size = 11, face = "bold")
  )
ggsave("output/frequence_lien.png", width = 14, height = 5, dpi = 300)

sect1 %>% count(sector)
# Taille ménage = nombre d'individus par hhid
sect1 %>% count(hhid) %>% summarise(min=min(n), max=max(n), mean=mean(n))





#5/
# =============================================================================
# COMPARAISON TAILLE DES MÉNAGES - URBAIN vs RURAL
# sect1_harvestw4
# 1. Calcul de la taille des ménages
# 2. Boxplot groupé
# 3. Test de Wilcoxon-Mann-Whitney
# 4. Taille d'effet : r de rang (r = Z / sqrt(N))
# =============================================================================

# -----------------------------------------------------------------------------
# 1. CHARGEMENT ET CALCUL DE LA TAILLE DES MÉNAGES
# -----------------------------------------------------------------------------
sect1<-  read_dta("data/raw/NGA-GHSP-W4/sect1_harvestw4.dta")

# Taille du ménage = nombre de membres par hhid
# On récupère aussi le secteur (urbain/rural) depuis sect1
# Un ménage a un seul secteur → on prend la première valeur non-NA
taille_menage <- sect1 %>%
  group_by(hhid) %>%
  summarise(
    taille  = n(),
    secteur = first(as.numeric(sector))
  ) %>%
  ungroup() %>%
  filter(!is.na(secteur)) %>%
  mutate(
    secteur_label = case_when(
      secteur == 1 ~ "Urbain",
      secteur == 2 ~ "Rural"
    )
  )

cat("Nombre de ménages :", nrow(taille_menage), "\n")
cat("Urbain :", sum(taille_menage$secteur_label == "Urbain"), "ménages\n")
cat("Rural  :", sum(taille_menage$secteur_label == "Rural"),  "ménages\n")


# -----------------------------------------------------------------------------
# 2. STATISTIQUES DESCRIPTIVES PAR GROUPE
# -----------------------------------------------------------------------------
stats_groupe <- taille_menage %>%
  group_by(secteur_label) %>%
  summarise(
    N        = n(),
    Moyenne  = round(mean(taille), 2),
    Mediane  = median(taille),
    Q1       = quantile(taille, 0.25),
    Q3       = quantile(taille, 0.75),
    Ecart_type = round(sd(taille), 2),
    Min      = min(taille),
    Max      = max(taille)
  )

cat("\n==============================================\n")
cat("   STATISTIQUES PAR SECTEUR\n")
cat("==============================================\n")
print(stats_groupe)


# -----------------------------------------------------------------------------
# 3. TEST DE WILCOXON-MANN-WHITNEY
# -----------------------------------------------------------------------------
urbain <- taille_menage %>% filter(secteur_label == "Urbain") %>% pull(taille)
rural  <- taille_menage %>% filter(secteur_label == "Rural")  %>% pull(taille)

wilcox_test <- wilcox.test(urbain, rural,
                           alternative = "two.sided",
                           conf.int    = TRUE,
                           conf.level  = 0.95)

cat("\n==============================================\n")
cat("   TEST DE WILCOXON-MANN-WHITNEY\n")
cat("==============================================\n")
cat("Statistique W       :", wilcox_test$statistic, "\n")
cat("p-value             :", format(wilcox_test$p.value, scientific = TRUE), "\n")
cat("Différence de loc.  :", round(wilcox_test$estimate, 3), "\n")
cat("IC 95%              : [",
    round(wilcox_test$conf.int[1], 3), ";",
    round(wilcox_test$conf.int[2], 3), "]\n")

if (wilcox_test$p.value < 0.05) {
  cat("Conclusion : ✅ Différence significative (p < 0.05)\n")
} else {
  cat("Conclusion : ❌ Différence non significative (p ≥ 0.05)\n")
}


# -----------------------------------------------------------------------------
# 4. TAILLE D'EFFET : r DE RANG
#    Formule : r = Z / sqrt(N)
#    Interprétation : |r| < 0.1 = négligeable
#                     |r| < 0.3 = petit
#                     |r| < 0.5 = moyen
#                     |r| >= 0.5 = grand  (Cohen, 1992)
# -----------------------------------------------------------------------------

# Calculer Z à partir de la p-value bilatérale
N_total <- length(urbain) + length(rural)
Z       <- qnorm(wilcox_test$p.value / 2)   # Z négatif car p-value / 2
r_rang  <- abs(Z) / sqrt(N_total)

cat("\n==============================================\n")
cat("   TAILLE D'EFFET - r de rang\n")
cat("==============================================\n")
cat("N total :", N_total, "\n")
cat("Z       :", round(Z, 4), "\n")
cat("r       :", round(r_rang, 4), "\n")

interpretation <- case_when(
  r_rang < 0.1 ~ "Négligeable",
  r_rang < 0.3 ~ "Petit",
  r_rang < 0.5 ~ "Moyen",
  TRUE         ~ "Grand"
)
cat("Interprétation :", interpretation,
    "(seuils de Cohen : 0.1 / 0.3 / 0.5)\n")


# -----------------------------------------------------------------------------
# 5. BOXPLOT GROUPÉ
# -----------------------------------------------------------------------------

# Préparer les annotations pour le graphique
label_wilcox <- paste0(
  "Wilcoxon W = ", round(wilcox_test$statistic, 0),
  "\np = ", format(wilcox_test$p.value, scientific = TRUE, digits = 3),
  "\nr = ", round(r_rang, 3), " (", interpretation, ")"
)

# Moyennes par groupe (pour le point rouge)
moyennes <- taille_menage %>%
  group_by(secteur_label) %>%
  summarise(moyenne = mean(taille))

ggplot(taille_menage,
       aes(x    = secteur_label,
           y    = taille,
           fill = secteur_label)) +
  
  # Boxplot
  geom_boxplot(alpha        = 0.75,
               outlier.color = "grey50",
               outlier.size  = 0.8,
               outlier.alpha = 0.5,
               width         = 0.5) +
  
  # Points individuels (jitter) pour voir la distribution
  geom_jitter(width = 0.15, alpha = 0.08, size = 0.6, color = "grey30") +
  
  # Point de la moyenne
  geom_point(data  = moyennes,
             aes(x = secteur_label, y = moyenne),
             shape = 18, size = 4, color = "#D7191C") +
  
  # Étiquette de la moyenne
  geom_text(data  = moyennes,
            aes(x = secteur_label,
                y = moyenne,
                label = paste0("Moy. = ", round(moyenne, 1))),
            vjust = -0.8, color = "#D7191C", size = 3.5, fontface = "bold") +
  
  # Annotation test statistique
  annotate("text",
           x     = 1.5,
           y     = max(taille_menage$taille) * 0.95,
           label = label_wilcox,
           size  = 3.5,
           color = "grey20",
           hjust = 0.5,
           vjust = 1,
           fontface = "italic") +
  
  # Couleurs
  scale_fill_manual(values = c("Urbain" = "#2D3BB6", "Rural" = "#D9691C")) +
  
  scale_y_continuous(breaks = seq(0, 35, by = 5)) +
  
  labs(
    title    = "Taille des ménages selon le secteur (Urbain vs Rural)",
    subtitle = paste0("n = ", scales::comma(nrow(taille_menage)),
                      " ménages | ◆ = Moyenne | Test de Wilcoxon-Mann-Whitney"),
    x        = NULL,
    y        = "Taille du ménage (nombre de membres)",
    caption  = "Source : NBS Nigeria, GHSP-Panel Wave 4 (2018/19)"
  ) +
  
  theme_minimal(base_size = 12) +
  theme(
    plot.title      = element_text(face = "bold", size = 14),
    plot.subtitle   = element_text(color = "grey40", size = 11),
    plot.caption    = element_text(color = "grey50", size = 9),
    legend.position = "none",
    panel.grid.minor      = element_blank(),
    panel.grid.major.x    = element_blank(),
    axis.text.x     = element_text(size = 12, face = "bold")
  )
ggsave("output/analyse_age.png", width = 14, height = 5, dpi = 300)


#6/
# =============================================================================
# TABLEAU RÉCAPITULATIF GTSUMMARY - STRATIFIÉ PAR SECTEUR
# Variables : âge (s1q4), sexe (s1q2), taille du ménage
# Stratification : sector (1=Urbain, 2=Rural)
# =============================================================================

# -----------------------------------------------------------------------------
# 1. CHARGEMENT ET PRÉPARATION
# -----------------------------------------------------------------------------
sect1 <-read_dta("data/raw/NGA-GHSP-W4/sect1_harvestw4.dta")

# --- Taille du ménage (calculée à partir de sect1) --------------------------
taille_menage <- sect1 %>%
  group_by(hhid) %>%
  summarise(taille_menage = n(), .groups = "drop")

# --- Données individuelles --------------------------------------------------
data_tableau <- sect1 %>%
  left_join(taille_menage, by = "hhid") %>%
  filter(!is.na(sector)) %>%
  transmute(
    # Secteur (variable de stratification)
    secteur = factor(
      as.numeric(sector),
      levels = c(1, 2),
      labels = c("Urbain", "Rural")
    ),
    
    # Âge (quantitative continue)
    age = as.numeric(s1q4),
    
    # Sexe (qualitative binaire)
    sexe = factor(
      as.numeric(s1q2),
      levels = c(1, 2),
      labels = c("Masculin", "Féminin")
    ),
    
    # Taille du ménage (quantitative discrète)
    taille_menage = taille_menage
  )

cat("Dimensions du tableau :", nrow(data_tableau), "x", ncol(data_tableau), "\n")
cat("Urbain :", sum(data_tableau$secteur == "Urbain", na.rm = TRUE), "\n")
cat("Rural  :", sum(data_tableau$secteur == "Rural",  na.rm = TRUE), "\n")


# -----------------------------------------------------------------------------
# 2. TABLEAU GTSUMMARY STRATIFIÉ
# -----------------------------------------------------------------------------
tableau <- data_tableau %>%
  tbl_summary(
    by = secteur,       # Stratification par secteur
    
    include = c(age, sexe, taille_menage),
    
    # Statistiques affichées
    statistic = list(
      all_continuous()  ~ "{mean} ({sd}) \n Méd. {median} [{p25} ; {p75}]",
      all_categorical() ~ "{n} ({p}%)"
    ),
    
    # Libellés des variables
    label = list(
      age           ~ "Âge (années)",
      sexe          ~ "Sexe",
      taille_menage ~ "Taille du ménage (nb. membres)"
    ),
    
    # Chiffres significatifs
    digits = list(
      all_continuous()  ~ 1,
      all_categorical() ~ c(0, 1)
    ),
    
    # Traitement des valeurs manquantes
    missing      = "ifany",
    missing_text = "Valeurs manquantes"
  ) %>%
  
  # Ajouter la colonne "Total"
  add_overall(last = FALSE, col_label = "**Total**") %>%
  
  # Ajouter les p-valeurs des tests de comparaison
  # - Wilcoxon pour les variables continues (non normales)
  # - Chi² pour les variables catégorielles
  add_p(
    test = list(
      age           ~ "wilcox.test",
      sexe          ~ "chisq.test",
      taille_menage ~ "wilcox.test"
    ),
    pvalue_fun = ~ style_pvalue(.x, digits = 3)
  ) %>%
  
  # Ajouter les effectifs par groupe en en-tête
  add_n() %>%
  
  # Mise en forme finale
  modify_header(
    label      ~ "**Variable**",
    stat_0     ~ "**Total**\nN = {N}",
    stat_1     ~ "**Urbain**\nN = {n}",
    stat_2     ~ "**Rural**\nN = {n}",
    p.value    ~ "**p-valeur**"
  ) %>%
  
  modify_spanning_header(
    c(stat_1, stat_2) ~ "**Secteur de résidence**"
  ) %>%
  
  modify_caption(
    "**Tableau 1. Caractéristiques sociodémographiques selon le secteur**
     Source : NBS Nigeria, GHSP-Panel Wave 4 (2018/19)"
  ) %>%
  
  # Note de bas de tableau
  modify_footnote(
    p.value ~ "Wilcoxon-Mann-Whitney pour variables continues ;
               Chi² de Pearson pour variables catégorielles"
  ) %>%
  
  bold_labels() %>%
  bold_p(t = 0.05)    # Met en gras les p-valeurs significatives


# -----------------------------------------------------------------------------
# 3. AFFICHAGE
# -----------------------------------------------------------------------------
tableau


# -----------------------------------------------------------------------------
# 4. EXPORT
# -----------------------------------------------------------------------------

# --- Export en HTML (le plus fidèle visuellement) ---------------------------
tableau %>%
  as_gt() %>%
  gt::gtsave("data/raw/NGA-GHSP-W4/sect1_harvestw4.dta/tableau_gtsummary.html")

# --- Export en Word (.docx) -------------------------------------------------
# install.packages("flextable")
# library(flextable)
# tableau %>%
#   as_flex_table() %>%
#   flextable::save_as_docx(
#     path = "data/raw/NGA-GHSP-W4/sect1_harvestw4.dta/tableau_gtsummary.docx"
#   )

cat("\n✅ Tableau exporté en HTML.\n")
cat("   Pour Word : décommente le bloc export .docx en bas du script.\n")
