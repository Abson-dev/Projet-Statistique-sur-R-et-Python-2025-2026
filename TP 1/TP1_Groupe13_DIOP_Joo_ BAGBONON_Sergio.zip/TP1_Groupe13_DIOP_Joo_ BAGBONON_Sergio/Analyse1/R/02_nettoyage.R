source("R/fonctions.R")

#1/

sect1_harvestw4 <- read_dta("data/raw/NGA-GHSP-W4/sect1_harvestw4.dta")
View(sect1_harvestw4)
str(sect1_harvestw4)
glimpse(sect1_harvestw4)
summary(sect1_harvestw4)

# vérifier les doublons
doublons <- sect1_harvestw4 %>%
  group_by(hhid, indiv) %>%      # groupe par ménage et individu
  tally() %>%                    # compte le nombre d'occurrences
  filter(n > 1)                  # garde ceux >1 (donc doublons)

doublons

sect1_harvestw4_sample <- sect1_harvestw4 %>% slice_sample(n = 1000) # choisir n observation au hasard
vis_miss(sect1_harvestw4_sample)                                     #visualiser les valeurs manquantes pour ces n observations

