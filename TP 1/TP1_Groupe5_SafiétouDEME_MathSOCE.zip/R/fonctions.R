# ==============================================================================
# TP1 — PROFIL DÉMOGRAPHIQUE DES MÉNAGES NIGÉRIANS
# Script  : fonctions.R
# Objet   : Fonctions personnalisées réutilisables dans les scripts TP1
# Usage   : source("R/fonctions.R")
# Auteurs : Math SOCE / Safiétou DEME — ENSAE ISE 1 (2025-2026)
# ==============================================================================
# CORRECTIFS v2 (2026-03-23)
#   FONCTION 2 resume_pondere() :
#     → Extraction des quantiles via coef() pour compatibilité survey ≥ 4.1
#       (l'ancienne indexation [[1]][i,1] plante sur les objets "newsvyquantile")
#   FONCTION 7 wilcox_pondere() :
#     → svyby() pour les médianes remplacé par svyquantile() par groupe,
#       car svyby(..., FUN = svyquantile) retourne une structure incompatible
#       depuis survey ≥ 4.1 ; extraction via coef() sur chaque sous-plan
# ==============================================================================

library(survey)

# ------------------------------------------------------------------------------
# FONCTION 1 : resume_numerique()
# Statistiques descriptives d'un vecteur numérique (non pondéré)
# Utilisée pour le contrôle qualité (diagnostics NA, doublons)
# ------------------------------------------------------------------------------

resume_numerique <- function(x, nom_var = "variable") {
  
  if (!is.numeric(x)) stop("Argument 'x' doit être numérique.")
  
  x_clean <- x[!is.na(x)]
  n       <- length(x_clean)
  
  if (n == 0) stop("Aucune observation valide après suppression des NA.")
  
  m2   <- mean((x_clean - mean(x_clean))^2)
  m3   <- mean((x_clean - mean(x_clean))^3)
  skew <- ifelse(m2 == 0, 0, m3 / m2^(3/2))
  
  cv <- ifelse(mean(x_clean) != 0,
               sd(x_clean) / mean(x_clean) * 100,
               NA_real_)
  
  q1  <- quantile(x_clean, 0.25)
  q3  <- quantile(x_clean, 0.75)
  iqr <- q3 - q1
  
  data.frame(
    variable       = nom_var,
    N              = n,
    manquants      = sum(is.na(x)),
    pct_manquants  = round(sum(is.na(x)) / length(x) * 100, 1),
    moyenne        = round(mean(x_clean),   2),
    mediane        = round(median(x_clean), 2),
    Q1             = round(q1, 2),
    Q3             = round(q3, 2),
    ecart_type     = round(sd(x_clean), 2),
    CV_pct         = round(cv, 1),
    asymetrie      = round(skew, 3),
    min            = round(min(x_clean), 2),
    max            = round(max(x_clean), 2),
    outlier_bas    = round(q1 - 1.5 * iqr, 2),
    outlier_haut   = round(q3 + 1.5 * iqr, 2),
    n_outliers     = sum(x_clean < (q1 - 1.5*iqr) | x_clean > (q3 + 1.5*iqr)),
    stringsAsFactors = FALSE
  )
}


# ------------------------------------------------------------------------------
# FONCTION 2 : resume_pondere()
# Statistiques descriptives pondérées via le plan de sondage (svydesign)
# Les résultats représentent la population nigériane, corrigés du plan d'échantillonnage
#
# CORRECTIF v2 : svyquantile() retourne un objet "newsvyquantile" depuis
# survey ≥ 4.1 ; coef() extrait proprement le vecteur des quantiles quelle
# que soit la version du package.
# ------------------------------------------------------------------------------

resume_pondere <- function(svy, var, nom_var = NULL) {
  
  if (is.null(nom_var)) nom_var <- var
  
  frm     <- as.formula(paste("~", var))
  moy_obj <- survey::svymean(frm, design = svy, na.rm = TRUE)
  moy_val <- as.numeric(coef(moy_obj))
  moy_se  <- as.numeric(SE(moy_obj))
  
  var_pond <- as.numeric(survey::svyvar(frm, design = svy, na.rm = TRUE))
  sd_pond  <- sqrt(var_pond)
  cv_pond  <- ifelse(moy_val != 0, sd_pond / moy_val * 100, NA_real_)
  
  # --- CORRECTIF : utiliser coef() — robuste à toutes les versions de survey ---
  qnt  <- survey::svyquantile(frm, design = svy,
                              quantiles = c(0.25, 0.50, 0.75),
                              na.rm = TRUE, ci = FALSE)
  vals <- as.numeric(coef(qnt))   # vecteur nommé (0.25, 0.50, 0.75)
  q1v  <- vals[1]
  med  <- vals[2]
  q3v  <- vals[3]
  
  data.frame(
    variable     = nom_var,
    N_obs        = sum(!is.na(svy$variables[[var]])),
    moyenne      = round(moy_val, 2),
    IC95_inf     = round(moy_val - 1.96 * moy_se, 2),
    IC95_sup     = round(moy_val + 1.96 * moy_se, 2),
    mediane      = round(med, 2),
    Q1           = round(q1v, 2),
    Q3           = round(q3v, 2),
    ecart_type   = round(sd_pond, 2),
    CV_pct       = round(cv_pond, 1),
    stringsAsFactors = FALSE
  )
}


# ------------------------------------------------------------------------------
# FONCTION 3 : freq_ic()
# Fréquences et IC Clopper-Pearson (non pondéré) — contrôle qualité
# ------------------------------------------------------------------------------

freq_ic <- function(x, nom_var = "variable") {
  
  if (is.factor(x)) {
    niveaux <- levels(x)
    x_clean <- x[!is.na(x)]
    n_total <- length(x_clean)
    tab <- data.frame(
      modalite = niveaux,
      effectif = as.integer(table(factor(x_clean, levels = niveaux))),
      stringsAsFactors = FALSE
    )
  } else {
    x_clean <- x[!is.na(x)]
    n_total <- length(x_clean)
    if (n_total == 0) stop("Vecteur vide après suppression des NA.")
    tab <- as.data.frame(table(x_clean), stringsAsFactors = FALSE)
    names(tab) <- c("modalite", "effectif")
  }
  
  tab$n_total    <- n_total
  tab$proportion <- tab$effectif / n_total
  tab$IC_inf     <- mapply(function(k, n) binom.test(k, n)$conf.int[1],
                           tab$effectif, tab$n_total)
  tab$IC_sup     <- mapply(function(k, n) binom.test(k, n)$conf.int[2],
                           tab$effectif, tab$n_total)
  tab$variable   <- nom_var
  tab <- tab[, c("variable","modalite","effectif","n_total","proportion","IC_inf","IC_sup")]
  tab[order(-tab$proportion), ]
}


# ------------------------------------------------------------------------------
# FONCTION 4 : freq_ic_pondere()
# Proportions pondérées et IC de Wald via survey::svymean
# Les proportions représentent la structure de la population nigériane
# ------------------------------------------------------------------------------

freq_ic_pondere <- function(svy, var, nom_var = NULL) {
  
  if (is.null(nom_var)) nom_var <- var
  
  if (!is.factor(svy$variables[[var]]))
    svy$variables[[var]] <- factor(svy$variables[[var]])
  
  res   <- survey::svymean(as.formula(paste("~", var)), design = svy, na.rm = TRUE)
  mods  <- gsub(paste0("^", var), "", names(coef(res)))
  props <- as.numeric(coef(res))
  ses   <- as.numeric(SE(res))
  
  tab_brut <- table(factor(svy$variables[[var]]))
  eff      <- as.integer(tab_brut[match(mods, names(tab_brut))])
  eff[is.na(eff)] <- 0L
  
  df <- data.frame(
    variable    = nom_var,
    modalite    = mods,
    effectif    = eff,
    proportion  = round(props, 4),
    IC_inf      = round(pmax(0, props - 1.96 * ses), 4),
    IC_sup      = round(pmin(1, props + 1.96 * ses), 4),
    stringsAsFactors = FALSE
  )
  df[order(-df$proportion), ]
}


# ------------------------------------------------------------------------------
# FONCTION 5 : creer_groupe_age()
# Groupes quinquennaux ordonnés
# ------------------------------------------------------------------------------

creer_groupe_age <- function(age, pas = 5, age_max = 80) {
  
  bornes     <- c(seq(0, age_max, by = pas), Inf)
  etiquettes <- c(paste(seq(0, age_max - pas, by = pas),
                        seq(pas - 1, age_max - 1, by = pas), sep = "-"),
                  paste0(age_max, "+"))
  cut(age, breaks = bornes, labels = etiquettes,
      right = FALSE, include.lowest = TRUE)
}


# ------------------------------------------------------------------------------
# FONCTION 6 : creer_plan_sondage()
# Construit l'objet svydesign à partir du jeu de données
# Strates = zone géopolitique × milieu ; poids = wt_wave4
# ------------------------------------------------------------------------------

creer_plan_sondage <- function(data, id_var = "ea",
                               strate = "strate_id", poids = "wt_wave4") {
  
  if (!poids %in% names(data)) stop("Colonne manquante : ", poids)
  
  if (!strate %in% names(data)) {
    if (all(c("zone_geo", "milieu") %in% names(data))) {
      data[[strate]] <- interaction(data$zone_geo, data$milieu, drop = TRUE)
    } else {
      data[[strate]] <- factor("tout")
    }
  }
  
  if (!id_var %in% names(data)) id_var <- "hhid"
  
  n0   <- nrow(data)
  data <- data[!is.na(data[[poids]]), ]
  if (nrow(data) < n0)
    message(sprintf("%d lignes supprimées (poids manquant)", n0 - nrow(data)))
  
  survey::svydesign(
    ids     = as.formula(paste("~", id_var)),
    strata  = as.formula(paste("~", strate)),
    weights = as.formula(paste("~", poids)),
    data    = data,
    nest    = TRUE
  )
}


# ------------------------------------------------------------------------------
# FONCTION 7 : wilcox_pondere()
# Test de Wilcoxon pondéré via survey::svyranktest
# Le résultat s'interprète au niveau de la population
#
# CORRECTIF v2 : calcul des médianes pondérées par groupe via svyquantile()
# sur des sous-plans (subset), puis extraction via coef(). L'ancienne approche
# svyby(..., FUN = svyquantile) produisait une structure non décodable depuis
# survey ≥ 4.1.
# ------------------------------------------------------------------------------

wilcox_pondere <- function(data, var, groupe, poids = "wt_wave4") {
  
  data_ok <- data[!is.na(data[[var]]) & !is.na(data[[groupe]]) &
                    !is.na(data[[poids]]), ]
  
  modalites <- unique(data_ok[[groupe]])
  if (length(modalites) != 2)
    stop("'", groupe, "' doit avoir exactement 2 modalités.")
  
  svy_sub <- survey::svydesign(ids = ~1,
                               weights = as.formula(paste("~", poids)),
                               data = data_ok)
  
  frm <- as.formula(paste(var, "~", groupe))
  
  res <- tryCatch(
    survey::svyranktest(frm, design = svy_sub, test = "wilcoxon"),
    error = function(e) wilcox.test(frm, data = data_ok)
  )
  
  # --- CORRECTIF : médiane pondérée par groupe via subset() + svyquantile() ---
  meds <- tryCatch({
    frm_var <- as.formula(paste("~", var))
    med_vec <- sapply(as.character(modalites), function(mod) {
      sous_plan <- subset(svy_sub, get(groupe) == mod)
      qobj      <- survey::svyquantile(frm_var, design = sous_plan,
                                       quantiles = 0.5, na.rm = TRUE, ci = FALSE)
      as.numeric(coef(qobj))[1]
    })
    med_vec
  }, error = function(e) NULL)
  
  list(test = res, p_value = res$p.value, medianes = meds)
}


# ------------------------------------------------------------------------------
# Utilitaires : sauvegarder_figure, sauvegarder_tableau, titre_section
# Recodeurs   : sexe, secteur, zone géopolitique, lien de parenté
# ------------------------------------------------------------------------------

sauvegarder_figure <- function(p, nom_fichier, largeur = 10, hauteur = 7) {
  dir.create("output/figures", recursive = TRUE, showWarnings = FALSE)
  chemin <- file.path("output", "figures", paste0(nom_fichier, ".png"))
  ggplot2::ggsave(filename = chemin, plot = p,
                  width = largeur, height = hauteur, dpi = 300, bg = "white")
  message("Figure sauvegardée : ", chemin)
}

sauvegarder_tableau <- function(df, nom_fichier) {
  dir.create("output/tables", recursive = TRUE, showWarnings = FALSE)
  chemin <- file.path("output", "tables", paste0(nom_fichier, ".csv"))
  write.csv(df, chemin, row.names = FALSE)
  message("Tableau sauvegardé : ", chemin)
}

titre_section <- function(titre) {
  sep <- paste(rep("=", 70), collapse = "")
  message("\n", sep, "\n  ", toupper(titre), "\n", sep)
}

recoder_sexe <- function(sexe_code) {
  s <- as.numeric(sexe_code)
  factor(dplyr::case_when(s == 1 ~ "Masculin", s == 2 ~ "Féminin",
                          TRUE ~ NA_character_),
         levels = c("Masculin", "Féminin"))
}

recoder_secteur <- function(sector_code) {
  s <- as.numeric(sector_code)
  factor(dplyr::case_when(s == 1 ~ "Urbain", s == 2 ~ "Rural",
                          TRUE ~ NA_character_),
         levels = c("Urbain", "Rural"))
}

recoder_zone_geopolitique <- function(zone_code) {
  z <- as.numeric(zone_code)
  factor(dplyr::case_when(
    z == 1 ~ "North Central", z == 2 ~ "North East",
    z == 3 ~ "North West",    z == 4 ~ "South East",
    z == 5 ~ "South South",   z == 6 ~ "South West",
    TRUE ~ NA_character_),
    levels = c("North Central","North East","North West",
               "South East","South South","South West"))
}

recoder_lien_parente <- function(s1q3_code) {
  code <- as.numeric(s1q3_code)
  factor(dplyr::case_when(
    code == 1             ~ "Chef de ménage",
    code == 2             ~ "Conjoint(e)",
    code %in% c(3, 4, 5) ~ "Enfant",
    code >= 6             ~ "Autre membre",
    TRUE ~ NA_character_),
    levels = c("Chef de ménage", "Conjoint(e)", "Enfant", "Autre membre"))
}