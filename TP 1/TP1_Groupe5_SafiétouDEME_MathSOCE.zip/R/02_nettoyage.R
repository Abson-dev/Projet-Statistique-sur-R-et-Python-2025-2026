# ==============================================================================
# TP1 — PROFIL DÉMOGRAPHIQUE DES MÉNAGES NIGÉRIANS
# Script  : 02_nettoyage.R
# Objet   : Recodage, nettoyage, jointures et construction du plan de sondage
# Prérequis : 01_import.R
# Auteurs : Math SOCE / Safiétou DEME — ENSAE ISE 1 (2025-2026)
# ==============================================================================

library(dplyr)
library(haven)
library(survey)

source("R/fonctions.R")


# ------------------------------------------------------------------------------
# 1 — Chargement des données brutes
# ------------------------------------------------------------------------------

titre_section("Chargement des données brutes")

sect1_w4 <- readRDS("data/processed/sect1_w4_raw.rds")
secta_w4 <- readRDS("data/processed/secta_w4_raw.rds")

message("sect1_w4 : ", nrow(sect1_w4), " individus | ", ncol(sect1_w4), " variables")
message("secta_w4 : ", nrow(secta_w4), " ménages   | ", ncol(secta_w4), " variables")


# ------------------------------------------------------------------------------
# 2 — Nettoyage de sect1_w4 (niveau individu)
# ------------------------------------------------------------------------------

titre_section("Nettoyage de sect1_w4")

sect1_clean <- sect1_w4 |>
  dplyr::rename(
    lien_parente_code = s1q3,
    sexe_code         = s1q2,
    age               = s1q4,
    resident          = s1q4a
  ) |>
  dplyr::mutate(
    sexe = recoder_sexe(sexe_code),
    age  = dplyr::case_when(
      is.na(age)  ~ NA_real_,
      age < 0     ~ NA_real_,
      age > 110   ~ NA_real_,
      TRUE        ~ as.numeric(age)
    ),
    lien_cat   = recoder_lien_parente(lien_parente_code),
    groupe_age = creer_groupe_age(age, pas = 5, age_max = 80),
    milieu     = recoder_secteur(sector),
    zone_geo   = recoder_zone_geopolitique(zone)
  )

message("Distribution sexe :")
print(table(sect1_clean$sexe, useNA = "always"))
message("\nDistribution lien_cat :")
print(table(sect1_clean$lien_cat, useNA = "always"))
message("\nDistribution milieu :")
print(table(sect1_clean$milieu, useNA = "always"))


# ------------------------------------------------------------------------------
# 3 — Nettoyage de secta_w4 (niveau ménage)
# ------------------------------------------------------------------------------

titre_section("Nettoyage de secta_w4")

secta_clean <- secta_w4 |>
  dplyr::mutate(
    milieu   = recoder_secteur(sector),
    zone_geo = recoder_zone_geopolitique(zone)
  ) |>
  dplyr::filter(!is.na(hhid))

message("secta_clean : ", nrow(secta_clean), " ménages")


# ------------------------------------------------------------------------------
# 4 — Taille du ménage : membres résidents uniquement (s1q4a == 1)
# ------------------------------------------------------------------------------

titre_section("Taille du ménage")

taille_menage <- sect1_clean |>
  dplyr::filter(as.numeric(resident) == 1) |>
  dplyr::group_by(hhid) |>
  dplyr::summarise(taille_menage = dplyr::n(), .groups = "drop")


# ------------------------------------------------------------------------------
# 5 — Jointures : individus + géographie (secta) + taille ménage
# ------------------------------------------------------------------------------

titre_section("Jointures")

sect1_clean <- sect1_clean |>
  dplyr::select(-dplyr::any_of(c("zone","sector","milieu","zone_geo","state","lga"))) |>
  dplyr::left_join(
    secta_clean |> dplyr::select(hhid, milieu, zone_geo, state, lga, wt_wave4),
    by = "hhid"
  ) |>
  dplyr::left_join(taille_menage, by = "hhid")

n_sans_milieu <- sum(is.na(sect1_clean$milieu))
message(sprintf("Individus sans milieu après jointure : %d / %d (%.1f%%)",
                n_sans_milieu, nrow(sect1_clean),
                n_sans_milieu / nrow(sect1_clean) * 100))

menage_milieu <- sect1_clean |>
  dplyr::filter(!is.na(milieu)) |>
  dplyr::group_by(hhid, milieu, zone_geo, state) |>
  dplyr::summarise(
    taille   = dplyr::n_distinct(indiv[as.numeric(resident) == 1]),
    wt_wave4 = dplyr::first(wt_wave4),
    .groups  = "drop"
  )


# ------------------------------------------------------------------------------
# 6 — Construction du plan de sondage
#
# Le GHS Panel W4 est un sondage stratifié en grappes à deux degrés :
#   strates = 6 zones géopolitiques × 2 milieux de résidence
#   PSU     = zone de dénombrement (hhid utilisé comme proxy si ea absent)
#   poids   = wt_wave4
#
# Les statistiques calculées via ces plans représentent la population
# nigériane et non simplement l'échantillon observé.
# ------------------------------------------------------------------------------

titre_section("Construction du plan de sondage")

# Plan individu — membres résidents avec poids valide
data_svy_individu <- sect1_clean |>
  dplyr::filter(as.numeric(resident) == 1, !is.na(wt_wave4))

message(sprintf("Individus résidents avec poids valide : %d", nrow(data_svy_individu)))

svy_individu <- creer_plan_sondage(data = data_svy_individu, poids = "wt_wave4")

# Plan ménage
data_svy_menage <- menage_milieu |> dplyr::filter(!is.na(wt_wave4))

message(sprintf("Ménages avec poids valide : %d", nrow(data_svy_menage)))

svy_menage <- creer_plan_sondage(data = data_svy_menage, poids = "wt_wave4")

# Vérification : la somme des poids doit approcher la population nigériane
message(sprintf("Population individus estimée : %s",
                formatC(sum(weights(svy_individu)), format = "f", digits = 0, big.mark = " ")))
message(sprintf("Population ménages estimée   : %s",
                formatC(sum(weights(svy_menage)),   format = "f", digits = 0, big.mark = " ")))


# ------------------------------------------------------------------------------
# 7 — Sauvegardes
# ------------------------------------------------------------------------------

titre_section("Sauvegarde")

saveRDS(sect1_clean,   "data/processed/sect1_w4_clean.rds")
saveRDS(secta_clean,   "data/processed/secta_w4_clean.rds")
saveRDS(taille_menage, "data/processed/taille_menage_w4.rds")
saveRDS(menage_milieu, "data/processed/menage_milieu_w4.rds")
saveRDS(svy_individu,  "data/processed/svy_individu_w4.rds")
saveRDS(svy_menage,    "data/processed/svy_menage_w4.rds")

message("Sauvegardés dans data/processed/")
message("--- Nettoyage terminé. Étape suivante : 03_analyse.R ---")
