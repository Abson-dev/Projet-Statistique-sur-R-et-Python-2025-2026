# ==============================================================================
# TP1 — PROFIL DÉMOGRAPHIQUE DES MÉNAGES NIGÉRIANS
# Script  : 03_analyse.R
# Objet   : Analyses statistiques et visualisations — Tâches 2 à 6
# Prérequis : 01_import.R puis 02_nettoyage.R
# Auteurs : Math SOCE / Safiétou DEME — ENSAE ISE 1 (2025-2026)
# ==============================================================================
# CORRECTIFS v2 (2026-03-23)
#   TÂCHE 5 — variable de taille :
#     → menage_milieu contient la colonne "taille" (calculée dans 02_nettoyage.R)
#       et sect1_clean contient "taille_menage" (jointure depuis taille_menage_w4).
#       Le tableau gtsummary (tâche 6) utilise data_tableau issu de sect1_clean,
#       donc la colonne s'appelle bien "taille_menage" ici — OK.
#       En revanche svy_menage est construit sur menage_milieu → colonne "taille".
#       Correction : resume_pondere() appelé avec var = "taille" sur svy_menage.
#   TÂCHE 6 — plan de sondage du tableau gtsummary :
#     → Ajout de zone_geo dans le plan pour cohérence avec les strates.
#     → Fallback tbl_summary conservé mais rendu plus robuste.
# ==============================================================================

library(dplyr)
library(ggplot2)
library(apyramid)
library(gtsummary)
library(rstatix)
library(patchwork)
library(scales)
library(forcats)
library(ggpubr)
library(gt)
library(survey)

source("R/fonctions.R")


# ------------------------------------------------------------------------------
# 1 — Chargement des données et des plans de sondage
# ------------------------------------------------------------------------------

titre_section("Chargement des données")

sect1_clean   <- readRDS("data/processed/sect1_w4_clean.rds")
menage_milieu <- readRDS("data/processed/menage_milieu_w4.rds")
svy_individu  <- readRDS("data/processed/svy_individu_w4.rds")
svy_menage    <- readRDS("data/processed/svy_menage_w4.rds")

message("sect1_clean : ", nrow(sect1_clean), " individus")
message("menage_milieu : ", nrow(menage_milieu), " ménages")

# Vérification des colonnes disponibles (aide au débogage)
message("Colonnes menage_milieu : ", paste(names(menage_milieu), collapse = ", "))
message("Colonnes svy_menage$variables : ",
        paste(names(svy_menage$variables), collapse = ", "))


# ------------------------------------------------------------------------------
# Thème graphique global
# ------------------------------------------------------------------------------

theme_tp1 <- ggplot2::theme_minimal(base_size = 13) +
  ggplot2::theme(
    plot.title       = ggplot2::element_text(face = "bold", size = 14),
    plot.subtitle    = ggplot2::element_text(colour = "grey40", size = 11),
    plot.caption     = ggplot2::element_text(colour = "grey55", size = 9),
    legend.position  = "bottom",
    panel.grid.minor = ggplot2::element_blank()
  )

ggplot2::theme_set(theme_tp1)


# ==============================================================================
# TÂCHE 2 — Analyse univariée de l'âge
# ==============================================================================

titre_section("Tâche 2 — Analyse univariée de l'âge")

data_age <- sect1_clean |>
  dplyr::filter(as.numeric(resident) == 1, !is.na(age))

# Statistiques pondérées — représentatives de la population nigériane
stats_age <- resume_pondere(svy_individu, var = "age", nom_var = "Age (années révolues)")

message("Statistiques pondérées de l'âge :")
print(stats_age)
sauvegarder_tableau(stats_age, "tp1_t2_stats_age")

# Test de normalité de Shapiro-Wilk (sous-échantillon — n ≤ 5 000)
age_vals <- data_age$age
set.seed(2025)
n_sw     <- min(length(age_vals), 5000)
age_sw   <- sample(age_vals, n_sw)
test_sw  <- shapiro.test(age_sw)

message(sprintf("Shapiro-Wilk : W = %.5f | p = %.3e", test_sw$statistic, test_sw$p.value))
message(ifelse(test_sw$p.value < 0.05,
               "→ Distribution non normale (p < 0,05) — tests non-paramétriques justifiés.",
               "→ Normalité non rejetée (p ≥ 0,05)."))

# Histogramme
p_hist_age <- ggplot2::ggplot(data_age, ggplot2::aes(x = age)) +
  ggplot2::geom_histogram(binwidth = 5, fill = "#1976D2", colour = "white", alpha = 0.85) +
  ggplot2::geom_vline(xintercept = stats_age$moyenne,
                      colour = "#E53935", linewidth = 1.2, linetype = "dashed") +
  ggplot2::geom_vline(xintercept = stats_age$mediane,
                      colour = "#43A047", linewidth = 1.2) +
  ggplot2::annotate("text", x = stats_age$moyenne + 1.5, y = Inf, vjust = 2, hjust = 0,
                    label = sprintf("Moy. = %.1f", stats_age$moyenne),
                    colour = "#E53935", size = 3.8) +
  ggplot2::annotate("text", x = stats_age$mediane - 1.5, y = Inf, vjust = 4, hjust = 1,
                    label = sprintf("Méd. = %.1f", stats_age$mediane),
                    colour = "#43A047", size = 3.8) +
  ggplot2::labs(
    title    = "Distribution de l'âge des membres des ménages",
    subtitle = "Nigeria GHS Panel — Vague 4 (2018) | sect1_harvestw4",
    x = "Âge (années révolues)", y = "Effectif",
    caption = sprintf("N = %d | Shapiro-Wilk : W = %.4f, p = %.2e",
                      length(age_vals), test_sw$statistic, test_sw$p.value)
  )

sauvegarder_figure(p_hist_age, "tp1_t2_histogramme_age")

# Boxplot
p_box_age <- ggplot2::ggplot(data_age, ggplot2::aes(y = age, x = "")) +
  ggplot2::geom_boxplot(fill = "#1976D2", alpha = 0.70,
                        outlier.colour = "#E53935", outlier.alpha = 0.40,
                        outlier.size = 1.5, width = 0.40) +
  ggplot2::stat_summary(fun = mean, geom = "point", shape = 18, size = 5, colour = "#E53935") +
  ggplot2::labs(title = "Boîte à moustaches de l'âge",
                subtitle = "Nigeria GHS Panel — Vague 4 (2018)",
                y = "Âge (années)", x = NULL,
                caption = "◆ rouge = moyenne") +
  ggplot2::scale_y_continuous(breaks = seq(0, 100, by = 10))

sauvegarder_figure(p_box_age, "tp1_t2_boxplot_age", largeur = 5, hauteur = 8)

p_age_combine <- p_hist_age + p_box_age +
  patchwork::plot_layout(widths = c(3, 1)) +
  patchwork::plot_annotation(title = "TP1 Tâche 2 — Analyse univariée de l'âge")

sauvegarder_figure(p_age_combine, "tp1_t2_age_combine", largeur = 14, hauteur = 7)


# ==============================================================================
# TÂCHE 3 — Pyramide des âges
# ==============================================================================

titre_section("Tâche 3 — Pyramide des âges")

# Proportions de sexe pondérées — représentatives de la population
freq_sexe_p <- freq_ic_pondere(svy_individu, var = "sexe", nom_var = "Sexe")
n_m_p <- freq_sexe_p$proportion[freq_sexe_p$modalite == "Masculin"]
n_f_p <- freq_sexe_p$proportion[freq_sexe_p$modalite == "Féminin"]
rm_pond <- round(n_m_p / n_f_p * 100, 1)
message(sprintf("Ratio de masculinité (population) : %.1f H/100F", rm_pond))

data_pyramide <- sect1_clean |>
  dplyr::filter(as.numeric(resident) == 1, !is.na(groupe_age), !is.na(sexe)) |>
  dplyr::select(groupe_age, sexe)

p_pyramide <- apyramid::age_pyramid(data = data_pyramide,
                                    age_group = "groupe_age", split_by = "sexe") +
  ggplot2::scale_fill_manual(values = c("Masculin" = "#1565C0", "Féminin" = "#C62828"),
                             name = "Sexe") +
  ggplot2::labs(
    title    = "Pyramide des âges des membres des ménages",
    subtitle = sprintf("Nigeria GHS Panel — Vague 4 (2018) | Ratio de masculinité = %.1f H/100F",
                       rm_pond),
    x = "Effectif", y = "Groupe d'âge (années)",
    caption = sprintf("N = %d | Masculin : %.1f%% | Féminin : %.1f%% (estimations population)",
                      nrow(data_pyramide), n_m_p * 100, n_f_p * 100)
  ) +
  ggplot2::theme_minimal(base_size = 12) +
  ggplot2::theme(plot.title = ggplot2::element_text(face = "bold"), legend.position = "bottom")

sauvegarder_figure(p_pyramide, "tp1_t3_pyramide_ages_w4", largeur = 9, hauteur = 11)


# ==============================================================================
# TÂCHE 4 — Fréquences du lien de parenté
# ==============================================================================

titre_section("Tâche 4 — Fréquences lien de parenté")

# Proportions pondérées — représentatives de la structure de la population
freq_lien <- freq_ic_pondere(svy_individu, var = "lien_cat", nom_var = "lien_parente")

message("Proportions du lien de parenté dans la population :")
print(freq_lien)
sauvegarder_tableau(freq_lien, "tp1_t4_freq_lien_parente")

p_lien <- ggplot2::ggplot(
  data = freq_lien,
  ggplot2::aes(x = proportion, y = forcats::fct_reorder(modalite, proportion),
               xmin = IC_inf, xmax = IC_sup, fill = modalite)
) +
  ggplot2::geom_col(alpha = 0.85, show.legend = FALSE) +
  ggplot2::geom_errorbarh(height = 0.30, linewidth = 0.90, colour = "grey30") +
  ggplot2::geom_text(ggplot2::aes(x = IC_sup,
                                  label = scales::percent(proportion, accuracy = 0.1)),
                     hjust = -0.20, size = 4.0, fontface = "bold") +
  ggplot2::scale_x_continuous(labels = scales::percent_format(accuracy = 1),
                              limits = c(0, max(freq_lien$IC_sup) * 1.18)) +
  ggplot2::scale_fill_manual(values = c("Chef de ménage" = "#1565C0",
                                        "Conjoint(e)"    = "#E91E63",
                                        "Enfant"         = "#FB8C00",
                                        "Autre membre"   = "#43A047")) +
  ggplot2::labs(
    title    = "Répartition du lien de parenté dans les ménages",
    subtitle = "Nigeria GHS Panel — Vague 4 (2018)",
    x = "Proportion dans la population (%) — IC à 95%", y = NULL,
    caption = sprintf("N = %d individus résidents | Estimations au niveau population",
                      sum(freq_lien$effectif))
  )

sauvegarder_figure(p_lien, "tp1_t4_barplot_lien_parente")


# ==============================================================================
# TÂCHE 5 — Taille du ménage : rural vs urbain
# ==============================================================================
# NOTE : svy_menage est construit sur menage_milieu dont la colonne de taille
# s'appelle "taille" (calculée dans 02_nettoyage.R par n_distinct(indiv)).
# sect1_clean contient "taille_menage" (jointure depuis taille_menage_w4).
# Ces deux colonnes sont utilisées dans des contextes différents — ne pas mélanger.
# ==============================================================================

titre_section("Tâche 5 — Taille du ménage rural vs urbain")

# Statistiques pondérées par milieu — représentatives de la population
# CORRECTIF : var = "taille" (nom dans svy_menage/menage_milieu)
svy_rural  <- subset(svy_menage, milieu == "Rural")
svy_urbain <- subset(svy_menage, milieu == "Urbain")

sr <- resume_pondere(svy_rural,  var = "taille", nom_var = "Rural")
su <- resume_pondere(svy_urbain, var = "taille", nom_var = "Urbain")

stats_taille <- rbind(sr, su)
message("Statistiques pondérées de la taille du ménage par milieu :")
print(stats_taille)
sauvegarder_tableau(stats_taille, "tp1_t5_stats_taille_milieu")

# Test de Wilcoxon pondéré — différence dans la population
# CORRECTIF : var = "taille" (nom dans menage_milieu)
test_w <- wilcox_pondere(data = menage_milieu, var = "taille",
                         groupe = "milieu", poids = "wt_wave4")

message(sprintf("Test de Wilcoxon pondéré : p = %.4e", test_w$p_value))
if (!is.null(test_w$medianes))
  message("Médianes dans la population : ",
          paste(names(test_w$medianes), round(test_w$medianes, 1), sep = "=", collapse = " | "))

# Taille d'effet r de rang (non pondéré — indicateur relatif)
# CORRECTIF : variable "taille" dans menage_milieu
effet_r <- menage_milieu |> rstatix::wilcox_effsize(taille ~ milieu)

p_box_taille <- ggplot2::ggplot(menage_milieu,
                                ggplot2::aes(x = milieu, y = taille, fill = milieu)) +
  ggplot2::geom_boxplot(alpha = 0.75, width = 0.50,
                        outlier.alpha = 0.40, outlier.colour = "#E53935") +
  ggplot2::stat_summary(fun = median, geom = "text",
                        ggplot2::aes(label = after_stat(round(y, 1))),
                        vjust = -0.60, size = 4.2, fontface = "bold", colour = "grey15") +
  ggpubr::stat_compare_means(method = "wilcox.test", label = "p.format",
                             label.x = 1.5, label.y.npc = 0.96) +
  ggplot2::scale_fill_manual(values = c("Urbain" = "#FF7043", "Rural" = "#42A5F5")) +
  ggplot2::labs(
    title    = "Taille des ménages selon le milieu de résidence",
    subtitle = sprintf("Moyenne dans la population — Rural : %.1f | Urbain : %.1f membres",
                       sr$moyenne, su$moyenne),
    x = "Milieu de résidence", y = "Nombre de membres résidents", fill = NULL,
    caption = sprintf("N = %d ménages | Wilcoxon pondéré p = %.2e | r = %.3f (%s)",
                      nrow(menage_milieu), test_w$p_value,
                      effet_r$effsize, effet_r$magnitude)
  ) +
  ggplot2::theme(legend.position = "none")

sauvegarder_figure(p_box_taille, "tp1_t5_boxplot_taille_milieu", largeur = 7, hauteur = 7)


# ==============================================================================
# TÂCHE 6 — Tableau gtsummary pondéré stratifié par milieu
# ==============================================================================

titre_section("Tâche 6 — Tableau gtsummary pondéré")

# CORRECTIF : "taille_menage" est bien le nom dans sect1_clean (jointure depuis
# taille_menage_w4) — cohérent avec le select() ci-dessous.
data_tableau <- sect1_clean |>
  dplyr::filter(as.numeric(resident) == 1, !is.na(milieu), !is.na(wt_wave4)) |>
  dplyr::select(age, sexe, taille_menage, milieu, zone_geo, wt_wave4)

message(sprintf("N individus dans le tableau : %d", nrow(data_tableau)))

# Plan de sondage pour gtsummary — strates incluses pour cohérence
plan_tab <- survey::svydesign(
  ids     = ~1,
  strata  = ~interaction(zone_geo, milieu, drop = TRUE),
  weights = ~wt_wave4,
  data    = data_tableau,
  nest    = TRUE
)

tbl_milieu <- tryCatch({
  plan_tab |>
    gtsummary::tbl_svysummary(
      by = milieu,
      statistic = list(
        gtsummary::all_continuous()  ~ "{mean} ({sd})",
        gtsummary::all_categorical() ~ "{n_unweighted} ({p}%)"
      ),
      label = list(
        age           ~ "Âge (années révolues)",
        sexe          ~ "Sexe",
        taille_menage ~ "Taille du ménage (membres résidents)",
        zone_geo      ~ "Zone géopolitique"
      ),
      digits       = gtsummary::all_continuous() ~ 1,
      missing_text = "(Manquant)"
    ) |>
    gtsummary::add_overall(last = FALSE) |>
    gtsummary::add_p(
      test = list(
        age           ~ "svy.wilcox.test",
        sexe          ~ "svy.chisq.test",
        taille_menage ~ "svy.wilcox.test",
        zone_geo      ~ "svy.chisq.test"
      ),
      pvalue_fun = function(x) gtsummary::style_pvalue(x, digits = 3)
    ) |>
    gtsummary::bold_labels() |>
    gtsummary::italicize_levels() |>
    gtsummary::modify_header(label ~ "**Caractéristique**") |>
    gtsummary::modify_caption(
      "**Tableau 1. Caractéristiques démographiques par milieu de résidence**\n*Nigeria GHS Panel — Vague 4 (2018)*"
    )
}, error = function(e) {
  message("tbl_svysummary non disponible — utilisation de tbl_summary : ", e$message)
  data_tableau |>
    gtsummary::tbl_summary(
      by = milieu,
      statistic = list(
        gtsummary::all_continuous()  ~ "{median} ({p25}–{p75})",
        gtsummary::all_categorical() ~ "{n} ({p}%)"
      ),
      label = list(
        age           ~ "Âge (années révolues)",
        sexe          ~ "Sexe",
        taille_menage ~ "Taille du ménage (membres résidents)",
        zone_geo      ~ "Zone géopolitique"
      ),
      digits       = gtsummary::all_continuous() ~ 1,
      missing_text = "(Manquant)"
    ) |>
    gtsummary::add_overall(last = FALSE) |>
    gtsummary::add_p(
      test = list(age ~ "wilcox.test", sexe ~ "chisq.test",
                  taille_menage ~ "wilcox.test", zone_geo ~ "chisq.test"),
      pvalue_fun = function(x) gtsummary::style_pvalue(x, digits = 3)
    ) |>
    gtsummary::bold_labels() |>
    gtsummary::italicize_levels() |>
    gtsummary::modify_header(label ~ "**Caractéristique**") |>
    gtsummary::modify_caption("**Tableau 1. Caractéristiques démographiques par milieu**")
})

print(tbl_milieu)

dir.create("output/tables", recursive = TRUE, showWarnings = FALSE)
tbl_milieu |> gtsummary::as_gt() |>
  gt::gtsave("output/tables/tp1_t6_tableau_gtsummary_milieu.html")


# ==============================================================================
# Figure de synthèse
# ==============================================================================

titre_section("Figure de synthèse")

p_synthese <- (p_hist_age + p_box_age) / (p_pyramide | p_lien) / p_box_taille +
  patchwork::plot_annotation(
    title    = "TP1 — Profil démographique des ménages nigérians (2018)",
    subtitle = "Nigeria GHS Panel — Vague 4 | ENSAE ISE 1 (2025-2026)",
    caption  = "Source : World Bank LSMS-ISA"
  )

sauvegarder_figure(p_synthese, "tp1_synthese", largeur = 16, hauteur = 22)

message("--- Analyses terminées. Étape suivante : rapport/tp1_rapport.Rmd ---")