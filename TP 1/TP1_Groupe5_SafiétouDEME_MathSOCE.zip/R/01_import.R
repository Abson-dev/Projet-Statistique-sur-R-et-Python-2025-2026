# ==============================================================================
# TP1 — PROFIL DÉMOGRAPHIQUE DES MÉNAGES NIGÉRIANS
# Script  : 01_import.R
# Objet   : Chargement, exploration et contrôle qualité des données brutes
# Données : sect1_harvestw4.dta  |  secta_harvestw4.dta
# Auteurs  : Math SOCE / Safiétou DEME — ENSAE ISE 1 (2025-2026)

# ------------------------------------------------------------------------------
# SECTION 0 — PACKAGES ET FONCTIONS
# ------------------------------------------------------------------------------

library(haven)    # lire les fichiers Stata .dta (conserve labels)
library(dplyr)    # manipulation de données
library(naniar)   # diagnostic des valeurs manquantes
library(ggplot2)  # visualisation

source("R/fonctions.R")

# ------------------------------------------------------------------------------
# SECTION 1 — PARAMÈTRES
# ------------------------------------------------------------------------------

DOSSIER_RAW       <- "data/raw"
DOSSIER_PROCESSED <- "data/processed"

dir.create(DOSSIER_PROCESSED, recursive = TRUE, showWarnings = FALSE)


# ==============================================================================
# SECTION 2 — IMPORT DE sect1_harvestw4
# Niveau : individu (un enregistrement par membre du ménage)
# Clé    : hhid + indiv  (NB : le nom exact est 'indiv', pas 'indiv_id')
# ==============================================================================

titre_section("Import de sect1_harvestw4")

sect1_w4 <- haven::read_dta(
  file.path(DOSSIER_RAW, "sect1_harvestw4.dta")
)

# ---- 2.1 Dimensions et aperçu ----
message(sprintf("Dimensions : %d lignes × %d colonnes", nrow(sect1_w4), ncol(sect1_w4)))
message("\nAperçu (6 premières lignes) :")
print(head(sect1_w4[, c("hhid", "indiv", "s1q4a", "s1q2", "s1q3", "s1q4", "zone", "sector")], 6))

# ---- 2.2 Exploration des labels Stata ----
# Critique pour comprendre le codage exact avant tout recodage
message("\nLabels des variables clés :")
vars_a_explorer <- c("s1q2", "s1q3", "s1q4a", "zone", "sector")
for (v in vars_a_explorer) {
  if (v %in% names(sect1_w4)) {
    lbl <- attr(sect1_w4[[v]], "labels")
    if (!is.null(lbl)) {
      message(sprintf("  %s : %s", v, paste(names(lbl), "=", lbl, collapse = " | ")))
    } else {
      message(sprintf("  %s : (pas de labels Stata)", v))
    }
  }
}

# ---- 2.3 Distinction zone géopolitique vs milieu de résidence ----
# C'est ici le POINT LE PLUS IMPORTANT du script :
# 'zone'   → 6 zones géopolitiques du Nigeria (North Central, North East…)
# 'sector' → milieu de résidence : 1=Urbain, 2=Rural

message("\n--- DISTINCTION zone (géopolitique) vs sector (milieu) ---")
message("Distribution de 'zone' :")
print(table(as.numeric(sect1_w4$zone), useNA = "always"))

message("\nDistribution de 'sector' :")
print(table(as.numeric(sect1_w4$sector), useNA = "always"))

message("\nCroisement zone × sector (fréquences brutes) :")
print(table(zone   = as.numeric(sect1_w4$zone),
            sector = as.numeric(sect1_w4$sector),
            useNA  = "always"))

# ---- 2.4 Variable de lien de parenté : s1q3 (pas s1q11) ----
# s1q3  = relation au chef de ménage (15 modalités, codes 1–15)
# s1q11 = conjoint vit-il dans le ménage ? (oui/non) → USAGE INCORRECT en v1

message("\n--- LIEN DE PARENTÉ : utiliser s1q3, pas s1q11 ---")
message("Distribution de s1q3 (RELATION AU CHEF) :")
print(table(as.numeric(sect1_w4$s1q3), useNA = "always"))
message("Distribution de s1q11 (CONJOINT DANS MÉNAGE? oui/non) — ne pas utiliser pour lien_cat :")
print(table(as.numeric(sect1_w4$s1q11), useNA = "always"))

# ---- 2.5 Membres résidents vs non-résidents ----
# s1q4a = 1 → membre encore dans le ménage (RÉSIDENT)
# s1q4a = 2 → membre parti entre les deux visites (NON-RÉSIDENT)
# La taille du ménage = nombre de membres avec s1q4a == 1

message("\n--- FILTRE MEMBRES RÉSIDENTS (s1q4a) ---")
print(table(s1q4a = as.numeric(sect1_w4$s1q4a), useNA = "always"))
message(sprintf(
  "Membres résidents (s1q4a=1) : %d | Non-résidents (s1q4a=2) : %d | Sans info : %d",
  sum(sect1_w4$s1q4a == 1, na.rm = TRUE),
  sum(sect1_w4$s1q4a == 2, na.rm = TRUE),
  sum(is.na(sect1_w4$s1q4a))
))

# ---- 2.6 Vérification doublons sur clé primaire (hhid + indiv) ----
n_doublons_sect1 <- sect1_w4 |>
  dplyr::group_by(hhid, indiv) |>
  dplyr::filter(dplyr::n() > 1) |>
  nrow()

message(sprintf("\n>>> Doublons sur (hhid + indiv) : %d", n_doublons_sect1))
if (n_doublons_sect1 > 0) warning("Des doublons existent sur la clé primaire !")

# ---- 2.7 Valeurs manquantes — toutes les variables clés ----
vars_cles_sect1 <- c("hhid", "indiv", "s1q4a", "s1q2", "s1q3", "s1q4",
                     "zone", "sector")

message("\nValeurs manquantes — variables clés sect1 :")
print(
  sect1_w4 |>
    dplyr::select(dplyr::all_of(vars_cles_sect1)) |>
    naniar::miss_var_summary()
)

# ---- 2.8 Plausibilité de l'âge ----
age_vals_brut <- as.numeric(sect1_w4$s1q4)
message(sprintf(
  "\nÂge brut : min=%.0f, max=%.0f, NA=%.0f (%.1f%%)",
  min(age_vals_brut, na.rm = TRUE),
  max(age_vals_brut, na.rm = TRUE),
  sum(is.na(age_vals_brut)),
  sum(is.na(age_vals_brut)) / nrow(sect1_w4) * 100
))
message("Âges > 100 ans (potentiellement aberrants) :")
print(table(ifelse(age_vals_brut > 100, "> 100", "≤ 100"), useNA = "always"))

# ---- 2.9 Heatmap NA — variables clés ----
p_miss_sect1 <- sect1_w4 |>
  dplyr::select(dplyr::all_of(vars_cles_sect1)) |>
  naniar::vis_miss() +
  ggplot2::labs(
    title    = "Valeurs manquantes — sect1_harvestw4 (variables clés)",
    subtitle = "TP1 Démographie — Nigeria GHS Panel W4 (2018)"
  ) +
  ggplot2::theme_minimal(base_size = 12)

sauvegarder_figure(p_miss_sect1, "tp1_missing_sect1_cles", largeur = 9, hauteur = 5)


# ==============================================================================
# SECTION 3 — IMPORT DE secta_harvestw4
# Niveau : ménage (une ligne par ménage)
# Clé    : hhid
# Variables clés : sector (1=Urbain/2=Rural), zone (géopolitique), state, lga,
#                  wt_wave4 (poids d'enquête)
# ==============================================================================

titre_section("Import de secta_harvestw4")

secta_w4 <- haven::read_dta(
  file.path(DOSSIER_RAW, "secta_harvestw4.dta")
)

message(sprintf("Dimensions : %d ménages × %d colonnes", nrow(secta_w4), ncol(secta_w4)))
dplyr::glimpse(secta_w4)

# ---- 3.1 Doublons sur hhid ----
n_doublons_secta <- secta_w4 |>
  dplyr::group_by(hhid) |>
  dplyr::filter(dplyr::n() > 1) |>
  nrow()
message(sprintf(">>> Doublons sur hhid : %d", n_doublons_secta))

# ---- 3.2 Vérification des variables géographiques dans secta ----
message("\nDistribution de sector dans secta (VARIABLE MILIEU CORRECT) :")
print(table(as.numeric(secta_w4$sector), useNA = "always"))

message("\nDistribution de zone dans secta (ZONES GÉOPOLITIQUES) :")
print(table(as.numeric(secta_w4$zone), useNA = "always"))

# ---- 3.3 Poids d'enquête ----
# wt_wave4 est le poids de sondage W4 ; wt_longpanel pour le panel longitudinal
# Pour des analyses représentatives, il faudra pondérer par wt_wave4
message("\nRésumé des poids d'enquête (wt_wave4) :")
print(summary(secta_w4$wt_wave4))
message(sprintf("NA sur wt_wave4 : %d", sum(is.na(secta_w4$wt_wave4))))

# ---- 3.4 Cohérence hhid sect1 ↔ secta ----
n_hh_sect1  <- dplyr::n_distinct(sect1_w4$hhid)
n_hh_secta  <- dplyr::n_distinct(secta_w4$hhid)
n_hh_commun <- dplyr::n_distinct(intersect(sect1_w4$hhid, secta_w4$hhid))

message(sprintf(
  "\nMénages uniques — sect1: %d | secta: %d | en commun: %d",
  n_hh_sect1, n_hh_secta, n_hh_commun
))
if (n_hh_commun < n_hh_secta) {
  message("ATTENTION : tous les ménages de secta ne sont pas dans sect1.")
}

# ---- 3.5 NA sur variables clés secta ----
vars_cles_secta <- c("hhid", "zone", "sector", "state", "lga", "wt_wave4")
message("\nValeurs manquantes — variables clés secta :")
print(
  secta_w4 |>
    dplyr::select(dplyr::all_of(vars_cles_secta)) |>
    naniar::miss_var_summary()
)


# ==============================================================================
# SECTION 4 — SAUVEGARDE AU FORMAT .rds
# ==============================================================================

titre_section("Sauvegarde des données brutes")

saveRDS(sect1_w4, file.path(DOSSIER_PROCESSED, "sect1_w4_raw.rds"))
saveRDS(secta_w4, file.path(DOSSIER_PROCESSED, "secta_w4_raw.rds"))

# Tableau récapitulatif
recap_import <- data.frame(
  Fichier       = c("sect1_harvestw4", "secta_harvestw4"),
  Niveau        = c("Individu", "Ménage"),
  N_lignes      = c(nrow(sect1_w4),  nrow(secta_w4)),
  N_variables   = c(ncol(sect1_w4),  ncol(secta_w4)),
  Doublons_cle  = c(n_doublons_sect1, n_doublons_secta),
  Var_milieu    = c("sector (dans sect1)", "sector (dans secta)"),
  Var_geo       = c("zone (géopolitique)", "zone (géopolitique)")
)
print(recap_import)
sauvegarder_tableau(recap_import, "tp1_recap_import")

message("\n--- Import TP1 terminé. Étape suivante : 02_nettoyage.R ---")