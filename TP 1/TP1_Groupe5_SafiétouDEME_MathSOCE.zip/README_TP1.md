# TP1 — Profil démographique des ménages nigérians

**Cours** : Projet Statistique sous R et Python — ENSAE ISE 1 (2025-2026)  
**Auteurs** : Math SOCE / Safietou DEME  
**Données** : Nigeria General Household Survey Panel — Vague 4 (2018)  
**Tâches** : T1 à T6

---

## Structure du projet

```
TP1_Demographie/
├── data/
│   ├── raw/                        # Fichiers .dta originaux (non modifiés)
│   │   ├── sect1_harvestw4.dta     # Roster individus (sexe, âge, lien parenté)
│   │   └── secta_harvestw4.dta     # Ménages (milieu, zone, poids sondage)
│   └── processed/                  # Fichiers .rds nettoyés (générés par scripts)
│       ├── sect1_w4_clean.rds
│       ├── secta_w4_clean.rds
│       ├── taille_menage_w4.rds
│       └── menage_milieu_w4.rds
├── R/
│   └── fonctions.R                 # Fonctions personnalisées (voir section dédiée)
├── output/
│   ├── figures/                    # PNG 300 dpi (générés par 03_analyse.R)
│   └── tables/                     # CSV et HTML (générés par 03_analyse.R)
├── rapport/
│   ├── tp1_rapport.Rmd             # Rapport principal (9 pages PDF)
│   └── preamble.tex                # En-tête LaTeX (doit être dans ce dossier)
├── 01_import.R                     # Étape 1 : import et exploration
├── 02_nettoyage.R                  # Étape 2 : nettoyage et recodage
├── 03_analyse.R                    # Étape 3 : analyses et figures
└── TP1_Demographie.Rproj
```

---

## Données mobilisées

| Fichier | Niveau | Variables clés |
|---|---|---|
| `sect1_harvestw4.dta` | Individu | `s1q2` (sexe), `s1q3` (lien parenté), `s1q4` (âge), `s1q4a` (résident) |
| `secta_harvestw4.dta` | Ménage | `zone` (géopolitique), `sector` (milieu), `state`, `wt_wave4` |

> **Attention** : `zone` (1–6) = zones géopolitiques ≠ `sector` (1=Urbain, 2=Rural).  
> Toujours utiliser `sector` pour les comparaisons rural/urbain.

---

## Variables construites

| Variable R | Source | Description |
|---|---|---|
| `age` | `s1q4` | Âge en années révolues, nettoyé (0–110) |
| `sexe` | `s1q2` | Facteur : Masculin / Féminin |
| `lien_cat` | `s1q3` | 4 catégories : Chef / Conjoint(e) / Enfant / Autre |
| `groupe_age` | `s1q4` | Groupes quinquennaux pour pyramide |
| `milieu` | `sector` (secta) | Facteur : Urbain / Rural |
| `zone_geo` | `zone` (secta) | 6 zones géopolitiques |
| `taille_menage` | calculée | Nb membres résidents par ménage (`s1q4a == 1`) |
| `resident` | `s1q4a` | 1 = encore dans le ménage, 2 = parti |
| `wt_wave4` | secta | Poids de sondage vague 4 |

---

## Tâches et méthodes

| Tâche | Contenu | Méthode |
|---|---|---|
| T1 | Contrôle qualité : doublons, valeurs manquantes | `naniar::vis_miss`, `miss_var_summary` |
| T2 | Analyse univariée de l'âge : stats descriptives + normalité | `resume_numerique()`, `shapiro.test` |
| T3 | Pyramide des âges par sexe | `apyramid::age_pyramid` |
| T4 | Fréquences lien de parenté + IC 95 % | `freq_ic()` (Clopper-Pearson) |
| T5 | Taille ménage rural vs urbain | `rstatix::wilcox_test`, `wilcox_effsize` |
| T6 | Tableau de synthèse gtsummary | `gtsummary::tbl_summary`, `add_p` |

---

## Fonctions personnalisées requises (`R/fonctions.R`)

| Fonction | Usage dans TP1 | Valeurs retournées attendues |
|---|---|---|
| `resume_numerique(x, nom_var)` | T2 : stats de l'âge | Liste avec : `N`, `manquants`, `pct_manquants`, `moyenne`, `mediane`, `Q1`, `Q3`, `ecart_type`, `CV_pct`, `asymetrie`, `min`, `max`, `outlier_bas`, `outlier_haut`, `n_outliers` |
| `freq_ic(x, nom_var)` | T4 : IC Clopper-Pearson | Tibble avec : `modalite`, `effectif`, `n_total`, `proportion`, `IC_inf`, `IC_sup` |

> **Point critique** : les noms de champs retournés par `resume_numerique()` sont  
> utilisés directement en inline R dans le rapport (`stats_age$mediane`, etc.).  
> Tout écart de nom produit un `NULL` silencieux dans le PDF.

---

## Instructions pour compiler le rapport

### Prérequis

```r
install.packages(c(
  "haven", "dplyr", "tidyr", "ggplot2", "apyramid",
  "gtsummary", "rstatix", "patchwork", "scales",
  "forcats", "ggpubr", "gt", "naniar", "knitr", "kableExtra"
))
```

### Ordre d'exécution

```r
# 1. Depuis la racine du projet TP1_Demographie/
source("01_import.R")      # Génère data/processed/*_raw.rds
source("02_nettoyage.R")   # Génère data/processed/*_clean.rds + taille_menage + menage_milieu
source("03_analyse.R")     # Génère output/figures/ et output/tables/

# 2. Compiler le rapport
rmarkdown::render("rapport/tp1_rapport.Rmd")
```

> **Important** : `preamble.tex` doit être dans le même dossier que `tp1_rapport.Rmd`.  
> Le moteur LaTeX utilisé est **XeLaTeX** (`latex_engine: xelatex`).  
> Vérifier que XeLaTeX est installé : `tinytex::install_tinytex()` si besoin.

### Encodage

Sauvegarder `tp1_rapport.Rmd` en **UTF-8** (File → Save with Encoding dans RStudio)  
pour que les accents dans `scale_fill_manual` ("Féminin", etc.) compilent correctement.

---

## Résultats attendus

- Âge médian ≈ 17 ans, asymétrie positive (γ₁ > 0)
- Shapiro-Wilk : H₀ rejetée → tests non-paramétriques justifiés
- Pyramide expansive, RM global ≈ 100 H/100 F
- Enfants ≈ 50 % des membres résidents
- Ménages ruraux significativement plus grands (WMW p < 0,001, effet faible)
- Toutes les différences urbain/rural significatives au seuil 1 % (gtsummary)

---

## Points de vigilance

- `taille_menage` doit être une colonne de `sect1_clean` après jointure dans `02_nettoyage.R`
- `as.numeric(resident)` sur haven_labelled : préférer `as.integer(haven::zap_labels(resident))`
- `pivot_wider` dans T3 : ajouter `values_fill = list(n = 0)` pour éviter les NA dans le RM
- `twmw$n1`, `twmw$n2` : noms de colonnes qui varient selon la version de `rstatix` — vérifier avec `names(wilcox_test(...))`
