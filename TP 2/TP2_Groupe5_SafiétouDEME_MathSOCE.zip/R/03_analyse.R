# ==============================================================================
# TP2 — ÉDUCATION ET ALPHABÉTISATION
# Script  : 03_analyse.R
# Objet   : Tâches 7 à 12
# Prérequis : 01_import.R → 02_nettoyage.R
# Packages  : haven, dplyr, forcats, ggplot2, rstatix, ggpubr,
#             gtsummary, viridis, patchwork
# ==============================================================================


# ------------------------------------------------------------------------------
# SECTION 0 — PACKAGES ET FONCTIONS
# ------------------------------------------------------------------------------

library(dplyr)
library(ggplot2)
library(forcats)
library(rstatix)
library(ggpubr)
library(gtsummary)
library(viridis)
library(patchwork)
library(scales)
library(knitr)

source("R/fonctions.R")


# ------------------------------------------------------------------------------
# SECTION 1 — CHARGEMENT
# ------------------------------------------------------------------------------

titre_section("Chargement des données nettoyées")

df_joint <- readRDS("data/processed/tp2_df_joint.rds")
adultes  <- readRDS("data/processed/tp2_adultes.rds")
enfants  <- readRDS("data/processed/tp2_enfants.rds")

message(sprintf("df_joint : %d obs | adultes : %d | enfants : %d",
                nrow(df_joint), nrow(adultes), nrow(enfants)))


# ------------------------------------------------------------------------------
# SECTION 2 — THÈME GRAPHIQUE
# ------------------------------------------------------------------------------

theme_tp2 <- theme_minimal(base_size = 12) +
  theme(
    plot.title       = element_text(face = "bold", size = 13),
    plot.subtitle    = element_text(colour = "grey40", size = 10),
    plot.caption     = element_text(colour = "grey55", size = 8),
    legend.position  = "bottom",
    panel.grid.minor = element_blank()
  )
theme_set(theme_tp2)

# Palette par niveau d'éducation (5 couleurs ordonnées)
pal_educ <- c(
  "Aucun"            = "#D32F2F",   # rouge — absence de formation
  "Primaire"         = "#FF8F00",   # orange
  "Junior Secondary" = "#FDD835",   # jaune
  "Senior Secondary" = "#388E3C",   # vert
  "Tertiaire"        = "#1565C0"    # bleu
)


# ==============================================================================
# TÂCHE 7 — IMPORT, JOINTURE ET INSPECTION DES NA
# ==============================================================================

titre_section("Tache 7 -- Import, jointure, NA")

# Les jointures sont faites dans 02_nettoyage.R
# Ici : vérification documentée + rapport des NA

message("Dimensions après jointure sect2 + sect1 + secta :")
message(sprintf("  %d individus x %d variables", nrow(df_joint), ncol(df_joint)))

# NA sur la variable centrale niveau_educ
na_niveau <- sum(is.na(df_joint$niveau_educ))
message(sprintf("\nNA sur niveau_educ (total) : %d / %d (%.2f%%)",
                na_niveau, nrow(df_joint),
                na_niveau / nrow(df_joint) * 100))

# Tableau complet des NA sur variables analytiques
tab_na_t7 <- df_joint |>
  dplyr::select(hhid, indiv, s2aq9, s2aq6, niveau_educ,
                age, sexe, milieu, state) |>
  naniar::miss_var_summary()

message("\nRésumé NA — variables analytiques TP2 :")
print(tab_na_t7)
sauvegarder_tableau(tab_na_t7, "tp2_t7_na_variables")

# Heatmap NA
p_miss_t7 <- df_joint |>
  dplyr::select(s2aq9, s2aq6, niveau_educ, age, sexe, milieu, state) |>
  naniar::vis_miss() +
  labs(title    = "Valeurs manquantes -- variables cles TP2",
       subtitle = "GHS-Panel W3 (2015)")

sauvegarder_figure(p_miss_t7, "tp2_t7_missing", largeur = 9, hauteur = 5)

# ==============================================================================
# TÂCHE 8 — DISTRIBUTION DE niveau_educ : FRÉQUENCES ET BARPLOT
# ==============================================================================

titre_section("Tache 8 -- Distribution niveau_educ")

# Travailler sur adultes >= 18 ans avec niveau renseigné
adultes_8 <- adultes |> dplyr::filter(!is.na(niveau_educ))
message(sprintf("N adultes 18+ avec niveau_educ : %d", nrow(adultes_8)))

# Fréquences + IC Clopper-Pearson
freq_niveau <- freq_ic(adultes_8$niveau_educ, nom_var = "niveau_educ")
message("\nFréquences et IC 95% du niveau d'éducation :")
print(freq_niveau)
sauvegarder_tableau(freq_niveau, "tp2_t8_freq_niveau_educ")

# Barplot horizontal coloré par catégorie
p_t8 <- ggplot(
  freq_niveau,
  aes(x    = proportion,
      y    = forcats::fct_reorder(modalite, proportion),
      xmin = IC_inf, xmax = IC_sup,
      fill = modalite)
) +
  geom_col(alpha = 0.88, show.legend = FALSE) +
  geom_errorbarh(height = 0.30, linewidth = 0.85, colour = "grey30") +
  geom_text(
    aes(x = IC_sup,
        label = scales::percent(proportion, accuracy = 0.1)),
    hjust = -0.15, size = 3.8, fontface = "bold"
  ) +
  scale_x_continuous(
    labels = percent_format(accuracy = 1),
    limits = c(0, max(freq_niveau$IC_sup) * 1.18)
  ) +
  scale_fill_manual(values = pal_educ) +
  labs(
    title    = "Distribution du niveau d'education des adultes (18+)",
    subtitle = "Nigeria GHS Panel -- Vague 3 (2015) | N = 13 311 adultes",
    x        = "Proportion (%) -- IC 95% Clopper-Pearson",
    y        = NULL,
    caption  = sprintf("N = %d adultes >= 18 ans avec niveau renseigne",
                       nrow(adultes_8))
  )

sauvegarder_figure(p_t8, "tp2_t8_barplot_niveau_educ", largeur = 10, hauteur = 6)


# ==============================================================================
# TÂCHE 9 — NIVEAU D'ÉDUCATION HOMMES VS FEMMES (ADULTES 18+)
#           Barplot 100% empilé + chi-deux + V de Cramér
# ==============================================================================

titre_section("Tache 9 -- Niveau education par sexe")

adultes_9 <- adultes |>
  dplyr::filter(!is.na(niveau_educ), !is.na(sexe))

message(sprintf("N adultes 18+ avec niveau ET sexe : %d", nrow(adultes_9)))

# ---- 9.1 Tableau de contingence ----
tab_sexe_niveau <- table(
  Sexe   = adultes_9$sexe,
  Niveau = adultes_9$niveau_educ
)
message("\nTableau de contingence Sexe × Niveau :")
print(tab_sexe_niveau)
message("\nTableau en % ligne :")
print(round(prop.table(tab_sexe_niveau, margin = 1) * 100, 1))

# ---- 9.2 Test du chi-deux ----
# H0 : indépendance entre sexe et niveau d'éducation
# H1 : association significative
chi2_t9 <- chisq.test(tab_sexe_niveau, correct = FALSE)
message("\nTest du chi-deux :")
print(chi2_t9)
# Vérification effectifs théoriques >= 5
message("Effectifs théoriques (min) :")
message(sprintf("  min = %.1f", min(chi2_t9$expected)))

# ---- 9.3 V de Cramér ----
v_t9 <- calc_cramer_v(tab = tab_sexe_niveau)
message(sprintf("\nV de Cramer = %.4f => association '%s'",
                v_t9$V, v_t9$interpretation))

# Sauvegarder résultats
res_t9 <- data.frame(
  Test        = "Chi-deux",
  Chi2        = round(chi2_t9$statistic, 3),
  df          = chi2_t9$parameter,
  p_valeur    = formatC(chi2_t9$p.value, format = "e", digits = 3),
  V_Cramer    = v_t9$V,
  Association = v_t9$interpretation,
  N           = nrow(adultes_9)
)
sauvegarder_tableau(res_t9, "tp2_t9_chi2_cramer")

# ---- 9.4 Barplot 100% empilé (proportions) ----
# Préparer les données : proportions par sexe × niveau
prop_sexe_niveau <- adultes_9 |>
  dplyr::count(sexe, niveau_educ) |>
  dplyr::group_by(sexe) |>
  dplyr::mutate(prop = n / sum(n)) |>
  dplyr::ungroup()

p_t9 <- ggplot(
  prop_sexe_niveau,
  aes(x = sexe, y = prop, fill = niveau_educ)
) +
  geom_col(position = "fill", alpha = 0.88) +
  geom_text(
    aes(label = ifelse(prop > 0.04, scales::percent(prop, accuracy = 0.1), "")),
    position = position_fill(vjust = 0.5),
    size = 3.2, colour = "white", fontface = "bold"
  ) +
  scale_y_continuous(labels = percent_format()) +
  scale_fill_manual(values = pal_educ, name = "Niveau d'education") +
  labs(
    title    = "Distribution du niveau d'education par sexe (adultes 18+)",
    subtitle = sprintf(
      "Nigeria GHS W3 (2015) | chi2=%.1f, df=%d, p=%.2e | V=%.3f (%s)",
      chi2_t9$statistic, chi2_t9$parameter,
      chi2_t9$p.value, v_t9$V, v_t9$interpretation),
    x        = "Sexe",
    y        = "Proportion (%)",
    caption  = sprintf("N = %d adultes", nrow(adultes_9))
  )

sauvegarder_figure(p_t9, "tp2_t9_barplot_sexe_niveau", largeur = 9, hauteur = 7)


# ==============================================================================
# TÂCHE 10 — ÂGE × NIVEAU D'ÉDUCATION
#            Boxplot + Kruskal-Wallis + post-hoc Dunn
# ==============================================================================

titre_section("Tache 10 -- Age et niveau d'education")

adultes_10 <- adultes |>
  dplyr::filter(!is.na(niveau_educ), !is.na(groupe_age))

message(sprintf("N adultes avec niveau ET groupe_age : %d", nrow(adultes_10)))

# ---- 10.1 Statistiques descriptives par groupe d'âge ----
stats_age_niveau <- adultes_10 |>
  dplyr::group_by(groupe_age) |>
  dplyr::summarise(
    N         = dplyr::n(),
    Aucun_pct = round(mean(niveau_educ == "Aucun", na.rm=TRUE)*100, 1),
    Tert_pct  = round(mean(niveau_educ == "Tertiaire", na.rm=TRUE)*100, 1),
    Rang_moy  = round(mean(niveau_educ_n, na.rm=TRUE), 2),
    .groups   = "drop"
  )
message("\nStatistiques par groupe d'age :")
print(stats_age_niveau)
sauvegarder_tableau(stats_age_niveau, "tp2_t10_stats_age_niveau")

# ---- 10.2 Test de Kruskal-Wallis ----
# H0 : distributions identiques du rang de niveau_educ entre les 4 groupes
# Variable de test : niveau_educ_n (rang numérique 1-5)
kw_t10 <- adultes_10 |>
  rstatix::kruskal_test(niveau_educ_n ~ groupe_age)
message("\nTest de Kruskal-Wallis :")
print(kw_t10)

# Taille d'effet eta-carré (epsilon-carré)
# eta2 = (H - k + 1) / (n - k)  où H = stat KW, k = nb groupes, n = effectif total
H <- kw_t10$statistic
k <- length(levels(adultes_10$groupe_age))
n <- nrow(adultes_10)
eta2_kw <- round((H - k + 1) / (n - k), 4)
message(sprintf("Taille d'effet eta-carre = %.4f", eta2_kw))

# ---- 10.3 Post-hoc Dunn (si KW significatif) ----
if (kw_t10$p < 0.05) {
  message("\nTest post-hoc de Dunn (correction Bonferroni) :")
  dunn_t10 <- adultes_10 |>
    rstatix::dunn_test(niveau_educ_n ~ groupe_age,
                       p.adjust.method = "bonferroni")
  print(dunn_t10)
  sauvegarder_tableau(as.data.frame(dunn_t10), "tp2_t10_dunn_posthoc")
} else {
  message("KW non significatif -- pas de post-hoc Dunn")
  dunn_t10 <- NULL
}

# ---- 10.4 Boxplot niveau_educ_n par groupe_age ----
p_t10 <- ggplot(
  adultes_10,
  aes(x = groupe_age, y = niveau_educ_n, fill = groupe_age)
) +
  geom_boxplot(alpha = 0.75, width = 0.55,
               outlier.alpha = 0.25, outlier.colour = "#E53935") +
  stat_summary(fun = mean, geom = "point", shape = 18,
               size = 4, colour = "#E53935") +
  scale_y_continuous(
    breaks = 1:5,
    labels = c("Aucun","Primaire","Junior Sec.","Senior Sec.","Tertiaire")
  ) +
  scale_fill_viridis_d(option = "D", begin = 0.2, end = 0.9) +
  labs(
    title    = "Relation entre groupe d'age et niveau d'education",
    subtitle = sprintf(
      "Nigeria GHS W3 (2015) | Kruskal-Wallis H=%.1f, df=%d, p=%.2e | eta2=%.3f",
      kw_t10$statistic, kw_t10$df, kw_t10$p, eta2_kw),
    x        = "Groupe d'age",
    y        = "Niveau d'education (rang 1-5)",
    fill     = NULL,
    caption  = sprintf("N = %d adultes | Losange rouge = moyenne",
                       nrow(adultes_10))
  ) +
  theme(legend.position = "none")

sauvegarder_figure(p_t10, "tp2_t10_boxplot_age_niveau", largeur = 10, hauteur = 7)


# ==============================================================================
# TÂCHE 11 — TAUX DE SCOLARISATION 6-17 ANS : RURAL VS URBAIN
#            Tableau contingence + chi-deux + barplot IC 95%
# ==============================================================================

titre_section("Tache 11 -- Scolarisation 6-17 ans rural vs urbain")

enfants_11 <- enfants |>
  dplyr::filter(!is.na(scolarise), !is.na(milieu))

message(sprintf("N enfants 6-17 avec scolarise ET milieu : %d", nrow(enfants_11)))

# ---- 11.1 Tableau de contingence ----
tab_scol <- table(
  Milieu    = enfants_11$milieu,
  Scolarise = enfants_11$scolarise_fct
)
message("\nTableau de contingence Milieu × Scolarise :")
print(tab_scol)
message("\nTableau en % ligne :")
print(round(prop.table(tab_scol, margin = 1) * 100, 1))

# ---- 11.2 Test du chi-deux ----
chi2_t11 <- chisq.test(tab_scol, correct = FALSE)
message("\nTest du chi-deux :")
print(chi2_t11)
message(sprintf("Effectif théorique min = %.1f", min(chi2_t11$expected)))

# V de Cramér
v_t11 <- calc_cramer_v(tab = tab_scol)
message(sprintf("V de Cramer = %.4f => '%s'", v_t11$V, v_t11$interpretation))

# ---- 11.3 Proportions et IC Clopper-Pearson par milieu ----
# Taux de scolarisation = proportion de scolarise == 1 par milieu
prop_scol <- enfants_11 |>
  dplyr::group_by(milieu) |>
  dplyr::summarise(
    n_scolarise = sum(scolarise == 1L, na.rm = TRUE),
    n_total     = dplyr::n(),
    .groups     = "drop"
  ) |>
  dplyr::mutate(
    prop   = n_scolarise / n_total,
    IC_inf = mapply(function(k,n) binom.test(k,n)$conf.int[1],
                    n_scolarise, n_total),
    IC_sup = mapply(function(k,n) binom.test(k,n)$conf.int[2],
                    n_scolarise, n_total)
  )

message("\nTaux de scolarisation par milieu avec IC 95% :")
print(prop_scol)
sauvegarder_tableau(prop_scol, "tp2_t11_taux_scolarisation")

# ---- 11.4 Barplot groupé avec IC ----
p_t11 <- ggplot(
  prop_scol,
  aes(x = milieu, y = prop, fill = milieu,
      ymin = IC_inf, ymax = IC_sup)
) +
  geom_col(alpha = 0.85, width = 0.55, show.legend = FALSE) +
  geom_errorbar(width = 0.20, linewidth = 1.0, colour = "grey30") +
  geom_text(
    aes(y = IC_sup,
        label = scales::percent(prop, accuracy = 0.1)),
    vjust = -0.5, size = 4.2, fontface = "bold"
  ) +
  scale_y_continuous(
    labels = percent_format(accuracy = 1),
    limits = c(0, 1.05)
  ) +
  scale_fill_manual(values = c("Urbain" = "#FF7043", "Rural" = "#42A5F5")) +
  labs(
    title    = "Taux de scolarisation des enfants de 6 a 17 ans par milieu",
    subtitle = sprintf(
      "Nigeria GHS W3 (2015) | chi2=%.1f, df=%d, p=%.2e | V=%.3f (%s)",
      chi2_t11$statistic, chi2_t11$parameter,
      chi2_t11$p.value, v_t11$V, v_t11$interpretation),
    x        = "Milieu de residence",
    y        = "Taux de scolarisation (%) -- IC 95% Clopper-Pearson",
    caption  = sprintf("N = %d enfants 6-17 ans", nrow(enfants_11))
  )

sauvegarder_figure(p_t11, "tp2_t11_scolarisation_milieu", largeur = 8, hauteur = 7)


# ==============================================================================
# TÂCHE 12 — HEATMAP ÉTAT × NIVEAU D'ÉDUCATION
#            Part d'adultes sans instruction par État (quintiles)
# ==============================================================================

titre_section("Tache 12 -- Heatmap analphabetisme par Etat")

adultes_12 <- adultes |>
  dplyr::filter(!is.na(niveau_educ), !is.na(state))

# ---- 12.1 Calculer % sans instruction par État ----
aucun_par_etat <- adultes_12 |>
  dplyr::group_by(state) |>
  dplyr::summarise(
    N            = dplyr::n(),
    n_aucun      = sum(niveau_educ == "Aucun"),
    pct_aucun    = round(n_aucun / N * 100, 1),
    .groups      = "drop"
  ) |>
  dplyr::arrange(dplyr::desc(pct_aucun))

message("% sans instruction par Etat (top 10) :")
print(head(aucun_par_etat, 10))
message("Resume :")
print(summary(aucun_par_etat$pct_aucun))

# Ajouter quintile (Q1 = moins analphabètes, Q5 = plus analphabètes)
aucun_par_etat <- aucun_par_etat |>
  dplyr::mutate(
    quintile = dplyr::ntile(pct_aucun, 5),
    quintile_lbl = factor(quintile,
                          levels = 1:5,
                          labels = c("Q1 (le moins)","Q2","Q3","Q4",
                                     "Q5 (le plus)"))
  )

sauvegarder_tableau(aucun_par_etat, "tp2_t12_aucun_par_etat")

# ---- 12.2 Préparer données pour heatmap ----
# Croiser État × niveau_educ (distribution complète)
dist_etat_niveau <- adultes_12 |>
  dplyr::count(state, niveau_educ) |>
  dplyr::group_by(state) |>
  dplyr::mutate(prop = n / sum(n)) |>
  dplyr::ungroup() |>
  # Joindre le quintile d'analphabétisme pour ordonner les États
  dplyr::left_join(aucun_par_etat |> dplyr::select(state, pct_aucun, quintile),
                   by = "state") |>
  # Ordonner les États par % sans instruction décroissant
  dplyr::mutate(
    state_lbl = factor(state),
    state_ord = forcats::fct_reorder(
      factor(state), pct_aucun, .desc = FALSE)
  )

# ---- 12.3 Heatmap : part SANS INSTRUCTION par État ----
heatmap_data <- aucun_par_etat |>
  dplyr::mutate(state_ord = forcats::fct_reorder(
    factor(state), pct_aucun, .desc = FALSE))

p_t12_hm <- ggplot(
  heatmap_data,
  aes(x = 1, y = state_ord, fill = pct_aucun)
) +
  geom_tile(colour = "white", linewidth = 0.5) +
  geom_text(aes(label = paste0(pct_aucun, "%")),
            size = 2.8, colour = "white", fontface = "bold") +
  scale_fill_viridis_c(
    option   = "inferno",
    direction = 1,
    name     = "%% sans instruction",
    labels   = function(x) paste0(x, "%")
  ) +
  scale_x_continuous(breaks = NULL) +
  labs(
    title    = "Part d'adultes (18+) sans instruction par Etat nigerian",
    subtitle = "Nigeria GHS Panel -- Vague 3 (2015)",
    x        = NULL,
    y        = "Etat (code GHS, ordre croissant)",
    caption  = sprintf("N = %d adultes dans %d etats | Couleur = quintile de %% sans instruction",
                       nrow(adultes_12), nrow(aucun_par_etat))
  ) +
  theme(
    axis.text.x  = element_blank(),
    axis.ticks.x = element_blank()
  )

sauvegarder_figure(p_t12_hm, "tp2_t12_heatmap_etat",
                   largeur = 6, hauteur = 14)

# ---- 12.4 Heatmap complète État × Niveau (distribution par niveau) ----
p_t12_full <- ggplot(
  dist_etat_niveau,
  aes(x = niveau_educ, y = state_ord, fill = prop)
) +
  geom_tile(colour = "white", linewidth = 0.4) +
  geom_text(aes(label = ifelse(prop > 0.05,
                               scales::percent(prop, accuracy = 1), "")),
            size = 2.2, colour = "white") +
  scale_fill_viridis_c(
    option   = "magma",
    direction = -1,
    name     = "Proportion",
    labels   = percent_format(accuracy = 1)
  ) +
  scale_x_discrete(guide = guide_axis(angle = 30)) +
  labs(
    title    = "Distribution du niveau d'education par Etat nigerian",
    subtitle = "Nigeria GHS W3 (2015) | Etats ordonnes par % sans instruction croissant",
    x        = "Niveau d'education",
    y        = "Etat (code GHS)",
    caption  = sprintf("N = %d adultes dans %d etats | Couleur = quintile de %% sans instruction",
                       nrow(adultes_12), nrow(aucun_par_etat))  )

sauvegarder_figure(p_t12_full, "tp2_t12_heatmap_etat_niveau_complet",
                   largeur = 11, hauteur = 14)


# ==============================================================================
# FIGURE DE SYNTHÈSE TP2
# ==============================================================================

titre_section("Figure de synthese TP2")

p_synthese <- (p_t8 / p_t9) | (p_t10 / p_t11)

p_synthese_annote <- p_synthese +
  patchwork::plot_annotation(
    title    = "TP2 -- Education et alphabetisation des menages nigerians (2015)",
    subtitle = "Nigeria GHS Panel -- Vague 3 | ENSAE ISE 1 (2025-2026)",
    caption  = "Source : World Bank LSMS-ISA"
  )

sauvegarder_figure(p_synthese_annote, "tp2_synthese",
                   largeur = 18, hauteur = 20)


# ==============================================================================
# RÉCAPITULATIF FINAL
# ==============================================================================

titre_section("Recapitulatif TP2")

message(sprintf("T7  -- Adultes 18+ apres jointure   : %d", nrow(adultes)))
message(sprintf("T8  -- Adultes avec niveau_educ     : %d", sum(!is.na(adultes$niveau_educ))))
message(sprintf("T9  -- Adultes pour chi-deux sexe   : %d", nrow(adultes_9)))
message(sprintf("       chi2=%.1f, p=%.2e, V=%.4f (%s)",
                chi2_t9$statistic, chi2_t9$p.value,
                v_t9$V, v_t9$interpretation))
message(sprintf("T10 -- Adultes pour Kruskal-Wallis  : %d", nrow(adultes_10)))
message(sprintf("       H=%.1f, df=%d, p=%.2e, eta2=%.4f",
                kw_t10$statistic, kw_t10$df, kw_t10$p, eta2_kw))
message(sprintf("T11 -- Enfants 6-17 pour chi-deux   : %d", nrow(enfants_11)))
message(sprintf("       chi2=%.1f, p=%.2e, V=%.4f (%s)",
                chi2_t11$statistic, chi2_t11$parameter,
                v_t11$V, v_t11$interpretation))
message(sprintf("T12 -- Adultes pour heatmap etats   : %d", nrow(adultes_12)))
message(sprintf("       Etat le plus touche : code %d (%.1f%% sans instruction)",
                aucun_par_etat$state[1], aucun_par_etat$pct_aucun[1]))
message(sprintf("       Etat le moins touche: code %d (%.1f%%)",
                aucun_par_etat$state[nrow(aucun_par_etat)],
                aucun_par_etat$pct_aucun[nrow(aucun_par_etat)]))

message("\nFigures : output/figures/ | Tableaux : output/tables/")
message("--- Analyses TP2 terminees. Etape suivante : rapport/tp2_rapport.Rmd ---")