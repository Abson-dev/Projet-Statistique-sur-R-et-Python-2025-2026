# ==============================================================================
# TP2 — ÉDUCATION ET ALPHABÉTISATION
# Script  : 01_import.R
# Objet   : Chargement, exploration et contrôle qualité des données brutes
# Données : sect2_harvestw3.dta | sect1_harvestw3.dta | secta_harvestw3.dta
# ==============================================================================
# NOTES SUR LA STRUCTURE GHS W3 :
#   Le TP cite sect2a et sect2b séparément (nomenclature W1/W2).
#   En W3, ces deux sections sont fusionnées dans un fichier unique : sect2_harvestw3.dta
#   Correspondances :
#     sect2a (scolarisation actuelle) → s2aq13, s2aq15  dans sect2_harvestw3
#     sect2b (niveau atteint)        → s2aq9, s2aq10    dans sect2_harvestw3
#   La variable s2aq6 (jamais scolarisé) est également dans sect2_harvestw3.
# ==============================================================================


# ------------------------------------------------------------------------------
# SECTION 0 — PACKAGES
# ------------------------------------------------------------------------------

library(haven)
library(dplyr)
library(naniar)
library(ggplot2)

source("R/fonctions.R")

dir.create("data/processed", recursive = TRUE, showWarnings = FALSE)
dir.create("output/figures",  recursive = TRUE, showWarnings = FALSE)
dir.create("output/tables",   recursive = TRUE, showWarnings = FALSE)

DOSSIER_RAW  <- "data/raw"
DOSSIER_PROC <- "data/processed"


# ==============================================================================
# SECTION 1 — IMPORT sect2_harvestw3
# Niveau   : individu (un enregistrement par membre >= 5 ans)
# Clé      : hhid + indiv
# Variables clés pour TP2 :
#   s2aq5  — sait lire et écrire (alphabétisation)
#   s2aq6  — a-t-il jamais fréquenté l'école ?
#   s2aq9  — niveau le plus élevé atteint (27 codes)
#   s2aq13 — actuellement scolarisé ?
#   s2aq15 — niveau en cours d'études
# ==============================================================================

titre_section("Import sect2_harvestw3")

sect2_w3 <- haven::read_dta(file.path(DOSSIER_RAW, "sect2_harvestw3.dta"))

message(sprintf("Dimensions : %d obs x %d variables", nrow(sect2_w3), ncol(sect2_w3)))
message("\nStructure (variables clés) :")
dplyr::glimpse(sect2_w3 |> dplyr::select(
  hhid, indiv, zone, state, sector,
  s2aq2, s2aq5, s2aq6, s2aq9, s2aq10, s2aq13, s2aq15
))

# Labels Stata des variables clés
message("\nLabels des variables clés :")
vars_cles_s2 <- c("s2aq2","s2aq5","s2aq6","s2aq9","s2aq13","s2aq15")
for (v in vars_cles_s2) {
  lbl <- attr(sect2_w3[[v]], "labels")
  if (!is.null(lbl) && length(lbl) <= 15) {
    message(sprintf("  %s : %s",v,
                    paste(names(lbl), "=", lbl, collapse=" | ")))
  } else if (!is.null(lbl)) {
    message(sprintf("  %s : %d modalités (première: %s='%s')",
                    v, length(lbl), lbl[1], names(lbl)[1]))
  }
}

# Doublons
n_doub_s2 <- sect2_w3 |>
  dplyr::group_by(hhid, indiv) |>
  dplyr::filter(dplyr::n() > 1) |>
  nrow()
message(sprintf("\nDoublons (hhid+indiv) dans sect2 : %d", n_doub_s2))

# Valeurs manquantes variables clés
message("\nNA sur variables clés de sect2 :")
print(
  sect2_w3 |>
    dplyr::select(hhid, indiv, s2aq5, s2aq6, s2aq9, s2aq13, s2aq15) |>
    naniar::miss_var_summary()
)

# Distribution s2aq9 (niveau atteint — 27 codes)
message("\nDistribution brute de s2aq9 (niveau atteint) :")
print(table(as.numeric(sect2_w3$s2aq9), useNA = "always"))

# Distribution s2aq6 (jamais scolarisé)
message("\nDistribution s2aq6 (jamais fréquenté l'école) :")
print(table(as.numeric(sect2_w3$s2aq6), useNA = "always"))


# ==============================================================================
# SECTION 2 — IMPORT sect1_harvestw3
# Clé : hhid + indiv
# Variables nécessaires : s1q2 (sexe), s1q4 (âge), s1q4a (résident)
# ==============================================================================

titre_section("Import sect1_harvestw3")

sect1_w3 <- haven::read_dta(file.path(DOSSIER_RAW, "sect1_harvestw3.dta"))
message(sprintf("Dimensions : %d obs x %d variables", nrow(sect1_w3), ncol(sect1_w3)))

# Vérifier les variables indispensables
vars_s1_utiles <- c("hhid","indiv","s1q2","s1q4","s1q4a","zone","sector","state")
message("\nVariables récupérées depuis sect1 :")
for (v in vars_s1_utiles) {
  lbl <- attr(sect1_w3[[v]], "label")
  message(sprintf("  %-12s : %s", v, ifelse(is.null(lbl),"",lbl)))
}

n_doub_s1 <- sect1_w3 |>
  dplyr::group_by(hhid, indiv) |>
  dplyr::filter(dplyr::n() > 1) |>
  nrow()
message(sprintf("\nDoublons (hhid+indiv) dans sect1 : %d", n_doub_s1))


# ==============================================================================
# SECTION 3 — IMPORT secta_harvestw3
# Clé      : hhid (niveau ménage)
# Variables : sector (milieu), zone, state, lga, wt_wave3
# ==============================================================================

titre_section("Import secta_harvestw3")

secta_w3 <- haven::read_dta(file.path(DOSSIER_RAW, "secta_harvestw3.dta"))
message(sprintf("Dimensions : %d ménages x %d variables", nrow(secta_w3), ncol(secta_w3)))

message("\nDistribution sector (milieu) dans secta :")
print(table(as.numeric(secta_w3$sector), useNA = "always"))

message("\nDistribution zone (geopolitique) dans secta :")
print(table(as.numeric(secta_w3$zone), useNA = "always"))

n_doub_sa <- secta_w3 |>
  dplyr::group_by(hhid) |>
  dplyr::filter(dplyr::n() > 1) |>
  nrow()
message(sprintf("\nDoublons (hhid) dans secta : %d", n_doub_sa))


# ==============================================================================
# SECTION 4 — COHÉRENCE DES CLÉS
# ==============================================================================

titre_section("Cohérence des clés entre fichiers")

hh_s2 <- dplyr::n_distinct(sect2_w3$hhid)
hh_s1 <- dplyr::n_distinct(sect1_w3$hhid)
hh_sa <- dplyr::n_distinct(secta_w3$hhid)
hh_commun_s2_s1 <- dplyr::n_distinct(intersect(sect2_w3$hhid, sect1_w3$hhid))
hh_commun_s2_sa <- dplyr::n_distinct(intersect(sect2_w3$hhid, secta_w3$hhid))

message(sprintf("Menages uniques : sect2=%d | sect1=%d | secta=%d", hh_s2, hh_s1, hh_sa))
message(sprintf("Menages communs sect2 & sect1 : %d", hh_commun_s2_s1))
message(sprintf("Menages communs sect2 & secta : %d", hh_commun_s2_sa))


# ==============================================================================
# SECTION 5 — SAUVEGARDE
# ==============================================================================

titre_section("Sauvegarde")

saveRDS(sect2_w3, file.path(DOSSIER_PROC, "sect2_w3_raw.rds"))
saveRDS(sect1_w3, file.path(DOSSIER_PROC, "sect1_w3_raw.rds"))
saveRDS(secta_w3, file.path(DOSSIER_PROC, "secta_w3_raw.rds"))

recap <- data.frame(
  Fichier     = c("sect2_harvestw3","sect1_harvestw3","secta_harvestw3"),
  Niveau      = c("Individu","Individu","Menage"),
  N_lignes    = c(nrow(sect2_w3), nrow(sect1_w3), nrow(secta_w3)),
  N_variables = c(ncol(sect2_w3), ncol(sect1_w3), ncol(secta_w3)),
  Doublons    = c(n_doub_s2, n_doub_s1, n_doub_sa)
)
print(recap)
sauvegarder_tableau(recap, "tp2_recap_import")

message("\n--- Import TP2 termine. Etape suivante : 02_nettoyage.R ---")