# ==============================================================================
# TP2 — ÉDUCATION ET ALPHABÉTISATION
# Script  : fonctions.R
# Objet   : Fonctions personnalisées pour les tâches 7 à 12
# Usage   : source("R/fonctions.R")
# Auteurs : Math SOCE / Safiétou DEME — ENSAE ISE 1 (2025-2026)
# ==============================================================================

library(survey)
library(dplyr)


# ------------------------------------------------------------------------------
# FONCTION 1 : recoder_niveau_educ()
# Recode s2aq9 (niveau atteint, 27 codes GHS) + s2aq6 (jamais scolarisé)
# en une variable ordonnée à 5 catégories analytiques.
#
# Logique :
#   1. Si s2aq6 == 2 (jamais fréquenté l'école) → "Aucun"
#   2. Sinon, s2aq9 :
#      0, 1, 2, 51, 52, 61 → "Aucun"
#      11–16               → "Primaire"
#      21–23               → "Junior Secondary"
#      24–28               → "Senior Secondary"
#      31–43               → "Tertiaire"
# ------------------------------------------------------------------------------

recoder_niveau_educ <- function(s2aq9_code, s2aq6_code) {
  
  s9 <- as.numeric(s2aq9_code)
  s6 <- as.numeric(s2aq6_code)
  
  niveau <- dplyr::case_when(
    s6 == 2                         ~ "Aucun",
    s9 %in% c(0, 1, 2, 51, 52, 61) ~ "Aucun",
    s9 >= 11 & s9 <= 16             ~ "Primaire",
    s9 >= 21 & s9 <= 23             ~ "Junior Secondary",
    s9 >= 24 & s9 <= 28             ~ "Senior Secondary",
    s9 %in% c(31,32,33,34,41,42,43) ~ "Tertiaire",
    TRUE                            ~ NA_character_
  )
  
  factor(niveau,
         levels  = c("Aucun","Primaire","Junior Secondary",
                     "Senior Secondary","Tertiaire"),
         ordered = TRUE)
}


# ------------------------------------------------------------------------------
# FONCTION 2 : recoder_groupe_age_educ()
# Quatre groupes d'âge analytiques pour les adultes (18+)
# ------------------------------------------------------------------------------

recoder_groupe_age_educ <- function(age) {
  
  age_num <- as.numeric(age)
  
  grp <- dplyr::case_when(
    age_num >= 18 & age_num <= 30 ~ "18-30 ans",
    age_num >= 31 & age_num <= 45 ~ "31-45 ans",
    age_num >= 46 & age_num <= 60 ~ "46-60 ans",
    age_num  > 60                 ~ "60+ ans",
    TRUE                          ~ NA_character_
  )
  
  factor(grp,
         levels  = c("18-30 ans","31-45 ans","46-60 ans","60+ ans"),
         ordered = TRUE)
}


# ------------------------------------------------------------------------------
# FONCTION 3 : calc_cramer_v()
# V de Cramér depuis un tableau de contingence ou les composantes chi²
# Nommée calc_cramer_v pour éviter le masquage par rstatix::cramer_v
# ------------------------------------------------------------------------------

calc_cramer_v <- function(tab = NULL, chi2 = NULL, n = NULL, r = NULL, c = NULL) {
  
  if (!is.null(tab)) {
    test <- chisq.test(tab, correct = FALSE)
    chi2 <- test$statistic
    n    <- sum(tab)
    r    <- nrow(tab)
    c    <- ncol(tab)
  }
  
  v <- sqrt(chi2 / (n * (min(r, c) - 1)))
  
  interp <- dplyr::case_when(
    v < 0.10 ~ "négligeable",
    v < 0.30 ~ "faible",
    v < 0.50 ~ "modéré",
    TRUE     ~ "fort"
  )
  
  list(V = round(as.numeric(v), 4), interpretation = interp,
       chi2 = round(as.numeric(chi2), 3), n = n)
}


# ------------------------------------------------------------------------------
# FONCTION 4 : freq_ic_pondere()
# Proportions pondérées et IC de Wald — résultats au niveau population
# ------------------------------------------------------------------------------

freq_ic_pondere <- function(svy, var, nom_var = NULL) {
  
  if (is.null(nom_var)) nom_var <- var
  
  if (!is.factor(svy$variables[[var]]))
    svy$variables[[var]] <- factor(svy$variables[[var]])
  
  res   <- survey::svymean(as.formula(paste("~", var)), design = svy, na.rm = TRUE)
  mods  <- gsub(paste0("^", var), "", names(coef(res)))
  props <- as.numeric(coef(res))
  ses   <- as.numeric(SE(res))
  
  tab_brut <- table(factor(svy$variables[[var]]))
  eff      <- as.integer(tab_brut[match(mods, names(tab_brut))])
  eff[is.na(eff)] <- 0L
  
  df <- data.frame(
    variable   = nom_var,
    modalite   = mods,
    effectif   = eff,
    proportion = round(props, 4),
    IC_inf     = round(pmax(0, props - 1.96 * ses), 4),
    IC_sup     = round(pmin(1, props + 1.96 * ses), 4),
    stringsAsFactors = FALSE
  )
  df[order(-df$proportion), ]
}


# ------------------------------------------------------------------------------
# FONCTION 5 : freq_ic()
# Fréquences + IC Clopper-Pearson (non pondéré — diagnostics qualité)
# ------------------------------------------------------------------------------

freq_ic <- function(x, nom_var = "variable") {
  
  if (is.factor(x)) {
    niveaux <- levels(x)
    x_clean <- x[!is.na(x)]
    n_total <- length(x_clean)
    tab <- data.frame(modalite = niveaux,
                      effectif = as.integer(table(factor(x_clean, levels = niveaux))),
                      stringsAsFactors = FALSE)
  } else {
    x_clean <- x[!is.na(x)]
    n_total <- length(x_clean)
    tab <- as.data.frame(table(x_clean), stringsAsFactors = FALSE)
    names(tab) <- c("modalite", "effectif")
  }
  
  tab$n_total    <- n_total
  tab$proportion <- tab$effectif / n_total
  tab$IC_inf     <- mapply(function(k, n) binom.test(k, n)$conf.int[1],
                           tab$effectif, tab$n_total)
  tab$IC_sup     <- mapply(function(k, n) binom.test(k, n)$conf.int[2],
                           tab$effectif, tab$n_total)
  tab$variable   <- nom_var
  tab <- tab[, c("variable","modalite","effectif","n_total","proportion","IC_inf","IC_sup")]
  tab[order(-tab$proportion), ]
}


# ------------------------------------------------------------------------------
# FONCTION 6 : resume_pondere()
# Statistiques descriptives pondérées — résultats au niveau population
# ------------------------------------------------------------------------------

resume_pondere <- function(svy, var, nom_var = NULL) {
  
  if (is.null(nom_var)) nom_var <- var
  
  frm     <- as.formula(paste("~", var))
  moy_obj <- survey::svymean(frm, design = svy, na.rm = TRUE)
  moy_val <- as.numeric(coef(moy_obj))
  moy_se  <- as.numeric(SE(moy_obj))
  
  var_pond <- as.numeric(survey::svyvar(frm, design = svy, na.rm = TRUE))
  sd_pond  <- sqrt(var_pond)
  cv_pond  <- ifelse(moy_val != 0, sd_pond / moy_val * 100, NA_real_)
  
  qnt  <- survey::svyquantile(frm, design = svy,
                              quantiles = c(0.25, 0.50, 0.75),
                              na.rm = TRUE, ci = FALSE)
  vals <- as.numeric(coef(qnt))
  
  data.frame(
    variable   = nom_var,
    N_obs      = sum(!is.na(svy$variables[[var]])),
    moyenne    = round(moy_val, 2),
    IC95_inf   = round(moy_val - 1.96 * moy_se, 2),
    IC95_sup   = round(moy_val + 1.96 * moy_se, 2),
    mediane    = round(vals[2], 2),
    Q1         = round(vals[1], 2),
    Q3         = round(vals[3], 2),
    ecart_type = round(sd_pond, 2),
    CV_pct     = round(cv_pond, 1),
    stringsAsFactors = FALSE
  )
}


# ------------------------------------------------------------------------------
# FONCTION 7 : creer_plan_sondage()
# Construit le svydesign (strates zone_geo × milieu, poids wt_wave3)
# ------------------------------------------------------------------------------

creer_plan_sondage <- function(data, id_var = "ea",
                               strate = "strate_id", poids = "wt_wave3") {
  
  if (!poids %in% names(data)) stop("Colonne manquante : ", poids)
  
  if (!strate %in% names(data)) {
    if (all(c("zone_geo", "milieu") %in% names(data))) {
      data[[strate]] <- interaction(data$zone_geo, data$milieu, drop = TRUE)
    } else {
      data[[strate]] <- factor("tout")
    }
  }
  
  if (!id_var %in% names(data)) id_var <- "hhid"
  
  n0   <- nrow(data)
  data <- data[!is.na(data[[poids]]), ]
  if (nrow(data) < n0)
    message(sprintf("%d lignes supprimées (poids manquant)", n0 - nrow(data)))
  
  survey::svydesign(
    ids     = as.formula(paste("~", id_var)),
    strata  = as.formula(paste("~", strate)),
    weights = as.formula(paste("~", poids)),
    data    = data,
    nest    = TRUE
  )
}


# ------------------------------------------------------------------------------
# FONCTION 8 : resume_numerique()
# Statistiques descriptives non pondérées (diagnostics)
# ------------------------------------------------------------------------------

resume_numerique <- function(x, nom_var = "variable") {
  
  if (!is.numeric(x)) stop("'x' doit être numérique.")
  x_clean <- x[!is.na(x)]
  n       <- length(x_clean)
  if (n == 0) stop("Aucune observation valide.")
  
  m2   <- mean((x_clean - mean(x_clean))^2)
  m3   <- mean((x_clean - mean(x_clean))^3)
  skew <- ifelse(m2 == 0, 0, m3 / m2^(3/2))
  cv   <- ifelse(mean(x_clean) != 0, sd(x_clean)/mean(x_clean)*100, NA_real_)
  q1   <- quantile(x_clean, 0.25)
  q3   <- quantile(x_clean, 0.75)
  iqr  <- q3 - q1
  
  data.frame(variable = nom_var, N = n, manquants = sum(is.na(x)),
             pct_manquants = round(sum(is.na(x))/length(x)*100, 1),
             moyenne = round(mean(x_clean), 2), mediane = round(median(x_clean), 2),
             Q1 = round(q1, 2), Q3 = round(q3, 2), ecart_type = round(sd(x_clean), 2),
             CV_pct = round(cv, 1), asymetrie = round(skew, 3),
             min = round(min(x_clean), 2), max = round(max(x_clean), 2),
             outlier_bas = round(q1 - 1.5*iqr, 2), outlier_haut = round(q3 + 1.5*iqr, 2),
             n_outliers = sum(x_clean < (q1-1.5*iqr) | x_clean > (q3+1.5*iqr)),
             stringsAsFactors = FALSE)
}


# ------------------------------------------------------------------------------
# Recodeurs géographiques et sociodémographiques
# ------------------------------------------------------------------------------

recoder_secteur <- function(sector_code) {
  s <- as.numeric(sector_code)
  factor(dplyr::case_when(s == 1 ~ "Urbain", s == 2 ~ "Rural",
                          TRUE ~ NA_character_),
         levels = c("Urbain", "Rural"))
}

recoder_zone_geo <- function(zone_code) {
  z <- as.numeric(zone_code)
  factor(dplyr::case_when(
    z == 1 ~ "North Central", z == 2 ~ "North East",
    z == 3 ~ "North West",    z == 4 ~ "South East",
    z == 5 ~ "South South",   z == 6 ~ "South West",
    TRUE   ~ NA_character_),
    levels = c("North Central","North East","North West",
               "South East","South South","South West"))
}

recoder_sexe <- function(sexe_code) {
  s <- as.numeric(sexe_code)
  factor(dplyr::case_when(s == 1 ~ "Masculin", s == 2 ~ "Féminin",
                          TRUE ~ NA_character_),
         levels = c("Masculin", "Féminin"))
}


# ------------------------------------------------------------------------------
# Utilitaires
# ------------------------------------------------------------------------------

sauvegarder_figure <- function(p, nom, largeur = 10, hauteur = 7) {
  dir.create("output/figures", recursive = TRUE, showWarnings = FALSE)
  chemin <- file.path("output", "figures", paste0(nom, ".png"))
  ggplot2::ggsave(chemin, plot = p, width = largeur, height = hauteur,
                  dpi = 300, bg = "white")
  message("Figure : ", chemin)
}

sauvegarder_tableau <- function(df, nom) {
  dir.create("output/tables", recursive = TRUE, showWarnings = FALSE)
  chemin <- file.path("output", "tables", paste0(nom, ".csv"))
  df_clean <- as.data.frame(df)
  df_clean[] <- lapply(df_clean, function(col) {
    if (is.numeric(col)) as.numeric(col)
    else if (is.integer(col)) as.integer(col)
    else as.character(col)
  })
  write.csv(df_clean, chemin, row.names = FALSE)
  message("Tableau : ", chemin)
}

titre_section <- function(titre) {
  sep <- paste(rep("=", 70), collapse = "")
  message("\n", sep, "\n  ", toupper(titre), "\n", sep)
}