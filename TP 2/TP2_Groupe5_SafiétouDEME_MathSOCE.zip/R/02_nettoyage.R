# ==============================================================================
# TP2 — ÉDUCATION ET ALPHABÉTISATION
# Script  : 02_nettoyage.R
# Objet   : Recodage, jointures et construction des variables analytiques
# Prérequis : 01_import.R
# ==============================================================================
# VARIABLES CONSTRUITES :
#   niveau_educ   — facteur ordonné 5 catégories (Aucun → Tertiaire)
#   niveau_educ_n — rang numérique de niveau_educ (1–5, pour Kruskal-Wallis)
#   groupe_age    — 4 groupes adultes (18-30, 31-45, 46-60, 60+)
#   sexe          — facteur (Masculin/Feminin)
#   milieu        — facteur (Urbain/Rural) depuis sector
#   zone_geo      — facteur 6 zones géopolitiques
#   scolarise     — binaire pour enfants 6-17 ans (tâche 11)
# ==============================================================================


# ------------------------------------------------------------------------------
# SECTION 0 — PACKAGES
# ------------------------------------------------------------------------------

library(dplyr)
library(haven)
library(naniar)

source("R/fonctions.R")


# ------------------------------------------------------------------------------
# SECTION 1 — CHARGEMENT
# ------------------------------------------------------------------------------

titre_section("Chargement des données brutes")

sect2_w3 <- readRDS("data/processed/sect2_w3_raw.rds")
sect1_w3 <- readRDS("data/processed/sect1_w3_raw.rds")
secta_w3 <- readRDS("data/processed/secta_w3_raw.rds")

message(sprintf("sect2 : %d obs | sect1 : %d obs | secta : %d menages",
                nrow(sect2_w3), nrow(sect1_w3), nrow(secta_w3)))


# ==============================================================================
# SECTION 2 — JOINTURE sect2 + sect1 + secta
# Objectif : enrichir sect2 (éducation) avec :
#   - sexe (s1q2) et âge (s1q4) issus de sect1
#   - milieu (sector), zone_geo (zone), state depuis secta (référence ménage)
# ==============================================================================

titre_section("Jointures")

# Préparer secta : garder les variables géographiques de référence ménage
secta_geo <- secta_w3 |>
  dplyr::select(hhid, sector, zone, state, lga, wt_wave3) |>
  dplyr::mutate(
    milieu   = recoder_secteur(sector),
    zone_geo = recoder_zone_geo(zone)
  )

# Préparer sect1 : garder sexe, âge, statut résident
sect1_utile <- sect1_w3 |>
  dplyr::select(hhid, indiv, s1q2, s1q4, s1q4a) |>
  dplyr::rename(sexe_code = s1q2, age = s1q4, resident = s1q4a) |>
  dplyr::mutate(
    sexe = recoder_sexe(sexe_code),
    age  = dplyr::case_when(
      as.numeric(age) < 0   ~ NA_real_,
      as.numeric(age) > 110 ~ NA_real_,
      TRUE                  ~ as.numeric(age)
    )
  )

# Jointure : sect2 + sect1 (sur hhid + indiv) + secta (sur hhid)
# sect2_w3 contient deja zone, state, lga, sector, ea -> suppression avant
# jointure avec secta_geo pour eviter les conflits state.x / state.y
# La reference officielle au niveau menage est secta (comme dans TP1).
df_joint <- sect2_w3 |>
  dplyr::select(-dplyr::any_of(c("zone", "sector", "state", "lga"))) |>
  dplyr::left_join(sect1_utile, by = c("hhid", "indiv")) |>
  dplyr::left_join(secta_geo,   by = "hhid")

message(sprintf("Après jointures : %d obs x %d variables", nrow(df_joint), ncol(df_joint)))

# Contrôle : NA sur les variables jointes
message("\nNA sur variables jointes :")
print(
  df_joint |>
    dplyr::select(age, sexe, milieu, zone_geo, state) |>
    naniar::miss_var_summary()
)


# ==============================================================================
# SECTION 3 — CONSTRUCTION DE niveau_educ
# Variable centrale du TP2, construite selon la logique GHS :
#   - s2aq6 == 2 → jamais scolarisé → "Aucun" (prioritaire)
#   - s2aq9      → niveau le plus élevé atteint (27 codes → 5 catégories)
# ==============================================================================

titre_section("Construction de niveau_educ")

df_joint <- df_joint |>
  dplyr::mutate(
    niveau_educ = recoder_niveau_educ(s2aq9, s2aq6),
    # Rang numérique pour les tests basés sur les rangs (Kruskal-Wallis)
    # Aucun=1, Primaire=2, Junior Secondary=3, Senior Secondary=4, Tertiaire=5
    niveau_educ_n = as.numeric(niveau_educ)
  )

message("Distribution niveau_educ (tous membres >= 5 ans) :")
print(table(df_joint$niveau_educ, useNA = "always"))

message("\nNA residuels sur niveau_educ :")
message(sprintf("  %d obs (%.2f%%)",
                sum(is.na(df_joint$niveau_educ)),
                sum(is.na(df_joint$niveau_educ))/nrow(df_joint)*100))


# ==============================================================================
# SECTION 4 — SOUS-ENSEMBLES ANALYTIQUES
# ==============================================================================

titre_section("Construction des sous-ensembles analytiques")

# ---- 4.1 Adultes >= 18 ans (tâches 8, 9, 10, 12) ----
adultes <- df_joint |>
  dplyr::filter(!is.na(age), age >= 18) |>
  dplyr::mutate(
    groupe_age = recoder_groupe_age_educ(age)
  )

message(sprintf("Adultes >= 18 ans : %d obs", nrow(adultes)))
message(sprintf("  dont avec niveau_educ renseigne : %d (%.1f%%)",
                sum(!is.na(adultes$niveau_educ)),
                sum(!is.na(adultes$niveau_educ))/nrow(adultes)*100))
message(sprintf("  dont avec sexe renseigne        : %d (%.1f%%)",
                sum(!is.na(adultes$sexe)),
                sum(!is.na(adultes$sexe))/nrow(adultes)*100))

message("\nDistribution niveau_educ adultes 18+ :")
print(table(adultes$niveau_educ, useNA = "always"))

message("\nDistribution groupe_age adultes 18+ :")
print(table(adultes$groupe_age, useNA = "always"))

# ---- 4.2 Enfants 6-17 ans (tâche 11 — taux de scolarisation) ----
# Variable scolarise :
#   - s2aq6 == 2 (jamais scolarisé) → 0
#   - s2aq13 == 1 (actuellement scolarisé) → 1
#   - s2aq13 == 2 (non scolarisé actuellement) → 0

enfants <- df_joint |>
  dplyr::filter(!is.na(age), age >= 6, age <= 17) |>
  dplyr::mutate(
    scolarise = dplyr::case_when(
      as.numeric(s2aq6)  == 2 ~ 0L,   # jamais été à l'école
      as.numeric(s2aq13) == 1 ~ 1L,   # actuellement scolarisé
      as.numeric(s2aq13) == 2 ~ 0L,   # a arrêté
      TRUE                    ~ NA_integer_
    ),
    scolarise_fct = factor(scolarise, levels = c(0, 1),
                           labels = c("Non scolarise", "Scolarise"))
  )

message(sprintf("\nEnfants 6-17 ans : %d obs", nrow(enfants)))
message("Distribution scolarise (6-17 ans) :")
print(table(enfants$scolarise_fct, useNA = "always"))
message("Distribution scolarise × milieu :")
print(table(enfants$scolarise_fct, enfants$milieu, useNA = "always"))


# ==============================================================================
# SECTION 5 — CONTRÔLES QUALITÉ FINAUX
# ==============================================================================

titre_section("Controles qualité finaux")

message("=== ADULTES ===")
message(sprintf("  N total          : %d", nrow(adultes)))
message(sprintf("  N avec niveau    : %d", sum(!is.na(adultes$niveau_educ))))
message(sprintf("  N avec sexe      : %d", sum(!is.na(adultes$sexe))))
message(sprintf("  N avec milieu    : %d", sum(!is.na(adultes$milieu))))
message(sprintf("  N avec state     : %d", sum(!is.na(adultes$state))))
message(sprintf("  N avec grp_age   : %d", sum(!is.na(adultes$groupe_age))))

message("\n=== ENFANTS 6-17 ===")
message(sprintf("  N total          : %d", nrow(enfants)))
message(sprintf("  N avec scolarise : %d", sum(!is.na(enfants$scolarise))))
message(sprintf("  N avec milieu    : %d", sum(!is.na(enfants$milieu))))

# Distribution niveau_educ × sexe (contrôle cohérence tâche 9)
message("\nTableau croisé niveau_educ × sexe (adultes) :")
print(table(adultes$niveau_educ, adultes$sexe, useNA = "always"))


# ==============================================================================
# SECTION 6 — SAUVEGARDE
# ==============================================================================

titre_section("Sauvegarde")

saveRDS(df_joint, "data/processed/tp2_df_joint.rds")
saveRDS(adultes,  "data/processed/tp2_adultes.rds")
saveRDS(enfants,  "data/processed/tp2_enfants.rds")

message("Sauvegardes :")
message(sprintf("  tp2_df_joint.rds : %d obs", nrow(df_joint)))
message(sprintf("  tp2_adultes.rds  : %d obs (adultes 18+)", nrow(adultes)))
message(sprintf("  tp2_enfants.rds  : %d obs (enfants 6-17)", nrow(enfants)))

message("\n--- Nettoyage TP2 termine. Etape suivante : 03_analyse.R ---")