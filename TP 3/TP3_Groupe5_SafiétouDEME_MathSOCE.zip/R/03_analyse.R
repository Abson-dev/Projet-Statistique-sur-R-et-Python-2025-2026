# ==============================================================================
# TP3 — ACCÈS AUX SOINS ET DÉPENSES DE SANTÉ
# Script  : 03_analyse.R  |  Tâches 13 à 18
# Packages : haven, dplyr, ggplot2, rstatix, ggpubr, scales, patchwork,
#            gtsummary, naniar
# ==============================================================================


library(dplyr)
library(ggplot2)
library(forcats)
library(rstatix)
library(ggpubr)
library(scales)
library(patchwork)
library(gtsummary)
library(naniar)
library(stringr)

source("R/fonctions.R")


# SECTION 1 — CHARGEMENT
titre_section("Chargement des donnees nettoyees")

# Suppression systématique des labels haven_labelled residuels dans les .rds
# (certaines colonnes GHS gardent le type haven_labelled apres saveRDS/readRDS
#  ce qui bloque as.numeric() dans dplyr::mutate et rstatix)
zap_all <- function(df) haven::zap_labels(haven::zap_label(df))

df_joint      <- zap_all(readRDS("data/processed/tp3_df_joint.rds"))
pop_totale    <- zap_all(readRDS("data/processed/tp3_pop_totale.rds"))
malades       <- zap_all(readRDS("data/processed/tp3_malades.rds"))
malades_cons  <- zap_all(readRDS("data/processed/tp3_malades_cons.rds"))
malades_cout  <- zap_all(readRDS("data/processed/tp3_malades_cout.rds"))
malades_medoc <- zap_all(readRDS("data/processed/tp3_malades_medoc.rds"))
malades_oop   <- zap_all(readRDS("data/processed/tp3_malades_oop.rds"))

message(sprintf("pop:%d | malades:%d | cons:%d | cout:%d | medoc:%d | oop:%d",
                nrow(pop_totale), nrow(malades), nrow(malades_cons),
                nrow(malades_cout), nrow(malades_medoc), nrow(malades_oop)))


# SECTION 2 — THÈME GRAPHIQUE
theme_tp3 <- theme_minimal(base_size=12) +
  theme(plot.title=element_text(face="bold",size=13),
        plot.subtitle=element_text(colour="grey40",size=10),
        plot.caption=element_text(colour="grey55",size=8),
        legend.position="bottom", panel.grid.minor=element_blank())
theme_set(theme_tp3)

pal_prest <- c("Professionnel"="#1565C0","Pharmacie"="#43A047",
               "Tradipraticien"="#FB8C00","Aucun recours"="#E53935",
               "Autre"="#9C27B0")


# ==============================================================================
# TÂCHE 13 — TAUX DE MORBIDITÉ PAR SEXE ET GROUPE D'ÂGE
# Définition : proportion de membres ayant déclaré une maladie ou blessure
# dans les 4 semaines précédant l'enquête (s4aq3 == 1)
# IC : Clopper-Pearson exact (valide pour toute valeur de k et n)
# ==============================================================================

titre_section("Tache 13 -- Taux de morbidite")

tx_global <- mean(pop_totale$morbide==1, na.rm=TRUE) * 100
message(sprintf("Taux de morbidite global : %.1f%% (N=%d)", tx_global, nrow(pop_totale)))

# ---- Par sexe ----
tx_sexe <- pop_totale |>
  dplyr::filter(!is.na(sexe)) |>
  dplyr::group_by(sexe) |>
  dplyr::summarise(n_m=sum(morbide==1), n_t=n(), .groups="drop") |>
  dplyr::mutate(
    taux   = n_m / n_t,
    IC_inf = mapply(function(k,n) binom.test(k,n)$conf.int[1], n_m, n_t),
    IC_sup = mapply(function(k,n) binom.test(k,n)$conf.int[2], n_m, n_t))
message("\nTaux de morbidite par sexe :")
print(tx_sexe)
sauvegarder_tableau(tx_sexe, "tp3_t13_morbidite_sexe")

# ---- Par groupe d'âge ----
tx_age <- pop_totale |>
  dplyr::filter(!is.na(groupe_age)) |>
  dplyr::group_by(groupe_age) |>
  dplyr::summarise(n_m=sum(morbide==1), n_t=n(), .groups="drop") |>
  dplyr::mutate(
    taux   = n_m / n_t,
    IC_inf = mapply(function(k,n) binom.test(k,n)$conf.int[1], n_m, n_t),
    IC_sup = mapply(function(k,n) binom.test(k,n)$conf.int[2], n_m, n_t))
message("\nTaux de morbidite par groupe d'age :")
print(tx_age)
sauvegarder_tableau(tx_age, "tp3_t13_morbidite_age")

# ---- Graphiques ----
p_t13_sexe <- ggplot(tx_sexe,
                     aes(x=sexe, y=taux, fill=sexe, ymin=IC_inf, ymax=IC_sup)) +
  geom_col(alpha=0.85, width=0.55, show.legend=FALSE) +
  geom_errorbar(width=0.20, linewidth=1.0, colour="grey30") +
  geom_text(aes(y=IC_sup, label=percent(taux,accuracy=0.1)),
            vjust=-0.5, size=4.2, fontface="bold") +
  scale_y_continuous(labels=percent_format(accuracy=1), limits=c(0,0.25)) +
  scale_fill_manual(values=c("Masculin"="#1565C0","Feminin"="#C62828")) +
  labs(title="Morbidite par sexe", x=NULL,
       y="Taux -- IC 95% Clopper-Pearson",
       caption=sprintf("N=%d | Taux global=%.1f%%", nrow(pop_totale), tx_global))

p_t13_age <- ggplot(tx_age,
                    aes(x=groupe_age, y=taux, fill=groupe_age, ymin=IC_inf, ymax=IC_sup)) +
  geom_col(alpha=0.85, width=0.60, show.legend=FALSE) +
  geom_errorbar(width=0.20, linewidth=1.0, colour="grey30") +
  geom_text(aes(y=IC_sup, label=percent(taux,accuracy=0.1)),
            vjust=-0.5, size=3.8, fontface="bold") +
  scale_y_continuous(labels=percent_format(accuracy=1), limits=c(0,0.40)) +
  scale_fill_viridis_d(option="D", begin=0.15, end=0.90) +
  labs(title="Morbidite par groupe d'age", x=NULL, y="Taux -- IC 95%")

p_t13 <- p_t13_sexe | p_t13_age
sauvegarder_figure(p_t13, "tp3_t13_morbidite", largeur=12, hauteur=6)


# ==============================================================================
# TÂCHE 14 — TYPES DE MALADIES DÉCLARÉES (10 affections + catégorie clinique)
# ==============================================================================

titre_section("Tache 14 -- Types de maladies")

# Labels textuels des 12 codes s4aq3b
label_mal <- c(
  "1"="Malaria",        "2"="Tuberculose",     "3"="Fievre jaune",
  "4"="Typhoid",        "5"="Cholera",          "6"="Diarrhee",
  "7"="Meningite",      "8"="Varicelle",        "9"="Pneumonie",
  "10"="Rhume commun",  "11"="Blessure/trauma", "12"="Autre")

top_mal <- malades |>
  dplyr::filter(!is.na(s4aq3b)) |>
  dplyr::mutate(
    code_str     = as.character(as.integer(s4aq3b)),
    maladie_lbl  = label_mal[code_str],
    cat_clinique = recoder_type_maladie(s4aq3b)
  ) |>
  dplyr::count(maladie_lbl, cat_clinique, sort=TRUE) |>
  dplyr::mutate(
    prop    = n / sum(n),
    maladie = forcats::fct_reorder(maladie_lbl, n)
  )

message("Fréquences types de maladies :")
print(top_mal)
sauvegarder_tableau(top_mal, "tp3_t14_types_maladies")

p_t14 <- ggplot(top_mal,
                aes(x=n, y=maladie, fill=cat_clinique)) +
  geom_col(alpha=0.88) +
  geom_text(aes(label=percent(prop, accuracy=0.1)),
            hjust=-0.12, size=3.8, fontface="bold") +
  scale_x_continuous(limits=c(0, max(top_mal$n)*1.22)) +
  scale_fill_manual(
    values=c("Infectieuse"="#E53935","Traumatique"="#1565C0","Autre"="#43A047"),
    name="Categorie clinique") +
  labs(title="Affections declarees dans les 4 dernieres semaines",
       subtitle=sprintf("Nigeria GHS W3 (2015) | N=%d malades/blesses",
                        nrow(malades)),
       x="Effectif", y=NULL,
       caption="Colore par categorie clinique (Infectieuse / Traumatique / Autre)")

sauvegarder_figure(p_t14, "tp3_t14_types_maladies", largeur=11, hauteur=6)


# ==============================================================================
# TÂCHE 15 — RECOURS AUX SOINS PAR TYPE DE PRESTATAIRE
# Fréquences + IC Clopper-Pearson, barplot ordonné
# ==============================================================================

titre_section("Tache 15 -- Recours aux soins par prestataire")

# Utiliser tous les malades avec prestataire renseigné (y compris Aucun recours)
malades_15 <- malades |> dplyr::filter(!is.na(prestataire))
message(sprintf("N malades avec prestataire renseigne : %d", nrow(malades_15)))

freq_prest <- freq_ic(malades_15$prestataire, "prestataire")
message("\nFréquences prestataire :")
print(freq_prest)
sauvegarder_tableau(freq_prest, "tp3_t15_freq_prestataire")

p_t15 <- ggplot(freq_prest,
                aes(x=proportion, y=forcats::fct_reorder(modalite,proportion),
                    xmin=IC_inf, xmax=IC_sup, fill=modalite)) +
  geom_col(alpha=0.88, show.legend=FALSE) +
  geom_errorbarh(height=0.28, linewidth=0.85, colour="grey30") +
  geom_text(aes(x=IC_sup, label=percent(proportion,accuracy=0.1)),
            hjust=-0.15, size=3.8, fontface="bold") +
  scale_x_continuous(labels=percent_format(accuracy=1),
                     limits=c(0, max(freq_prest$IC_sup)*1.20)) +
  scale_fill_manual(values=pal_prest) +
  labs(title="Type de prestataire consulte pour maladie/blessure",
       subtitle=sprintf("Nigeria GHS W3 (2015) | N=%d malades", nrow(malades_15)),
       x="Proportion (%) -- IC 95% Clopper-Pearson", y=NULL)

sauvegarder_figure(p_t15, "tp3_t15_prestataire", largeur=11, hauteur=6)


# ==============================================================================
# TÂCHE 16 — DISTRIBUTION DES DÉPENSES DE SANTÉ
# Histogramme log (s4aq14 OTC), déciles, boxplot par prestataire (s4aq9)
# + identification des valeurs aberrantes (règle Tukey 1,5×IQR)
# ==============================================================================

titre_section("Tache 16 -- Distribution des depenses de sante")

# --- 16.1 Statistiques descriptives ---
message("=== s4aq14 (médicaments OTC, tous acheteurs) ===")
stats_medoc <- resume_numerique(malades_medoc$cout_medoc, "Medicaments OTC (Naira)")
print(stats_medoc)
sauvegarder_tableau(stats_medoc, "tp3_t16_stats_medoc")

message("\n=== s4aq9 (coût consultation, parmi consultants) ===")
stats_cout <- resume_numerique(malades_cout$cout_consult, "Cout consultation (Naira)")
print(stats_cout)
sauvegarder_tableau(stats_cout, "tp3_t16_stats_consultation")

# --- 16.2 Déciles s4aq14 ---
deciles_medoc <- quantile(malades_medoc$cout_medoc, probs=seq(0,1,0.1), na.rm=TRUE)
message("\nDéciles coût médicaments OTC (Naira) :")
print(round(deciles_medoc, 0))
sauvegarder_tableau(
  data.frame(decile=names(deciles_medoc), valeur=round(deciles_medoc,0)),
  "tp3_t16_deciles_medoc")

# --- 16.3 Outliers Tukey sur s4aq14 ---
q1_m <- quantile(malades_medoc$cout_medoc, 0.25, na.rm=TRUE)
q3_m <- quantile(malades_medoc$cout_medoc, 0.75, na.rm=TRUE)
iqr_m <- q3_m - q1_m
borne_sup_m <- q3_m + 1.5*iqr_m
n_out_m <- sum(malades_medoc$cout_medoc > borne_sup_m, na.rm=TRUE)
message(sprintf("\nOutliers Tukey (>%.0f N) : %d obs (%.1f%%)",
                borne_sup_m, n_out_m,
                n_out_m/nrow(malades_medoc)*100))

# --- 16.4 Histogramme log s4aq14 ---
p_t16_hist <- ggplot(malades_medoc, aes(x=log1p(cout_medoc))) +
  geom_histogram(bins=40, fill="#1976D2", colour="white", alpha=0.85) +
  geom_vline(xintercept=log1p(median(malades_medoc$cout_medoc)),
             colour="#43A047", linewidth=1.2) +
  geom_vline(xintercept=log1p(mean(malades_medoc$cout_medoc)),
             colour="#E53935", linewidth=1.2, linetype="dashed") +
  geom_vline(xintercept=log1p(borne_sup_m),
             colour="#FF8F00", linewidth=1.0, linetype="dotted") +
  scale_x_continuous(
    breaks=log1p(c(0,100,300,500,1000,3000,10000,50000)),
    labels=function(x) format(round(expm1(x)), big.mark=" ")) +
  annotate("text", x=log1p(borne_sup_m), y=Inf,
           vjust=2, hjust=-0.05, size=3,
           label=sprintf("Tukey+\n%.0f N", borne_sup_m), colour="#FF8F00") +
  labs(title="Distribution des depenses de medicaments OTC (s4aq14)",
       subtitle=sprintf("N=%d acheteurs | Mediane=%.0f N | Moy=%.0f N | %d outliers Tukey",
                        nrow(malades_medoc),
                        median(malades_medoc$cout_medoc),
                        mean(malades_medoc$cout_medoc), n_out_m),
       x="Cout medicaments OTC (Naira, echelle log+1)",
       y="Effectif",
       caption="Vert=mediane | Rouge pointillee=moyenne | Orange pointillee=borne Tukey superieure")

# --- 16.5 Boxplot coût consultation par prestataire (s4aq9) ---
# s4aq9 est plus pertinent que s4aq21 pour le boxplot par prestataire
# car directement lié à la consultation (pas de masse de zéros artificiels)
p_t16_box <- ggplot(malades_cout,
                    aes(x=prestataire, y=log1p(cout_consult), fill=prestataire)) +
  geom_boxplot(alpha=0.75, outlier.alpha=0.20, outlier.colour="#E53935") +
  stat_summary(fun=median, geom="point", shape=18, size=4, colour="#E53935") +
  scale_y_continuous(
    breaks=log1p(c(0,50,200,500,1000,5000,20000)),
    labels=function(x) format(round(expm1(x)), big.mark=" ")) +
  scale_fill_manual(values=pal_prest) +
  scale_x_discrete(labels=function(x) str_wrap(x, 12)) +
  labs(title="Cout de consultation par type de prestataire (s4aq9)",
       subtitle=sprintf("Nigeria GHS W3 (2015) | N=%d consultants avec cout renseigne",
                        nrow(malades_cout)),
       x=NULL, y="Cout consultation (Naira, echelle log+1)",
       caption="Losange rouge = mediane | Echelle log+1 pour gerer l'asymetrie") +
  theme(legend.position="none", axis.text.x=element_text(size=9))

p_t16 <- p_t16_hist / p_t16_box
sauvegarder_figure(p_t16, "tp3_t16_depenses_sante", largeur=11, hauteur=11)


# ==============================================================================
# TÂCHE 17 — RECOURS AUX SOINS × QUINTILE DE CONSOMMATION
# Test d'indépendance : chi-deux (ou Fisher si effectifs < 5) + V de Cramér
# Barplot 100% empilé
# ==============================================================================

titre_section("Tache 17 -- Recours aux soins x quintile de consommation")

malades_17 <- malades |>
  dplyr::filter(!is.na(consulte), !is.na(quintile_lbl))
message(sprintf("N malades avec consulte + quintile : %d", nrow(malades_17)))

# Tableau de contingence
tab_17 <- table(Quintile=malades_17$quintile_lbl,
                Recours =malades_17$consulte_fct)
message("\nTableau de contingence recours × quintile :")
print(tab_17)
message("\n% ligne :")
print(round(prop.table(tab_17, margin=1)*100, 1))

# Effectifs théoriques → choix chi-deux ou Fisher
chi2_brut_17 <- chisq.test(tab_17, correct=FALSE)
min_eff_17   <- min(chi2_brut_17$expected)
message(sprintf("\nEffectif theorique minimum : %.1f", min_eff_17))

if (min_eff_17 >= 5) {
  test_17 <- chi2_brut_17
  methode_17 <- "Chi-deux de Pearson"
  message(sprintf("=> %s (tous effectifs >= 5)", methode_17))
} else {
  test_17 <- fisher.test(tab_17, simulate.p.value=TRUE, B=10000)
  methode_17 <- "Test exact de Fisher (Monte Carlo)"
  message(sprintf("=> %s (effectifs < 5)", methode_17))
}
message(sprintf("chi2/stat = %.3f | df = %s | p = %.4f",
                ifelse(methode_17=="Chi-deux de Pearson",
                       test_17$statistic, NA),
                ifelse(methode_17=="Chi-deux de Pearson",
                       as.character(test_17$parameter), "—"),
                test_17$p.value))

v_17 <- calc_cramer_v(tab=tab_17)
message(sprintf("V de Cramer = %.4f => association '%s'",
                v_17$V, v_17$interpretation))

# Interprétation du résultat p > 0,05
if (test_17$p.value >= 0.05) {
  message("\nNOTE : p >= 0.05 => on ne rejette pas H0.")
  message("Le recours aux soins ne differe pas significativement")
  message("selon le quintile de richesse (pour cette vague/echantillon).")
  message("Interpretation possible : acces quasi-universel parmi les malades,")
  message("sans gradient economique fort dans le recours aux soins.")
}

res_17 <- data.frame(
  Test=methode_17,
  Statistique=round(ifelse(methode_17=="Chi-deux de Pearson",
                           test_17$statistic, NA), 3),
  df=ifelse(methode_17=="Chi-deux de Pearson",
            as.character(test_17$parameter), "—"),
  p_valeur=round(test_17$p.value, 4),
  V_Cramer=v_17$V,
  Association=v_17$interpretation,
  N=nrow(malades_17))
sauvegarder_tableau(res_17, "tp3_t17_test_recours_quintile")

# Barplot 100% empilé
prop_17 <- malades_17 |>
  dplyr::count(quintile_lbl, consulte_fct) |>
  dplyr::group_by(quintile_lbl) |>
  dplyr::mutate(prop=n/sum(n)) |>
  dplyr::ungroup()

p_t17 <- ggplot(prop_17,
                aes(x=quintile_lbl, y=prop, fill=consulte_fct)) +
  geom_col(position="fill", alpha=0.88, width=0.6) +
  geom_text(aes(label=ifelse(prop>0.03, percent(prop,accuracy=0.1),"")),
            position=position_fill(vjust=0.5),
            size=3.5, colour="white", fontface="bold") +
  scale_y_continuous(labels=percent_format()) +
  scale_fill_manual(values=c("Non consulte"="#E53935","Consulte"="#1565C0"),
                    name="Statut de recours") +
  labs(title="Recours aux soins selon le quintile de bien-etre",
       subtitle=sprintf("%s | p=%.3f | V=%.4f (%s) | N=%d malades",
                        methode_17, test_17$p.value, v_17$V,
                        v_17$interpretation, nrow(malades_17)),
       x="Quintile de depense par tete (Q1=plus pauvre, Q5=plus riche)",
       y="Proportion (%)",
       caption=sprintf("Effectif theorique min=%.1f => %s",
                       min_eff_17, methode_17))

sauvegarder_figure(p_t17, "tp3_t17_recours_quintile", largeur=11, hauteur=6)


# ==============================================================================
# TÂCHE 18 — DÉPENSES MÉDIANES OOP : RURAL VS URBAIN
# Test de Wilcoxon-Mann-Whitney + violin plot + boxplot superposé
# ==============================================================================

titre_section("Tache 18 -- Depenses OOP rural vs urbain")

malades_18 <- malades_oop |>
  dplyr::filter(!is.na(milieu))
message(sprintf("N malades avec OOP + milieu : %d", nrow(malades_18)))
message(sprintf("  dont OOP > 0 : %d", sum(malades_18$oop > 0)))

# Statistiques par milieu
stats_18 <- malades_18 |>
  dplyr::group_by(milieu) |>
  dplyr::summarise(
    N         = n(),
    N_oop_pos = sum(oop > 0),
    Mediane   = round(median(oop, na.rm=TRUE), 0),
    Moyenne   = round(mean(oop, na.rm=TRUE), 0),
    Q1        = round(quantile(oop, 0.25, na.rm=TRUE), 0),
    Q3        = round(quantile(oop, 0.75, na.rm=TRUE), 0),
    .groups   = "drop")
message("\nStatistiques OOP par milieu (Naira) :")
print(stats_18)
sauvegarder_tableau(stats_18, "tp3_t18_stats_oop_milieu")

# Test de Wilcoxon-Mann-Whitney
# Justification : OOP très asymétrique (médiane = 0 dans les deux groupes,
# longue queue droite) → test non-paramétrique obligatoire
test_18  <- malades_18 |> wilcox_test(oop ~ milieu, paired=FALSE)
effet_18 <- malades_18 |> wilcox_effsize(oop ~ milieu)
message(sprintf("\nWilcoxon-Mann-Whitney : U=%.0f | p=%.4e | r=%.4f (%s)",
                test_18$statistic, test_18$p, effet_18$effsize, effet_18$magnitude))

# Pour la visualisation, restreindre aux OOP > 0 (violons plus informatifs)
malades_18_pos <- malades_18 |> dplyr::filter(oop > 0)
message(sprintf("Violin plot sur OOP>0 : N_Urbain=%d, N_Rural=%d",
                sum(malades_18_pos$milieu=="Urbain"),
                sum(malades_18_pos$milieu=="Rural")))

p_t18 <- ggplot(malades_18_pos,
                aes(x=milieu, y=log1p(oop), fill=milieu)) +
  geom_violin(alpha=0.55, trim=TRUE) +
  geom_boxplot(width=0.15, alpha=0.90, outlier.alpha=0.15,
               outlier.colour="#E53935") +
  stat_summary(fun=median, geom="point", shape=18, size=5, colour="#E53935") +
  stat_compare_means(method="wilcox.test", label="p.format",
                     label.x=1.5, label.y.npc=0.97) +
  scale_y_continuous(
    breaks=log1p(c(0,50,200,500,1000,5000,20000,100000)),
    labels=function(x) format(round(expm1(x)), big.mark=" ")) +
  scale_fill_manual(values=c("Urbain"="#FF7043","Rural"="#42A5F5")) +
  labs(title="Depenses OOP par milieu de residence",
       subtitle=sprintf(
         "Nigeria GHS W3 (2015) | Wilcoxon p=%.3f | r=%.4f (%s)",
         test_18$p, effet_18$effsize, effet_18$magnitude),
       x="Milieu (variable : sector)",
       y="OOP total (Naira, echelle log+1)",
       caption=sprintf(
         "Uniquement malades avec OOP>0 | N_Urbain=%d, N_Rural=%d | Losange rouge=mediane",
         sum(malades_18_pos$milieu=="Urbain"),
         sum(malades_18_pos$milieu=="Rural"))) +
  theme(legend.position="none")

sauvegarder_figure(p_t18, "tp3_t18_oop_milieu", largeur=8, hauteur=8)


# ==============================================================================
# FIGURE DE SYNTHÈSE TP3
# ==============================================================================

titre_section("Figure de synthese TP3")

p_syn <- (p_t13_sexe | p_t13_age) /
  (p_t14 | p_t15) /
  (p_t17 | p_t18) +
  patchwork::plot_annotation(
    title    = "TP3 -- Acces aux soins et depenses de sante (Nigeria GHS W3, 2015)",
    subtitle = "ENSAE ISE 1 (2025-2026)",
    caption  = "Source : World Bank LSMS-ISA")
sauvegarder_figure(p_syn, "tp3_synthese", largeur=18, hauteur=22)


# ==============================================================================
# RÉCAPITULATIF FINAL
# ==============================================================================

titre_section("Recapitulatif TP3")

message(sprintf("T13 -- Taux morbidite global    : %.1f%%", tx_global))
message(sprintf("       Femmes vs hommes          : %.1f%% vs %.1f%%",
                tx_sexe$taux[tx_sexe$sexe=="Feminin"]*100,
                tx_sexe$taux[tx_sexe$sexe=="Masculin"]*100))
message(sprintf("       60+ ans                   : %.1f%%",
                tx_age$taux[tx_age$groupe_age=="60+ ans"]*100))
message(sprintf("T14 -- N malades avec type rens. : %d", sum(!is.na(malades$s4aq3b))))
message(sprintf("       Affection #1              : %s (%.1f%%)",
                as.character(top_mal$maladie[1]), top_mal$prop[1]*100))
message(sprintf("T15 -- Prestataire le + freq.    : %s (%.1f%%)",
                freq_prest$modalite[1], freq_prest$proportion[1]*100))
message(sprintf("T16 -- Mediane cout OTC          : %.0f Naira",
                stats_medoc$mediane))
message(sprintf("       N outliers Tukey           : %d (%.1f%%)",
                n_out_m, n_out_m/nrow(malades_medoc)*100))
message(sprintf("T17 -- %s | p=%.4f | V=%.4f (%s)",
                methode_17, test_17$p.value, v_17$V, v_17$interpretation))
message(sprintf("T18 -- Wilcoxon p=%.4e | r=%.4f (%s)",
                test_18$p, effet_18$effsize, effet_18$magnitude))
message(sprintf("       Mediane OOP Urbain : %.0f N | Rural : %.0f N",
                stats_18$Mediane[stats_18$milieu=="Urbain"],
                stats_18$Mediane[stats_18$milieu=="Rural"]))

message("\nFigures : output/figures/ | Tableaux : output/tables/")
message("--- Analyses TP3 terminees. Etape suivante : rapport/tp3_rapport.Rmd ---")