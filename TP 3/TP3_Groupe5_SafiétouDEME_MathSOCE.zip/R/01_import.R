# ==============================================================================
# TP3 — ACCÈS AUX SOINS ET DÉPENSES DE SANTÉ
# Script  : 01_import.R
# Données : sect4a_harvestw3.dta | sect1_harvestw3.dta | secta_harvestw3.dta
#           cons_agg_wave3_visit2.dta
# ==============================================================================
# CORRESPONDANCES GHS W3 vs nomenclature TP (W1/W2) :
#
#   TP cite         │ Fichier W3               │ Variable W3
#   ───────────────────────────────────────────────────────
#   sect3a          │ sect4a_harvestw3.dta      │ —
#   s3aq1 (maladie) │ idem                      │ s4aq3
#   s3aq3 (type)    │ idem                      │ s4aq3b
#   sect3b          │ sect4a_harvestw3.dta      │ — (fusionné avec sect3a)
#   s3bq1 (consult) │ idem                      │ s4aq6a
#   s3bq8 (dépense) │ idem                      │ s4aq21 (OOP total)
#   cons_agg_w4_v2  │ cons_agg_wave3_visit2.dta │ totcons, hhsize
#
# Note OOP : s4aq21 (OOP total) présente 85% de zéros chez les malades car
# inclut ceux ne payant rien (pharmacie informelle, soins gratuits, etc.).
# Pour T16 (boxplot par prestataire) on utilisera s4aq9 (coût consultation).
# Pour T18 (OOP rural/urbain) on utilisera s4aq21 sur les non-zéros.
# ==============================================================================


library(haven)
library(dplyr)
library(naniar)
library(ggplot2)

source("R/fonctions.R")

dir.create("data/processed", recursive=TRUE, showWarnings=FALSE)
dir.create("output/figures",  recursive=TRUE, showWarnings=FALSE)
dir.create("output/tables",   recursive=TRUE, showWarnings=FALSE)

DOSSIER_RAW  <- "data/raw"
DOSSIER_PROC <- "data/processed"


# ==============================================================================
# SECTION 1 — IMPORT sect4a_harvestw3 (= sect3a + sect3b fusionnés en W3)
# ==============================================================================

titre_section("Import sect4a_harvestw3 (sante individuelle)")

sect4a_w3 <- haven::read_dta(file.path(DOSSIER_RAW, "sect4a_harvestw3.dta"))
message(sprintf("Dimensions : %d obs x %d variables", nrow(sect4a_w3), ncol(sect4a_w3)))

# Labels des variables clés
vars_cles <- c("s4aq3","s4aq3b","s4aq6a","s4aq8a","s4aq9","s4aq14","s4aq21","s4aq13")
message("\nLabels variables cles :")
for (v in vars_cles) {
  lab  <- attr(sect4a_w3[[v]], "label")
  lbls <- attr(sect4a_w3[[v]], "labels")
  if (!is.null(lab)) message(sprintf("  %s : %s", v, lab))
  if (!is.null(lbls) && length(lbls) <= 15)
    message(sprintf("    Codes: %s",
                    paste(names(lbls),"=",lbls,collapse=" | ")))
}

# Doublons
n_doub_s4 <- sect4a_w3 |> group_by(hhid,indiv) |> filter(n()>1) |> nrow()
message(sprintf("\nDoublons (hhid+indiv) : %d", n_doub_s4))

# Distributions variables clés
message("\ns4aq3 (maladie/blessure 4 semaines) :")
print(table(as.numeric(sect4a_w3$s4aq3), useNA="always"))

message("\ns4aq3b (type maladie) :")
print(table(as.numeric(sect4a_w3$s4aq3b), useNA="always"))

message("\ns4aq6a (prestataire consulte) :")
print(table(as.numeric(sect4a_w3$s4aq6a), useNA="always"))

message("\ns4aq8a (type etablissement) :")
print(table(as.numeric(sect4a_w3$s4aq8a), useNA="always"))

message("\nStats s4aq21 (OOP total, Naira) :")
print(summary(as.numeric(sect4a_w3$s4aq21)))

message("\nStats s4aq9 (cout consultation, Naira) :")
print(summary(as.numeric(sect4a_w3$s4aq9)))

message("\nStats s4aq14 (medicaments OTC, Naira) :")
print(summary(as.numeric(sect4a_w3$s4aq14)))


# ==============================================================================
# SECTION 2 — IMPORT sect1_harvestw3 (sexe, âge, statut résident)
# ==============================================================================

titre_section("Import sect1_harvestw3")

sect1_w3 <- haven::read_dta(file.path(DOSSIER_RAW, "sect1_harvestw3.dta"))
message(sprintf("Dimensions : %d obs x %d variables", nrow(sect1_w3), ncol(sect1_w3)))

n_doub_s1 <- sect1_w3 |> group_by(hhid,indiv) |> filter(n()>1) |> nrow()
message(sprintf("Doublons : %d", n_doub_s1))

message("\nDistribution s1q2 (sexe) :")
print(table(as.numeric(sect1_w3$s1q2), useNA="always"))
message("\nRésumé s1q4 (age) :")
print(summary(as.numeric(sect1_w3$s1q4)))


# ==============================================================================
# SECTION 3 — IMPORT secta_harvestw3 (poids de sondage)
# ==============================================================================

titre_section("Import secta_harvestw3")

secta_w3 <- haven::read_dta(file.path(DOSSIER_RAW, "secta_harvestw3.dta"))
message(sprintf("Dimensions : %d menages x %d variables", nrow(secta_w3), ncol(secta_w3)))

message("\nDistribution sector (milieu) :")
print(table(as.numeric(secta_w3$sector), useNA="always"))
# 1=Urbain (1476), 2=Rural (3116), confirme avec recoder_secteur()

message("\nRésumé poids wt_wave3 :")
print(summary(secta_w3$wt_wave3))


# ==============================================================================
# SECTION 4 — IMPORT cons_agg_wave3_visit2 (richesse → quintile)
# ==============================================================================

titre_section("Import cons_agg_wave3_visit2")

cons_w3 <- haven::read_dta(file.path(DOSSIER_RAW, "cons_agg_wave3_visit2.dta"))
message(sprintf("Dimensions : %d menages x %d variables", nrow(cons_w3), ncol(cons_w3)))
message("\nVariables disponibles :")
message(paste(names(cons_w3), collapse=", "))

message("\nStats totcons (dépense annuelle ménage, Naira) :")
print(summary(as.numeric(cons_w3$totcons)))
message("Stats hhsize :")
print(summary(as.numeric(cons_w3$hhsize)))


# ==============================================================================
# SECTION 5 — COHÉRENCE DES CLÉS
# ==============================================================================

titre_section("Coherence des cles")

hh_s4  <- n_distinct(sect4a_w3$hhid)
hh_s1  <- n_distinct(sect1_w3$hhid)
hh_sa  <- n_distinct(secta_w3$hhid)
hh_con <- n_distinct(cons_w3$hhid)
hh_com_s4_s1  <- n_distinct(intersect(sect4a_w3$hhid, sect1_w3$hhid))
hh_com_s4_con <- n_distinct(intersect(sect4a_w3$hhid, cons_w3$hhid))

message(sprintf("Menages uniques : sect4a=%d | sect1=%d | secta=%d | cons=%d",
                hh_s4, hh_s1, hh_sa, hh_con))
message(sprintf("Communs sect4a ∩ sect1    : %d", hh_com_s4_s1))
message(sprintf("Communs sect4a ∩ cons_agg : %d", hh_com_s4_con))


# ==============================================================================
# SECTION 6 — SAUVEGARDE
# ==============================================================================

saveRDS(sect4a_w3, file.path(DOSSIER_PROC, "sect4a_w3_raw.rds"))
saveRDS(sect1_w3,  file.path(DOSSIER_PROC, "sect1_w3_raw.rds"))
saveRDS(secta_w3,  file.path(DOSSIER_PROC, "secta_w3_raw.rds"))
saveRDS(cons_w3,   file.path(DOSSIER_PROC, "cons_w3_raw.rds"))

recap <- data.frame(
  Fichier  = c("sect4a_harvestw3","sect1_harvestw3","secta_harvestw3",
               "cons_agg_wave3_visit2"),
  Niveau   = c("Individu","Individu","Menage","Menage"),
  N_lignes = c(nrow(sect4a_w3),nrow(sect1_w3),nrow(secta_w3),nrow(cons_w3)),
  N_vars   = c(ncol(sect4a_w3),ncol(sect1_w3),ncol(secta_w3),ncol(cons_w3)),
  Doublons = c(n_doub_s4, n_doub_s1, 0, 0)
)
print(recap)
sauvegarder_tableau(recap, "tp3_recap_import")

message("\n--- Import TP3 termine. Etape suivante : 02_nettoyage.R ---")