# ==============================================================================
# TP3 — ACCÈS AUX SOINS ET DÉPENSES DE SANTÉ
# Script  : 02_nettoyage.R
# Prérequis : 01_import.R
# ==============================================================================
# VARIABLES CONSTRUITES :
#   morbide       — 1/0 : maladie ou blessure dans les 4 dernières semaines
#   morbide_fct   — facteur labelisé
#   type_maladie  — 3 catégories cliniques (Infectieuse/Traumatique/Autre)
#   prestataire   — 5 types de recours (s4aq6a recodé)
#   type_etab     — Public / Prive / Autre (s4aq8a recodé)
#   consulte      — 1=a consulté un prestataire, 0=pas de recours
#   consulte_fct  — facteur labelisé
#   cout_consult  — s4aq9 : coût 1ère consultation (Naira)
#   cout_medoc    — s4aq14 : coût médicaments OTC (Naira)
#   oop           — s4aq21 : dépense out-of-pocket totale (Naira)
#   sexe          — Masculin/Feminin
#   age           — nettoyé (0–110)
#   groupe_age    — 4 groupes (0-14, 15-24, 25-59, 60+)
#   milieu        — Urbain/Rural (depuis sector de sect4a)
#   zone_geo      — 6 zones géopolitiques
#   quintile_lbl  — 5 quintiles de dépense par tête (cons_agg)
#   depense_tete  — totcons/hhsize (Naira/an)
#
# DÉCISIONS MÉTHODOLOGIQUES SUR LES DÉPENSES :
#   - s4aq21 (OOP total) : 85 % de zéros parmi les malades car inclut ceux
#     ne payant rien. Distribution extrêmement asymétrique.
#     → Utilisé pour T17 (recours×quintile) et T18 (rural/urbain).
#   - s4aq9 (coût consultation) : disponible chez ~95% des consultants,
#     médiane=150 Naira. Plus pertinent pour boxplot par prestataire (T16).
#   - s4aq14 (médicaments OTC) : médiane=500 Naira, distribution moins
#     extrême. Utilisé pour histogramme général (T16).
# ==============================================================================


library(dplyr)
library(haven)
library(naniar)

source("R/fonctions.R")


# SECTION 1 — CHARGEMENT
titre_section("Chargement des donnees brutes")

sect4a_w3 <- readRDS("data/processed/sect4a_w3_raw.rds")
sect1_w3  <- readRDS("data/processed/sect1_w3_raw.rds")
secta_w3  <- readRDS("data/processed/secta_w3_raw.rds")
cons_w3   <- readRDS("data/processed/cons_w3_raw.rds")

message(sprintf("sect4a:%d | sect1:%d | secta:%d | cons:%d",
                nrow(sect4a_w3), nrow(sect1_w3), nrow(secta_w3), nrow(cons_w3)))


# ==============================================================================
# SECTION 2 — QUINTILES DE CONSOMMATION
# Dépense par tête = totcons / hhsize (Naira annuel par membre équivalent)
# Q1=plus pauvre → Q5=plus riche
# ==============================================================================

titre_section("Construction des quintiles de consommation")

cons_clean <- cons_w3 |>
  dplyr::mutate(
    totcons      = as.numeric(totcons),
    hhsize       = as.numeric(hhsize),
    depense_tete = totcons / hhsize,
    quintile_conso = dplyr::ntile(depense_tete, 5),
    quintile_lbl   = factor(quintile_conso, levels=1:5,
                            labels=c("Q1 (plus pauvre)","Q2","Q3",
                                     "Q4","Q5 (plus riche)"))
  ) |>
  dplyr::select(hhid, depense_tete, quintile_conso, quintile_lbl)

message("Dépense par tête (Naira/an) :")
print(summary(cons_clean$depense_tete))
message("\nDistribution des quintiles :")
print(table(cons_clean$quintile_lbl))


# ==============================================================================
# SECTION 3 — JOINTURES
# sect4a possède déjà zone/state/lga/sector → on les conserve directement.
# Pas besoin de jointure avec secta pour les variables géographiques.
# On joint uniquement : sect1 (sexe, âge) et cons_agg (quintile).
# ==============================================================================

titre_section("Jointures")

sect1_utile <- sect1_w3 |>
  dplyr::select(hhid, indiv, s1q2, s1q4, s1q4a) |>
  dplyr::rename(sexe_code=s1q2, age_raw=s1q4, resident=s1q4a)

secta_utile <- secta_w3 |>
  dplyr::select(hhid, wt_wave3)  # poids uniquement

# Jointure : sect4a + sect1 + secta (poids) + cons_agg (quintile)
# NE PAS supprimer zone/sector/state de sect4a : ce sont les variables de
# référence géographique directement collectées au niveau individu.
df_joint <- sect4a_w3 |>
  dplyr::left_join(sect1_utile, by=c("hhid","indiv")) |>
  dplyr::left_join(secta_utile, by="hhid") |>
  dplyr::left_join(cons_clean,  by="hhid")

message(sprintf("Après jointures : %d obs x %d variables",
                nrow(df_joint), ncol(df_joint)))

message("\nNA sur variables jointes :")
print(
  df_joint |>
    dplyr::select(age_raw, sexe_code, wt_wave3, quintile_lbl) |>
    naniar::miss_var_summary() |>
    as.data.frame()
)


# ==============================================================================
# SECTION 4 — RECODAGE DES VARIABLES ANALYTIQUES
# ==============================================================================

titre_section("Recodage des variables analytiques")

df_joint <- df_joint |>
  dplyr::mutate(
    # --- Démographie ---
    sexe      = recoder_sexe(sexe_code),
    age       = dplyr::case_when(
      as.numeric(age_raw) < 0   ~ NA_real_,
      as.numeric(age_raw) > 110 ~ NA_real_,
      TRUE                      ~ as.numeric(age_raw)),
    groupe_age = recoder_groupe_age_sante(age),
    
    # --- Géographie (depuis sect4a directement) ---
    milieu   = recoder_secteur(sector),
    zone_geo = recoder_zone_geo(zone),
    
    # --- MORBIDITÉ (s4aq3 = équivalent s3aq1) ---
    # 1=malade/blessé, 2=non → recoder en binaire
    morbide = dplyr::case_when(
      as.numeric(s4aq3)==1 ~ 1L,
      as.numeric(s4aq3)==2 ~ 0L,
      TRUE                 ~ NA_integer_),
    morbide_fct = factor(morbide, levels=c(0,1),
                         labels=c("Non malade","Malade/blesse")),
    
    # --- TYPE DE MALADIE (s4aq3b = équivalent s3aq3) ---
    type_maladie = recoder_type_maladie(s4aq3b),
    
    # --- RECOURS AUX SOINS (s4aq6a = équivalent s3bq1) ---
    prestataire = recoder_prestataire(s4aq6a),
    # consulte = 1 si prestataire != 12 (personne) et non-NA
    # Pour les malades avec s4aq6a NA : cas marginaux (3 obs) → 0 conservateur
    consulte = dplyr::case_when(
      as.numeric(s4aq6a)==12            ~ 0L,   # code "Personne" = pas de recours
      !is.na(as.numeric(s4aq6a))        ~ 1L,   # a consulté quelqu'un
      is.na(as.numeric(s4aq6a)) & as.numeric(s4aq3)==1 ~ 0L, # malade sans info → pas consulté
      TRUE                              ~ NA_integer_),
    consulte_fct = factor(consulte, levels=c(0,1),
                          labels=c("Non consulte","Consulte")),
    
    # --- TYPE D'ÉTABLISSEMENT (s4aq8a) ---
    type_etab = recoder_type_etab(s4aq8a),
    
    # --- DÉPENSES DE SANTÉ (Naira) ---
    oop          = as.numeric(s4aq21),  # OOP total (s3bq8 équivalent)
    cout_consult = as.numeric(s4aq9),   # coût 1ère consultation
    cout_medoc   = as.numeric(s4aq14)   # médicaments OTC
  )

message("Distribution morbide :")
print(table(df_joint$morbide_fct, useNA="always"))
message("\nTaux de morbidite global :")
message(sprintf("  %.1f%%", mean(df_joint$morbide==1, na.rm=TRUE)*100))

message("\nDistribution prestataire (parmi individus avec s4aq6a renseigné) :")
print(table(df_joint$prestataire, useNA="always"))

message("\nDistribution milieu :")
print(table(df_joint$milieu, useNA="always"))


# ==============================================================================
# SECTION 5 — SOUS-ENSEMBLES ANALYTIQUES
# ==============================================================================

titre_section("Sous-ensembles analytiques")

# Population totale avec morbide renseigné (T13 : taux morbidité)
pop_totale <- df_joint |>
  dplyr::filter(!is.na(morbide), !is.na(sexe), !is.na(age))

# Individus malades (T14, T15, T16, T17, T18)
malades <- df_joint |>
  dplyr::filter(morbide == 1L)

# Malades ayant consulté (T15, T16 boxplot)
malades_cons <- malades |>
  dplyr::filter(consulte == 1L, !is.na(prestataire))

# Malades avec coût consultation renseigné (T16 boxplot par prestataire)
malades_cout <- malades_cons |>
  dplyr::filter(!is.na(cout_consult))

# Malades avec médicaments OTC renseignés (T16 histogramme)
malades_medoc <- df_joint |>
  dplyr::filter(!is.na(cout_medoc), cout_medoc > 0)

# Malades avec OOP renseigné (T17, T18)
malades_oop <- malades |>
  dplyr::filter(!is.na(oop))

message(sprintf("pop_totale     : %d", nrow(pop_totale)))
message(sprintf("malades        : %d (%.1f%%)", nrow(malades),
                nrow(malades)/nrow(pop_totale)*100))
message(sprintf("malades_cons   : %d (%.1f%% des malades)",
                nrow(malades_cons), nrow(malades_cons)/nrow(malades)*100))
message(sprintf("malades_cout   : %d", nrow(malades_cout)))
message(sprintf("malades_medoc  : %d (OTC > 0)", nrow(malades_medoc)))
message(sprintf("malades_oop    : %d", nrow(malades_oop)))
message(sprintf("  dont OOP > 0 : %d (%.1f%%)",
                sum(malades_oop$oop > 0),
                sum(malades_oop$oop > 0)/nrow(malades_oop)*100))


# ==============================================================================
# SECTION 6 — CONTRÔLE QUALITÉ FINAL
# ==============================================================================

titre_section("Controle qualite final")

message("NA sur variables analytiques principales :")
print(
  df_joint |>
    dplyr::select(morbide, type_maladie, prestataire, consulte,
                  oop, cout_consult, cout_medoc, sexe, milieu,
                  groupe_age, quintile_lbl) |>
    naniar::miss_var_summary() |>
    as.data.frame()
)

message("\nStats OOP (s4aq21) parmi malades (Naira) :")
print(resume_numerique(malades_oop$oop, "OOP total (Naira)"))

message("\nStats cout_consult (s4aq9) parmi consultants :")
print(resume_numerique(malades_cout$cout_consult, "Cout consultation (Naira)"))

message("\nStats cout_medoc (s4aq14, tous individus > 0) :")
print(resume_numerique(malades_medoc$cout_medoc, "Medicaments OTC (Naira)"))


# ==============================================================================
# SECTION 7 — SAUVEGARDE
# ==============================================================================

saveRDS(df_joint,     "data/processed/tp3_df_joint.rds")
saveRDS(pop_totale,   "data/processed/tp3_pop_totale.rds")
saveRDS(malades,      "data/processed/tp3_malades.rds")
saveRDS(malades_cons, "data/processed/tp3_malades_cons.rds")
saveRDS(malades_cout, "data/processed/tp3_malades_cout.rds")
saveRDS(malades_medoc,"data/processed/tp3_malades_medoc.rds")
saveRDS(malades_oop,  "data/processed/tp3_malades_oop.rds")

message(sprintf("\nSauvegardes OK : %d fichiers .rds dans data/processed/", 7))
message("\n--- Nettoyage TP3 termine. Etape suivante : 03_analyse.R ---")