# Chargement des packages

library(haven)
library(naniar)
library(openxlsx)
library(dplyr)
library(ggplot2)
library(patchwork)

# Chargement des bases
 
## vague 4

secta1_harvestw4 <- read_dta("secta1_harvestw4.dta")
sect11b1_planting <- read_dta("sect11b1_plantingw4.dta")
secta_harvestw4 <- read_dta("secta_harvestw4.dta")

# Exploration et préparation des bases 

## Vague 4

### Variables disponibles et leurs libellés

names(secta1_harvestw4)
names(sect11b1_planting)

variables_secta1w4 <- data.frame(variables = names(secta1_harvestw4),
                               libellés = sapply(secta1_harvestw4, function(x) attr(x,"label")))
write.xlsx(variables_secta1w4,"variables_secta1w4.xlsx")

variables_sectaw4 <- data.frame(variables = names(secta_harvestw4),
                                 libellés = sapply(secta_harvestw4, function(x) attr(x,"label")))
write.xlsx(variables_sectaw4,"variables_sectaw4.xlsx")


variables_sect11b1 <- data.frame(variables = names(sect11b1_planting),
                               libellés = sapply(sect11b1_planting, function(x) attr(x,"label")))
write.xlsx(variables_sect11b1,"variables_sect11b1.xlsx")

### Création d'identifiant unique pour chaque base pour jointure

secta1_harvestw4 <- secta1_harvestw4 %>% 
  mutate(iden_unique = paste(hhid, plotid, sep = "_") )

sect11b1_planting <- sect11b1_planting %>% 
  mutate(iden_unique = paste(hhid, plotid, sep = "_"))

#### Vérification de l'unicité de la variable de jointure iden_unique

anyDuplicated(secta1_harvestw4$iden_unique)
anyDuplicated(sect11b1_planting$iden_unique)

### Jointure des deux bases

secta1_harvestw4 <- secta1_harvestw4 %>% 
  left_join(
    sect11b1_planting %>% select(iden_unique,s11b1q4),
    by = "iden_unique")

secta1_harvestw4 <- secta1_harvestw4 %>% 
  left_join(
    secta_harvestw4 %>% select(hhid,wt_wave4,interview_result),
    by = "hhid"
  )

### Donnons des noms explicites aux variables 

secta1_harvestw4 <- secta1_harvestw4 %>%
  rename(
    zone_geopoli              = zone,
    etat                      = state,
    zone_gouvenmnt_loc        = lga,
    milieu                    = sector,
    zone_denombre             = ea,
    iden_menage               = hhid,
    iden_parcelle             = plotid,
    parce_decla_cul_ps        = sa1q1aa,
    parce_mesuree_gps_prec = sa1q1a,
    superfi_gps_prec_m2    = prefilled_gps_area,
    parce_signa_nouv_mesure  = sa1q1d,
    repondant_parcelle = sa1q3,
    accesouposse_parce = sa1q4,
    comment_perte_acces = sa1q5,
    comment_perte_acces_autre = sa1q5_os,
    montant_recu_parcelle     = sa1q6,
    pourquoi_perte_acces      = sa1q7,
    pourquoi_perte_acces_autre= sa1q7_os,
    decideur_principal        = sa1q2,
    autres_decideurs          = sa1q2b,
    autre_decideur_1          = sa1q2c_1,
    autre_decideur_2          = sa1q2c_2,
    autre_decideur_3          = sa1q2c_3,
    autre_decideur_4          = sa1q2c_4,
    autre_decideur_5          = sa1q2c_5,
    autre_decideur_6          = sa1q2c_6,
    decideur_princ_confirme   = sa1q8a,
    ancien_decideur_princ     = sa1q8b,
    raison_chgt_decideur      = sa1q8c,
    raison_chgt_decideur_autre= sa1q8c_os,
    parcelle_mesuree_gps      = sa1q9,
    raison_non_mesure_gps     = sa1q10,
    raison_non_mesure_gps_os  = sa1q10_os,
    raison_non_mesure_gps_0   = sa1q10_0,
    superficie_declaree_m2    = sa1q11,
    tenure = s11b1q4,
    poids = wt_wave4
  )

### Sélection des variables d'intérêt

secta1_harvestw4 <- secta1_harvestw4 %>% 
  select(zone_geopoli,
         etat,
         zone_gouvenmnt_loc,
         milieu, 
         zone_denombre,
         iden_menage,
         iden_parcelle,
         parce_mesuree_gps_prec,
         superfi_gps_prec_m2,
         parcelle_mesuree_gps,
         superficie_declaree_m2,
         tenure,
         interview_result,
         poids
         )

### Valeurs manquantes

#### avec vis_miss

##### Version simple

vis_miss(secta1_harvestw4) # Version simple

##### Version avancée 

graph1_valeurs_manquantes_secta1w4 <- vis_miss(secta1_harvestw4) +
  labs(
    title = "Carte des valeurs manquantes de la base secta1_harvestw4",
    subtitle = "Les lignes représentent les les observations et les colonnes, les variables") +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 7),
    axis.text.y = element_text(size = 8),
    axis.ticks.y = element_blank(),
    plot.margin = margin(t = 50, r = 20, b = 20, l = 20, unit = "pt")
    ) +
  scale_y_continuous(
    breaks = c(1, 1000, 2000, 3000, 4000, 5000, 6000, 7000,8000, 9000, 10000, 11000),
    labels = c("1","1000","2000","3000","4000","5000","6000","7000","8000","9000","10000","11000")
  )

##### Sauvegarde en PNG

ggsave(
  filename = "valeurs_manquantes1_secta1w4.png",
  plot     = graph1_valeurs_manquantes_secta1w4,
  width    = 12,      # largeur en pouces — augmenter si libellés encore coupés
  height   = 6,       # hauteur en pouces
  dpi      = 300      # résolution (300 = qualité impression)
)

#### avec gg_miss_var

##### version simple

gg_miss_var(secta1_harvestw4)

##### version avancé

graph2_valeurs_manquantes_secta1w4 <- gg_miss_var(secta1_harvestw4) +
  labs(
    title    = "Valeurs manquantes — secta1_harvestw4",
    subtitle = "Les colonnes représentent les valeurs manquantes, chaque ligne une variable"
  )

##### sauvergarde en png

ggsave(
  filename = "Valeurs_manquantes2_secta1w4.png",
  plot     = graph2_valeurs_manquantes_secta1w4,
  width    = 12,      # largeur en pouces — augmenter si libellés encore coupés
  height   = 6,       # hauteur en pouces
  dpi      = 300      # résolution (300 = qualité impression)
)

#### tableau des valeurs manquantes avec miss_var_summury

valeurs_manquantes_secta1_harvestw4 <- as.data.frame(miss_var_summary(secta1_harvestw4)) %>% 
  mutate(across(everything(), ~ as.vector(.x)))
write.xlsx(valeurs_manquantes_secta1_harvestw4,"valeurs_manquantes_secta1_harvestw4.xlsx")

# 19. Construction de la variable superficie en hectare, calcul superficie totale par menage et descripions des valeurs manquantes et aberrantes

## Construction de la variable superficie en hectare

secta1_harvestw4 <- secta1_harvestw4 %>%
  mutate(
    superf_gps_ha  = superfi_gps_prec_m2 / 10000,
    superf_decl_ha = superficie_declaree_m2 / 10000,
    superf_ha = if_else(!is.na(superf_gps_ha), superf_gps_ha, superf_decl_ha)
  )

## calcul superficie totale par menage 

superficie_tot_pr_men <- secta1_harvestw4 %>% 
  group_by(iden_menage) %>% 
  summarise(
    nb_parcelles   = n(),
    superf_tot_ha  = sum(superf_ha, na.rm = TRUE),
    nb_avec_mesure = sum(!is.na(superf_ha)),
    .groups = "drop"
  )

write_dta(superficie_tot_pr_men, "superficie_tot_pr_menage.dta")

## Valeurs manquantes

valeurs_manquantes <- secta1_harvestw4 %>%
  summarise(
    total_parcelles    = n(),
    manq_gps           = sum(is.na(superf_gps_ha)),
    pct_manq_gps       = round(100 * mean(is.na(superf_gps_ha)), 1),
    manq_decl          = sum(is.na(superf_decl_ha)),
    pct_manq_decl      = round(100 * mean(is.na(superf_decl_ha)), 1),
    manq_superf_ha     = sum(is.na(superf_ha)),
    pct_manq_superf_ha = round(100 * mean(is.na(superf_ha)), 1)
  ) 

## Valeurs aberrantes

Valeurs_aberrantes <- secta1_harvestw4 %>%
  filter(!is.na(superf_ha) & (superf_ha < 0 | superf_ha > 500)) %>%
  select(iden_menage, iden_parcelle, superf_gps_ha, superf_decl_ha, superf_ha)
cat("il y a",nrow(valeurs_manquantes), "valeurs aberrantes")

# 20. Analyse univariée de la superficie par parcelle et par ménage

## histogramme echelle log Superficie par parcelle

p1 <- secta1_harvestw4 %>%
  filter(!is.na(superf_ha) & superf_ha > 0) %>%
  ggplot(aes(x = superf_ha)) +
  geom_histogram(bins = 40, fill = "#2E86AB", color = "white") +
  scale_x_log10(labels = scales::comma) +
  labs(
    title    = "Distribution de la superficie par parcelle",
    subtitle = "Échelle logarithmique — Wave 4",
    x        = "Superficie (ha) — échelle log",
    y        = "Nombre de parcelles"
  ) +
  theme_minimal()

ggsave(
  filename = "Distribution_de_la_superficie_par_parcelle.png",
  plot = p1,
  width = 12,
  height = 6,
  dpi = 300
)

## Boxplot superficie par parcelle 

p2 <- secta1_harvestw4 %>%
  filter(!is.na(superf_ha) & superf_ha > 0 & superf_ha <= 500) %>%
  ggplot(aes(y = superf_ha)) +
  geom_boxplot(fill = "#2E86AB", color = "#1a5276", width = 0.4) +
  scale_y_log10(labels = scales::comma) +
  labs(
    title    = "Boxplot — superficie par parcelle",
    subtitle = "Échelle log · valeurs > 500 ha exclues",
    x        = "",
    y        = "Superficie (ha)"
  ) +
  theme_minimal() +
  theme(axis.text.x = element_blank(),
        axis.ticks.x = element_blank())
ggsave(
  filename = "boxplot_superf_parcel.png",
  plot = p2,
  width = 12,
  height = 6,
  dpi = 300
)

## Statistiques descriptives par décile — superficie par parcelle

stat_par_dec <- secta1_harvestw4 %>%
  filter(!is.na(superf_ha) & superf_ha > 0) %>%
  mutate(decile = ntile(superf_ha, 10)) %>%
  group_by(decile) %>%
  summarise(
    n       = n(),
    min     = round(min(superf_ha), 4),
    max     = round(max(superf_ha), 4),
    moyenne = round(mean(superf_ha), 4),
    mediane = round(median(superf_ha), 4)
  )
write.xlsx(stat_par_dec, "statistiques_par_deciles.xlsx")

## Scatter plot déclaré vs GPS + ligne 45° 

### Garder uniquement les parcelles avec les deux mesures disponibles

df_comparaison <- secta1_harvestw4 %>%
  filter(!is.na(superf_gps_ha) & !is.na(superf_decl_ha) &
           superf_gps_ha > 0     & superf_decl_ha > 0)

cat("Nombre de parcelles avec les deux mesures :", nrow(df_comparaison), "\n")

### Corrélation de Spearman

cor_spearman <- cor.test(
  df_comparaison$superf_decl_ha,
  df_comparaison$superf_gps_ha,
  method = "spearman"
)

cat("Corrélation de Spearman :", round(cor_spearman$estimate, 3), "\n")
cat("p-valeur               :", format(cor_spearman$p.value, scientific = TRUE), "\n")

### Scatter plot

p3 <- df_comparaison %>%
  ggplot(aes(x = superf_gps_ha, y = superf_decl_ha)) +
  geom_point(alpha = 0.4, color = "#2E86AB", size = 1.5) +
  geom_abline(slope = 1, intercept = 0,
              color = "red", linetype = "dashed", linewidth = 1) +
  scale_x_log10(labels = scales::comma) +
  scale_y_log10(labels = scales::comma) +
  annotate("text",
           x     = Inf, y = -Inf,
           label = paste0("ρ de Spearman = ", round(cor_spearman$estimate, 3)),
           hjust = 1.1, vjust = -1,
           size  = 4, color = "#1a5276") +
  labs(
    title    = "Superficie déclarée vs superficie GPS",
    subtitle = "Ligne rouge = accord parfait (45°) · Échelle log",
    x        = "Superficie GPS (ha)",
    y        = "Superficie déclarée (ha)"
  ) +
  theme_minimal()

ggsave(
  filename = "nuages_point_sup_gps_dec.png",
  plot = p3,
  width = 12,
  height = 6,
  dpi = 300
)

#21. Analyse du régime de tenure

## Fréquences et proportions des modalités de tenure

frequences_propor_tenu <- secta1_harvestw4 %>%
  mutate(tenure_lbl = as_factor(tenure)) %>%
  count(tenure_lbl) %>%
  mutate(proportion = round(100 * n / sum(n), 1)) %>%
  arrange(desc(n))
write.xlsx(frequences_propor_tenu, "frequences_propor_tenu.xlsx")

## Barplot horizontal des modalités de tenure 

p4 <- secta1_harvestw4 %>%
  mutate(tenure_lbl = as_factor(tenure)) %>%
  count(tenure_lbl) %>%
  mutate(
    proportion = round(100 * n / sum(n), 1),
    # Raccourcir les libellés pour la lisibilité
    tenure_court = recode(as.character(tenure_lbl),
                          "1. OUTRIGHT PURCHASE"                                        = "Achat",
                          "2. RENTED FOR CASH OR IN-KIND GOODS FROM OTHER HOUSEHOLDS"   = "Location",
                          "3. USED FREE OF CHARGE (AND NOT OWNED BY HOUSEHOLD)"         = "Prêt gratuit",
                          "4. DISTRIBUTED BY COMMUNITY"                                 = "Attribution communautaire",
                          "5. FAMILY INHERITANCE"                                       = "Héritage familial",
                          "6. SHARECROPPED IN"                                          = "Métayage",
                          "7. TEMPORARY LAND EXCHANGE"                                  = "Échange temporaire"
    ),
    # Ordonner par fréquence
    tenure_court = reorder(tenure_court, proportion)
  ) %>%
  ggplot(aes(x = proportion, y = tenure_court)) +
  geom_bar(stat = "identity", fill = "#2E86AB") +
  geom_text(aes(label = paste0(proportion, "%")),
            hjust = -0.2, size = 3.5) +
  labs(
    title    = "Régime de tenure foncière des parcelles",
    subtitle = "Wave 4 — Nigeria GHS Panel",
    x        = "Proportion (%)",
    y        = ""
  ) +
  xlim(0, 75) +
  theme_minimal()
ggsave(
  filename = "Diagramme_en_barre_horizontale.png",
  plot = p4,
  width = 12,
  height = 6,
  dpi = 300
)

## Tableau de contingence tenure × milieu (rural/urbain)

table_contingence <- table(
  as_factor(secta1_harvestw4$tenure),
  as_factor(secta1_harvestw4$milieu)
)

print(table_contingence)

## Test du chi-deux 

test_chi2 <- chisq.test(table_contingence)
print(test_chi2)

## V de Cramér (mesure de la force de l'association) 

# V = sqrt(chi2 / (n * (min(lignes, colonnes) - 1)))

n  <- sum(table_contingence)
V  <- sqrt(test_chi2$statistic / (n * (min(nrow(table_contingence),
                                           ncol(table_contingence)) - 1)))
cat("V de Cramér :", round(V, 3), "\n")

## Barplot groupé tenure × milieu

p5 <- secta1_harvestw4 %>%
  mutate(
    tenure_court = recode(as.character(as_factor(tenure)),
                          "1. OUTRIGHT PURCHASE"                                        = "Achat",
                          "2. RENTED FOR CASH OR IN-KIND GOODS FROM OTHER HOUSEHOLDS"   = "Location",
                          "3. USED FREE OF CHARGE (AND NOT OWNED BY HOUSEHOLD)"         = "Prêt gratuit",
                          "4. DISTRIBUTED BY COMMUNITY"                                 = "Attribution communautaire",
                          "5. FAMILY INHERITANCE"                                       = "Héritage familial",
                          "6. SHARECROPPED IN"                                          = "Métayage",
                          "7. TEMPORARY LAND EXCHANGE"                                  = "Échange temporaire"
    ),
    milieu_lbl = recode(as.character(as_factor(milieu)),
                        "1. Urban" = "Urbain",
                        "2. Rural" = "Rural"
    )
  ) %>%
  group_by(milieu_lbl, tenure_court) %>%
  summarise(n = n(), .groups = "drop") %>%
  group_by(milieu_lbl) %>%
  mutate(proportion = round(100 * n / sum(n), 1)) %>%
  ggplot(aes(x = proportion, y = reorder(tenure_court, proportion),
             fill = milieu_lbl)) +
  geom_bar(stat = "identity", position = "dodge") +
  geom_text(aes(label = paste0(proportion, "%")),
            position = position_dodge(width = 0.9),
            hjust = -0.2, size = 3) +
  scale_fill_manual(values = c("Urbain" = "#2E86AB", "Rural" = "#A23B72")) +
  labs(
    title    = "Régime de tenure foncière selon le milieu",
    subtitle = paste0("Chi-deux = 509.43 · p < 0.001 · V de Cramér = 0.216"),
    x        = "Proportion (%)",
    y        = "",
    fill     = "Milieu"
  ) +
  xlim(0, 80) +
  theme_minimal()

ggsave(
  filename = "tenure_par_milieu.png",
  plot = p5,
  width = 12,
  height = 6,
  dpi = 300
)

#23. Analysons la relation entre superficie totale du ménage et le nombre de parcelles

## Corrélation de Spearman superficie totale × nombre de parcelles

cor_spearman <- cor.test(
  superficie_tot_pr_men$superf_tot_ha,
  superficie_tot_pr_men$nb_parcelles,
  method = "spearman"
)

cat("Corrélation de Spearman :", round(cor_spearman$estimate, 3), "\n")
cat("p-valeur               :", format(cor_spearman$p.value, scientific = TRUE), "\n")

## Scatter plot superficie totale × nombre de parcelles + loess

p6 <- superficie_tot_pr_men %>%
  filter(superf_tot_ha > 0) %>%
  ggplot(aes(x = nb_parcelles, y = superf_tot_ha)) +
  geom_point(alpha = 0.3, color = "#2E86AB", size = 1.5) +
  geom_smooth(method = "loess", color = "red",
              se = TRUE, linewidth = 1) +
  scale_y_log10(labels = scales::comma) +
  annotate("text",
           x     = Inf, y = Inf,
           label = paste0("ρ de Spearman = 0.387\np < 0.001"),
           hjust = 1.1, vjust = 1.5,
           size  = 4, color = "#1a5276") +
  labs(
    title    = "Superficie totale selon le nombre de parcelles par ménage",
    subtitle = "Courbe rouge = tendance loess · Échelle log · ménages sans mesure exclus",
    x        = "Nombre de parcelles",
    y        = "Superficie totale (ha)"
  ) +
  theme_minimal()

ggsave(
  filename = "nuage_point_suptot_nbre_parce.png",
  plot = p6,
  width = 12,
  height = 6,
  dpi = 300
)

#24. heatmap

## Superficie médiane par état 

superf_par_etat <- secta1_harvestw4 %>%
  filter(!is.na(superf_ha) & superf_ha > 0) %>%
  group_by(etat) %>%
  summarise(
    n              = n(),
    superf_med_ha  = round(median(superf_ha), 4),
    .groups        = "drop"
  ) %>%
  mutate(etat_lbl = as_factor(etat))

print(superf_par_etat)

## Heatmap superficie médiane par état

p7 <- superf_par_etat %>%
  mutate(etat_lbl = reorder(etat_lbl, superf_med_ha)) %>%
  ggplot(aes(x = 1, y = etat_lbl, fill = superf_med_ha)) +
  geom_tile(color = "white", linewidth = 0.5) +
  geom_text(aes(label = paste0(superf_med_ha, " ha")),
            size = 2.5, color = "black") +
  scale_fill_gradient(low = "#D6EAF8", high = "#1A5276",
                      name = "Superficie\nmédiane (ha)") +
  labs(
    title    = "Superficie médiane des exploitations par état",
    subtitle = "Wave 4 — Nigeria GHS Panel",
    x        = "",
    y        = ""
  ) +
  theme_minimal() +
  theme(
    axis.text.x  = element_blank(),
    axis.ticks.x = element_blank(),
    axis.text.y  = element_text(size = 7),   # réduire taille noms états
    panel.grid   = element_blank(),
    plot.margin  = margin(t = 10, r = 10, b = 10, l = 10, unit = "pt")
  )

ggsave(
  filename = "heatmap_superficie_etat.png",
  plot = p7,
  width = 8, 
  height = 12, 
  dpi = 300)

