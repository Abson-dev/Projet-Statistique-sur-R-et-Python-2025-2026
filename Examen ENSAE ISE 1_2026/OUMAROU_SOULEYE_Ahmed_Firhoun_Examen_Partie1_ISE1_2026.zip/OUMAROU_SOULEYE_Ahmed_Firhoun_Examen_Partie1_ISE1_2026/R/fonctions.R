sauvegarder_figure <- function(nom_fichier,
                               largeur = 10,
                               hauteur = 6,
                               dpi     = 300) {
  chemin <- file.path("outputs", "figures", nom_fichier)
  ggplot2::ggsave(chemin, width = largeur, height = hauteur, dpi = dpi)
  cat(sprintf("  -> Figure : %s\n", chemin))
}


# ----------------------------------------------------------------
# 7. SAUVEGARDER UN TABLEAU (CSV)
# ----------------------------------------------------------------
sauvegarder_tableau <- function(df, nom_fichier) {
  chemin <- file.path("outputs", "tables", nom_fichier)
  readr::write_csv(df, chemin)
  cat(sprintf("  -> Tableau : %s\n", chemin))
}
