library(tidyverse)
library(haven)
library(ggplot2)
library(readxl)
library(renv)
library(sf)
library(naniar)
library(mice)
library(labelled)
library(survey)
library(srvyr)
library(gtsummary)
library(flextable)
#library(tmap)
library(gglorenz) 
source("R/fonctions.R")
#_________________________________________________________
# Section 1. Import, structuration et nettoyage
#_________________________________________________________

#1.  Importer les cinq sources avec les packages appropriés, en respectant les types de colonnes et les encodages. 
ensan_menages <- read_dta("data/raw/ensan_menages.dta")
ensan_individus <-read.csv("data/raw/ensan_individus.csv")
ensan_consommation_groupes <- read_excel("data/raw/ensan_consommation.xlsx",sheet = 1)
ensan_consommation_depenses <- read_excel("data/raw/ensan_consommation.xlsx", sheet=2)
chocs_menages <- read.csv("data/raw/chocs_menages.csv")
prix_marches <- read.csv("data/raw/prix_marches.csv")
tcd_admin1 <- st_read("data/raw/tcd_admin1.shp", quiet = TRUE)
#2.  Fusionner les modules en un jeu de données ménages enrichi comportant les caractéristiques du chef de ménage, la consommation alimentaire agrégée et les chocs subis, par des jointures adaptées. Vérifier explicitement que le nombre de lignes du jeu de données ménages reste inchangé après chaque jointure.
##2.1. Sélection des chefs de ménages
ensan_CM <- ensan_individus |>
  filter(rang==1) 
##2.2. Harmonisation des codes hhid, les autres bases ont des "0000" en préfixe 
## sauf la base ensan_individus, il faut donc harmoniser, on enlève les préfixes en 
## convertissant les colonnes en entiers
ensan_menages$hhid <- as.integer(ensan_menages$hhid)
ensan_consommation_groupes$hhid <- as.integer(ensan_consommation_groupes$hhid)
ensan_consommation_depenses$hhid <- as.integer(ensan_consommation_depenses$hhid)
chocs_menages$hhid <- as.integer(chocs_menages$hhid)

##2.3. La fusion
fusion1 <- left_join(x=ensan_menages,y=ensan_CM)
fusion2 <- left_join(x=fusion1,y=ensan_consommation_groupes)
fusion3 <- left_join(x=fusion2,y=ensan_consommation_depenses)
ensan_fusion <- left_join(x=fusion3,chocs_menages) #Base enrichie

# 3.  Identifier et corriger les libellés de régions incohérents entre fichiers avant toute jointure spatiale. 
ensan_fusion <- ensan_fusion |>
  mutate(
    region_lib = recode(region_lib,
                        "BATHA"="Batha",
                        "BORKOU"="Borkou",
                        "CHARI_BAGUIRMI"="Chari Baguirmi",
                        "ENNEDI_EST"="Ennedi Est",
                        "ENNEDI_OUEST"="Ennedi Ouest",
                        "GUÉRA"= "Guéra" ,
                        "GUERA"= "Guéra" ,
                        "HADJER_LAMIS"="Hadjer Lamis" ,  
                        "KANEM"="Kanem",
                        "LAC"="Lac",
                        "LOGONE_OCCIDENTAL"="Logone Occidental",
                        "LOGONE_ORIENTAL"="Logone Oriental" ,
                        "MANDOUL"="Mandoul",
                        "MAYO_KEBBI_EST"="Mayo Kebbi Est",
                        "MAYO_KEBBI_OUEST"="Mayo Kebbi Ouest",
                        "MOYEN_CHARI"="Moyen Chari",
                        "OUADDAÏ"="Ouaddaï" ,
                        "OUADAI"="Ouaddaï" ,
                        "SALAMAT"="Salamat",
                        "SILA"="Sila",
                        "TANDJILÉ"="Tandjilé" ,
                        "TANDJILLE"="Tandjilé" ,
                        "TIBESTI"="Tibesti" ,
                        "WADI_FIRA"="Wadi Fira",
                        "NDJAMENA"="N'Djamena",
                        "BARH_EL_GAZEL" = "Barh El Gazel"
                          )
  )
tcd_admin1 <- tcd_admin1 |>
  mutate(
    adm1_name = recode(adm1_name,
                       "BATHA"="Batha",
                       "BORKOU"="Borkou",
                       "CHARI BAGUIRMI"="Chari Baguirmi",
                       "ENNEDI EST"="Ennedi Est",
                       "ENNEDI OUEST"="Ennedi Ouest",
                       "GUÉRA"= "Guéra" ,
                       "HADJER LAMIS"="Hadjer Lamis" ,  
                       "KANEM"="Kanem",
                       "LAC"="Lac",
                       "LOGONE OCCIDENTAL"="Logone Occidental",
                       "LOGONE ORIENTAL"="Logone Oriental" ,
                       "MANDOUL"="Mandoul",
                       "MAYO KEBBI EST"="Mayo Kebbi Est",
                       "MAYO KEBBI OUEST"="Mayo Kebbi Ouest",
                       "MOYEN CHARI"="Moyen Chari",
                       "OUADDAÏ"="Ouaddaï" ,
                       "SALAMAT"="Salamat",
                       "SILA"="Sila",
                       "TANDJILÉ"="Tandjilé",
                       "TIBESTI"="Tibesti" ,
                       "WADI FIRA"="Wadi Fira",
                       "N'DJAMENA"="N'Djamena",
                       "BARH EL GAZEL" = "Barh El Gazel"
    )
  )
# 4.  Produire un diagnostic complet des valeurs manquantes avec naniar (résumé, visualisation, cooccurrences), en distinguant les valeurs manquantes standards des valeurs manquantes taguées Stata. 
grph4_1 <- miss_var_summary(ensan_fusion)
## Les variables présentant des NAs sont le revenu, la taille du ménage et l'âge
vis_miss(ensan_fusion)
vis_miss(prix_marches)

grph4_2 <- gg_miss_upset(ensan_fusion)
# 5.  Justifier, pour deux variables clés de votre choix, une hypothèse de mécanisme de non-réponse (MCAR, MAR  ou MNAR) et appliquer une imputation multiple par équations chaînées adaptée avec mice. 
## Pour le revenu, il est logique de supposer que certains chefs de ménages ont refusé de donner
## leurs revenus. Les valeurs manquantes sont MNAR car elles dépendent du montant du revenu lui-même.

## Pour l'âge on peut supposer que certains chefs de ménages ne connaissent pas leurs âges
## Les NAs sont donc MCAR.

## 5.1. Imputation
#On effectue l'imputation en utilisant ranfom forest
imp <- mice(ensan_fusion, m = 5,method = "rf", print = FALSE, seed = 22112)
ensan_imp <- complete(imp, 5)

# 6.  Recoder  les variables catégorielles nécessaires à  l’analyse  (milieu,  niveau  d’éducation  du chef  de  ménage, quintiles de revenu par tête)
ensan_imp <- ensan_imp |>
  mutate(
    milieu = case_when(
      milieu==1 ~ "Urbain",
      milieu==2 ~ "Rural"
    )
  )
## Le niveau d'éducation est déjà codé
## Pour les quintiles, il faut inclure le plan de sondage pour avoir des 
## quintiles pondérés
plan_sondage <- svydesign(
  ids     = ~grappe,
  strata  = ~strate,
  weights = ~poids_final,
  data    = ensan_imp,
  nest    = TRUE
)


quintiles <- svyquantile(~revenu, plan_sondage, 
                     quantiles = c(0.2, 0.4, 0.6,0.8), 
                     na.rm = TRUE)

Q1 <- coef(quintiles)[1]
Q2 <- coef(quintiles)[2]
Q3 <- coef(quintiles)[3]
Q4 <- coef(quintiles)[4]


ensan_fusion <- ensan_fusion |>
  mutate(
    quintile_revenu = case_when(
      revenu<=Q1 ~ "Quintile 1",
      revenu<=Q2 & revenu>Q1 ~ "Quintile 2",
      revenu<=Q3 & revenu>Q2 ~ "Quintile 3",
      revenu<=Q4 & revenu>Q3 ~ "Quintile 4",
      revenu>Q4 ~ "Quintile 5",
      TRUE ~ NA
    )
  )
#_________________________________________________________
#Section 2. Statistiques descriptives pondérées et indices composites 
#_________________________________________________________
#7.  Déclarer le plan de sondage complet (grappes, strates, poids finaux) avec srvyr. 
plan_sondage <- ensan_imp |> 
  as_survey_design( 
    ids     =  grappe,          # Identifiant des grappes (PSU) 
    strata  = strate,          # Variable de stratification 
    weights =  poids_final,     # Poids de sondage finaux 
    nest    = TRUE 
  ) 
#8.  Construire le score de diversité alimentaire des ménages (HDDS) et la classification FAO associée. 

# Les données indiquent si chaque groupe alimentaire a été consommé (0/1) 
# Variables:cons_cereales, cons_tubercules, cons_legumineuses, cons_legumes, 
#             cons_fruits, cons_viande, cons_poisson, cons_oeufs, cons_lait, 
#             cons_huile, cons_sucre, cons_condiments 

ensan_imp <- ensan_imp |> 
  mutate( 
    # Score HDDS:somme des 12 groupes alimentaires 
    hdds = rowSums(across(starts_with("cons_")), na.rm = TRUE), 
    
    # Classification FAO 
    securite_alim = case_when( 
      hdds <= 3  ~ "Insécurité alimentaire sévère", 
      hdds <= 6  ~ "Insécurité alimentaire modérée", 
      hdds <= 9  ~ "Sécurité alimentaire acceptable", 
      TRUE       ~ "Bonne diversité alimentaire" 
    ) |> factor(levels = c("Insécurité alimentaire sévère", 
                           "Insécurité alimentaire modérée", 
                           "Sécurité alimentaire acceptable", 
                           "Bonne diversité alimentaire"), ordered = TRUE) 
  ) 

#9.  Construire un indice composite de vulnérabilité aux chocs, combinant le nombre et la gravité des chocs subis avec l’intensité des stratégies d’adaptation mobilisées. La construction, la pondération des composantes et les  choix de seuils doivent être explicitement justifiés dans le rapport. 
## 9.1. Calculons un indice de choc mesurant l'intensité du choc subi
ensan_imp <- ensan_imp |>
  mutate(
    indice_choc = (choc_hausse_prix+choc_maladie*2+choc_secheresse*3+choc_conflit*3)/(1+2+3+3)
  )
#On a pondéré avec 1,2 et 3 en fonction de la gravité du choc, l'indice est compris entre 0 et 1
## 9.2. Calculons un indice d'intensité des stratégies
ensan_imp <- ensan_imp |>
  mutate(
    indice_strat = (strat_reduction_repas+strat_endettement*2+strat_migration*3+strat_vente_actifs*4)/(1+2+3+4)
  )
#On a pondéré en fonction de la gravité des stratégie. L'indice est toujours compris entre 0 et 1.
# 9.3. L'indice composite final est la moyenne pondérée des deux indices de chocs et de stratégies
ensan_imp <- ensan_imp |>
  mutate(
    indice_composite = (indice_choc*0.7+indice_strat*0.3),
    ## On applique un poids plus important aux chocs car les stratégies ne sont que des réponses aux chocs
    niveau_vulnerabilite  = case_when(
      indice_composite <= 0.25  ~ "Très faible vulnérabilité", 
      indice_composite <= 0.5  ~ "Faible vulnérabilité ", 
      indice_composite <= 0.75  ~ "Forte vulnérabilité", 
      TRUE       ~ "Très forte vulnérabilité" 
    ) |> factor(levels = c("Très faible vulnérabilité", 
                           "Faible vulnérabilité ", 
                           "Forte vulnérabilité", 
                           "Très forte vulnérabilité"), ordered = TRUE) 
    )

# Plus l'indice est proche de 1, plus le ménage est vulnérable, plus il est proche de 0, plus il est insensible aux chocs
# Nous avons construits 4 classes de même taille car nous ne disposons pas de critères rigoureux permettant de mieux construire les classes

#10. Produire un tableau descriptif pondéré de type Tableau 1 avec gtsummary, comparant les indicateurs clés par  milieu et par région, avec test de comparaison et colonne d’effectifs. 

# Tableau descriptif complet 
tab <- ensan_imp |> 
  select(hdds, indice_composite, securite_alim, niveau_vulnerabilite, milieu, region) |> 
  tbl_summary( 
    by         = milieu,                   # Comparer urbain vs rural 
    statistic  = list( 
      all_continuous()  ~ "{mean} ({sd})",  # Moyenne (écart-type) pour numériques 
      all_categorical() ~ "{n} ({p}%)"      # N (%) pour catégorielles 
    ), 
    digits     = all_continuous() ~ 1, 
     label      = list( 
       hdds      ~ "HDDS", 
       indice_composite  ~ "Indice composite de vulnérabilité", 
       securite_alim        ~ "Niveau de sécurité alimentaire", 
       niveau_vulnerabilite         ~ "Niveau de vulnérabilité" 
     ), 
    missing    = "ifany" 
  ) |> 
  add_p() |>                               # Tests de comparaison 
  add_overall() |>                         # Colonne totale 
  add_n() |> 
  bold_labels() |> 
  modify_header(label = "**Caractéristique**") |> 
  modify_caption("Tableau 1. Indicateurs clés par milieu de 
résidence et par ménage") 
  tab |>
  as_flex_table() |>
  bold(part = "header") |>
  color(color = "white", part = "header") |>
  bg(bg = "#173C69", part = "header") |>
  bg(bg = "#C6DBEF", i = seq(2, nrow(tab), 2)) |>
  fontsize(size = 10, part = "all") |>
  autofit()
#11. Calculer le coefficient de Gini du revenu par tête au niveau national et par région, avec un intervalle de confiance  obtenu par bootstrap

##11.1. Calcul du revenu par tête
ensan_imp  <- ensan_imp |>
  mutate(
    revenu_tete = revenu/taille_menage
  )
##11.2. Calcul du coefficient de Gini
tab_gini <- plan_sondage |> 
  summarise( 
    gini = survey_ratio( 
      numerator   = revenu_tete * (rank(revenu_tete) / n()), 
      denominator = revenu_tete 
      ) 
) 
###11.2.1. Gini national
gini <- tab_gini$gini[1]

gini_graph <- ggplot(plan_sondage, aes(revenu_tete)) + 
  stat_lorenz(color = "#2E75B6", size = 1.2) + 
  geom_abline(linetype = "dashed", color = "gray50") + 
  annotate("text", x = 0.25, y = 0.75, 
           label = paste0("Gini = ", round(gini, 3)), 
           size = 4, color = "#1F4E79") + 
  labs(title = "Courbe de Lorenz — Revenu par tête", 
       x = "Part cumulée de la population", 
       y = "Part cumulée du revenu") + 
  theme_minimal(base_size = 12) 
##11.1.2. Gini regional
tab_gini_regional <- plan_sondage |> 
  group_by(region) |>
  summarise( 
    gini = survey_ratio( 
      numerator   = revenu_tete * (rank(revenu_tete) / n()), 
      denominator = revenu_tete 
    ) 
  ) 

tab_gini_regional |>
  select(-gini_se) |>
  flextable() |>
  bold(part = "header")|>
  color(color = "white", part = "header")|>
  bg(bg = "#173C69", part = "header") |>
  bg(bg = "#C6DBEF", i = seq(2, nrow(tab_gini_regional), 2))|>
  fontsize(size = 10, part = "all") |>
  autofit()

#_________________________________________________________
# Section 3. Visualisation 
#_________________________________________________________

# 12. Représenter la distribution du revenu par tête par région (graphique de densités superposées ou équivalent),  avec une échelle adaptée à l’asymétrie de la variable. 

# 13. Produire une carte choroplèthe de l’indice de vulnérabilité par région avec sf et ggplot2, ainsi qu’une version  interactive avec tmap. 

# 14. Composer une figure unique regroupant au moins trois graphiques avec patchwork, en appliquant un thème graphique cohérent et personnalisé sur l’ensemble des graphiques du rapport. 

# 15. Exporter l’ensemble des figures du rapport en PNG haute résolution et en PDF dans output/figures/. 
