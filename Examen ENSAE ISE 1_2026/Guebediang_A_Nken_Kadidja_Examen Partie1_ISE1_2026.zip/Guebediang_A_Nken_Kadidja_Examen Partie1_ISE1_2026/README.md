# [PROJET FINALE STATISTIQUE SOUS R]

projet statistique sous R (nettoyage, tests statistiques, tableaux
gtsummary/flextable, rapport Word via R Markdown). 

**Auteure**: [Kadidja GUEBEDIANG A NKEN], ISE1


## 1. Structure du projet

```
.
├── data/
│   ├── raw/                     # données brutes (vidé)
│   └── processed/                # objets .rds nettoyés, produits par les scripts
├── docs/
│   ├── rapport.Rmd               # rapport, 
│   └── reference.docx            # styles Word (titres, tableaux...) utilisés par rapport.Rmd
├── outputs/
│   ├── figures/                  # tous les .png générés par 02_analyses.R
│   └── tables/                   # tableaux exportés en .html/.csv/.xlsx
├── scripts/
│   ├── 00_fonctions_utiles.R     # palette, thème ggplot, style flextable, helpers Rmd
│   ├── 01_import_nettoyage.R     # import, vérifications, recodage, plan de sondage
│   └── 02_analyses.R             # stats, tests, figures, tableaux, 
├── main.R                        # orchestrateur : packages -> scripts -> knit du rapport
├── README.md
├── .gitignore
```

