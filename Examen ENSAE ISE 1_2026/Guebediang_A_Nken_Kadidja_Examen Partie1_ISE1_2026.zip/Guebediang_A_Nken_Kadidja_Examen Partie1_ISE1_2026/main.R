
# Ce script me permet de
# charger les packages ; je fixe aussi la grane aléatoire avec set.seed
# Exécuter dans l'ordre les scripts scripts/01_import_nettoyage.R puis
# scripts/02_analyses.R
#  et enfin Compiler (knit) docs/rapport.Rmd en .docx

rm(list = ls())


pkgs <- c(
  "tidyverse", "haven", "readxl","utils","labelled", "here", "scales",
  "patchwork", "naniar", "moments",
  "rstatix", "coin", "gtsummary", "gt",
  "srvyr", "survey", "flextable", "officer", "knitr", "rmarkdown",
  "forcats", "viridis", "magick","sf", "rnaturalearth", "rnaturalearthdata", "rnaturalearthhires","ineq","infer" 
)

manquants <- pkgs[!pkgs %in% installed.packages()[, 1]]
if (length(manquants) > 0) {
  cat("Packages manquants :", paste(manquants, collapse = ", "), "\n")
  cat("Installez-les avec install.packages()")
  stop("Environnement non initialisé.")
}

invisible(lapply(pkgs, library, character.only = TRUE))
cat("Packages chargés :", length(pkgs), "\n")

set.seed(2070)  

# la source que je réutiliserai en légende de toutes les figures et tableaux
source_donnees <- "Source : Enquête nationale sur la sécurité alimentaire ENSAN 2026. Calculs de l'auteure."

source(here("scripts", "00_fonctions_utiles.R"), encoding = "UTF-8")
source(here("scripts", "01_import_nettoyage.R"), encoding = "UTF-8")
source(here("scripts", "02_analyses.R"),        encoding = "UTF-8")

cat("\nPipeline terminé.\n")
cat("Les figures sont dans : outputs/figures/\n")
cat("Les tableaux sont dans : outputs/tables/\n")

#RMARKDOWN
rmarkdown::render(
  here("docs", "rapport.Rmd"),
  output_format = "word_document",
  output_file   = here("docs", "rapport.docx")
)

cat("Rapport généré : docs/rapport.docx\n")
