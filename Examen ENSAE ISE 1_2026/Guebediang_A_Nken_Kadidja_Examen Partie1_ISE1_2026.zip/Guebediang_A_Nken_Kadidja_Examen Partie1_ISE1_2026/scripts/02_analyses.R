# *********************************************
# Section 2. Statistiques descriptives pondérées et indices composites
# *********************************************


# 1. DECLARONS LE PLAN DE SONDAGE

plan_sondage <- donnees_propres |>
  filter(!is.na(poids_final)) |>
  as_survey_design(
    ids     = grappe,         
    strata  = strate,           
    weights = poids_final,    
    nest    = TRUE
  )

saveRDS(plan_sondage,    here("data", "processed", "plan_sondage.rds"))

####nos base
donnees_propres <- readRDS(here("data", "processed", "donnees_propres.rds"))
plan_sondage    <- readRDS(here("data", "processed", "plan_sondage.rds"))  # à retirer si pas d'enquête pondérée

# Nous présentons Quelques statisitique descriptives pondérée 
stats_desc_pondere <- plan_sondage |>
  summarise(
    N          = srvyr::unweighted(sum(!is.na(age))),
    moyenne    = survey_mean(age, na.rm = TRUE, vartype = NULL),
    mediane    = survey_median(age, na.rm = TRUE, vartype = NULL),
    q1         = survey_quantile(age, quantiles = 0.25, na.rm = TRUE, vartype = NULL),
    q3         = survey_quantile(age, quantiles = 0.75, na.rm = TRUE, vartype = NULL),
    ecart_type = survey_sd(age, na.rm = TRUE, vartype = NULL)
  )
cat("Statistiques descriptives :\n"); print(stats_desc_pondere)


#8.CONSTRUISONS UN SCORE DE DIVERSITE ALIMENTAIRE
names (donnees_propres)
#étant donnée que pour chaque variété on affiche 1 s'il y a consommation et O sinon, on va juste faire la somme
donnees_propres <- donnees_propres |>
  mutate(
    hdds =
      cons_cereales +
      cons_tubercules +
      cons_legumineuses +
      cons_legumes +
      cons_fruits +
      cons_viande +
      cons_poisson +
      cons_oeufs +
      cons_lait +
      cons_huile +
      cons_sucre +
      cons_condiments
  )

##classification FAO
 # Classification FAO trouver dans le cours     
donnees_propres<-donnees_propres|> 
  mutate(class_FAO = case_when(hdds <= 3  ~ "Insécurité alimentaire sévère", 
                          hdds <= 6  ~ "Insécurité alimentaire modérée",
                          hdds <= 9  ~ "Sécurité alimentaire acceptable", 
                          TRUE   ~ "Bonne diversité alimentaire"     ) |> 
  factor(levels = c("Insécurité alimentaire sévère", "Insécurité alimentaire modérée",                          
                    "Sécurité alimentaire acceptable",                             
                    "Bonne diversité alimentaire"), 
         ordered = TRUE))


#9. INDICE DE COMPOSITE DE VULNERABILITE AUX CHOCS
#On va faire la somme de chaque catégorie puis on va la moyenne des scores obtenus

donnees_propres <- donnees_propres |>
  mutate(
    # Nombre de chocs
    score_chocs = choc_secheresse+
      choc_hausse_prix+
      choc_conflit+
      choc_maladie,
    
    # Nombre de stratégies
    score_strategies =strat_vente_actifs+
      strat_reduction_repas+
      strat_migration+
      strat_endettement
  )

#Nous allons maintenant faire une moyenne des score pour que chaque score contribue de part égale.

donnees_propres <- donnees_propres |>
  mutate(
    indice_vulnerabilite =
      0.5 * score_chocs +
      0.5 * score_strategies
  )

##pour le score soit synthé tique , nous pouvons le normaliser en le divisiant par 04 
##(en effet le score ainsi obtenu va de zero à 4)

donnees_propres <- donnees_propres |>
  mutate(
    indice_vulnerabilite = indice_vulnerabilite/4
  )

#10.Produire un tableau descriptif pondéré de type 
#Tableau 1 avec gtsummary, comparant les indicateurs clés par milieu et par région, 
#avec test de comparaison et colonne d’effectifs.
##nous avons également vu ceci dans le cours

tableau1_region <-
  tbl_svysummary(
    data = plan_sondage,
    by = region,
    include = c(
      revenu,
      taille_menage,
      sexe_f,
      age,
      indice_vulnerabilite
    ),
    statistic = list(
      all_continuous() ~ "{mean} ({sd})",
      all_categorical() ~ "{n} ({p}%)"
    ),
    digits = all_continuous() ~ 1,
    missing = "no",
    label = list(
      revenu ~ "Revenu par tête (FCFA/mois)",
      taille_menage ~ "Taille du ménage",
      sexe_f ~ "Sexe du chef de ménage",
      age ~ "Âge du chef de ménage"
    )
  ) |>
  add_p() |>
  bold_labels()
####par milieu
tableau1_milieu <-
  tbl_svysummary(
    data = plan_sondage,
    by = milieu_f,
    include = c(
      age,
      sexe_f,
      revenu,
      taille_menage,
      indice_vulnerabilite
    ),
    statistic = list(
      all_continuous() ~ "{mean} ({sd})",
      all_categorical() ~ "{n} ({p}%)"
    ),
    digits = all_continuous() ~ 1,
    missing = "no",
    label = list( revenu ~ "Revenu du menage (FCFA/mois)", 
                 taille_menage ~ "Taille du ménage", 
                 sexe_f ~ "Sexe du chef de ménage", 
                 age ~ "Âge du chef de ménage" ),
                
  ) |>
  add_p() |>
  bold_labels()


##11.Calculer le coefficient de Gini du revenu par tête au niveau national 
##et par région, avec un intervalle de confiance obtenu par bootstrap.
#créons d'abord le revenu par tête
donnees_propres <- donnees_propres|>
  mutate(
    revenu_tete = revenu / taille_menage
  )

###maintenant calculons selon la méthode du cours
