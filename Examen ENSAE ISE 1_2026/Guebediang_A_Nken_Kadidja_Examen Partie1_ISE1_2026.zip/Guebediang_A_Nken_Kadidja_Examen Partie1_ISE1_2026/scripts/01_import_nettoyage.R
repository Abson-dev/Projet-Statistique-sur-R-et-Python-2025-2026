
# *********************************************
# Section 1. Import, structuration et nettoyage
# *********************************************

#IMPORTONS LES DONNEES ET PARCOURONS LES

  #Stata (.dta)
  donnees_brutes_menage_dta <- haven::read_dta(here("data", "raw", "ensan_menages.dta"))


  # Excel (.xlsx)
  donnees_brutes_ensan_consommation_1 <- readxl::read_excel(here("data", "raw", "ensan_consommation.xlsx"), sheet = 1)
  donnees_brutes_ensan_consommation_2 <- readxl::read_excel(here("data", "raw", "ensan_consommation.xlsx"), sheet = 2)
  
  # CSV 
  donnees_brutes_chocs_menages_CSV <- utils::read.csv(here("data", "raw", "chocs_menages.csv"))
  donnees_brutes_ensan_individus_CSV <- utils::read.csv(here("data", "raw", "ensan_individus.csv"))
  donnees_brutes_prix_marches_CSV <- utils::read.csv(here("data", "raw", "prix_marches.csv"))
  
  #shapefile
  Tchad<-sf::read_sf(here("data", "raw", "tcd_admin1.shp"))
  
#visualisons nos bases
cat("Données brutes menage :", nrow(donnees_brutes_menage_dta), "lignes x", ncol(donnees_brutes_menage_dta), "colonnes\n")
cat("Données brutes ensan consommation 1 :", nrow(donnees_brutes_ensan_consommation_1), "lignes x", ncol(donnees_brutes_ensan_consommation_1), "colonnes\n")
cat("Données brutes ensan consommation 2 :", nrow(donnees_brutes_ensan_consommation_2), "lignes x", ncol(donnees_brutes_ensan_consommation_1), "colonnes\n")
cat("Données brutes chocs menages :", nrow(donnees_brutes_chocs_menages_CSV), "lignes x", ncol(donnees_brutes_chocs_menages_CSV), "colonnes\n")
cat("Données brutes ensan individus :", nrow(donnees_brutes_ensan_individus_CSV), "lignes x", ncol(donnees_brutes_ensan_individus_CSV), "colonnes\n")
cat("Données brutes prix marché :", nrow(donnees_brutes_prix_marches_CSV), "lignes x", ncol(donnees_brutes_prix_marches_CSV), "colonnes\n")

#  pour une meilleure exploration 
glimpse(donnees_brutes_prix_marches_CSV) 
glimpse(donnees_brutes_menage_dta) 
glimpse(donnees_brutes_ensan_consommation_1) 
glimpse(donnees_brutes_ensan_consommation_2) 
glimpse(donnees_brutes_chocs_menages_CSV) 
glimpse(donnees_brutes_ensan_individus_CSV) 



# VERIFIONS LES INCOHERENCES

# Doublons sur une hhid de la base ménage
doublons <- donnees_brutes_menage_dta |> group_by(hhid) |> filter(n() > 1) |> nrow()
cat("Doublons détectés :", doublons, "\n")

# Cohérence entre base ménage et individu
absents <- sum(!donnees_brutes_menage_dta$hhid %in% donnees_brutes_ensan_individus_CSV$hhid)
cat("Identifiants présents dans une base mais absents de l'autre :", absents, "\n")
####ici il y a une différence car hhi dans menage est 001 alors que dans individu c'est 1
###mais les individus de hhid appartiennent tous à un ménage de la base ménage
donnees_brutes_menage_dta$hhid<-as.integer(donnees_brutes_menage_dta$hhid)
donnees_brutes_ensan_consommation_1$hhid<-as.integer(donnees_brutes_ensan_consommation_1$hhid)
donnees_brutes_ensan_consommation_2$hhid<-as.integer(donnees_brutes_ensan_consommation_1$hhid)
donnees_brutes_chocs_menages_CSV$hhid<-as.integer(donnees_brutes_chocs_menages_CSV$hhid)
donnees_brutes_ensan_individus_CSV$hhid<-as.integer(donnees_brutes_ensan_individus_CSV$hhid)

#Après avoir converti tous les hhid en integer, verifions la cohérence
absents <- sum(!donnees_brutes_menage_dta$hhid %in% donnees_brutes_ensan_individus_CSV$hhid)
cat("Identifiants présents dans une base mais absents de l'autre :", absents, "\n")

# JOIGNONS LES DONNEES POUR ENRICHIR LA BASE MENAGE
# constituons la base chef de ménage

base_chef_menage <- donnees_brutes_ensan_individus_CSV |>
  filter(rang == 1) |>
  select(
    hhid,
    rang,
    age,
    sexe,
    niveau_educ
  )

###maintenant faisons la jointure

baseniveau1  <- left_join(donnees_brutes_menage_dta, base_chef_menage, by = "hhid")
baseniveau2  <- left_join(baseniveau1, donnees_brutes_ensan_consommation_1, by = "hhid")
baseniveau3  <- left_join(baseniveau2, donnees_brutes_ensan_consommation_2, by = "hhid")
base_menage_finale_enrichie <- left_join(baseniveau3, donnees_brutes_chocs_menages_CSV, by = "hhid")

View(base_chef_menage)
##il y a 30 doublons au niveau de la base chef de ménage
##il faut les supprimer
doublons <- base_chef_menage |> group_by(hhid) |> filter(n() > 1) |> nrow()
cat("Doublons détectés :", doublons, "\n")

doublons <- base_chef_menage |>
  group_by(hhid) |>
  filter(n() > 1) |>
  ungroup()
View(doublons)

###nous voyons que les hhid qui sont duppliquer sont enfait les mêmes chefs de ménage qui ont été dupliqué donc
###on va supprimer l'excédent de chef de ménage et garder le reste en une seule observation

#### avec la commande "help" de R on a pu trouver la fonction distinct(.x, .keepall) qui nous permetra de le faire
base_chef_menage <- base_chef_menage |>
 distinct(hhid, .keep_all = TRUE)

###refaisons la jointure

baseniveau1  <- left_join(donnees_brutes_menage_dta, base_chef_menage, by = "hhid")
baseniveau2  <- left_join(baseniveau1, donnees_brutes_ensan_consommation_1, by = "hhid")
baseniveau3  <- left_join(baseniveau2, donnees_brutes_ensan_consommation_2, by = "hhid")
base_menage_finale_enrichie <- left_join(baseniveau3, donnees_brutes_chocs_menages_CSV, by = "hhid")

resume_nombre_observation <- data.frame(
  type_join = c("baseniveau1", "baseniveau2", "baseniveau3", "base_menage_finale_enrichie"),
  base_gauche = "menage",
  base_droite = "individu",
  n_apres_join = c(
    nrow(baseniveau1),
    nrow(baseniveau2),
    nrow(baseniveau3),
    nrow(base_menage_finale_enrichie)
  )
)


view(resume_nombre_observation)

####nous avons dons les 3540 ménages trouver dès le départ


# 3. CORRECTION DES LIBELLES DE REGIONS

###observons nos deux bases
View(base_menage_finale_enrichie)
View(Tchad)
##egardons les noms des regions pourchaques bases
unique(base_menage_finale_enrichie$region)
unique(Tchad$adm1_name)

###essayons d'identifier la différence avec setdiff
setdiff(Tchad$adm1_name,base_menage_finale_enrichie$region)

###essayons de corriger la différence avec toupper trouver dans le help de R
base_menage_finale_enrichie <- base_menage_finale_enrichie |>
  mutate(region = toupper(region))

Tchad <- Tchad |>
  mutate(adm1_name = toupper(adm1_name))
 
###reobservons la différence si elle existe encore
setdiff(Tchad$adm1_name,base_menage_finale_enrichie$region)

base_menage_finale_enrichie <- base_menage_finale_enrichie |>
  left_join(Tchad,
            by = c("region" = "adm1_name"))


#  4. DIAGNOSTIC DES VALEURS LANQUANTES AVEC NANIAR
###nous avons eu à faire cet exercice en ccours durant les TP 
###nous allons ainsi adapter le code que nous avions eu à utiliser durant le cours
vars_diag <- base_menage_finale_enrichie |>
  select(Région = region, Milieu = milieu, Sexe = sexe,
         Âge = age, Éducation = niveau_educ, Revenu = revenu)

fig00 <- naniar::vis_miss(vars_diag, sort_miss = TRUE) +
  labs(
    title    = "Diagnostic des valeurs manquantes",
    subtitle = "la Région, le milieu de résidence, sexe, age, education, et le revenu",
    caption  = source_donnees
  ) +
  theme_minimal(base_size = 10)

enregistrer_figure("fig00_diagnostic_NA.png", fig00, width = 9, height = 5)

#5. MCA
# 6. RECODONS LES VARIABLES CATEGORIELLES NECESSAIRES A LANALYSE
base_menage_finale_enrichie <- base_menage_finale_enrichie |>
  mutate(
    # Recodage de la variable sexe, et milieu de résidence numérique  codée en factor avec libellés 
    sexe_f = factor(sexe, levels = c(1, 2), labels = c("Homme", "Femme")),
    milieu_f = factor(milieu, levels =c(1,2) , labels= c("Urbain", "Rural")),

    # les quintiles de revenu
    quintile_revenu = ntile(revenu, 5)
  )


donnees_propres<-base_menage_finale_enrichie

# 7. Sauvegardons les objets nettoyés 
saveRDS(donnees_propres, here("data", "processed", "donnees_propres.rds"))

cat(sprintf("donnees_propres : %d obs x %d vars\n",
            nrow(donnees_propres), ncol(donnees_propres)))
cat("Script 01_import_nettoyage.R terminé\n")


