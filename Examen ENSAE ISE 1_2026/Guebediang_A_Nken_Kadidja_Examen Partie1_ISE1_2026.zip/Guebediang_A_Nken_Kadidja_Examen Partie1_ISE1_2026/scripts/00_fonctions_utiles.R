# *********************************************
# Fonctions et paramètres graphiques communs
# *********************************************

# Décommenter/adapter selon les catégories du sujet (sexe, milieu, groupes...)
col_homme    <- "#0058AB"  # convention WHO/HMD
col_femme    <- "#E8416F"  # convention WHO/HMD
col_rural    <- "#80BD41"  # convention FAO/IFPRI
col_urbain   <- "#6C757D"  # convention ONU-HABITAT
col_principal <- "#1CABE2" # convention UNICEF (couleur "neutre" pour histos/scatters)
col_secondaire <- "#374EA2"
col_accent    <- "#E53935"

# Palette générique pour n catégories (usage : scale_fill_manual(values = palette_generique(k)))
palette_generique <- function(n) {
  viridis::viridis(n, option = "D")
}

# ------------------------------------------------------------------------------
# 2. Thème ggplot commun
# ------------------------------------------------------------------------------
theme_rapport <- theme_minimal(base_size = 10) +
  theme(
    plot.title      = element_text(size = 11, face = "bold", hjust = 0),
    plot.subtitle   = element_text(size = 9,  color = "grey40"),
    plot.caption    = element_text(size = 7,  color = "grey50", hjust = 1),
    axis.title      = element_text(size = 9),
    legend.position = "bottom"
  )
theme_set(theme_rapport)

# ------------------------------------------------------------------------------
# 3. Fonction "mode" (valeur la plus fréquente / pic de densité)
# ------------------------------------------------------------------------------
calc_mode <- function(x) {
  x <- x[!is.na(x) & is.finite(x)]
  if (length(x) < 10) return(NA_real_)
  d <- density(x, bw = "SJ")
  d$x[which.max(d$y)]
}

# ------------------------------------------------------------------------------
# 4. Mise en forme des tableaux flextable (style "rapport institutionnel")
# ------------------------------------------------------------------------------
# À MODIFIER : couleurs/police selon le thème retenu. Fonctionne sur un objet
# flextable (issu de as_flex_table(), flextable(), etc.)
style_rapport <- function(ft,
                           couleur_header = "#1A3C5E",
                           couleur_alt    = "#DCE9F5",
                           police         = "Garamond") {
  blanc     <- "#FFFFFF"
  gris_bord <- "#A0A0A0"
  nr        <- nrow(ft$body$dataset)

  ft |>
    flextable::font(fontname = police, part = "all") |>
    flextable::fontsize(size = 9,   part = "body") |>
    flextable::fontsize(size = 9.5, part = "header") |>
    flextable::bg(bg = couleur_header, part = "header") |>
    flextable::color(color = blanc, part = "header") |>
    flextable::bold(part = "header") |>
    flextable::align(align = "center", part = "header") |>
    flextable::align(j = 1, align = "left", part = "header") |>
    flextable::bg(i = seq(1, nr, 2), bg = blanc,      part = "body") |>
    flextable::bg(i = seq(2, nr, 2), bg = couleur_alt, part = "body") |>
    flextable::align(j = 1, align = "left", part = "body") |>
    flextable::bold(j = 1, part = "body") |>
    flextable::border_remove() |>
    flextable::border_outer(part = "all",
      border = officer::fp_border(color = couleur_header, width = 1.5)) |>
    flextable::border_inner_h(part = "body",
      border = officer::fp_border(color = gris_bord, width = 0.4)) |>
    flextable::hline_bottom(part = "header",
      border = officer::fp_border(color = couleur_header, width = 2)) |>
    flextable::padding(padding.left = 6, padding.right = 6,
      padding.top = 3, padding.bottom = 3, part = "all") |>
    flextable::autofit()
}

enregistrer_figure <- function(nom_fichier, plot, width, height, dpi = 300) {
  chemin <- here::here("outputs", "figures", nom_fichier)
  ggplot2::ggsave(chemin, plot, width = width, height = height, dpi = dpi)

  dims_path <- here::here("outputs", "figures", "_dims.csv")
  nouvelle_ligne <- data.frame(
    fichier = nom_fichier, width_in = width, height_in = height, dpi = dpi
  )
  if (file.exists(dims_path)) {
    dims <- utils::read.csv(dims_path)
    dims <- dims[dims$fichier != nom_fichier, ]  # évite les doublons si on relance le script
    dims <- rbind(dims, nouvelle_ligne)
  } else {
    dims <- nouvelle_ligne
  }
  utils::write.csv(dims, dims_path, row.names = FALSE)
  cat(nom_fichier, "exportée (", width, "x", height, "in )\n")
  invisible(chemin)
}

#####
afficher_figure <- function(nom_fichier, largeur_max = "95%") {
  chemin <- here::here("outputs", "figures", nom_fichier)
  if (!file.exists(chemin)) {
    stop("Figure introuvable : ", chemin,
         " — vérifiez qu'elle a bien été générée par 02_analyses.R")
  }

  dims_path <- here::here("outputs", "figures", "_dims.csv")
  ratio <- NA_real_

  if (file.exists(dims_path)) {
    dims <- utils::read.csv(dims_path)
    ligne <- dims[dims$fichier == nom_fichier, ]
    if (nrow(ligne) == 1) ratio <- ligne$width_in[1] / ligne$height_in[1]
  }
  if (is.na(ratio)) {
    info  <- magick::image_info(magick::image_read(chemin))
    ratio <- info$width[1] / info$height[1]
  }

  # Règle simple : une figure "portrait" (plus haute que large, ratio < 0.9)
  # est affichée plus étroite pour ne pas déborder la page en hauteur.
  out_w <- if (ratio < 0.9) "60%" else largeur_max
  knitr::opts_current$set(out.width = out_w)
  knitr::include_graphics(chemin)
}

# un data.frame simple calculé directement dans le .Rmd).
afficher_tableau <- function(x, caption = NULL, chiffres = 2) {
  if (is.character(x) && length(x) == 1) {
    ext <- tolower(tools::file_ext(x))
    df <- switch(ext,
      csv  = utils::read.csv(x),
      xlsx = readxl::read_excel(x),
      stop("Extension non gérée par afficher_tableau() : ", ext)
    )
  } else {
    df <- x
  }

  df |>
    dplyr::mutate(dplyr::across(where(is.numeric), \(v) round(v, chiffres))) |>
    flextable::flextable() |>
    flextable::set_caption(caption %||% "") |>
    flextable::theme_booktabs() |>
    style_rapport()
}

`%||%` <- function(a, b) if (is.null(a) || length(a) == 0) b else a

cat("Fonctions utilitaires chargées (00_fonctions_utiles.R)\n")
