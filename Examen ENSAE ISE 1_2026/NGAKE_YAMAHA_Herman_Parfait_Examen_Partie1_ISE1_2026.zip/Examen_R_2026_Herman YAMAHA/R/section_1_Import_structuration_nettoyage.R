# ============================================================================
# SECTION 1 :  IMPORT, STRUCTURATION ET NETTOYAGE 
# ============================================================================

# 1.1 Importons les 05 sources avec les packages appropriés
# ----------------------------------------------------------------------------

library(tidyverse)
library(haven)        # pour lire les fichiers .dta (Stata)
library(readxl)       # pour lire les fichiers .xlsx
library(janitor)      # pour nettoyer les noms de colonnes
library(naniar)
library(visdat)
library(UpSetR)

# Chemin vers les données brutes
raw_path <- "data/raw/"

# a. ensan_menages.dta (Stata avec labels)
menages <- read_dta(file.path(raw_path, "ensan_menages.dta")) %>%
  clean_names()  # standardise les noms de colonnes

# Visualisation de la base
View(menages)

# b. ensan_individus.csv (UTF-8)
individus <- read_csv(file.path(raw_path, "ensan_individus.csv"),
                      locale = locale(encoding = "UTF-8")) %>%
  clean_names()

# Visualisation de la base
View(individus)

# c. ensan_consommation.xlsx (plusieurs feuilles)
# Feuille 1 : Consommation_groupes
consommation <- read_excel(file.path(raw_path, "ensan_consommation.xlsx"),
                           sheet = "Consommation_groupes") %>%
  clean_names()

# Visualisation de la base
View(consommation)

# Feuille 2 : Depenses_menage
depenses <- read_excel(file.path(raw_path, "ensan_consommation.xlsx"),
                       sheet = "Depenses_menage") %>%
  clean_names()

# Visualisation de la base
View(depenses)

# d. chocs_menages.csv
chocs <- read_csv(file.path(raw_path, "chocs_menages.csv"),
                  locale = locale(encoding = "UTF-8")) %>%
  clean_names()

# Visualisation de la base
View(chocs)


# e. prix_marches.csv
prix <- read_csv(file.path(raw_path, "prix_marches.csv"),
                 locale = locale(encoding = "UTF-8")) %>%
  clean_names()


# Visualisation de la base
View(prix)


# Vérification rapide des structures
glimpse(menages)
glimpse(individus)
glimpse(consommation)
glimpse(depenses)
glimpse(chocs)
glimpse(prix)







# 1.2 Fusionnons les modules en un jeu de données ménages enrichi
# ----------------------------------------------------------------------------

# ---- Étape 1 : Extraire le chef de ménage et ses caractéristiques ----

# Le chef de ménage est identifié par rang == 1
chef_menage <- individus %>%
  filter(rang == 1) %>%
  select(hhid, age, sexe, niveau_educ) %>%
  rename(
    age_chef = age,
    sexe_chef = sexe,
    educ_chef = niveau_educ
  )

# Visualisation
View(chef_menage)


# ---- Étape 2 : Agréger la consommation alimentaire (HDDS)  ----

# Le HDDS est un score qui compte le nombre de groupes alimentaires différents consommés par le ménage.

# Compter le nombre de groupes alimentaires consommés par ménage
consommation_agregee <- consommation %>%
  mutate(
    hdds = rowSums(select(., starts_with("cons_")), na.rm = TRUE)    # select(., starts_with("cons_")) sélectionne toutes les colonnes
                                                                     #   dont le nom commence par "cons_" (cons_cereales, cons_tubercules, ...)
  ) %>%
  select(hhid, hdds, starts_with("cons_"))



# ---- Étape 3 : Fusionner toutes les tables ----

# 3a. menages + chef de ménage
menages_enrichi <- menages %>%
  left_join(chef_menage, by = "hhid")

# Vérification : nombre de lignes inchangé
message("Lignes après menages + chef: ", nrow(menages_enrichi))
# stopifnot(nrow(menages_enrichi) == nrow(menages))

# Résultat : Erreur : nrow(menages_enrichi) == nrow(menages) n'est pas TRUE

# Essayons de comprendre pourquoi le nombre de lignes a changé. Il est possible que certains ménages n'aient pas de chef identifié (rang == 1) dans la table individus, ce qui entraînerait une perte de lignes lors de la jointure.

# Comptons le nombre de chefs par ménage
individus %>%
  filter(rang == 1) %>%
  group_by(hhid) %>%
  summarise(n_chefs = n()) %>%
  filter(n_chefs > 1) %>%
  glimpse()

# Résultat :
# Rows: 15
# Columns: 2
# $ hhid    <chr> "00451", "00632", "00643", "00886", "01122", "01464", "01815", "01862", "0186…
# $ n_chefs <int> 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2

# Observation : Nous avons 15 ménages qui ont 02 chefs de ménages. 

# Vérifions les types
typeof(menages$hhid)
typeof(individus$hhid)

# Vérifions les formats
head(menages$hhid)
head(individus$hhid)

# Les types et les formats ne posent pas de problème.
# Le problème vient du fait que certains ménages ont plusieurs chefs (rang == 1). 
# Pour résoudre ce problème, nous choisissons de garder uniquement le premier chef pour chaque ménage. 
# Nous allons donc filtrer les individus pour ne garder qu'un seul chef par ménage avant de faire la jointure.



# ---- Extraire le chef de ménage (sans doublons) ----

chef_menage <- individus %>%
  filter(rang == 1) %>%
  distinct(hhid, .keep_all = TRUE) %>%  # Garde le premier chef rencontré
  select(hhid, age, sexe, niveau_educ) %>%
  rename(
    age_chef = age,
    sexe_chef = sexe,
    educ_chef = niveau_educ
  )


# ---- Fusion avec vérification ----

menages_enrichi <- menages %>%
  left_join(chef_menage, by = "hhid")

message("Lignes après menages + chef: ", nrow(menages_enrichi))

#stopifnot(nrow(menages_enrichi) == nrow(menages)) 

# Maintenant c'est bon, les résultats sont cohérents.Lorsque la fonction
# stopitnot n'affiche rien, la resultat de la condition est TRUE. On peut donc continuer.


# 3b. + consommation agrégée

menages_enrichi <- menages_enrichi %>%
  left_join(consommation_agregee, by = "hhid")

message("Lignes après + consommation: ", nrow(menages_enrichi))

#stopifnot(nrow(menages_enrichi) == nrow(menages))
# Pas de problème


# 3c. + dépenses
menages_enrichi <- menages_enrichi %>%
  left_join(depenses, by = "hhid")

message("Lignes après + dépenses: ", nrow(menages_enrichi))

#stopifnot(nrow(menages_enrichi) == nrow(menages))
# Pas de problème


# 3d. + chocs
menages_enrichi <- menages_enrichi %>%
  left_join(chocs, by = "hhid")

message("Lignes après + chocs: ", nrow(menages_enrichi))

#stopifnot(nrow(menages_enrichi) == nrow(menages))
# Pas de problème

# ---- Vérification finale ----

# Aperçu du jeu de données enrichi
View(menages_enrichi)

# Vérification des valeurs manquantes après jointures
menages_enrichi %>%
  summarise(across(everything(), ~ sum(is.na(.)))) %>%
  glimpse()





# 1.3 Identifier et corriger les libellés de régions incohérents entre fichiers
# ----------------------------------------------------------------------------

# ---- Étape 1 : Lister les régions uniques par fichier ----

# Régions dans menages
regions_menages <- menages_enrichi %>%
  distinct(region) %>%
  pull(region) %>%
  sort()


# Régions dans chocs
regions_chocs <- chocs %>%
  distinct(region_lib) %>%
  pull(region_lib) %>%
  sort()


# Régions dans prix
regions_prix <- prix %>%
  distinct(region) %>%
  pull(region) %>%
  sort()


# ---- Étape 2 : Comparer les libellés ----

cat("=== Régions dans menages ===\n")
print(regions_menages)

cat("\n=== Régions dans chocs ===\n")
print(regions_chocs)

cat("\n=== Régions dans prix ===\n")
print(regions_prix)

# D'après les résultats, les problèmes sont :
# - MAJUSCULES vs minuscules avec accents
# - "BARH_EL_GAZEL" vs "Barh El Gazel"
# - "CHARI_BAGUIRMI" vs "Chari Baguirmi"
# - "GUERA" / "GUÉRA" vs "Guéra"
# - "NDJAMENA" vs "N'Djamena"
# - "OUADAI" / "OUADDAÏ" vs "Ouaddaï"
# - "TANDJILÉ" / "TANDJILLE" vs "Tandjilé"


# ---- Étape 3 : Créer une table de correspondance complète ----

correspondance_regions <- tibble(
  region_chocs = c(
    "BARH_EL_GAZEL",
    "BATHA",
    "BORKOU",
    "CHARI_BAGUIRMI",
    "ENNEDI_EST",
    "ENNEDI_OUEST",
    "GUERA",
    "GUÉRA",
    "HADJER_LAMIS",
    "KANEM",
    "LAC",
    "LOGONE_OCCIDENTAL",
    "LOGONE_ORIENTAL",
    "MANDOUL",
    "MAYO_KEBBI_EST",
    "MAYO_KEBBI_OUEST",
    "MOYEN_CHARI",
    "NDJAMENA",
    "OUADAI",
    "OUADDAÏ",
    "SALAMAT",
    "SILA",
    "TANDJILÉ",
    "TANDJILLE",
    "TIBESTI",
    "WADI_FIRA"
  ),
  region_menages = c(
    "Barh El Gazel",
    "Batha",
    "Borkou",
    "Chari Baguirmi",
    "Ennedi Est",
    "Ennedi Ouest",
    "Guéra",
    "Guéra",
    "Hadjer Lamis",
    "Kanem",
    "Lac",
    "Logone Occidental",
    "Logone Oriental",
    "Mandoul",
    "Mayo Kebbi Est",
    "Mayo Kebbi Ouest",
    "Moyen Chari",
    "N'Djamena",
    "Ouaddaï",
    "Ouaddaï",
    "Salamat",
    "Sila",
    "Tandjilé",
    "Tandjilé",
    "Tibesti",
    "Wadi Fira"
  )
)

cat("\n=== Table de correspondance ===\n")
print(correspondance_regions)

# ---- Étape 4 : Appliquer la correction ----

chocs_corrige <- chocs %>%
  left_join(correspondance_regions, by = c("region_lib" = "region_chocs")) %>%
  mutate(
    region = if_else(!is.na(region_menages), region_menages, region_lib)
  ) %>%
  select(-region_menages)

# ---- Étape 5 : Vérifier la correction ----

regions_chocs_corrige <- chocs_corrige %>%
  distinct(region) %>%
  pull(region) %>%
  sort()

cat("\n=== Régions dans chocs après correction ===\n")
print(regions_chocs_corrige)

# Vérification : plus de différences
manquantes_apres <- setdiff(regions_menages, regions_chocs_corrige)
cat("\n=== Régions encore manquantes après correction ===\n")
print(manquantes_apres)

if (length(manquantes_apres) == 0) {
  cat("\n Toutes les régions sont maintenant cohérentes !\n")
} else {
  cat("\n Il reste des incohérences à corriger\n")
}

# ---- Étape 6 : Mettre à jour menages_enrichi avec les chocs corrigés ----

menages_enrichi <- menages_enrichi %>%
  select(-starts_with("choc_"), -starts_with("strat_")) %>% # starts_with("choc_") Sélectionne toutes les colonnes qui commencent par "choc_"
  left_join(chocs_corrige, by = c("hhid" = "hhid"))

# Vérification du nombre de lignes
#stopifnot(nrow(menages_enrichi) == nrow(menages))
# Pas de problème

# ---- Étape 7 : Sauvegarder les données traitées ----

saveRDS(menages_enrichi, file = "data/processed/menages_enrichi.rds")
saveRDS(chocs_corrige, file = "data/processed/chocs_corrige.rds")

message("\n Fichiers sauvegardés dans data/processed/")






# 1.4 Diagnostic complet des valeurs manquantes avec naniar
# ----------------------------------------------------------------------------


# ---- Étape 1 : Résumé global des valeurs manquantes ----

# Pourcentage global de valeurs manquantes

cat("=== Résumé global des valeurs manquantes ===\n")

cat("Nombre total de cellules : ", nrow(menages_enrichi) * ncol(menages_enrichi), "\n")

cat("Nombre de cellules manquantes : ", sum(is.na(menages_enrichi)), "\n")

cat("Pourcentage de cellules manquantes : ", 
    round(100 * sum(is.na(menages_enrichi)) / (nrow(menages_enrichi) * ncol(menages_enrichi)), 2), "%\n")



# ---- Étape 2 : Résumé par variable ----

# Nombre et pourcentage de NA par colonne

na_summary <- menages_enrichi %>%
  miss_var_summary() %>%
  arrange(desc(pct_miss))

cat("\n=== Variables avec valeurs manquantes ===\n")

print(na_summary)

# n_miss : nombre de valeurs manquantes par variable 
# pct_miss : pourcentage de valeurs manquantes par variable

# A tibble: 42 × 3
# variable      n_miss pct_miss
# <chr>          <int>    <num>
#  1 revenu           369    10.4 
# 2 educ_chef        185     5.23
# 3 taille_menage    150     4.24
# 4 age_chef          74     2.09
# 5 hhid               0     0   
# 6 region.x           0     0   
# 7 milieu             0     0   
# 8 grappe             0     0   
# 9 strate             0     0   
# 10 poids_final        0     0   
# ℹ 32 more rows
# ℹ Use `print(n = ...)` to see more rows



# ---- Étape 3 : Visualisations des valeurs manquantes  ----

# 3a. Visdat : visualisation globale des données
p1 <- vis_dat(menages_enrichi) +
  scale_fill_manual(
    values = c(
      "character" = "#2E86AB",   # Bleu pour les caractères
      "numeric" = "#A23B72",     # Violet pour les numériques
      "integer" = "#F18F01",     # Orange pour les entiers
      "logical" = "#C73E1D",     # Rouge pour les logiques
      "Date" = "#06A77D"         # Vert pour les dates
    ),
    name = "Type de données"
  ) +
  labs(
    title = "Structure des données et valeurs manquantes",
    subtitle = paste("Ménages:", nrow(menages_enrichi), "| Variables:", ncol(menages_enrichi)),
    x = "Position des variables",
    y = "Lignes (ménages)"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 11, hjust = 0.5, color = "gray40"),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 7),
    axis.text.y = element_text(size = 8),
    legend.position = "bottom",
    legend.title = element_text(size = 10, face = "bold"),
    legend.text = element_text(size = 9),
    panel.grid.minor = element_blank()
  )

# 3b. Visualisation des valeurs manquantes
p2 <- vis_miss(menages_enrichi, 
               sort_miss = TRUE, 
               cluster = TRUE,
               warn_large_data = FALSE) +
  scale_fill_manual(
    values = c(
      "Present" = "#2E86AB",     # Bleu pour les valeurs présentes
      "Missing" = "#C73E1D"      # Rouge pour les valeurs manquantes
    ),
    name = "Statut",
    labels = c("Présent", "Manquant")
  ) +
  labs(
    title = "Carte des valeurs manquantes",
    subtitle = paste("Total:", round(100 * sum(is.na(menages_enrichi)) / (nrow(menages_enrichi) * ncol(menages_enrichi)), 2), "% de données manquantes"),
    x = "Variables (triées par taux de manquants)",
    y = "Lignes (ménages)"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 11, hjust = 0.5, color = "gray40"),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 8),
    axis.text.y = element_text(size = 8),
    legend.position = "bottom",
    legend.title = element_text(size = 10, face = "bold"),
    legend.text = element_text(size = 9),
    panel.grid.minor = element_blank()
  )

# Sauvegarde des figures

# En png

ggsave("output/figures/vis_dat_menages.png", 
       p1, 
       width = 12, 
       height = 8, 
       dpi = 300)

ggsave("output/figures/vis_miss_menages.png", 
       p2, 
       width = 12, 
       height = 8, 
       dpi = 300)

# En PDF (pour publication)
ggsave("output/figures/vis_dat_menages.pdf", 
       p1, 
       width = 12, 
       height = 8)

ggsave("output/figures/vis_miss_menages.pdf", 
       p2, 
       width = 12, 
       height = 8)

message("\n Figures sauvegardées dans output/figures/")







# ---- Étape 4 : Heatmaps des valeurs manquantes ----

# 4a. Heatmap des valeurs manquantes par variable
p3 <- gg_miss_var(menages_enrichi, show_pct = TRUE) +
  scale_fill_gradient(
    low = "#2E86AB",
    high = "#C73E1D",
    name = "Proportion\nmanquante (%)",
    labels = function(x) paste0(round(x, 1), "%")
  ) +
  labs(
    title = "Proportion de valeurs manquantes par variable",
    subtitle = paste("Total:", ncol(menages_enrichi), "variables"),
    x = "",
    y = "Proportion de valeurs manquantes (%)"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 11, hjust = 0.5, color = "gray40"),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 9),
    axis.text.y = element_text(size = 9),
    axis.title.y = element_text(size = 10, face = "bold"),
    legend.position = "right",
    legend.title = element_text(size = 9, face = "bold"),
    legend.text = element_text(size = 8),
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_blank()
  )


# 4b. Heatmap alternative : calcul manuel des NA par région
p4_alt <- menages_enrichi %>%

  group_by(region) %>%
  summarise(across(everything(), ~ mean(is.na(.)) * 100)) %>%
  pivot_longer(
    cols = -region,
    names_to = "variable",
    values_to = "pct_miss"
  ) %>%
  filter(pct_miss > 0) %>%
  mutate(
    variable = factor(variable, 
                      levels = rev(unique(variable))),
    region = factor(region, 
                    levels = sort(unique(region)))
  ) %>%
  ggplot(aes(x = region, y = variable, fill = pct_miss)) +
  geom_tile(color = "white", size = 0.5) +
  scale_fill_gradient(
    low = "#2E86AB",
    high = "#C73E1D",
    name = "% manquant",
    labels = function(x) paste0(round(x, 1), "%")
  ) +
  labs(
    title = "Carte des valeurs manquantes par région et par variable",
    subtitle = paste("Basé sur", nrow(menages_enrichi), "ménages dans", 
                     length(unique(menages_enrichi$region)), "régions"),
    x = "Région",
    y = "Variable"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 11, hjust = 0.5, color = "gray40"),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 8),
    axis.text.y = element_text(size = 7),
    axis.title = element_text(size = 10, face = "bold"),
    legend.position = "right",
    legend.title = element_text(size = 9, face = "bold"),
    legend.text = element_text(size = 8),
    panel.grid = element_blank()
  )
# ---- Sauvegarde des figures ----


# Sauvegarder p3 (proportion par variable)
ggsave("output/figures/heatmap_miss_var.png", 
       p3, 
       width = 10, 
       height = 7, 
       dpi = 300)

ggsave("output/figures/heatmap_miss_var.pdf", 
       p3, 
       width = 10, 
       height = 7)

# Sauvegarder p4_alt (proportion par région)
ggsave("output/figures/heatmap_miss_region.png", 
       p4_alt, 
       width = 16,
       height = 12,
       dpi = 300)

ggsave("output/figures/heatmap_miss_region.pdf", 
       p4_alt, 
       width = 16, 
       height = 12)

message("\n Heatmaps sauvegardées dans output/figures/")






# ---- Étape 5 : Cooccurrences des valeurs manquantes ----

# 5a. Identifier les colonnes avec NA
colonnes_avec_na <- menages_enrichi %>%
  select(where(~ any(is.na(.)))) %>%
  names()

cat("\n=== Colonnes avec valeurs manquantes ===\n")
print(colonnes_avec_na)

# 5b. Compter les combinaisons de NA
# Créer un pattern de NA pour chaque ligne
na_patterns <- menages_enrichi %>%
  select(colonnes_avec_na) %>%
  mutate(
    pattern = apply(., 1, function(x) {
      vars <- names(.)[is.na(x)]
      if (length(vars) == 0) return("Aucune_NA")
      paste(sort(vars), collapse = " | ")
    })
  ) %>%
  count(pattern, sort = TRUE) %>%
  mutate(
    n_vars = str_count(pattern, "\\|") + 1,
    pattern = ifelse(pattern == "Aucune_NA", "Aucune valeur manquante", pattern)
  )

# 5c. Visualisation : Top des patterns avec chiffres
p5_clean <- na_patterns %>%
  filter(pattern != "Aucune valeur manquante") %>%
  head(15) %>%
  mutate(pattern = fct_reorder(pattern, n)) %>%
  ggplot(aes(x = n, y = pattern, fill = n_vars)) +
  geom_col() +
  # Ajouter les chiffres à l'intérieur ou à côté des barres
  geom_text(aes(label = n), 
            hjust = -0.2,           # Position à droite de la barre
            size = 3.5,
            color = "black") +
  scale_fill_gradient(
    low = "#2E86AB", 
    high = "#C73E1D", 
    name = "Nombre de\nvariables NA",
    breaks = 1:max(na_patterns$n_vars, na.rm = TRUE)
  ) +
  # Étendre l'axe des x pour faire place aux chiffres
  scale_x_continuous(expand = expansion(mult = c(0, 0.15))) +
  labs(
    title = "Top 15 des combinaisons de valeurs manquantes",
    subtitle = paste("Basé sur", nrow(menages_enrichi), "ménages"),
    x = "Nombre de ménages avec cette combinaison",
    y = "Combinaison de variables manquantes"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 11, hjust = 0.5, color = "gray40"),
    axis.text.y = element_text(size = 7),
    axis.title = element_text(size = 10, face = "bold"),
    legend.position = "right",
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_blank()  # Supprime les grilles horizontales
  )

# Sauvegarder
ggsave("output/figures/top_na_combinations.png", 
       p5_clean, 
       width = 14, 
       height = 10, 
       dpi = 300)

ggsave("output/figures/top_na_combinations.pdf", 
       p5_clean, 
       width = 14, 
       height = 10)

# 5d. Sauvegarder les données des patterns
write_csv(na_patterns, "output/tables/na_patterns.csv")

message("\n Top des combinaisons de NA sauvegardées :")
message("  - output/figures/top_na_combinations.png / .pdf")
message("  - output/tables/na_patterns.csv")




# ---- Étape 6 : Visualisation des motifs de valeurs manquantes ----

# 6a. Motif des valeurs manquantes pour les chocs et stratégies
p6 <- menages_enrichi %>%
  select(starts_with("choc_"), starts_with("strat_")) %>%
  vis_miss(cluster = TRUE, sort_miss = TRUE) +
  scale_fill_manual(
    values = c("Present" = "#2E86AB", "Missing" = "#C73E1D"),
    name = "Statut",
    labels = c("Présent", "Manquant")
  ) +
  labs(
    title = "Valeurs manquantes dans les chocs et stratégies",
    x = "Variables",
    y = "Lignes (ménages)"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 11, hjust = 0.5, color = "gray40"),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 9),
    axis.text.y = element_text(size = 8),
    legend.position = "bottom",
    legend.title = element_text(size = 10, face = "bold"),
    legend.text = element_text(size = 9)
  )

# 6b. Motif des valeurs manquantes pour les dépenses
p7 <- menages_enrichi %>%
  select(starts_with("dep_")) %>%
  vis_miss(cluster = TRUE, sort_miss = TRUE) +
  scale_fill_manual(
    values = c("Present" = "#2E86AB", "Missing" = "#C73E1D"),
    name = "Statut",
    labels = c("Présent", "Manquant")
  ) +
  labs(
    title = "Valeurs manquantes dans les dépenses",
    x = "Variables",
    y = "Lignes (ménages)"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 11, hjust = 0.5, color = "gray40"),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 9),
    axis.text.y = element_text(size = 8),
    legend.position = "bottom",
    legend.title = element_text(size = 10, face = "bold"),
    legend.text = element_text(size = 9)
  )

# 6c. Motif des valeurs manquantes pour la consommation 
p8 <- menages_enrichi %>%
  select(hdds, starts_with("cons_")) %>%
  vis_miss(cluster = TRUE, sort_miss = TRUE) +
  scale_fill_manual(
    values = c("Present" = "#2E86AB", "Missing" = "#C73E1D"),
    name = "Statut",
    labels = c("Présent", "Manquant")
  ) +
  labs(
    title = "Valeurs manquantes dans la consommation alimentaire",
    x = "Variables",
    y = "Lignes (ménages)"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 11, hjust = 0.5, color = "gray40"),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 9),
    axis.text.y = element_text(size = 8),
    legend.position = "bottom",
    legend.title = element_text(size = 10, face = "bold"),
    legend.text = element_text(size = 9)
  )

# ---- Sauvegarder les visualisations supplémentaires ----


# Chocs et stratégies
ggsave("output/figures/vis_miss_chocs_strategies.png", 
       p6, 
       width = 10, 
       height = 7, 
       dpi = 300)

ggsave("output/figures/vis_miss_chocs_strategies.pdf", 
       p6, 
       width = 10, 
       height = 7)

# Dépenses
ggsave("output/figures/vis_miss_depenses.png", 
       p7, 
       width = 10, 
       height = 7, 
       dpi = 300)

ggsave("output/figures/vis_miss_depenses.pdf", 
       p7, 
       width = 10, 
       height = 7)

# Consommation 
ggsave("output/figures/vis_miss_consommation.png", 
       p8, 
       width = 12, 
       height = 8, 
       dpi = 300)

ggsave("output/figures/vis_miss_consommation.pdf", 
       p8, 
       width = 12, 
       height = 8)

# ---- Message de confirmation ----

message("\n Visualisations des motifs de valeurs manquantes sauvegardées :")
message("  - output/figures/vis_miss_chocs_strategies.png / .pdf")
message("  - output/figures/vis_miss_depenses.png / .pdf")
message("  - output/figures/vis_miss_consommation.png / .pdf")



# ---- Étape 7 : Détection des valeurs manquantes taguées Stata ----

# 1. Identifier les colonnes qui contiennent des valeurs taguées Stata
colonnes_stata <- menages_enrichi %>%
  select(where(~ inherits(., "haven_labelled"))) %>%
  names()

cat("\n=== Colonnes avec des labels Stata (potentiellement des valeurs taguées) ===\n")
print(colonnes_stata)

# 2. Compter les valeurs manquantes taguées

# Fonction pour compter les valeurs taguées dans une colonne
compter_tagged_na <- function(x) {
  if (inherits(x, "haven_labelled")) {
    tagged_vals <- attr(x, "labels")
    if (!is.null(tagged_vals)) {
      # Identifier les codes commençant par "." (ex: .a, .b, .d)
      tagged_values <- names(tagged_vals)[grepl("^\\.", names(tagged_vals))]
      if (length(tagged_values) > 0) {
        # Convertir les codes en valeurs numériques
        tagged_numeric <- as.numeric(tagged_values)
        return(sum(x %in% tagged_numeric, na.rm = TRUE))
      }
    }
  }
  return(0)
}

# Appliquer la fonction à toutes les colonnes
tagged_na_count <- menages_enrichi %>%
  summarise(across(everything(), compter_tagged_na)) %>%
  pivot_longer(everything(), names_to = "variable", values_to = "tagged_na") %>%
  filter(tagged_na > 0)

cat("\n=== Colonnes avec des valeurs manquantes taguées Stata ===\n")
print(tagged_na_count)

# 3. Compter les NA standards par colonne
na_standards <- menages_enrichi %>%
  summarise(across(everything(), ~ sum(is.na(.)))) %>%
  pivot_longer(everything(), names_to = "variable", values_to = "std_na") %>%
  filter(std_na > 0)

# 4. Fusionner les deux résumés
na_comparison <- na_standards %>%
  left_join(tagged_na_count, by = "variable") %>%
  mutate(
    tagged_na = ifelse(is.na(tagged_na), 0, tagged_na),
    total_na = std_na + tagged_na
  ) %>%
  arrange(desc(total_na))

cat("\n=== Comparaison NA standards vs NA tagués ===\n")
print(na_comparison)

# 5. Visualisation de la comparaison
if (nrow(na_comparison) > 0) {
  p9 <- na_comparison %>%
    pivot_longer(cols = c(std_na, tagged_na), 
                 names_to = "type_na", 
                 values_to = "count") %>%
    filter(count > 0) %>%
    mutate(
      type_na = factor(type_na, 
                       levels = c("std_na", "tagged_na"),
                       labels = c("NA standards", "NA tagués Stata")),
      variable = fct_reorder(variable, count, sum, .desc = TRUE)
    ) %>%
    ggplot(aes(x = count, y = variable, fill = type_na)) +
    geom_col(position = "dodge") +
    geom_text(aes(label = count), 
              position = position_dodge(width = 0.9),
              hjust = -0.1,
              size = 3) +
    scale_fill_manual(
      values = c("NA standards" = "#2E86AB", "NA tagués Stata" = "#C73E1D"),
      name = "Type de valeur manquante"
    ) +
    scale_x_continuous(expand = expansion(mult = c(0, 0.15))) +
    labs(
      title = "Comparaison : NA standards vs NA tagués Stata",
      subtitle = paste("Distinction entre les valeurs manquantes classiques et les codes spéciaux Stata (.a, .b, .d, etc.)"),
      x = "Nombre de valeurs manquantes",
      y = "Variable"
    ) +
    theme_minimal() +
    theme(
      plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
      plot.subtitle = element_text(size = 11, hjust = 0.5, color = "gray40"),
      axis.text.y = element_text(size = 8),
      axis.title = element_text(size = 10, face = "bold"),
      legend.position = "bottom",
      legend.title = element_text(size = 10, face = "bold"),
      panel.grid.minor = element_blank()
    )
  
  # Sauvegarder
  ggsave("output/figures/na_standards_vs_tagged.png", 
         p9, 
         width = 12, 
         height = max(6, nrow(na_comparison) * 0.4), 
         dpi = 300)
  
  ggsave("output/figures/na_standards_vs_tagged.pdf", 
         p9, 
         width = 12, 
         height = max(6, nrow(na_comparison) * 0.4))
  
  message("\n Figure sauvegardée : output/figures/na_standards_vs_tagged.png / .pdf")
}

# 6. Détection des codes tagués spécifiques (pour la colonne milieu par exemple)
if (length(colonnes_stata) > 0) {
  cat("\n=== Analyse détaillée des codes tagués pour la colonne milieu ===\n")
  
  # Pour la colonne milieu, afficher les labels
  if ("milieu" %in% names(menages_enrichi)) {
    labels_milieu <- attr(menages_enrichi$milieu, "labels")
    print(labels_milieu)
    
    # Compter les valeurs par label
    milieu_counts <- menages_enrichi %>%
      count(milieu) %>%
      mutate(
        label = ifelse(is.na(milieu), "NA", 
                       names(labels_milieu)[match(milieu, labels_milieu)])
      )
    print(milieu_counts)
  }
}

# 7. Sauvegarder les résultats
write_csv(na_comparison, "output/tables/na_standards_vs_tagged.csv")

message("\n Résultats sauvegardés :")
message("  - output/tables/na_standards_vs_tagged.csv")

# Remarque : Il n'y a pas de valeurs manquantes taguées stata dans la base.
# Raison pour laquelle dans le graphique, il n'y a pas de barres pour les NA tagués Stata.



# ---- Étape 8 : Sauvegarder les résultats ----

# Sauvegarder le résumé des NA pour référence
na_summary <- menages_enrichi %>%
  miss_var_summary()

write_csv(na_summary, "output/tables/na_summary.csv")

# Sauvegarder la matrice de cooccurrence
if (exists("na_combinations")) {
  write_csv(na_combinations, "output/tables/na_cooccurrence.csv")
}

message("\n Tous les diagnostics sauvegardés :")
message("  - output/figures/upset_miss_cooccurrence.png / .pdf")
message("  - output/figures/vis_miss_chocs_strategies.png / .pdf")
message("  - output/figures/vis_miss_depenses.png / .pdf")
message("  - output/tables/na_summary.csv")
message("  - output/tables/na_cooccurrence.csv")






# 1.5 Justifier et appliquer une imputation multiple par équations chaînées
# ----------------------------------------------------------------------------

library(mice)
library(ggplot2)
library(patchwork)

# ---- Étape 1 : Sélection des variables clés pour l'imputation ----

# D'après le diagnostic des NA, identifions les variables avec des valeurs manquantes
# et choisissons deux variables clés pour l'analyse

# Variables avec NA
variables_avec_na <- menages_enrichi %>%
  summarise(across(everything(), ~ sum(is.na(.)))) %>%
  pivot_longer(everything(), names_to = "variable", values_to = "na_count") %>%
  filter(na_count > 0) %>%
  arrange(desc(na_count))

cat("\n=== Variables avec valeurs manquantes ===\n")
print(variables_avec_na)



# Choix des deux variables clés pour l'imputation :
# 1. revenu (variable économique clé)
# 2. dep_alimentaire (variable de dépense alimentaire, clé pour la sécurité alimentaire)

variables_a_imputer <- c("revenu", "dep_alimentaire")

cat("\n=== Variables sélectionnées pour l'imputation ===\n")
cat("1. revenu : ", sum(is.na(menages_enrichi$revenu)), " NA (", 
    round(100 * mean(is.na(menages_enrichi$revenu)), 1), "%)\n")
cat("2. dep_alimentaire : ", sum(is.na(menages_enrichi$dep_alimentaire)), " NA (", 
    round(100 * mean(is.na(menages_enrichi$dep_alimentaire)), 1), "%)\n")



# ---- Étape 2 : Justification du mécanisme de non-réponse ----

cat("\n=== Justification du mécanisme de non-réponse ===\n")
cat("\n1. MCAR (Missing Completely At Random) :\n")
cat("   - Hypothèse : les valeurs manquantes sont aléatoires et indépendantes\n")
cat("   - des autres variables.\n")
cat("   - Justification possible : erreurs de saisie, problèmes techniques.\n")
cat("   - Vraisemblance : peu probable car les NA sont concentrées sur certaines\n")
cat("     variables (revenu, dépenses).\n\n")

cat("2. MAR (Missing At Random) :\n")
cat("   - Hypothèse : la probabilité de manquer dépend des variables observées.\n")
cat("   - Justification : les ménages avec un revenu plus élevé ou en milieu\n")
cat("     urbain peuvent être plus susceptibles de ne pas déclarer leurs dépenses.\n")
cat("   - Vraisemblance : la plus probable pour les données d'enquête.\n\n")

cat("3. MNAR (Missing Not At Random) :\n")
cat("   - Hypothèse : la probabilité de manquer dépend de la valeur elle-même.\n")
cat("   - Justification : les ménages très pauvres ou très riches peuvent\n")
cat("     refuser de déclarer leur revenu.\n")
cat("   - Vraisemblance : possible mais difficile à vérifier.\n\n")

cat("=> Hypothèse retenue : MAR (Missing At Random)\n")
cat("   - Les NA sur 'revenu' et 'dep_alimentaire' sont probablement liées à\n")
cat("     des variables observées comme le milieu, la région, ou la taille du ménage.\n")




# ---- Étape 3 : Préparer les données pour l'imputation ----

# Sélectionner les variables pour l'imputation
# On inclut les variables auxiliaires qui peuvent prédire les NA
variables_imputation <- menages_enrichi %>%
  select(
    # Variables à imputer
    revenu, dep_alimentaire,
    # Variables auxiliaires 
    region, milieu, taille_menage, age_chef, sexe_chef, educ_chef,
    hdds,
    # Variables de chocs (peuvent expliquer les NA)
    choc_secheresse, choc_hausse_prix, choc_conflit, choc_maladie
  )


# Vérifier les types
glimpse(variables_imputation)



# ---- Étape 4 : Imputation multiple par équations chaînées ----

set.seed(123)  # Pour reproductibilité

# 4a. Configuration de la méthode d'imputation
# - pmm : Predictive Mean Matching (pour les variables continues)
# - logreg : régression logistique (pour les variables binaires)
# - polyreg : régression polytomique (pour les variables catégorielles)

# Définir les méthodes d'imputation
methode_imputation <- make.method(variables_imputation)
methode_imputation["revenu"] <- "pmm"           # Variable continue
methode_imputation["dep_alimentaire"] <- "pmm"  # Variable continue
methode_imputation["region"] <- "polyreg"       # Variable catégorielle
methode_imputation["milieu"] <- "logreg"        # Variable binaire
methode_imputation["taille_menage"] <- "pmm"    # Variable continue
methode_imputation["age_chef"] <- "pmm"         # Variable continue
methode_imputation["sexe_chef"] <- "logreg"     # Variable binaire
methode_imputation["educ_chef"] <- "polyreg"    # Variable catégorielle
methode_imputation["hdds"] <- "pmm"             # Variable continue

# Variables binaires (chocs) - imputation par régression logistique
methode_imputation["choc_secheresse"] <- "logreg"
methode_imputation["choc_hausse_prix"] <- "logreg"
methode_imputation["choc_conflit"] <- "logreg"
methode_imputation["choc_maladie"] <- "logreg"

# Afficher les méthodes choisies
cat("\n=== Méthodes d'imputation par variable ===\n")
print(methode_imputation)

# 4b. Créer la matrice des prédicteurs
# Spécifier quelles variables utilisent quelles autres comme prédicteurs
matrice_pred <- make.predictorMatrix(variables_imputation)

# Ajuster la matrice (ex: ne pas utiliser la variable elle-même)
diag(matrice_pred) <- 0



# 4c. Lancer l'imputation multiple
# m = 5 imputations (nombre modéré pour un diagnostic rapide)
# maxit = 10 itérations
cat("\n=== Lancement de l'imputation multiple (5 imputations, 10 itérations) ===\n")
cat("Cela peut prendre quelques minutes...\n")

imputation_mice <- mice(
  variables_imputation,
  m = 5,                    # Nombre d'imputations
  maxit = 10,               # Nombre d'itérations
  method = methode_imputation,
  predictorMatrix = matrice_pred,
  seed = 123,
  printFlag = TRUE
)

# ---- Étape 5 : Diagnostic de l'imputation ----

# 5a. Vérification de la convergence
cat("\n=== Diagnostic de la convergence ===\n")
plot(imputation_mice, layout = c(2, 2))

# Sauvegarder le graphique de convergence
png("output/figures/mice_convergence.png", width = 1000, height = 800, res = 100)
plot(imputation_mice, layout = c(2, 2))
dev.off()

# 5b. Densités des valeurs observées vs imputées
cat("\n=== Comparaison des distributions (observé vs imputé) ===\n")

# Fonction pour comparer les densités
comparer_distributions <- function(data_imputed, variable, n_imputations = 5) {
  # Extraire les données complètes
  complete_data <- complete(data_imputed, "long")
  
  # Séparer observé vs imputé
  complete_data <- complete_data %>%
    mutate(
      type = ifelse(is.na(menages_enrichi[[variable]][.id]), 
                    "Imputé", "Observé")
    )
  
  # Graphique de densité
  p <- ggplot(complete_data, aes(x = .data[[variable]], fill = type)) +
    geom_density(alpha = 0.5) +
    scale_fill_manual(values = c("Observé" = "#2E86AB", "Imputé" = "#C73E1D")) +
    labs(
      title = paste("Distribution de", variable, "- Observé vs Imputé"),
      subtitle = paste("Comparaison des valeurs observées et imputées"),
      x = variable,
      y = "Densité"
    ) +
    theme_minimal() +
    theme(
      plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
      plot.subtitle = element_text(size = 11, hjust = 0.5, color = "gray40"),
      legend.position = "bottom"
    )
  
  return(p)
}

# Comparer pour les deux variables clés
p_revenu <- comparer_distributions(imputation_mice, "revenu")
p_dep_alimentaire <- comparer_distributions(imputation_mice, "dep_alimentaire")

# Afficher les graphiques
print(p_revenu)
print(p_dep_alimentaire)

# Sauvegarder
ggsave("output/figures/mice_comparison_revenu.png", p_revenu, width = 10, height = 6, dpi = 300)
ggsave("output/figures/mice_comparison_dep_alimentaire.png", p_dep_alimentaire, width = 10, height = 6, dpi = 300)

# 5c. Vérification des valeurs imputées
cat("\n=== Statistiques des valeurs imputées ===\n")

# Statistiques pour revenu
revenu_obs <- menages_enrichi$revenu[!is.na(menages_enrichi$revenu)]
revenu_imp <- complete(imputation_mice, "long") %>%
  filter(is.na(menages_enrichi$revenu[.id])) %>%
  pull(revenu)

cat("\nRevenu :\n")
cat("  - Observé : moyenne =", round(mean(revenu_obs, na.rm = TRUE), 0), 
    ", sd =", round(sd(revenu_obs, na.rm = TRUE), 0), "\n")
cat("  - Imputé : moyenne =", round(mean(revenu_imp), 0), 
    ", sd =", round(sd(revenu_imp), 0), "\n")

# Statistiques pour dep_alimentaire
dep_obs <- menages_enrichi$dep_alimentaire[!is.na(menages_enrichi$dep_alimentaire)]
dep_imp <- complete(imputation_mice, "long") %>%
  filter(is.na(menages_enrichi$dep_alimentaire[.id])) %>%
  pull(dep_alimentaire)

cat("\nDépense alimentaire :\n")
cat("  - Observé : moyenne =", round(mean(dep_obs, na.rm = TRUE), 0), 
    ", sd =", round(sd(dep_obs, na.rm = TRUE), 0), "\n")
cat("  - Imputé : moyenne =", round(mean(dep_imp), 0), 
    ", sd =", round(sd(dep_imp), 0), "\n")



# ---- Étape 6 : Créer le jeu de données imputé final ----

# Extraire le premier jeu de données imputé (ou moyen)
menages_impute <- complete(imputation_mice, "long") %>%
  filter(.imp == 1) %>%
  select(-.imp, -.id)

# Ajouter les variables qui n'étaient pas dans l'imputation
menages_impute <- menages_enrichi %>%
  select(-all_of(names(variables_imputation))) %>%
  bind_cols(menages_impute)

# Vérifier qu'il n'y a plus de NA sur les variables imputées
cat("\n=== Vérification des NA après imputation ===\n")
cat("NA sur revenu :", sum(is.na(menages_impute$revenu)), "\n")
cat("NA sur dep_alimentaire :", sum(is.na(menages_impute$dep_alimentaire)), "\n")




# ---- Étape 7 : Sauvegarder ----

# Sauvegarder le modèle d'imputation
saveRDS(imputation_mice, "data/processed/imputation_mice.rds")

# Sauvegarder le jeu de données imputé
saveRDS(menages_impute, "data/processed/menages_impute.rds")

# Sauvegarder les résultats de diagnostic
write_csv(
  variables_avec_na,
  "output/tables/variables_avec_na.csv"
)

cat("\n=== Imputation terminée ===\n")
cat(" Modèle d'imputation sauvegardé : data/processed/imputation_mice.rds\n")
cat(" Données imputées sauvegardées : data/processed/menages_impute.rds\n")
cat(" Graphiques sauvegardés dans output/figures/\n")




# 1.6 Recoder les variables catégorielles nécessaires à l'analyse
# ----------------------------------------------------------------------------

library(forcats)

# ---- Étape 1 : Recoder la variable "milieu" ----

# Vérifier les valeurs actuelles de milieu
cat("=== Valeurs de 'milieu' avant recodage ===\n")
table(menages_impute$milieu, useNA = "ifany")

# Recoder milieu : 1 = Urbain, 2 = Rural
menages_impute <- menages_impute %>%
  mutate(
    milieu = case_when(
      milieu == 1 ~ "Urbain",
      milieu == 2 ~ "Rural",
      TRUE ~ NA_character_
    ),
    milieu = factor(milieu, levels = c("Urbain", "Rural"))
  )

cat("\n=== Valeurs de 'milieu' après recodage ===\n")
table(menages_impute$milieu, useNA = "ifany")





# ---- Étape 2 : Recoder le niveau d'éducation du chef de ménage ----

# Vérifier les valeurs actuelles de educ_chef
cat("\n=== Valeurs de 'educ_chef' avant recodage ===\n")
table(menages_impute$educ_chef, useNA = "ifany")

# Recoder en 4 niveaux : Aucun, Primaire, Secondaire, Supérieur
menages_impute <- menages_impute %>%
  mutate(
    educ_chef = case_when(
      educ_chef %in% c("Aucun", "aucun", "") ~ "Aucun",
      educ_chef %in% c("Primaire", "primaire") ~ "Primaire",
      educ_chef %in% c("Secondaire", "secondaire") ~ "Secondaire",
      educ_chef %in% c("Superieur", "supérieur", "Supérieur") ~ "Supérieur",
      TRUE ~ NA_character_
    ),
    educ_chef = factor(educ_chef, 
                       levels = c("Aucun", "Primaire", "Secondaire", "Supérieur"))
  )

cat("\n=== Valeurs de 'educ_chef' après recodage ===\n")
table(menages_impute$educ_chef, useNA = "ifany")





# ---- Étape 3 : Créer les quintiles de revenu par tête ----

# Calculer le revenu par tête (revenu / taille du ménage)
menages_impute <- menages_impute %>%
  mutate(
    revenu_par_tete = revenu / taille_menage
  )

# Créer les quintiles de revenu par tête
menages_impute <- menages_impute %>%
  mutate(
    quintile_revenu = ntile(revenu_par_tete, 5),
    quintile_revenu = factor(quintile_revenu, 
                             levels = 1:5,
                             labels = c("Q1 (Très faible)", 
                                        "Q2 (Faible)", 
                                        "Q3 (Moyen)", 
                                        "Q4 (Élevé)", 
                                        "Q5 (Très élevé)"))
  )

cat("\n=== Quintiles de revenu par tête ===\n")
table(menages_impute$quintile_revenu, useNA = "ifany")





# ---- Étape 4 : Recoder les chocs en variables factorielles ----

# Variables de chocs (0/1) -> facteurs avec labels explicites
chocs_vars <- c("choc_secheresse", "choc_hausse_prix", 
                "choc_conflit", "choc_maladie")

menages_impute <- menages_impute %>%
  mutate(
    across(all_of(chocs_vars), 
           ~ factor(., levels = c(0, 1), labels = c("Non", "Oui")),
           .names = "{.col}_fct")
  )

cat("\n=== Recodage des chocs ===\n")
for (var in chocs_vars) {
  cat("\n", var, ":\n")
  print(table(menages_impute[[paste0(var, "_fct")]], useNA = "ifany"))

}




# ---- Étape 5 : Recoder les stratégies d'adaptation ----

# Variables de stratégies (0/1) -> facteurs
strategies_vars <- c("strat_vente_actifs", "strat_reduction_repas", 
                     "strat_migration", "strat_endettement")

menages_impute <- menages_impute %>%
  mutate(
    across(all_of(strategies_vars), 
           ~ factor(., levels = c(0, 1), labels = c("Non", "Oui")),
           .names = "{.col}_fct")
  )

cat("\n=== Recodage des stratégies d'adaptation ===\n")
for (var in strategies_vars) {
  cat("\n", var, ":\n")
  print(table(menages_impute[[paste0(var, "_fct")]], useNA = "ifany"))
}





# ---- Étape 6 : Créer une variable d'âge du chef catégorielle ----

menages_impute <- menages_impute %>%
  mutate(
    age_chef_cat = case_when(
      age_chef < 25 ~ "18-24 ans",
      age_chef >= 25 & age_chef < 35 ~ "25-34 ans",
      age_chef >= 35 & age_chef < 45 ~ "35-44 ans",
      age_chef >= 45 & age_chef < 60 ~ "45-59 ans",
      age_chef >= 60 ~ "60 ans et +",
      TRUE ~ NA_character_
    ),
    age_chef_cat = factor(age_chef_cat, 
                          levels = c("18-24 ans", "25-34 ans", 
                                     "35-44 ans", "45-59 ans", 
                                     "60 ans et +"))
  )

cat("\n=== Catégories d'âge du chef ===\n")
table(menages_impute$age_chef_cat, useNA = "ifany")




# ---- Étape 7 : Vérification finale des variables recodées ----

cat("\n=== Résumé des variables recodées ===\n")
cat("\n1. Milieu :\n")
print(table(menages_impute$milieu))

cat("\n2. Niveau d'éducation du chef :\n")
print(table(menages_impute$educ_chef))

cat("\n3. Quintiles de revenu par tête :\n")
print(table(menages_impute$quintile_revenu))

cat("\n4. Âge du chef (catégories) :\n")
print(table(menages_impute$age_chef_cat))

cat("\n5. Chocs (ex: sécheresse) :\n")
print(table(menages_impute$choc_secheresse_fct))

cat("\n6. Stratégies (ex: vente d'actifs) :\n")
print(table(menages_impute$strat_vente_actifs_fct))






# ---- Étape 8 : Sauvegarder le jeu de données final ----

saveRDS(menages_impute, "data/processed/menages_final.rds")

# Exporter en CSV pour vérification rapide
write_csv(menages_impute, "data/processed/menages_final.csv")

cat("\n=== Variables recodées et sauvegardées ===\n")
cat(" Données finales sauvegardées : data/processed/menages_final.rds\n")
cat(" Données finales (CSV) : data/processed/menages_final.csv\n")

# ---- Étape 9 : Synthèse des transformations ----

cat("\n=== SYNTHÈSE DES TRANSFORMATIONS ===\n")
cat("\n1. Milieu : Urbain / Rural (factor)\n")
cat("2. educ_chef : Aucun / Primaire / Secondaire / Supérieur (factor)\n")
cat("3. quintile_revenu : 5 quintiles de revenu par tête (factor)\n")
cat("4. age_chef_cat : 5 catégories d'âge (factor)\n")
cat("5. choc_*_fct : Non / Oui (factor)\n")
cat("6. strat_*_fct : Non / Oui (factor)\n")
cat("7. revenu_par_tete : Revenu / taille du ménage (numeric)\n")
