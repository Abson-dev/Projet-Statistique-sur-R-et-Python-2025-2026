# ==============================================================================
# SCRIPT GENERAL — Boîte à outils des TP "Projet Statistique avec R"
# ==============================================================================
#
# A QUOI SERT CE FICHIER ?
# -------------------------
# Ce n'est PAS un script à lancer tel quel du début à la fin (les variables,
# les fichiers .dta et les questions changent à chaque TP). C'est un CATALOGUE
# de blocs de code déjà écrits et testés dans les TP1 à TP5, rangés dans l'ordre
# où on les utilise habituellement dans un pipeline. Quand un nouveau TP demande
# un traitement déjà vu ("fais un plan de sondage", "fais un tableau gtsummary
# pondéré", "fais une carte du Nigeria par état"...), on vient chercher le bloc
# correspondant ici, on le colle dans le script du nouveau TP, et on adapte les
# noms de variables/colonnes.
#
# SOMMAIRE (Ctrl+F le numéro du bloc) :
#   BLOC 0  — En-tête standard de main.R
#   BLOC 1  — Chargement / installation des packages
#   BLOC 2  — Graine aléatoire, options globales, caption source
#   BLOC 3  — Création de l'arborescence de dossiers
#   BLOC 4  — Téléchargement automatique des données brutes depuis GitHub
#   BLOC 5  — Import des fichiers .dta + diagnostics rapides
#   BLOC 6  — Vérifications qualité (doublons, ménages orphelins)
#   BLOC 7  — Extraction des poids / variables de plan de sondage
#   BLOC 8  — Filtre des membres résidents actifs
#   BLOC 9  — Construction de variables analytiques (factor, case_when, cut)
#   BLOC 10 — Jointures entre bases
#   BLOC 11 — Plan de sondage pondéré (srvyr / survey)
#   BLOC 12 — Diagnostic des valeurs manquantes (naniar::vis_miss)
#   BLOC 13 — Sauvegarde intermédiaire (saveRDS) pour passer nettoyage -> analyses
#   BLOC 14 — Palette de couleurs & thème ggplot commun
#   BLOC 15 — Statistiques descriptives pondérées
#   BLOC 16 — Tests statistiques (Wilcoxon, Chi2 de Rao-Scott, V de Cramér)
#   BLOC 17 — Graphiques types (histogramme, boxplot, QQ-plot, pyramide, barres)
#   BLOC 18 — Cartographie (sf / rnaturalearth)
#   BLOC 19 — Tableau gtsummary pondéré + mise en forme flextable pour Word
#   BLOC 20 — Rendu du rapport RMarkdown en .docx
#   BLOC 21 — Message de fin de pipeline
#
# CONVENTION DE NOMMAGE utilisée dans ce catalogue (à adapter dans le vrai TP) :
#   df_raw / <nom_section>   : table brute importée depuis un .dta
#   df_clean                 : table nettoyée, avec variables analytiques
#   plan_svy                 : objet plan de sondage (as_survey_design)
#   figXX                    : objet ggplot destiné à outputs/figures/figXX_....png
#   tab_xxx                  : objet gtsummary / flextable destiné à outputs/tables/
#
# ==============================================================================


# ==============================================================================
# BLOC 0 — En-tête standard de main.R
# ==============================================================================
# A copier tel quel en haut de chaque main.R d'un nouveau TP (adapter titre,
# auteurs, numéro de TP). C'est le pattern utilisé dans TP1/TP2/TP3/TP4.

# TP<N> : <titre du TP>
# Par : <Prénom NOM 1> & <Prénom NOM 2>, ENSAE ISE1 2025-2026
# Supervisé par : M. Aboubacar HEMA, IFPRI

rm(list = ls())


# ==============================================================================
# BLOC 1 — Chargement / installation des packages
# ==============================================================================
# Deux variantes rencontrées dans les TP : choisir UNE seule des deux dans le
# main.R du nouveau TP (pas besoin des deux).

## --- Variante A (TP1 à TP4) : projet avec renv -----------------------------
## On NE réinstalle pas automatiquement (le TP est censé tourner avec renv).
## Si un package manque, on arrête le script et on demande de faire renv::restore().

pkgs <- c(
  "tidyverse", "haven", "labelled", "here", "scales",     # import / manipulation
  "patchwork", "naniar", "moments",                       # diagnostics / stats desc.
  "rstatix", "coin", "PropCIs",                            # tests statistiques
  "gtsummary", "gt", "flextable", "officer", "knitr",      # tableaux
  "srvyr", "survey",                                        # plan de sondage pondéré
  "forcats", "viridis",                                    # facteurs / couleurs
  "sf", "rnaturalearth", "rnaturalearthdata",               # cartographie (si le TP a une carte)
  "apyramid"                                                # pyramide des âges (si utile)
)

manquants <- pkgs[!pkgs %in% installed.packages()[, 1]]
if (length(manquants) > 0) {
  cat("Packages manquants :", paste(manquants, collapse = ", "), "\n")
  cat("Lancez renv::restore() puis relancez main.R\n")
  stop("Environnement non initialisé.")
}

invisible(lapply(pkgs, library, character.only = TRUE))
cat("Packages charges :", length(pkgs), "\n")

## --- Variante B (main_inspo / projet sans renv) : auto-installation --------
## Pratique quand on démarre un tout nouveau TP sans renv déjà configuré.

pkgs_auto <- c(
  "haven", "dplyr", "tidyr", "ggplot2", "forcats", "scales",
  "rstatix", "ggpubr", "patchwork", "survey", "srvyr",
  "flextable", "officer", "knitr", "rmarkdown", "stringr", "openxlsx"
)

miss <- pkgs_auto[!pkgs_auto %in% installed.packages()[, "Package"]]
if (length(miss) > 0) {
  message(">>> Installation en cours : ", paste(miss, collapse = ", "))
  install.packages(miss, repos = "https://cloud.r-project.org")
}
invisible(lapply(pkgs_auto, library, character.only = TRUE))


# ==============================================================================
# BLOC 2 — Graine aléatoire, options globales, caption source
# ==============================================================================

set.seed(2070)                       # graine utilisée dans tous les TP (reproductibilité)
options(scipen = 999)                # désactive la notation scientifique dans les sorties

# Caption standard a coller en bas de CHAQUE figure ggplot (labs(caption = source_ghs))
source_ghs <- "Source : GHS Panel W4 (2018-2019), NBS Nigeria / World Bank LSMS-ISA. Calculs des auteurs."


# ==============================================================================
# BLOC 3 — Création de l'arborescence de dossiers
# ==============================================================================
# A lancer une fois en tout début de pipeline pour que les dossiers de sortie
# existent avant les premiers ggsave()/saveRDS().

for (rep in c("data/raw", "data/processed", "outputs/figures", "outputs/tables", "docs")) {
  dir.create(rep, showWarnings = FALSE, recursive = TRUE)
}
# Variante avec here() + message de confirmation (TP5) :
# dirs_needed <- c(here("data","raw"), here("data","processed"),
#                   here("outputs","figures"), here("outputs","tables"), here("docs"))
# for (d in dirs_needed) if (!dir.exists(d)) { dir.create(d, recursive = TRUE); cat("[+] Dossier cree :", d, "\n") }


# ==============================================================================
# BLOC 4 — Téléchargement automatique des données brutes depuis GitHub
# ==============================================================================
# Inspiré de main_inspo.R. A adapter à chaque TP : changer `base_url` (le
# sous-dossier GitHub du TP concerné) et la liste des fichiers `fichiers_tp`.
# Ne télécharge que les fichiers absents de data/raw (idempotent : on peut
# relancer le script sans re-télécharger).

options(timeout = 300)

base_url <- paste0(
  "https://raw.githubusercontent.com/",
  "<compte-github>/<nom-du-depot>/main/",
  "<chemin-du-dossier-du-TP>/"          # ex: "Projet%20Statistique%20sous%20R%20ou%20Python/TP%205/"
)

fichiers_tp <- c(
  "<fichier_1>.dta",
  "<fichier_2>.dta"
  # ... ajouter un fichier par ligne
)

for (f in fichiers_tp) {
  dest_file <- file.path("data/raw", f)
  if (!file.exists(dest_file)) {
    url_file <- paste0(base_url, f)
    tryCatch({
      download.file(url_file, destfile = dest_file, mode = "wb", quiet = TRUE)
      cat("  Telecharge :", f, "\n")
    }, error = function(e) {
      cat("  Erreur sur :", f, "-", conditionMessage(e), "\n")
    })
  } else {
    cat("  Deja present :", f, "\n")
  }
}

# Variante TP5 : si les données ne peuvent pas être re-téléchargées (accès
# restreint), on vérifie juste leur présence et on arrête le script avec un
# message clair si un fichier manque :
#
# raw_files <- c("fichier1.dta", "fichier2.dta")
# for (f in raw_files) {
#   path_f <- here("data", "raw", f)
#   if (!file.exists(path_f)) {
#     stop(sprintf("Fichier manquant : %s -- placez-le dans data/raw/", f))
#   }
# }


# ==============================================================================
# BLOC 5 — Import des fichiers .dta + diagnostics rapides
# ==============================================================================
# Pattern répété au début de chaque script "nettoyage.R" / "01_preparation.R".

df_raw   <- read_dta(here("data", "raw", "<fichier_section>.dta"))
df_poids <- read_dta(here("data", "raw", "<fichier_secta>.dta"))   # base qui contient les poids

cat("df_raw   :", nrow(df_raw),   "x", ncol(df_raw),   "\n")
cat("df_poids :", nrow(df_poids), "x", ncol(df_poids), "\n")


# ==============================================================================
# BLOC 6 — Vérifications qualité (doublons, ménages orphelins)
# ==============================================================================

# Doublons sur la clé composite ménage + individu
doublons <- df_raw |> group_by(hhid, indiv) |> filter(n() > 1) |> nrow()
cat("Doublons hhid+indiv :", doublons, "\n")

# Cohérence du nombre de ménages entre deux bases
menages_a <- n_distinct(df_raw$hhid)
menages_b <- n_distinct(df_poids$hhid)
cat("Menages base A :", menages_a, "| base B :", menages_b, "\n")
cat("Menages base B absents de base A :",
    sum(!unique(df_poids$hhid) %in% unique(df_raw$hhid)), "\n")


# ==============================================================================
# BLOC 7 — Extraction des poids / variables de plan de sondage
# ==============================================================================
# Les variables wt_wave4 / strata / cluster (souvent nommé `ea`) viennent
# presque toujours du fichier "secta_*.dta".

poids <- df_poids |>
  select(hhid, wt_wave4, wt_longpanel, old_new, strata, cluster = ea)


# ==============================================================================
# BLOC 8 — Filtre des membres résidents actifs
# ==============================================================================
# s1q4a == 1 -> membre résident actif ; NA -> erreur CAPI documentée, on garde
# quand même (cf. justification détaillée dans les rapports TP1-TP3).

n_total  <- nrow(df_raw)
df_actifs <- df_raw |> filter(s1q4a == 1 | is.na(s1q4a))
cat("Membres retires (non residents) :", n_total - nrow(df_actifs), "sur", n_total, "\n")


# ==============================================================================
# BLOC 9 — Construction de variables analytiques
# ==============================================================================
# Bibliothèque de recettes `mutate()` réutilisées d'un TP à l'autre.

df_clean <- df_actifs |>
  left_join(poids, by = "hhid") |>
  mutate(
    # --- Sexe (à partir d'un code numérique labellisé haven) ---------------
    sexe = factor(
      to_character(s1q2),                       # ou directement s1q2 si déjà numérique
      levels = c("1. MALE", "2. FEMALE"),
      labels = c("Homme", "Femme")
    ),
    # variante numérique simple : factor(s1q2, levels = c(1,2), labels = c("Homme","Femme"))

    # --- Milieu de résidence -------------------------------------------------
    milieu = factor(
      to_character(sector),
      levels = c("1. Urban", "2. Rural"),
      labels = c("Urbain", "Rural")
    ),

    # --- Recodage catégoriel avec case_when + niveaux ordonnés ---------------
    parente = case_when(
      s1q3 == 1             ~ "Chef de menage",
      s1q3 == 2             ~ "Conjoint(e)",
      s1q3 %in% c(3, 4, 5)  ~ "Enfant",
      !is.na(s1q3)          ~ "Autre"
    ) |> factor(levels = c("Chef de menage", "Conjoint(e)", "Enfant", "Autre")),

    # --- Age nettoyé (bornes plausibles) -------------------------------------
    age = if_else(s1q4 > 100, NA_real_, as.numeric(s1q4)),

    # --- Groupes d'âge quinquennaux (pyramide des âges) ----------------------
    groupe_age = cut(
      s1q4,
      breaks = c(0, 5, 10, 15, 20, 25, 30, 35, 40, 45,
                 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, Inf),
      labels = c("[0,5)","[5,10)","[10,15)","[15,20)","[20,25)",
                 "[25,30)","[30,35)","[35,40)","[40,45)","[45,50)",
                 "[50,55)","[55,60)","[60,65)","[65,70)","[70,75)",
                 "[75,80)","[80,85)","[85,90)","[90,95)","95+"),
      right = FALSE, include.lowest = TRUE
    ),

    # --- Groupes d'âge "OMS" (analyses santé, 4 classes) ----------------------
    # groupe_age_oms = cut(s1q4, breaks = c(0,15,35,60,Inf),
    #                       labels = c("0-14","15-34","35-59","60+"),
    #                       right = FALSE, include.lowest = TRUE),

    # --- Variable binaire depuis un code Oui/Non (1/2) ------------------------
    # a_consulte = case_when(s4aq1 == 1 ~ 1L, s4aq1 == 2 ~ 0L, TRUE ~ NA_integer_),

    # --- Somme de plusieurs postes de dépenses (NA si un poste manque) --------
    # depense_totale = rowSums(cbind(s4aq9, s4aq14, s4aq17), na.rm = FALSE),

    # --- Quintiles à partir d'une variable continue ----------------------------
    # quintile   = ntile(totcons_adj, 5),
    # quintile_f = factor(quintile, levels = 1:5,
    #                      labels = c("Q1 (plus pauvre)","Q2","Q3","Q4","Q5 (plus riche)")),
  )

# Taille de ménage (comptage par groupe + rattachement)
taille_menage <- df_clean |> group_by(hhid) |> summarise(taille_menage = n(), .groups = "drop")
df_clean <- df_clean |> left_join(taille_menage, by = "hhid")

# Winsorisation d'une variable continue au 99e percentile (robustesse aux outliers)
# p99 <- quantile(df_clean$depense_med, 0.99, na.rm = TRUE)
# df_clean <- df_clean |> mutate(depense_med_w = if_else(!is.na(depense_med) & depense_med > p99, p99, depense_med))


# ==============================================================================
# BLOC 10 — Jointures entre bases (module spécifique + poids + quintiles, etc.)
# ==============================================================================
# Pattern utilisé quand le module d'intérêt (santé, éducation, agriculture...)
# vit dans un fichier séparé du roster individuel.

# df_module <- read_dta(here("data", "raw", "<fichier_module>.dta"))
#
# df_final <- df_actifs |>
#   select(hhid, indiv, s1q2, s1q4, s1q3, sector, zone, state) |>
#   left_join(df_module |> select(-zone, -state, -sector), by = c("hhid", "indiv")) |>
#   left_join(poids,     by = "hhid") |>
#   left_join(quintiles, by = "hhid")   # si applicable


# ==============================================================================
# BLOC 11 — Plan de sondage pondéré (srvyr / survey)
# ==============================================================================
# A construire UNE fois après le nettoyage complet, puis à réutiliser dans
# tout le script d'analyses. Toujours filtrer les poids manquants avant.

plan_svy <- df_clean |>
  filter(!is.na(wt_wave4)) |>
  as_survey_design(
    ids     = cluster,
    strata  = strata,
    weights = wt_wave4,
    nest    = TRUE
  )

# Plan au niveau ménage (1 ligne par hhid) quand l'analyse porte sur le ménage
# et non sur l'individu (ex : taille du ménage, superficie des parcelles) :
menages <- df_clean |> distinct(hhid, .keep_all = TRUE) |> filter(!is.na(wt_wave4))
plan_menages <- menages |>
  as_survey_design(ids = cluster, strata = strata, weights = wt_wave4, nest = TRUE)


# ==============================================================================
# BLOC 12 — Diagnostic des valeurs manquantes (naniar::vis_miss)
# ==============================================================================
# A produire systématiquement en fig00 dès que les variables clés sont prêtes.

vars_diag <- df_clean |>
  select(zone, state, sector, hhid, indiv, s1q2, s1q3, age) |>
  rename(
    Zone = zone, Region = state, Milieu = sector,
    Menage = hhid, Individu = indiv, Sexe = s1q2, Parente = s1q3, Age = age
  )

fig00 <- vis_miss(vars_diag, sort_miss = TRUE) +
  labs(
    title    = "Diagnostic des valeurs manquantes - variables cles",
    subtitle = "GHS Panel W4 (2018-2019), membres residents",
    caption  = source_ghs
  ) +
  theme_minimal(base_size = 10)

ggsave(here("outputs", "figures", "fig00_diagnostic_NA.png"), fig00, width = 9, height = 5, dpi = 300)


# ==============================================================================
# BLOC 13 — Sauvegarde intermédiaire (fin du script de nettoyage)
# ==============================================================================
# Ce que le script nettoyage.R doit produire pour que analyses.R puisse
# repartir sans tout recalculer.

saveRDS(df_clean,  here("data", "processed", "df_clean.rds"))
saveRDS(menages,   here("data", "processed", "menages.rds"))
saveRDS(plan_svy,      here("data", "processed", "plan_svy.rds"))
saveRDS(plan_menages,  here("data", "processed", "plan_menages.rds"))

cat(sprintf("df_clean : %d obs x %d vars\n", nrow(df_clean), ncol(df_clean)))


# ==============================================================================
# BLOC 14 — Palette de couleurs & thème ggplot commun
# ==============================================================================
# Début de chaque script "analyses.R". Réutiliser ces couleurs institutionnelles
# pour rester cohérent d'un TP à l'autre (adapter si le thème du TP change,
# ex : palette OMS pour la santé, FAO pour l'agriculture).

col_homme  <- "#0058AB"  # WHO/HMD
col_femme  <- "#E8416F"  # WHO/HMD
col_rural  <- "#80BD41"  # FAO/IFPRI
col_urbain <- "#6C757D"  # ONU-HABITAT
col_bleu   <- "#1CABE2"  # UNICEF

theme_tp <- theme_minimal(base_size = 10) +
  theme(
    plot.title    = element_text(size = 11, face = "bold", hjust = 0),
    plot.subtitle = element_text(size = 9,  color = "grey40"),
    plot.caption  = element_text(size = 7,  color = "grey50", hjust = 1),
    axis.title    = element_text(size = 9),
    legend.position = "bottom"
  )
theme_set(theme_tp)

# Recharger les objets produits par le script de nettoyage :
# df_clean     <- readRDS(here("data", "processed", "df_clean.rds"))
# plan_svy     <- readRDS(here("data", "processed", "plan_svy.rds"))


# ==============================================================================
# BLOC 15 — Statistiques descriptives pondérées
# ==============================================================================

stats_var <- plan_svy |>
  summarise(
    N          = unweighted(sum(!is.na(age))),
    moyenne    = survey_mean(age, na.rm = TRUE, vartype = NULL),
    mediane    = survey_median(age, na.rm = TRUE, vartype = NULL),
    q1         = survey_quantile(age, quantiles = 0.25, na.rm = TRUE, vartype = NULL),
    q3         = survey_quantile(age, quantiles = 0.75, na.rm = TRUE, vartype = NULL),
    ecart_type = survey_sd(age, na.rm = TRUE, vartype = NULL),
    asymetrie  = unweighted(round(moments::skewness(age, na.rm = TRUE), 4))
  )

# Statistiques par groupe (ex : par milieu) :
# stats_par_groupe <- plan_svy |>
#   filter(!is.na(milieu)) |>
#   group_by(milieu) |>
#   summarise(N = unweighted(n()), moyenne = survey_mean(age, vartype = NULL), ...)

# Test de normalité (échantillon <= 5000 obs, exigence de shapiro.test)
age_vec <- df_clean$age[!is.na(df_clean$age)]
sw <- shapiro.test(sample(age_vec, min(5000, length(age_vec))))
cat(sprintf("Shapiro-Wilk : W = %.4f, p < 0.001\n", sw$statistic))

# Proportion pondérée par groupe, avec intervalle de confiance
# prop_groupe <- plan_svy |>
#   filter(!is.na(parente)) |>
#   group_by(parente) |>
#   summarise(effectif_pondere = survey_total(vartype = "ci"),
#             proportion       = survey_mean(vartype = "ci")) |>
#   arrange(desc(proportion))


# ==============================================================================
# BLOC 16 — Tests statistiques
# ==============================================================================

## --- Wilcoxon-Mann-Whitney (2 groupes, variable continue non normale) -------
wx <- wilcox.test(taille_menage ~ milieu, data = menages |> filter(!is.na(milieu)), conf.int = TRUE)
effet <- menages |> filter(!is.na(milieu)) |> rstatix::wilcox_effsize(taille_menage ~ milieu)
cat(sprintf("Wilcoxon W = %.0f, p < 0.001, r = %.3f\n", wx$statistic, effet$effsize))
# Lecture de la taille d'effet (Cohen, 1988) : 0.1 petit, 0.3 moyen, 0.5 grand

## --- Chi-deux de Rao-Scott (test d'association pondéré, plan de sondage) ----
# chi2 <- svychisq(~ quintile_f + a_consulte, design = plan_svy)
# v_cramer <- rstatix::cramer_v(df_clean$a_consulte, as.factor(df_clean$quintile))  # V non pondéré, en complément

## --- Bootstrap (ex : intervalle de confiance robuste sur une médiane) -------
# library(boot)
# boot_median <- boot(data = x, statistic = function(d, i) median(d[i]), R = 1000)
# boot.ci(boot_median, type = "perc")


# ==============================================================================
# BLOC 17 — Graphiques types
# ==============================================================================

## --- 17.1 Histogramme avec ligne de médiane annotée -------------------------
fig01 <- ggplot(df_clean |> filter(!is.na(age)), aes(x = age)) +
  geom_histogram(binwidth = 5, fill = col_bleu, color = "white", alpha = 0.85) +
  geom_vline(xintercept = as.numeric(stats_var$mediane), linetype = "dashed", color = "#374EA2") +
  labs(title = "Distribution de la variable", x = "Valeur", y = "Effectif", caption = source_ghs)
ggsave(here("outputs", "figures", "fig01_histogramme.png"), fig01, width = 8, height = 4.5, dpi = 300)

## --- 17.2 Boxplot vertical avec repères Q1/médiane/Q3/moyenne ---------------
fig02 <- ggplot(df_clean |> filter(!is.na(age)), aes(x = "", y = age)) +
  geom_boxplot(fill = col_bleu, alpha = 0.65, outlier.size = 0.5, outlier.alpha = 0.3, width = 0.5) +
  stat_summary(fun = mean, geom = "point", shape = 18, size = 3, color = "#E8416F") +
  labs(title = "Boite a moustaches", x = NULL, y = "Valeur")
ggsave(here("outputs", "figures", "fig02_boxplot.png"), fig02, width = 5, height = 4.5, dpi = 300)

## --- 17.3 QQ-plot (visualiser l'écart à la normalité) -----------------------
qq_data <- data.frame(theorique = qnorm(ppoints(length(age_vec))), observe = sort(age_vec))
fig_qq <- ggplot(qq_data, aes(x = theorique, y = observe)) +
  geom_point(color = col_bleu, size = 0.4, alpha = 0.4) +
  geom_abline(slope = sd(age_vec), intercept = mean(age_vec), color = "#E8416F", linewidth = 0.9) +
  labs(title = "QQ-plot", x = "Quantiles theoriques", y = "Quantiles observes")

## --- 17.4 Assemblage de plusieurs figures avec patchwork --------------------
fig_combinee <- (fig01 + labs(caption = NULL) | fig02 + labs(caption = NULL) | fig_qq) +
  plot_annotation(title = "Analyse univariee", caption = source_ghs)
ggsave(here("outputs", "figures", "fig_combinee.png"), fig_combinee, width = 14, height = 5.5, dpi = 200)

## --- 17.5 Pyramide des âges par sexe (effectifs pondérés) -------------------
pyramide_data <- df_clean |>
  filter(!is.na(age), !is.na(sexe), !is.na(groupe_age)) |>
  count(groupe_age, sexe, wt = wt_wave4) |>
  mutate(n = if_else(sexe == "Homme", -n, n))

fig_pyramide <- ggplot(pyramide_data, aes(x = groupe_age, y = n, fill = sexe)) +
  geom_bar(stat = "identity", width = 0.85) +
  coord_flip() +
  scale_y_continuous(labels = function(x) format(abs(x) / 1e3, big.mark = " ", suffix = "k")) +
  scale_fill_manual(values = c("Homme" = col_homme, "Femme" = col_femme)) +
  labs(title = "Pyramide des ages par sexe (ponderee)", x = "Groupe d'age",
       y = "Effectif pondere (milliers)", fill = "Sexe", caption = source_ghs)
ggsave(here("outputs", "figures", "fig03_pyramide_ages.png"), fig_pyramide, width = 7, height = 8, dpi = 300)

## --- 17.6 Barres horizontales de proportions pondérées, triées, avec % -----
prop_plot <- df_clean |>
  filter(!is.na(parente)) |>
  count(parente, wt = wt_wave4, name = "n_pond") |>
  mutate(prop = n_pond / sum(n_pond), pct_lbl = paste0(round(prop * 100, 1), "%"))

fig_barres <- ggplot(prop_plot, aes(x = reorder(parente, prop), y = prop)) +
  geom_col(fill = col_bleu, alpha = 0.85, width = 0.65) +
  geom_text(aes(label = pct_lbl), hjust = -0.1, size = 3.2) +
  coord_flip() +
  scale_y_continuous(labels = percent_format(accuracy = 1), expand = expansion(mult = c(0, 0.15))) +
  labs(title = "Repartition (ponderee)", x = NULL, y = "Proportion (%)", caption = source_ghs)
ggsave(here("outputs", "figures", "fig04_barplot.png"), fig_barres, width = 7, height = 4, dpi = 300)

## --- 17.7 Barres avec intervalle de confiance (survey_mean vartype="ci") ----
# taux_groupe <- plan_svy |>
#   filter(!is.na(groupe)) |> group_by(groupe) |>
#   summarise(taux = survey_mean(variable_binaire, vartype = "ci", na.rm = TRUE)) |>
#   mutate(across(c(taux, taux_low, taux_upp), ~ . * 100))
#
# ggplot(taux_groupe, aes(x = groupe, y = taux, fill = groupe)) +
#   geom_col(alpha = 0.85, width = 0.6) +
#   geom_errorbar(aes(ymin = taux_low, ymax = taux_upp), width = 0.15) +
#   geom_text(aes(label = paste0(round(taux, 1), "%")), vjust = -1.5) +
#   labs(title = "Taux par groupe (pondere, IC 95%)", caption = source_ghs)

## --- 17.8 Histogramme en échelle log (variable monétaire très asymétrique) --
# ggplot(df_clean |> filter(depense > 0), aes(x = log10(depense))) +
#   geom_histogram(bins = 40, fill = col_bleu, color = "white") +
#   scale_x_continuous(breaks = 1:5, labels = c("10","100","1 000","10 000","100 000")) +
#   labs(title = "Distribution des depenses (echelle log)", caption = source_ghs)

## --- 17.9 Violin + boxplot combinés (comparaison de distributions) ----------
# ggplot(df_clean, aes(x = milieu, y = log10(depense), fill = milieu)) +
#   geom_violin(alpha = 0.5, trim = TRUE) +
#   geom_boxplot(width = 0.15, alpha = 0.9, outlier.size = 0.5)


# ==============================================================================
# BLOC 18 — Cartographie (sf / rnaturalearth)
# ==============================================================================
# Pour une carte choroplèthe du Nigeria par état ou par zone géopolitique.

# 18.1 Agrégat statistique par état
# stat_etat <- df_clean |>
#   group_by(state_name) |>
#   summarise(n = n(), valeur_mediane = median(valeur, na.rm = TRUE), .groups = "drop")

# 18.2 Fond de carte + harmonisation des noms d'état (attention aux orthographes)
# nigeria_sf <- rnaturalearth::ne_states(country = "Nigeria", returnclass = "sf") |>
#   mutate(state_name = case_when(
#     name == "Federal Capital Territory" ~ "FCT",
#     name == "Nassarawa"                 ~ "Nasarawa",
#     TRUE ~ name
#   ))

# 18.3 Jointure + carte avec étiquettes de centroïdes
# carte_data <- nigeria_sf |> left_join(stat_etat, by = "state_name")
# centroides <- carte_data |> sf::st_centroid() |>
#   mutate(lon = sf::st_coordinates(geometry)[,1], lat = sf::st_coordinates(geometry)[,2])
#
# fig_carte <- ggplot(carte_data) +
#   geom_sf(aes(fill = valeur_mediane), color = "white", linewidth = 0.3) +
#   geom_text(data = centroides |> filter(!is.na(valeur_mediane)),
#             aes(x = lon, y = lat, label = paste0(state_name, "\n", round(valeur_mediane, 2))),
#             size = 3.2, color = "white", check_overlap = TRUE) +
#   labs(title = "Carte par etat", caption = source_ghs)

# 18.4 Agrégation par zone géopolitique (regrouper les états en 6 zones)
# carte_data <- carte_data |>
#   mutate(zone_f = case_when(
#     state_name %in% c("Benue","Kogi","Kwara","Nasarawa","Niger","Plateau","FCT") ~ "North Central",
#     # ... completer les 5 autres zones (North East, North West, South East, South South, South West)
#     TRUE ~ NA_character_
#   ))
# region_sf <- carte_data |> filter(!is.na(zone_f)) |> group_by(zone_f) |>
#   summarise(geometry = sf::st_union(geometry), .groups = "drop") |>
#   left_join(stat_zone, by = "zone_f")


# ==============================================================================
# BLOC 19 — Tableau gtsummary pondéré + mise en forme flextable pour Word
# ==============================================================================

tab_synthese <- plan_svy |>
  srvyr::filter(!is.na(milieu)) |>
  gtsummary::tbl_svysummary(
    by      = milieu,
    include = c(age, sexe, taille_menage),
    label   = list(age ~ "Age (annees)", sexe ~ "Sexe", taille_menage ~ "Taille du menage"),
    statistic = list(
      gtsummary::all_continuous()  ~ "{median} [{p25} ; {p75}]",
      gtsummary::all_categorical() ~ "{n} ({p}%)"
    ),
    digits  = list(gtsummary::all_continuous() ~ 0, gtsummary::all_categorical() ~ 0),
    missing = "no"
  ) |>
  gtsummary::add_overall(last = FALSE) |>
  gtsummary::add_p() |>
  gtsummary::modify_header(label ~ "Variable", gtsummary::all_stat_cols() ~ "**{level}**  \nn = {n}") |>
  gtsummary::modify_caption("Caracteristiques par milieu de residence (ponderees, wt_wave4).")

# Fonction de style flextable réutilisable pour tous les tableaux du rapport Word
# (changer juste les couleurs `couleur_header`/`couleur_claire` selon le thème du TP :
#  bleu institutionnel #1A3C5E pour demographie/education, cyan OMS #00ACC1 pour sante, etc.)
style_ghs <- function(ft, couleur_header = "#1A3C5E", couleur_claire = "#DCE9F5") {
  blanc     <- "#FFFFFF"
  gris_bord <- "#A0A0A0"
  nrow_ft   <- nrow(ft$body$dataset)

  ft |>
    flextable::font(fontname = "Garamond", part = "all") |>
    flextable::fontsize(size = 9, part = "body") |>
    flextable::fontsize(size = 9.5, part = "header") |>
    flextable::bg(bg = couleur_header, part = "header") |>
    flextable::color(color = blanc, part = "header") |>
    flextable::bold(part = "header") |>
    flextable::align(align = "center", part = "header") |>
    flextable::align(j = 1, align = "left", part = "header") |>
    flextable::bg(i = seq(1, nrow_ft, 2), bg = blanc,         part = "body") |>
    flextable::bg(i = seq(2, nrow_ft, 2), bg = couleur_claire, part = "body") |>
    flextable::align(j = 1, align = "left", part = "body") |>
    flextable::bold(j = 1, part = "body") |>
    flextable::border_remove() |>
    flextable::border_outer(part = "all", border = officer::fp_border(color = couleur_header, width = 1.5)) |>
    flextable::border_inner_h(part = "body", border = officer::fp_border(color = gris_bord, width = 0.4)) |>
    flextable::hline(part = "header", border = officer::fp_border(color = blanc, width = 0.6)) |>
    flextable::hline_bottom(part = "header", border = officer::fp_border(color = couleur_header, width = 2)) |>
    flextable::padding(padding.left = 6, padding.right = 6, padding.top = 3, padding.bottom = 3, part = "all")
}

# Export en 3 formats (HTML pour verification visuelle rapide, Word pour le
# rapport, CSV pour reprise dans Excel/autre) :
tab_synthese |> gtsummary::as_gt() |> gt::gtsave(here("outputs", "tables", "tab_synthese.html"))

tab_word <- tab_synthese |> gtsummary::as_flex_table() |> style_ghs()
saveRDS(tab_word, here("data", "processed", "tab_synthese_word.rds"))   # relu dans le rapport.Rmd

tab_synthese |> gtsummary::as_tibble() |> write.csv(here("outputs", "tables", "tab_synthese.csv"), row.names = FALSE)


# ==============================================================================
# BLOC 20 — Rendu du rapport RMarkdown en .docx
# ==============================================================================
# Dernière étape du main.R, après les deux scripts (nettoyage puis analyses).
# Le reference.docx (styles Word) est fourni à part dans modele/reference.docx.

source(here("scripts", "nettoyage.R"), encoding = "UTF-8")
source(here("scripts", "analyses.R"),  encoding = "UTF-8")

rmarkdown::render(
  here("docs", "rapport.Rmd"),
  output_format = "word_document",
  output_file   = here("docs", "rapport.docx")
)

# Variante avec tryCatch pour ne pas planter tout le pipeline si le rendu échoue :
# tryCatch({
#   rmarkdown::render(here("docs","rapport.Rmd"), output_format = "word_document",
#                      output_file = here("docs","rapport.docx"))
# }, error = function(e) cat("Erreur lors du rendu :", conditionMessage(e), "\n"))


# ==============================================================================
# BLOC 21 — Message de fin de pipeline
# ==============================================================================

cat("\nPipeline termine\n")
cat("Les figures sont dans : outputs/figures/\n")
cat("Les tableaux sont dans : outputs/tables/\n")
cat("Le rapport est dans   : docs/rapport.docx\n")

# ==============================================================================
# FIN DU CATALOGUE
# ==============================================================================
