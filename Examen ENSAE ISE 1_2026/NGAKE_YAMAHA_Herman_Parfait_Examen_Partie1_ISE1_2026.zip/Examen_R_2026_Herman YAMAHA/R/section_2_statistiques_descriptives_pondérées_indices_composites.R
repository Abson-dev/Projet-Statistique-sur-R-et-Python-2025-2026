# ======================================================================================
# SECTION 2 : STATISTIQUES DESCRIPTIVES PONDÉRÉES ET INDICES COMPOSITES
# ======================================================================================

# 2.7 Déclarer le plan de sondage complet (grappes, strates, poids finaux) avec srvyr
# --------------------------------------------------------------------------------------

library(srvyr)
library(survey)

# ---- Étape 1 : Vérifier les variables du plan de sondage ----

# Utiliser menages_impute (jeu de données après imputation)
menages <- menages_impute  # Ce recodage est fait juste pour faciliter l'écriture du nom de la base par la suite
                           # vu que nous n'aurons plus besoin de la base "menages" initiale pour la suite. 

cat("=== Variables du plan de sondage ===\n")
cat("- grappe :", ifelse("grappe" %in% names(menages), "Présente", "Manquante"), "\n")
cat("- strate :", ifelse("strate" %in% names(menages), "Présente", "Manquante"), "\n")
cat("- poids_final :", ifelse("poids_final" %in% names(menages), "Présente", "Manquante"), "\n")



# Vérifier les valeurs manquantes dans les variables du plan
cat("\n=== Valeurs manquantes dans les variables du plan ===\n")
cat("grappe :", sum(is.na(menages$grappe)), "\n")
cat("strate :", sum(is.na(menages$strate)), "\n")
cat("poids_final :", sum(is.na(menages$poids_final)), "\n")



# ---- Étape 2 : Déclarer le plan de sondage avec srvyr ----

# Déclarer le plan de sondage
# - ids = grappe (unités primaires de sondage)
# - strata = strate (strate de sondage)
# - weights = poids_final (poids de sondage)

plan_sondage <- menages %>%
  as_survey_design(
    ids = grappe,
    strata = strate,
    weights = poids_final,
    nest = TRUE  # Les strates sont imbriquées dans les grappes
  )

cat("\n=== Plan de sondage déclaré ===\n")
print(plan_sondage)




# ---- Étape 3 : Résumé du plan de sondage ----

cat("\n=== Résumé du plan de sondage ===\n")
cat("Nombre de ménages :", nrow(menages), "\n")
cat("Nombre de grappes :", length(unique(menages$grappe)), "\n")
cat("Nombre de strates :", length(unique(menages$strate)), "\n")
cat("Poids minimum :", round(min(menages$poids_final, na.rm = TRUE), 2), "\n")
cat("Poids maximum :", round(max(menages$poids_final, na.rm = TRUE), 2), "\n")
cat("Poids moyen :", round(mean(menages$poids_final, na.rm = TRUE), 2), "\n")




# ---- Étape 4 : Vérification de la structure des strates ----

cat("\n=== Distribution des ménages par strate ===\n")
strate_summary <- menages %>%
  group_by(strate) %>%
  summarise(
    n_menages = n(),
    n_grappes = n_distinct(grappe),
    poids_total = sum(poids_final, na.rm = TRUE)
  ) %>%
  arrange(desc(n_menages))

print(strate_summary)



# ---- Étape 5 : Calcul des statistiques pondérées de base ----

cat("\n=== Statistiques pondérées de base ===\n")

# Moyenne pondérée du revenu par tête
moyenne_revenu <- plan_sondage %>%
  summarise(
    revenu_moyen = survey_mean(revenu_par_tete, na.rm = TRUE),
    revenu_mediane = survey_median(revenu_par_tete, na.rm = TRUE),
    revenu_sd = survey_sd(revenu_par_tete, na.rm = TRUE)
  )

cat("\nRevenu par tête (pondéré) :\n")
print(moyenne_revenu)




# ---- Étape 6 : Vérification de la pondération ----

cat("\n=== Vérification de la pondération ===\n")

# Comparer les effectifs pondérés vs non pondérés
comparaison_poids <- menages %>%
  summarise(
    n_non_pondere = n(),
    n_pondere = sum(poids_final, na.rm = TRUE),
    ratio = n_pondere / n_non_pondere
  )

cat("Effectif non pondéré :", comparaison_poids$n_non_pondere, "\n")
cat("Effectif pondéré :", round(comparaison_poids$n_pondere, 0), "\n")
cat("Ratio pondéré / non pondéré :", round(comparaison_poids$ratio, 3), "\n")





# ---- Étape 7 : Vérification des strates avec peu de ménages ----

cat("\n=== Strates avec moins de 5 ménages ===\n")
strates_peu <- strate_summary %>%
  filter(n_menages < 5)

if (nrow(strates_peu) > 0) {
  print(strates_peu)
  cat("Attention : Des strates avec peu de ménages peuvent poser problème\n")
  cat("pour l'estimation de la variance.\n")
} else {
  cat("Toutes les strates ont au moins 5 ménages.\n")
}




# ---- Étape 8 : Sauvegarder le plan de sondage ----

saveRDS(plan_sondage, "data/processed/plan_sondage.rds")

cat("\n=== Plan de sondage sauvegardé ===\n")
cat("data/processed/plan_sondage.rds\n")



# ---- Étape 9 : Résumé des options du plan ----

cat("\n=== Options du plan de sondage ===\n")
cat("IDs : grappe\n")
cat("Strates : strate\n")
cat("Poids : poids_final\n")
cat("nest = TRUE (strates imbriquées dans les grappes)\n")
cat("Package : srvyr (interface tidyverse pour survey)\n")




# ---- Étape 10 : Vérification rapide ----

# Tester quelques statistiques pondérées par milieu
cat("\n=== Revenu par tête moyen par milieu (pondéré) ===\n")
revenu_par_milieu <- plan_sondage %>%
  group_by(milieu) %>%
  summarise(
    n = survey_total(),
    revenu_moyen = survey_mean(revenu_par_tete, na.rm = TRUE),
    revenu_mediane = survey_median(revenu_par_tete, na.rm = TRUE)
  )

print(revenu_par_milieu)

# Tester quelques statistiques pondérées par région
cat("\n=== Revenu par tête moyen par région (pondéré) ===\n")
revenu_par_region <- plan_sondage %>%
  group_by(region) %>%
  summarise(
    n = survey_total(),
    revenu_moyen = survey_mean(revenu_par_tete, na.rm = TRUE)
  ) %>%
  arrange(desc(revenu_moyen))

print(revenu_par_region)

cat("\n Plan de sondage prêt pour les analyses descriptives\n")






# 2.8 Construire le score de diversité alimentaire des ménages (HDDS) 
# et la classification FAO associée
# ----------------------------------------------------------------------------

# ---- Étape 1 : Rappel du HDDS déjà calculé ----

# Le HDDS a déjà été calculé dans la question 1.2

# Vérifions qu'il existe bien dans menages_impute

cat("=== Vérification du HDDS ===\n")
cat("Colonne hdds présente :", ifelse("hdds" %in% names(menages_impute), "Oui", "Non"), "\n")
cat("Valeurs manquantes dans hdds :", sum(is.na(menages_impute$hdds)), "\n")
cat("Étendue du HDDS :", range(menages_impute$hdds, na.rm = TRUE), "\n")

# Si hdds n'existe pas, le recalculer
if (!"hdds" %in% names(menages_impute)) {
  cat("\n=== Recalcul du HDDS ===\n")
  menages_impute <- menages_impute %>%
    mutate(
      hdds = rowSums(select(., starts_with("cons_")), na.rm = TRUE)
    )
}

# ---- Étape 2 : Définir les seuils FAO pour la classification ----

# - Sécurité alimentaire : HDDS >= 6 (consomme au moins 6 groupes)
# - Insécurité alimentaire modérée : HDDS entre 4 et 5
# - Insécurité alimentaire sévère : HDDS <= 3

menages_impute <- menages_impute %>%
  mutate(
    # Classification FAO
    securite_alimentaire_fao = case_when(
      hdds >= 6 ~ "Sécurité alimentaire",
      hdds >= 4 & hdds <= 5 ~ "Insécurité modérée",
      hdds <= 3 ~ "Insécurité sévère",
      TRUE ~ NA_character_
    ),
    # Version factor avec ordre logique
    securite_alimentaire_fao = factor(
      securite_alimentaire_fao,
      levels = c("Sécurité alimentaire", "Insécurité modérée", "Insécurité sévère")
    )
  )

cat("\n=== Classification FAO de la sécurité alimentaire ===\n")
print(table(menages_impute$securite_alimentaire_fao, useNA = "ifany"))



# ---- Étape 3 : Statistiques descriptives du HDDS (pondérées) ----

cat("\n=== Statistiques descriptives du HDDS (pondérées) ===\n")

# Utiliser le plan de sondage pour des statistiques pondérées
# Note : survey_min et survey_max n'existent pas dans srvyr
# On utilise survey_mean, survey_median, survey_sd
# Pour le min et max, on les calcule directement sur les données pondérées

hdds_stats <- plan_sondage %>%
  summarise(
    hdds_moyen = survey_mean(hdds, na.rm = TRUE),
    hdds_mediane = survey_median(hdds, na.rm = TRUE, vartype = NULL),
    hdds_sd = survey_sd(hdds, na.rm = TRUE)
  )

print(hdds_stats)

# Min et max (non pondérés ou calculés séparément)
hdds_min_max <- menages_impute %>%
  summarise(
    hdds_min = min(hdds, na.rm = TRUE),
    hdds_max = max(hdds, na.rm = TRUE)
  )

cat("\n=== Min et Max du HDDS ===\n")
print(hdds_min_max)





# ---- Étape 4 : HDDS par région (pondéré) ----

cat("\n=== HDDS moyen par région (pondéré) ===\n")

hdds_par_region <- plan_sondage %>%
  group_by(region) %>%
  summarise(
    hdds_moyen = survey_mean(hdds, na.rm = TRUE),
    hdds_mediane = survey_median(hdds, na.rm = TRUE, vartype = NULL),
    n = survey_total()
  ) %>%
  arrange(desc(hdds_moyen))

print(hdds_par_region)


# ---- Étape 5 : HDDS par milieu (pondéré) ----

cat("\n=== HDDS moyen par milieu (pondéré) ===\n")

hdds_par_milieu <- plan_sondage %>%
  group_by(milieu) %>%
  summarise(
    hdds_moyen = survey_mean(hdds, na.rm = TRUE),
    hdds_mediane = survey_median(hdds, na.rm = TRUE, vartype = NULL),
    n = survey_total()
  )

print(hdds_par_milieu)





# ---- Étape 6 : Classification FAO pondérée ----

# Ajouter la classification FAO au jeu de données

if (!"securite_alimentaire_fao" %in% names(menages_impute)) {
  menages_impute <- menages_impute %>%
    mutate(
      securite_alimentaire_fao = case_when(
        hdds >= 6 ~ "Sécurité alimentaire",
        hdds >= 4 & hdds <= 5 ~ "Insécurité modérée",
        hdds <= 3 ~ "Insécurité sévère",
        TRUE ~ NA_character_
      ),
      securite_alimentaire_fao = factor(
        securite_alimentaire_fao,
        levels = c("Sécurité alimentaire", "Insécurité modérée", "Insécurité sévère")
      )
    )
}



# Re-déclarer le plan de sondage avec la nouvelle variable
plan_sondage <- menages_impute %>%
  as_survey_design(
    ids = grappe,
    strata = strate,
    weights = poids_final,
    nest = TRUE
  )

cat("\n=== Classification FAO pondérée ===\n")

# Version pondérée
fao_ponderee <- plan_sondage %>%
  group_by(securite_alimentaire_fao) %>%
  summarise(
    n = survey_total(),
    proportion = survey_mean()
  ) %>%
  mutate(
    pourcentage = round(proportion * 100, 1)
  )

print(fao_ponderee)



# Version non pondérée (pour comparaison)
fao_non_ponderee <- menages_impute %>%
  group_by(securite_alimentaire_fao) %>%
  summarise(
    n = n(),
    proportion = n() / nrow(menages_impute) * 100
  )

cat("\n=== Classification FAO non pondérée (comparaison) ===\n")
print(fao_non_ponderee)



# ---- Étape 7 : Visualisation du HDDS ----

# 7a. Distribution du HDDS
p_hdds <- plan_sondage %>%
  group_by(hdds) %>%
  summarise(prop = survey_mean()) %>%
  ggplot(aes(x = hdds, y = prop)) +
  geom_col(fill = "#2E86AB", alpha = 0.8) +
  geom_text(aes(label = paste0(round(prop * 100, 1), "%")), 
            vjust = -0.5, size = 3) +
  labs(
    title = "Distribution du Score de Diversité Alimentaire (HDDS)",
    subtitle = "Nombre de groupes alimentaires consommés sur 12",
    x = "HDDS (nombre de groupes alimentaires)",
    y = "Proportion de ménages (%)"
  ) +
  scale_y_continuous(labels = scales::percent) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 11, hjust = 0.5, color = "gray40"),
    axis.text = element_text(size = 9),
    panel.grid.minor = element_blank()
  )

# 7b. Classification FAO par région
p_fao_region <- plan_sondage %>%
  group_by(region, securite_alimentaire_fao) %>%
  summarise(prop = survey_mean()) %>%
  filter(!is.na(securite_alimentaire_fao)) %>%
  ggplot(aes(x = region, y = prop, fill = securite_alimentaire_fao)) +
  geom_col(position = "fill") +
  scale_fill_manual(
    values = c("Sécurité alimentaire" = "#2E86AB", 
               "Insécurité modérée" = "#F18F01", 
               "Insécurité sévère" = "#C73E1D"),
    name = "Classification FAO"
  ) +
  labs(
    title = "Classification FAO par région",
    subtitle = "Proportion de ménages par catégorie de sécurité alimentaire",
    x = "Région",
    y = "Proportion de ménages"
  ) +
  scale_y_continuous(labels = scales::percent) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 11, hjust = 0.5, color = "gray40"),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 7),
    axis.text.y = element_text(size = 9),
    legend.position = "bottom",
    legend.title = element_text(size = 10, face = "bold"),
    panel.grid.minor = element_blank()
  )

# Afficher les graphiques
print(p_hdds)
print(p_fao_region)

# ---- Étape 8 : Tableau de synthèse ----

# Tableau récapitulatif HDDS par catégorie
hdds_summary <- menages_impute %>%
  group_by(securite_alimentaire_fao) %>%
  summarise(
    n = n(),
    hdds_min = min(hdds, na.rm = TRUE),
    hdds_moyen = round(mean(hdds, na.rm = TRUE), 1),
    hdds_max = max(hdds, na.rm = TRUE),
    pourcentage = round(n() / nrow(menages_impute) * 100, 1)
  )

cat("\n=== Synthèse HDDS par catégorie ===\n")
print(hdds_summary)

# ---- Étape 9 : Sauvegarder les résultats ----

# Créer les dossiers s'ils n'existent pas
dir.create("output/figures", recursive = TRUE, showWarnings = FALSE)
dir.create("output/tables", recursive = TRUE, showWarnings = FALSE)

# Sauvegarder les graphiques
ggsave("output/figures/hdds_distribution.png", p_hdds, width = 10, height = 6, dpi = 300)
ggsave("output/figures/hdds_distribution.pdf", p_hdds, width = 10, height = 6)

ggsave("output/figures/fao_classification_region.png", p_fao_region, 
       width = 14, height = 8, dpi = 300)
ggsave("output/figures/fao_classification_region.pdf", p_fao_region, 
       width = 14, height = 8)

# Sauvegarder les données
write_csv(hdds_par_region, "output/tables/hdds_par_region.csv")
write_csv(fao_ponderee, "output/tables/fao_classification_ponderee.csv")
write_csv(hdds_summary, "output/tables/hdds_summary.csv")

# Sauvegarder le jeu de données avec la classification
saveRDS(menages_impute, "data/processed/menages_impute.rds")

cat("\n=== Résultats sauvegardés ===\n")
cat("Graphiques : output/figures/hdds_distribution.png / .pdf\n")
cat("Graphiques : output/figures/fao_classification_region.png / .pdf\n")
cat("Tableaux : output/tables/hdds_par_region.csv\n")
cat("Tableaux : output/tables/fao_classification_ponderee.csv\n")
cat("Tableaux : output/tables/hdds_summary.csv\n")
cat("Données mises à jour : data/processed/menages_impute.rds\n")







# 2.9 Construire un indice composite de vulnérabilité aux chocs
# ----------------------------------------------------------------------------


# ---- Étape 1 : Comprendre les données de chocs et stratégies ----

cat("=== Aperçu des chocs et stratégies ===\n")


# Vérifier les colonnes de chocs
chocs_vars <- c("choc_secheresse", "choc_hausse_prix", "choc_conflit", "choc_maladie")
cat("Chocs disponibles :\n")
print(chocs_vars)

# Vérifier les colonnes de stratégies
strategies_vars <- c("strat_vente_actifs", "strat_reduction_repas", 
                     "strat_migration", "strat_endettement")
cat("\nStratégies disponibles :\n")
print(strategies_vars)



# Statistiques descriptives des chocs

cat("\n=== Prévalence des chocs (% de ménages touchés) ===\n")
chocs_prevalence <- menages_impute %>%
  summarise(across(all_of(chocs_vars), ~ mean(., na.rm = TRUE) * 100)) %>%
  pivot_longer(everything(), names_to = "choc", values_to = "pourcentage") %>%
  arrange(desc(pourcentage))

print(chocs_prevalence)


# Statistiques descriptives des stratégies

cat("\n=== Prévalence des stratégies d'adaptation (% de ménages) ===\n")
strategies_prevalence <- menages_impute %>%
  summarise(across(all_of(strategies_vars), ~ mean(., na.rm = TRUE) * 100)) %>%
  pivot_longer(everything(), names_to = "strategie", values_to = "pourcentage") %>%
  arrange(desc(pourcentage))

print(strategies_prevalence)




# ---- Étape 2 : Justification de la construction de l'indice ----

cat("\n=== Justification de l'indice composite de vulnérabilité ===\n")
cat("\nL'indice composite de vulnérabilité combine :\n")
cat("1. Le nombre de chocs subis (score de chocs)\n")
cat("   - Plus un ménage subit de chocs, plus il est vulnérable\n")
cat("   - Pondération : chaque chocs a le même poids (1 point)\n")
cat("   - Score de chocs = somme des 4 chocs (0 à 4)\n")
cat("\n2. L'intensité des stratégies d'adaptation (score d'adaptation)\n")
cat("   - L'utilisation de stratégies d'adaptation indique une vulnérabilité\n")
cat("   - Plus un ménage mobilise de stratégies, plus il est vulnérable\n")
cat("   - Pondération : chaque stratégie a le même poids (1 point)\n")
cat("   - Score d'adaptation = somme des 4 stratégies (0 à 4)\n")
cat("\n3. Indice composite = (Score_chocs + Score_adaptation) / 2\n")
cat("   - Normalisé entre 0 et 4\n")
cat("   - Plus l'indice est élevé, plus le ménage est vulnérable\n")



# ---- Étape 3 : Calculer les scores individuels ----

menages_impute <- menages_impute %>%
  mutate(
    # Score de chocs (nombre de chocs subis)
    score_chocs = rowSums(select(., all_of(chocs_vars)), na.rm = TRUE),
    
    # Score d'adaptation (nombre de stratégies mobilisées)
    score_adaptation = rowSums(select(., all_of(strategies_vars)), na.rm = TRUE),
    
    # Indice composite de vulnérabilité (moyenne des deux scores)
    indice_vulnerabilite = (score_chocs + score_adaptation) / 2
  )

# Vérifier les nouvelles colonnes
cat("\n=== Résumé des scores ===\n")
summary(menages_impute[, c("score_chocs", "score_adaptation", "indice_vulnerabilite")])

# ---- Étape 4 : Définir les seuils de vulnérabilité ----

cat("\n=== Définition des seuils de vulnérabilité ===\n")
cat("Basé sur la distribution de l'indice :\n")
cat("- Faible vulnérabilité : indice < 1 (peu ou pas de chocs/adaptation)\n")
cat("- Vulnérabilité modérée : indice entre 1 et 2\n")
cat("- Vulnérabilité élevée : indice entre 2 et 3\n")
cat("- Vulnérabilité très élevée : indice >= 3\n")

menages_impute <- menages_impute %>%
  mutate(
    categorie_vulnerabilite = case_when(
      indice_vulnerabilite < 1 ~ "Faible",
      indice_vulnerabilite >= 1 & indice_vulnerabilite < 2 ~ "Modérée",
      indice_vulnerabilite >= 2 & indice_vulnerabilite < 3 ~ "Élevée",
      indice_vulnerabilite >= 3 ~ "Très élevée",
      TRUE ~ NA_character_
    ),
    categorie_vulnerabilite = factor(
      categorie_vulnerabilite,
      levels = c("Faible", "Modérée", "Élevée", "Très élevée")
    )
  )

cat("\n=== Distribution des catégories de vulnérabilité ===\n")
print(table(menages_impute$categorie_vulnerabilite, useNA = "ifany"))




# ---- Étape 5 : Statistiques pondérées de l'indice ----

# Recalculer l'indice directement dans le plan de sondage
# ou s'assurer qu'il existe dans menages_impute

cat("\n=== Vérification de l'existence de l'indice ===\n")
cat("indice_vulnerabilite dans menages_impute :", 
    ifelse("indice_vulnerabilite" %in% names(menages_impute), "✓ Oui", "✗ Non"), "\n")
cat("score_chocs dans menages_impute :", 
    ifelse("score_chocs" %in% names(menages_impute), "✓ Oui", "✗ Non"), "\n")
cat("score_adaptation dans menages_impute :", 
    ifelse("score_adaptation" %in% names(menages_impute), "✓ Oui", "✗ Non"), "\n")

# Si l'indice n'existe pas, le recalculer
if (!"indice_vulnerabilite" %in% names(menages_impute)) {
  cat("\n=== Recalcul de l'indice de vulnérabilité ===\n")
  
  chocs_vars <- c("choc_secheresse", "choc_hausse_prix", "choc_conflit", "choc_maladie")
  strategies_vars <- c("strat_vente_actifs", "strat_reduction_repas", 
                       "strat_migration", "strat_endettement")
  
  menages_impute <- menages_impute %>%
    mutate(
      score_chocs = rowSums(select(., all_of(chocs_vars)), na.rm = TRUE),
      score_adaptation = rowSums(select(., all_of(strategies_vars)), na.rm = TRUE),
      indice_vulnerabilite = (score_chocs + score_adaptation) / 2
    )
}

# Re-déclarer le plan de sondage avec les nouvelles variables
plan_sondage <- menages_impute %>%
  as_survey_design(
    ids = grappe,
    strata = strate,
    weights = poids_final,
    nest = TRUE
  )

cat("\n=== Statistiques pondérées de l'indice de vulnérabilité ===\n")

indice_stats <- plan_sondage %>%
  summarise(
    indice_moyen = survey_mean(indice_vulnerabilite, na.rm = TRUE),
    indice_mediane = survey_median(indice_vulnerabilite, na.rm = TRUE, vartype = NULL),
    indice_sd = survey_sd(indice_vulnerabilite, na.rm = TRUE)
  )

print(indice_stats)



# ---- Étape 6 : Indice de vulnérabilité par région ----

cat("\n=== Indice de vulnérabilité moyen par région (pondéré) ===\n")

indice_par_region <- plan_sondage %>%
  group_by(region) %>%
  summarise(
    indice_moyen = survey_mean(indice_vulnerabilite, na.rm = TRUE),
    score_chocs_moyen = survey_mean(score_chocs, na.rm = TRUE),
    score_adaptation_moyen = survey_mean(score_adaptation, na.rm = TRUE),
    n = survey_total()
  ) %>%
  arrange(desc(indice_moyen))

print(indice_par_region)




# ---- Étape 7 : Catégories de vulnérabilité par région ----

# S'assurer que la catégorie existe
if (!"categorie_vulnerabilite" %in% names(menages_impute)) {
  menages_impute <- menages_impute %>%
    mutate(
      categorie_vulnerabilite = case_when(
        indice_vulnerabilite < 1 ~ "Faible",
        indice_vulnerabilite >= 1 & indice_vulnerabilite < 2 ~ "Modérée",
        indice_vulnerabilite >= 2 & indice_vulnerabilite < 3 ~ "Élevée",
        indice_vulnerabilite >= 3 ~ "Très élevée",
        TRUE ~ NA_character_
      ),
      categorie_vulnerabilite = factor(
        categorie_vulnerabilite,
        levels = c("Faible", "Modérée", "Élevée", "Très élevée")
      )
    )
}

# Re-déclarer le plan avec la catégorie
plan_sondage <- menages_impute %>%
  as_survey_design(
    ids = grappe,
    strata = strate,
    weights = poids_final,
    nest = TRUE
  )

cat("\n=== Catégories de vulnérabilité par région (pondéré) ===\n")

vuln_par_region <- plan_sondage %>%
  group_by(region, categorie_vulnerabilite) %>%
  summarise(prop = survey_mean()) %>%
  filter(!is.na(categorie_vulnerabilite))

print(vuln_par_region)




# ---- Étape 8 : Visualisations ----

# 8a. Distribution de l'indice de vulnérabilité
p_vuln_dist <- plan_sondage %>%
  group_by(indice_vulnerabilite = round(indice_vulnerabilite, 1)) %>%
  summarise(prop = survey_mean()) %>%
  ggplot(aes(x = indice_vulnerabilite, y = prop)) +
  geom_col(fill = "#C73E1D", alpha = 0.8) +
  geom_text(aes(label = paste0(round(prop * 100, 1), "%")), 
            vjust = -0.5, size = 3) +
  labs(
    title = "Distribution de l'indice composite de vulnérabilité",
    subtitle = "Plus l'indice est élevé, plus le ménage est vulnérable",
    x = "Indice de vulnérabilité",
    y = "Proportion de ménages (%)"
  ) +
  scale_y_continuous(labels = scales::percent) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 11, hjust = 0.5, color = "gray40"),
    axis.text = element_text(size = 9),
    panel.grid.minor = element_blank()
  )

# 8b. Catégories de vulnérabilité
p_vuln_cat <- plan_sondage %>%
  group_by(categorie_vulnerabilite) %>%
  summarise(prop = survey_mean()) %>%
  filter(!is.na(categorie_vulnerabilite)) %>%
  ggplot(aes(x = categorie_vulnerabilite, y = prop, fill = categorie_vulnerabilite)) +
  geom_col() +
  geom_text(aes(label = paste0(round(prop * 100, 1), "%")), 
            vjust = -0.5, size = 4) +
  scale_fill_manual(
    values = c("Faible" = "#2E86AB", 
               "Modérée" = "#F18F01", 
               "Élevée" = "#C73E1D",
               "Très élevée" = "#8B0000"),
    guide = "none"
  ) +
  labs(
    title = "Catégories de vulnérabilité des ménages",
    subtitle = "Classification basée sur l'indice composite",
    x = "Catégorie de vulnérabilité",
    y = "Proportion de ménages (%)"
  ) +
  scale_y_continuous(labels = scales::percent) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 11, hjust = 0.5, color = "gray40"),
    axis.text = element_text(size = 9),
    panel.grid.minor = element_blank()
  )

# 8c. Indice de vulnérabilité par région
p_vuln_region <- indice_par_region %>%
  mutate(region = fct_reorder(region, indice_moyen)) %>%
  ggplot(aes(x = indice_moyen, y = region, fill = indice_moyen)) +
  geom_col() +
  geom_errorbar(aes(xmin = indice_moyen - indice_moyen_se, 
                    xmax = indice_moyen + indice_moyen_se),
                width = 0.2) +
  scale_fill_gradient(low = "#2E86AB", high = "#C73E1D", guide = "none") +
  labs(
    title = "Indice de vulnérabilité moyen par région",
    subtitle = "Avec intervalles de confiance à 95%",
    x = "Indice de vulnérabilité moyen",
    y = "Région"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 11, hjust = 0.5, color = "gray40"),
    axis.text = element_text(size = 9),
    panel.grid.minor = element_blank()
  )

# Afficher les graphiques
print(p_vuln_dist)
print(p_vuln_cat)
print(p_vuln_region)

# ---- Étape 9 : Sauvegarder ----

# Créer les dossiers s'ils n'existent pas
dir.create("output/figures", recursive = TRUE, showWarnings = FALSE)
dir.create("output/tables", recursive = TRUE, showWarnings = FALSE)

# Sauvegarder les graphiques
ggsave("output/figures/vuln_distribution.png", p_vuln_dist, width = 10, height = 6, dpi = 300)
ggsave("output/figures/vuln_distribution.pdf", p_vuln_dist, width = 10, height = 6)

ggsave("output/figures/vuln_categories.png", p_vuln_cat, width = 10, height = 6, dpi = 300)
ggsave("output/figures/vuln_categories.pdf", p_vuln_cat, width = 10, height = 6)

ggsave("output/figures/vuln_by_region.png", p_vuln_region, width = 12, height = 8, dpi = 300)
ggsave("output/figures/vuln_by_region.pdf", p_vuln_region, width = 12, height = 8)

# Sauvegarder les données
write_csv(indice_par_region, "output/tables/indice_vulnerabilite_par_region.csv")
write_csv(vuln_par_region, "output/tables/categories_vulnerabilite_par_region.csv")

# Sauvegarder le jeu de données avec l'indice
saveRDS(menages_impute, "data/processed/menages_impute.rds")

cat("\n=== Indice de vulnérabilité construit ===\n")
cat(" 3 nouvelles colonnes ajoutées :\n")
cat("  - score_chocs : nombre de chocs subis (0-4)\n")
cat("  - score_adaptation : nombre de stratégies mobilisées (0-4)\n")
cat("  - indice_vulnerabilite : indice composite (0-4)\n")
cat("  - categorie_vulnerabilite : Faible/Modérée/Élevée/Très élevée\n")
cat("\n Résultats sauvegardés :\n")
cat("  - Graphiques : output/figures/vuln_*.png / .pdf\n")
cat("  - Tableaux : output/tables/indice_vulnerabilite_par_region.csv\n")
cat("  - Données : data/processed/menages_impute.rds\n")






# 2.10  Produire un tableau descriptif pondéré de type Tableau 1 avec gtsummary, comparant les indicateurs clés par 
# milieu et par région, avec test de comparaison et colonne d’effectifs. 
# -----------------------------------------------------------------------------------------------------------------

library(gtsummary)
library(gt)

# ---- Étape 1 : Préparer les données pour le tableau ----

# Sélectionner les variables à inclure dans le tableau
# Variables sociodémographiques
# Variables économiques
# Variables de chocs et vulnérabilité

tableau_vars <- menages_impute %>%
  select(
    # Variables d'identification
    region,
    milieu,
    
    # Caractéristiques du ménage
    taille_menage,
    revenu_par_tete,
    quintile_revenu,
    
    # Caractéristiques du chef
    age_chef,
    age_chef_cat,
    sexe_chef,
    educ_chef,
    
    # Sécurité alimentaire
    hdds,
    securite_alimentaire_fao,
    
    # Chocs et vulnérabilité
    score_chocs,
    score_adaptation,
    indice_vulnerabilite,
    categorie_vulnerabilite,
    
    # Poids pour les statistiques pondérées
    poids_final
  )



# ---- Étape 2 : Créer le tableau pondéré ----

# Note : gtsummary ne supporte pas nativement les poids de sondage
# On va donc créer un tableau avec des statistiques pondérées manuellement
# en utilisant les fonctions de survey

cat("\n=== Création du Tableau 1 pondéré ===\n")

# 2a. Variables catégorielles (pourcentages pondérés)
vars_categorielles <- c("region", "milieu", "quintile_revenu", 
                        "age_chef_cat", "sexe_chef", "educ_chef",
                        "securite_alimentaire_fao", "categorie_vulnerabilite")

# 2b. Variables continues (moyennes pondérées)
vars_continues <- c("taille_menage", "revenu_par_tete", "age_chef", 
                    "hdds", "score_chocs", "score_adaptation", "indice_vulnerabilite")




# ---- Étape 3 : Fonction pour calculer les statistiques pondérées ----

# Fonction pour calculer les proportions pondérées d'une variable catégorielle
calculer_prop_ponderee <- function(data, var, group = NULL) {
  if (!is.null(group)) {
    result <- data %>%
      group_by(!!sym(group), !!sym(var)) %>%
      summarise(
        n = survey_total(),
        prop = survey_mean(),
        .groups = "drop"
      ) %>%
      mutate(
        label = paste0(round(prop * 100, 1), "%"),
        n_label = paste0("(", round(n), ")")
      )
  } else {
    result <- data %>%
      group_by(!!sym(var)) %>%
      summarise(
        n = survey_total(),
        prop = survey_mean(),
        .groups = "drop"
      ) %>%
      mutate(
        label = paste0(round(prop * 100, 1), "%"),
        n_label = paste0("(", round(n), ")")
      )
  }
  return(result)
}

# Fonction pour calculer les moyennes pondérées d'une variable continue
calculer_moyenne_ponderee <- function(data, var, group = NULL) {
  if (!is.null(group)) {
    result <- data %>%
      group_by(!!sym(group)) %>%
      summarise(
        moyenne = survey_mean(!!sym(var), na.rm = TRUE),
        sd = survey_sd(!!sym(var), na.rm = TRUE),
        mediane = survey_median(!!sym(var), na.rm = TRUE, vartype = NULL),
        .groups = "drop"
      ) %>%
      mutate(
        label = paste0(round(moyenne, 1), " (", round(sd, 1), ")"),
        mediane_label = paste0("Médiane: ", round(mediane, 1))
      )
  } else {
    result <- data %>%
      summarise(
        moyenne = survey_mean(!!sym(var), na.rm = TRUE),
        sd = survey_sd(!!sym(var), na.rm = TRUE),
        mediane = survey_median(!!sym(var), na.rm = TRUE, vartype = NULL)
      ) %>%
      mutate(
        label = paste0(round(moyenne, 1), " (", round(sd, 1), ")"),
        mediane_label = paste0("Médiane: ", round(mediane, 1))
      )
  }
  return(result)
}





# ---- Étape 4 : Calculer les statistiques pondérées ----

# 4a. Variables catégorielles (proportions pondérées)
cat("\n=== Statistiques pondérées des variables catégorielles ===\n")

# Région
region_stats <- calculer_prop_ponderee(plan_sondage, "region")
print(region_stats)

# Milieu
milieu_stats <- calculer_prop_ponderee(plan_sondage, "milieu")
print(milieu_stats)

# Quintile de revenu
quintile_stats <- calculer_prop_ponderee(plan_sondage, "quintile_revenu")
print(quintile_stats)

# Âge du chef
age_chef_stats <- calculer_prop_ponderee(plan_sondage, "age_chef_cat")
print(age_chef_stats)

# Sexe du chef
sexe_chef_stats <- calculer_prop_ponderee(plan_sondage, "sexe_chef")
print(sexe_chef_stats)

# Éducation du chef
educ_chef_stats <- calculer_prop_ponderee(plan_sondage, "educ_chef")
print(educ_chef_stats)

# Sécurité alimentaire FAO
fao_stats <- calculer_prop_ponderee(plan_sondage, "securite_alimentaire_fao")
print(fao_stats)

# Catégorie de vulnérabilité
vuln_stats <- calculer_prop_ponderee(plan_sondage, "categorie_vulnerabilite")
print(vuln_stats)

# 4b. Variables continues (moyennes pondérées)
cat("\n=== Statistiques pondérées des variables continues ===\n")

# Taille du ménage
taille_stats <- calculer_moyenne_ponderee(plan_sondage, "taille_menage")
print(taille_stats)

# Revenu par tête
revenu_stats <- calculer_moyenne_ponderee(plan_sondage, "revenu_par_tete")
print(revenu_stats)

# Âge du chef
age_chef_moy <- calculer_moyenne_ponderee(plan_sondage, "age_chef")
print(age_chef_moy)

# HDDS
hdds_moy <- calculer_moyenne_ponderee(plan_sondage, "hdds")
print(hdds_moy)

# Score de chocs
chocs_moy <- calculer_moyenne_ponderee(plan_sondage, "score_chocs")
print(chocs_moy)

# Score d'adaptation
adapt_moy <- calculer_moyenne_ponderee(plan_sondage, "score_adaptation")
print(adapt_moy)

# Indice de vulnérabilité
vuln_moy <- calculer_moyenne_ponderee(plan_sondage, "indice_vulnerabilite")
print(vuln_moy)


# ---- Étape 5 : Construire le Tableau 1 pondéré avec survey ----

cat("\n=== Construction du Tableau 1 pondéré ===\n")

library(survey)
library(srvyr)

# 5a. Fonction pour calculer les statistiques pondérées par groupe
tableau_pondere <- function(data, by_var) {
  
  # Initialiser une liste pour stocker les résultats
  resultats <- list()
  
  # ---- Variables continues ----
  vars_continues <- c("taille_menage", "revenu_par_tete", "age_chef", 
                      "hdds", "score_chocs", "score_adaptation", "indice_vulnerabilite")
  
  # Calculer les moyennes pondérées par groupe
  cont_results <- data %>%
    group_by(!!sym(by_var)) %>%
    summarise(
      across(all_of(vars_continues), 
             list(
               mean = ~ survey_mean(., na.rm = TRUE),
               sd = ~ survey_sd(., na.rm = TRUE),
               median = ~ survey_median(., na.rm = TRUE, vartype = NULL)
             ))
    ) %>%
    pivot_longer(
      cols = -!!sym(by_var),
      names_to = c("variable", "stat"),
      names_sep = "_"
    ) %>%
    pivot_wider(
      names_from = c(!!sym(by_var), stat),
      values_from = value
    )
  
  # ---- Variables catégorielles ----
  vars_cat <- c("region", "quintile_revenu", "age_chef_cat", 
                "sexe_chef", "educ_chef", "securite_alimentaire_fao", 
                "categorie_vulnerabilite")
  
  # Calculer les proportions pondérées par groupe
  cat_results <- map_df(vars_cat, function(var) {
    data %>%
      group_by(!!sym(by_var), !!sym(var)) %>%
      summarise(
        n = survey_total(),
        prop = survey_mean(),
        .groups = "drop"
      ) %>%
      mutate(
        variable = var,
        label = paste0(round(prop * 100, 1), "%"),
        n_label = paste0("(", round(n), ")")
      )
  })
  
  return(list(continues = cont_results, categorielles = cat_results))
}

# 5b. Appliquer la fonction pour obtenir le tableau pondéré
tableau_pondere_result <- tableau_pondere(plan_sondage, "milieu")

# 5c. Afficher les résultats pondérés
cat("\n=== Variables continues pondérées ===\n")
print(tableau_pondere_result$continues)

cat("\n=== Variables catégorielles pondérées ===\n")
print(tableau_pondere_result$categorielles)










# ---- Étape 6 : Créer un tableau formaté avec gt ----

# 6a. Extraire les valeurs des listes
cont_table <- tableau_pondere_result$continues

# Créer les colonnes une par une avec sapply
cont_table$Urbain_mean_val <- sapply(cont_table$Urbain_mean, function(x) {
  if (is.null(x)) NA else as.numeric(x[1])
})

cont_table$Urbain_sd_val <- sapply(cont_table$Urbain_sd, function(x) {
  if (is.null(x)) NA else as.numeric(x[1])
})

cont_table$Rural_mean_val <- sapply(cont_table$Rural_mean, function(x) {
  if (is.null(x)) NA else as.numeric(x[1])
})

cont_table$Rural_sd_val <- sapply(cont_table$Rural_sd, function(x) {
  if (is.null(x)) NA else as.numeric(x[1])
})

# Créer les labels
cont_table$label <- case_when(
  cont_table$variable == "taille" ~ "Taille du ménage",
  cont_table$variable == "revenu" ~ "Revenu par tête (FCFA)",
  cont_table$variable == "age" ~ "Âge du chef (ans)",
  cont_table$variable == "hdds" ~ "Score de diversité alimentaire (HDDS)",
  cont_table$variable == "score" ~ "Nombre de chocs subis",
  cont_table$variable == "indice" ~ "Indice de vulnérabilité",
  TRUE ~ cont_table$variable
)

# Formater
cont_table$Urbain <- ifelse(
  is.na(cont_table$Urbain_mean_val), 
  "-", 
  paste0(round(cont_table$Urbain_mean_val, 1), " (", round(cont_table$Urbain_sd_val, 1), ")")
)

cont_table$Rural <- ifelse(
  is.na(cont_table$Rural_mean_val), 
  "-", 
  paste0(round(cont_table$Rural_mean_val, 1), " (", round(cont_table$Rural_sd_val, 1), ")")
)

# Sélectionner les colonnes finales
cont_table_final <- cont_table %>%
  select(label, Urbain, Rural)

# 6b. Afficher le tableau préparé
cat("\n=== Tableau des variables continues ===\n")
print(cont_table_final)




# ---- Étape 7 : Traiter les variables catégorielles ----


# Vérifier si les données catégorielles existent
if (exists("tableau_pondere_result$categorielles") && 
    nrow(tableau_pondere_result$categorielles) > 0) {
  
  # Filtrer d'abord pour réduire le dataset
  vars_cat_interet <- c("region", "quintile_revenu", "securite_alimentaire_fao", 
                        "categorie_vulnerabilite", "educ_chef", "sexe_chef")
  
  cat_table <- tableau_pondere_result$categorielles %>%
    filter(variable %in% vars_cat_interet) %>%
    mutate(
      label = case_when(
        variable == "region" ~ paste0("Région: ", region),
        variable == "quintile_revenu" ~ paste0("Quintile: ", quintile_revenu),
        variable == "securite_alimentaire_fao" ~ paste0("Sécurité alimentaire: ", securite_alimentaire_fao),
        variable == "categorie_vulnerabilite" ~ paste0("Vulnérabilité: ", categorie_vulnerabilite),
        variable == "educ_chef" ~ paste0("Éducation: ", educ_chef),
        variable == "sexe_chef" ~ paste0("Sexe: ", ifelse(sexe_chef == 1, "Homme", "Femme")),
        TRUE ~ paste0(variable, ": ", get(variable))
      ),
      Urbain = paste0(round(prop * 100, 1), "% (", round(n), ")"),
      Rural = paste0(round(prop * 100, 1), "% (", round(n), ")")
    ) %>%
    select(label, Urbain, Rural)
  
  cat("\n=== Tableau des variables catégorielles ===\n")
  print(cat_table)
  
} else {
  cat("\n=== Aucune donnée catégorielle disponible ===\n")
  cat_table <- NULL
}
  
  



# ---- Étape 8 : Fusionner les deux tableaux ----

# Vérifier si cat_table existe et n'est pas NULL
if (exists("cat_table") && !is.null(cat_table) && nrow(cat_table) > 0) {
  
  # Combiner variables continues et catégorielles
  tableau_complet <- bind_rows(
    cont_table_final %>% mutate(type = "Continues"),
    cat_table %>% mutate(type = "Catégorielles")
  ) %>%
    select(-type)
  
  cat("\n=== Tableau complet créé avec succès ===\n")
  
} else {
  
  # Si pas de données catégorielles, garder seulement les continues
  cat("\n=== Aucune donnée catégorielle disponible, utilisation des continues uniquement ===\n")
  tableau_complet <- cont_table_final %>%
    mutate(type = "Continues") %>%
    select(-type)
  
}

# ---- Étape 9 : Créer le tableau avec gt ----

library(gt)

tableau_complet_gt <- tableau_complet %>%
  gt() %>%
  tab_header(
    title = "Tableau 1 - Caractéristiques des ménages (PONDÉRÉ)",
    subtitle = "Comparaison Urbain vs Rural avec poids de sondage"
  ) %>%
  cols_label(
    label = "Variable",
    Urbain = "Urbain",
    Rural = "Rural"
  ) %>%
  tab_footnote(
    footnote = "Moyenne (Écart-type) pondérés utilisant les poids de sondage",
    locations = cells_column_labels(columns = c(Urbain, Rural))
  ) %>%
  tab_style(
    style = list(
      cell_text(weight = "bold")
    ),
    locations = cells_column_labels(everything())
  ) %>%
  tab_style(
    style = list(
      cell_text(align = "left")
    ),
    locations = cells_body(columns = label)
  ) %>%
  cols_align(
    align = "center",
    columns = c(Urbain, Rural)
  )

# Afficher le tableau
tableau_complet_gt

# ---- Étape 10 : Sauvegarder ----

# Créer le dossier s'il n'existe pas
dir.create("output/tables", recursive = TRUE, showWarnings = FALSE)

# Sauvegarder le tableau complet
tableau_complet_gt %>%
  gtsave("output/tables/tableau1_pondere_complet.html")

# Sauvegarder en CSV
write_csv(tableau_complet, "output/tables/tableau1_pondere_complet.csv")

cat("\n Tableau pondéré sauvegardé :\n")
cat("  - output/tables/tableau1_pondere_complet.html\n")
cat("  - output/tables/tableau1_pondere_complet.csv\n")












# 2.11 Calculer le coefficient de Gini du revenu par tête
# ----------------------------------------------------------------------------

library(DescTools)
library(boot)
library(tidyverse)

# ---- Étape 1 : Vérifier la variable revenu_par_tete ----

cat("=== Vérification de la variable revenu_par_tete ===\n")
cat("Valeurs manquantes :", sum(is.na(menages_impute$revenu_par_tete)), "\n")
cat("Résumé :\n")
print(summary(menages_impute$revenu_par_tete))

# ---- Étape 2 : Fonction pour calculer le Gini avec prise en compte des poids ----

# Fonction pour calculer le Gini pondéré
gini_pondere <- function(x, poids) {
  # Supprimer les NA
  valid <- !is.na(x) & !is.na(poids)
  x <- x[valid]
  poids <- poids[valid]
  
  # Calcul du Gini pondéré avec DescTools
  resultat <- Gini(x, weights = poids, na.rm = TRUE)
  return(resultat)
}

# ---- Étape 3 : Bootstrap pour le Gini national ----

cat("\n=== Calcul du Gini national avec bootstrap ===\n")

# Nombre de réplications bootstrap
n_boot <- 1000
set.seed(123)

# Fonction pour le bootstrap
boot_gini_national <- function(data, indices) {
  # Échantillon bootstrap
  boot_data <- data[indices, ]
  
  # Calcul du Gini sur l'échantillon bootstrap
  gini_val <- gini_pondere(boot_data$revenu_par_tete, boot_data$poids_final)
  return(gini_val)
}

# Préparer les données
data_boot <- menages_impute %>%
  select(revenu_par_tete, poids_final) %>%
  filter(!is.na(revenu_par_tete))

# Exécuter le bootstrap
boot_result <- boot(data_boot, boot_gini_national, R = n_boot)

# Résultats
gini_national <- boot_result$t0
gini_ic <- boot.ci(boot_result, type = c("perc", "bca"))

cat("\n=== Coefficient de Gini national ===\n")
cat("Gini :", round(gini_national, 3), "\n")
cat("IC 95% (percentile) : [", round(gini_ic$percent[4], 3), ", ", round(gini_ic$percent[5], 3), "]\n")
cat("IC 95% (BCA) : [", round(gini_ic$bca[4], 3), ", ", round(gini_ic$bca[5], 3), "]\n")

# ---- Étape 4 : Bootstrap pour le Gini par région ----

cat("\n=== Calcul du Gini par région avec bootstrap ===\n")

# Liste des régions
regions <- unique(menages_impute$region)
regions <- regions[!is.na(regions)]

# Fonction pour calculer le Gini par région sur un échantillon bootstrap
boot_gini_region <- function(data, indices, region_specifique) {
  # Échantillon bootstrap
  boot_data <- data[indices, ]
  
  # Filtrer par région
  boot_data_region <- boot_data %>% filter(region == region_specifique)
  
  # Si pas de données, retourner NA
  if (nrow(boot_data_region) == 0) return(NA)
  
  # Calcul du Gini sur l'échantillon bootstrap
  gini_val <- gini_pondere(boot_data_region$revenu_par_tete, boot_data_region$poids_final)
  return(gini_val)
}

# Initialiser un dataframe pour stocker les résultats
gini_region_results <- data.frame(
  region = character(),
  gini = numeric(),
  ic_inf = numeric(),
  ic_sup = numeric(),
  n_menages = integer(),
  stringsAsFactors = FALSE
)

# Boucle sur chaque région
for (reg in regions) {
  cat("Traitement de la région :", reg, "\n")
  
  # Préparer les données pour la région
  data_region <- menages_impute %>%
    filter(region == reg) %>%
    select(revenu_par_tete, poids_final) %>%
    filter(!is.na(revenu_par_tete))
  
  # Vérifier qu'il y a assez de données
  if (nrow(data_region) < 10) {
    cat("  -> Pas assez de données pour", reg, "(n =", nrow(data_region), ")\n")
    next
  }
  
  # Bootstrap
  boot_region <- boot(data_region, function(data, indices) {
    boot_data <- data[indices, ]
    gini_pondere(boot_data$revenu_par_tete, boot_data$poids_final)
  }, R = n_boot)
  
  # Résultats
  gini_val <- boot_region$t0
  ic <- tryCatch({
    boot.ci(boot_region, type = "perc")
  }, error = function(e) {
    return(NULL)
  })
  
  # Extraire les intervalles de confiance
  if (!is.null(ic)) {
    ic_inf <- ic$percent[4]
    ic_sup <- ic$percent[5]
  } else {
    ic_inf <- NA
    ic_sup <- NA
  }
  
  # Ajouter aux résultats
  gini_region_results <- rbind(gini_region_results, data.frame(
    region = reg,
    gini = gini_val,
    ic_inf = ic_inf,
    ic_sup = ic_sup,
    n_menages = nrow(data_region)
  ))
}

# ---- Étape 5 : Afficher les résultats par région ----

cat("\n=== Coefficient de Gini par région ===\n")
gini_region_results <- gini_region_results %>%
  arrange(desc(gini))

print(gini_region_results)

# ---- Étape 6 : Visualisation ----

# 6a. Graphique des Gini par région
p_gini_region <- gini_region_results %>%
  mutate(region = fct_reorder(region, gini)) %>%
  ggplot(aes(x = gini, y = region)) +
  geom_point(size = 3, color = "#2E86AB") +
  geom_errorbarh(aes(xmin = ic_inf, xmax = ic_sup), 
                 height = 0.2, color = "#2E86AB", alpha = 0.7) +
  geom_vline(xintercept = gini_national, linetype = "dashed", 
             color = "#C73E1D", size = 1) +
  annotate("text", x = gini_national + 0.01, y = 1, 
           label = paste("National:", round(gini_national, 3)),
           color = "#C73E1D", hjust = 0, size = 3.5) +
  labs(
    title = "Coefficient de Gini du revenu par tête par région",
    subtitle = paste("Avec intervalles de confiance à 95% (bootstrap,", n_boot, "réplications)"),
    x = "Coefficient de Gini",
    y = "Région"
  ) +
  scale_x_continuous(limits = c(0, 1), labels = scales::label_number(accuracy = 0.01)) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 11, hjust = 0.5, color = "gray40"),
    axis.text.y = element_text(size = 8),
    axis.title = element_text(size = 10, face = "bold"),
    panel.grid.minor = element_blank()
  )

# 6b. Distribution du Gini par région (boxplot des bootstraps)
# Extraire les valeurs bootstrap pour chaque région
boot_values_list <- list()

for (reg in regions) {
  data_region <- menages_impute %>%
    filter(region == reg) %>%
    select(revenu_par_tete, poids_final) %>%
    filter(!is.na(revenu_par_tete))
  
  if (nrow(data_region) >= 10) {
    boot_region <- boot(data_region, function(data, indices) {
      boot_data <- data[indices, ]
      gini_pondere(boot_data$revenu_par_tete, boot_data$poids_final)
    }, R = 200)  # Moins de réplications pour la visualisation
    
    boot_values_list[[reg]] <- data.frame(
      region = reg,
      gini_boot = boot_region$t
    )
  }
}

# Combiner les valeurs bootstrap
boot_values_df <- bind_rows(boot_values_list)

# Graphique des distributions bootstrap par région
p_gini_boot <- boot_values_df %>%
  ggplot(aes(x = gini_boot, y = region, fill = region)) +
  geom_violin(alpha = 0.6, show.legend = FALSE) +
  geom_boxplot(width = 0.1, alpha = 0.8, show.legend = FALSE) +
  geom_vline(xintercept = gini_national, linetype = "dashed", 
             color = "#C73E1D", size = 1) +
  labs(
    title = "Distribution bootstrap du Gini par région",
    subtitle = paste("Basé sur 200 réplications bootstrap"),
    x = "Coefficient de Gini",
    y = "Région"
  ) +
  scale_x_continuous(limits = c(0, 1), labels = scales::label_number(accuracy = 0.01)) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 11, hjust = 0.5, color = "gray40"),
    axis.text.y = element_text(size = 8),
    axis.title = element_text(size = 10, face = "bold"),
    panel.grid.minor = element_blank()
  )

# Afficher les graphiques
print(p_gini_region)
print(p_gini_boot)

# ---- Étape 7 : Sauvegarder ----

# Créer le dossier
dir.create("output/figures", recursive = TRUE, showWarnings = FALSE)
dir.create("output/tables", recursive = TRUE, showWarnings = FALSE)

# Sauvegarder les graphiques
ggsave("output/figures/gini_par_region.png", p_gini_region, width = 12, height = 10, dpi = 300)
ggsave("output/figures/gini_par_region.pdf", p_gini_region, width = 12, height = 10)

ggsave("output/figures/gini_bootstrap_distribution.png", p_gini_boot, width = 12, height = 10, dpi = 300)
ggsave("output/figures/gini_bootstrap_distribution.pdf", p_gini_boot, width = 12, height = 10)

# Sauvegarder les résultats
write_csv(gini_region_results, "output/tables/gini_par_region.csv")

# Sauvegarder le résultat national
gini_national_results <- data.frame(
  indicateur = "Coefficient de Gini national",
  gini = gini_national,
  ic_inf = gini_ic$percent[4],
  ic_sup = gini_ic$percent[5],
  n_boot = n_boot
)
write_csv(gini_national_results, "output/tables/gini_national.csv")

cat("\n=== Résultats sauvegardés ===\n")
cat(" Graphiques : output/figures/gini_par_region.png / .pdf\n")
cat(" Graphiques : output/figures/gini_bootstrap_distribution.png / .pdf\n")
cat(" Tableaux : output/tables/gini_par_region.csv\n")
cat(" Tableaux : output/tables/gini_national.csv\n")