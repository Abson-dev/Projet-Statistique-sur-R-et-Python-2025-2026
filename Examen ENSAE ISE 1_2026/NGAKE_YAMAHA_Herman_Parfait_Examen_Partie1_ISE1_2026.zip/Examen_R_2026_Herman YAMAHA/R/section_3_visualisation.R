# ============================================================================
# SECTION 3 : VISUALISATION
# ============================================================================

# 3.12 Représenter la distribution du revenu par tête par région
# ----------------------------------------------------------------------------

cat("\n=== 3.12 Distribution du revenu par tête par région ===\n")

# Vérifier que la variable existe
if (!"revenu_par_tete" %in% names(menages_impute)) {
  menages_impute <- menages_impute %>%
    mutate(revenu_par_tete = revenu / taille_menage)
}

# Distribution avec densités superposées par région
p_distribution_revenu <- menages_impute %>%
  filter(!is.na(revenu_par_tete) & revenu_par_tete > 0) %>%
  ggplot(aes(x = revenu_par_tete, fill = region, color = region)) +
  geom_density(alpha = 0.3, size = 0.5) +
  scale_x_log10(
    labels = scales::label_comma(),
    breaks = c(1000, 5000, 10000, 50000, 100000, 500000)
  ) +
  scale_fill_viridis_d(option = "plasma", guide = "none") +
  scale_color_viridis_d(option = "plasma", guide = "none") +
  facet_wrap(~ region, scales = "free_y", ncol = 4) +
  labs(
    title = "Distribution du revenu par tête par région",
    subtitle = "Échelle logarithmique pour mieux visualiser l'asymétrie",
    x = "Revenu par tête (FCFA, échelle log)",
    y = "Densité"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 11, hjust = 0.5, color = "gray40"),
    strip.text = element_text(size = 7, face = "bold"),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 6),
    axis.text.y = element_text(size = 6),
    axis.title = element_text(size = 9, face = "bold"),
    panel.grid.minor = element_blank(),
    panel.spacing = unit(0.5, "lines")
  )

# Version alternative : boxplot pour comparer les distributions
p_boxplot_revenu <- menages_impute %>%
  filter(!is.na(revenu_par_tete) & revenu_par_tete > 0) %>%
  ggplot(aes(x = reorder(region, revenu_par_tete, FUN = median), y = revenu_par_tete, fill = region)) +
  geom_boxplot(alpha = 0.7, outlier.size = 0.5, show.legend = FALSE) +
  scale_y_log10(
    labels = scales::label_comma(),
    breaks = c(1000, 5000, 10000, 50000, 100000, 500000)
  ) +
  scale_fill_viridis_d(option = "plasma") +
  labs(
    title = "Distribution du revenu par tête par région",
    subtitle = "Boxplots avec échelle logarithmique",
    x = "Région",
    y = "Revenu par tête (FCFA, échelle log)"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 11, hjust = 0.5, color = "gray40"),
    axis.text.x = element_text(angle = 45, hjust = 1, size = 7),
    axis.text.y = element_text(size = 8),
    axis.title = element_text(size = 10, face = "bold"),
    panel.grid.minor = element_blank()
  )

# Sauvegarder
dir.create("output/figures", recursive = TRUE, showWarnings = FALSE)

ggsave("output/figures/distribution_revenu_par_region.png", 
       p_distribution_revenu, width = 14, height = 10, dpi = 300)
ggsave("output/figures/distribution_revenu_par_region.pdf", 
       p_distribution_revenu, width = 14, height = 10)

ggsave("output/figures/boxplot_revenu_par_region.png", 
       p_boxplot_revenu, width = 12, height = 8, dpi = 300)
ggsave("output/figures/boxplot_revenu_par_region.pdf", 
       p_boxplot_revenu, width = 12, height = 8)

cat("Graphiques sauvegardés : output/figures/distribution_revenu_par_region.png/.pdf\n")
cat("Graphiques sauvegardés : output/figures/boxplot_revenu_par_region.png/.pdf\n")

# ============================================================================

# 3.13 Produire une carte choroplèthe de l'indice de vulnérabilité
# ----------------------------------------------------------------------------

cat("\n=== 3.13 Carte choroplèthe de l'indice de vulnérabilité ===\n")

# 3.13 Produire une carte choroplèthe de l'indice de vulnérabilité
# ----------------------------------------------------------------------------

cat("\n=== 3.13 Carte choroplèthe de l'indice de vulnérabilité ===\n")

# Vérifier si l'indice de vulnérabilité existe
if (!"indice_vulnerabilite" %in% names(menages_impute)) {
  chocs_vars <- c("choc_secheresse", "choc_hausse_prix", "choc_conflit", "choc_maladie")
  strategies_vars <- c("strat_vente_actifs", "strat_reduction_repas", 
                       "strat_migration", "strat_endettement")
  menages_impute <- menages_impute %>%
    mutate(
      score_chocs = rowSums(select(., all_of(chocs_vars)), na.rm = TRUE),
      score_adaptation = rowSums(select(., all_of(strategies_vars)), na.rm = TRUE),
      indice_vulnerabilite = (score_chocs + score_adaptation) / 2
    )
}

# Recalculer le plan de sondage si nécessaire
if (!"plan_sondage" %in% ls() || is.null(plan_sondage)) {
  plan_sondage <- menages_impute %>%
    as_survey_design(
      ids = grappe,
      strata = strate,
      weights = poids_final,
      nest = TRUE
    )
}

# Calculer l'indice moyen par région (pondéré)
vuln_par_region_carte <- plan_sondage %>%
  group_by(region) %>%
  summarise(
    indice_moyen = survey_mean(indice_vulnerabilite, na.rm = TRUE)
  ) %>%
  mutate(indice_moyen = round(indice_moyen, 2))

# Afficher les données pour vérification
print(vuln_par_region_carte)

# Vérifier si le shapefile existe
shapefile_path <- "data/raw/tcd_admin1.shp"

if (file.exists(shapefile_path)) {
  
  library(sf)
  
  # Importer le shapefile
  regions_sf <- tryCatch({
    st_read(shapefile_path, quiet = TRUE)
  }, error = function(e) {
    cat("Erreur lors de la lecture du shapefile :", e$message, "\n")
    return(NULL)
  })
  
  if (!is.null(regions_sf)) {
    
    # Voir les noms des colonnes disponibles
    cat("\n=== Noms des colonnes du shapefile ===\n")
    print(names(regions_sf))
    
    # Identifier la colonne contenant les noms de régions
    # Essayer plusieurs noms possibles
    colonnes_possibles <- c("NAME_1", "NAME", "region", "nom", "NOM", "admin1", "ADMIN1")
    colonne_region <- NULL
    
    for (col in colonnes_possibles) {
      if (col %in% names(regions_sf)) {
        colonne_region <- col
        break
      }
    }
    
    if (!is.null(colonne_region)) {
      cat("Colonne utilisée pour les régions :", colonne_region, "\n")
      
      # Normaliser les noms des régions dans le shapefile
      regions_sf <- regions_sf %>%
        mutate(
          region_norm = case_when(
            # Adapter selon les noms réels dans le shapefile
            TRUE ~ as.character(.data[[colonne_region]])
          )
        )
      
      # Joindre les données
      regions_sf <- regions_sf %>%
        left_join(vuln_par_region_carte, by = c("region_norm" = "region"))
      
      # Version statique avec ggplot2
      p_carte_ggplot <- regions_sf %>%
        ggplot() +
        geom_sf(aes(fill = indice_moyen), color = "white", size = 0.3) +
        geom_sf_text(aes(label = region_norm), size = 2.5, color = "black", check_overlap = TRUE) +
        scale_fill_gradient(
          low = "#2E86AB",
          high = "#C73E1D",
          name = "Indice de\nvulnérabilité",
          na.value = "gray90"
        ) +
        labs(
          title = "Indice de vulnérabilité par région",
          subtitle = "Carte choroplèthe de l'indice composite de vulnérabilité"
        ) +
        theme_minimal() +
        theme(
          plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
          plot.subtitle = element_text(size = 11, hjust = 0.5, color = "gray40"),
          legend.position = "right",
          legend.title = element_text(size = 10, face = "bold"),
          legend.text = element_text(size = 9),
          panel.grid = element_blank(),
          axis.text = element_blank(),
          axis.title = element_blank()
        )
      
      # Version interactive avec tmap
      if (requireNamespace("tmap", quietly = TRUE)) {
        library(tmap)
        
        tmap_mode("plot")
        
        p_carte_tmap <- tm_shape(regions_sf) +
          tm_polygons(
            col = "indice_moyen",
            title = "Indice de\nvulnérabilité",
            palette = "-RdYlBu",
            border.col = "white",
            border.lwd = 1,
            textNA = "Données\nmanquantes",
            colorNA = "gray90"
          ) +
          tm_text("region_norm", size = 0.7, col = "black") +
          tm_layout(
            title = "Indice de vulnérabilité par région",
            legend.position = c("right", "bottom"),
            legend.title.size = 1.2,
            legend.text.size = 0.9,
            frame = FALSE
          )
        
        # Sauvegarder la version tmap
        tmap_save(p_carte_tmap, "output/figures/carte_vulnerabilite_tmap.png", 
                  width = 10, height = 8, dpi = 300)
        tmap_save(p_carte_tmap, "output/figures/carte_vulnerabilite_tmap.pdf", 
                  width = 10, height = 8)
        cat("✓ Carte tmap sauvegardée : output/figures/carte_vulnerabilite_tmap.png/.pdf\n")
      }
      
      # Sauvegarder la version ggplot
      ggsave("output/figures/carte_vulnerabilite_ggplot.png", 
             p_carte_ggplot, width = 10, height = 8, dpi = 300)
      ggsave("output/figures/carte_vulnerabilite_ggplot.pdf", 
             p_carte_ggplot, width = 10, height = 8)
      
      cat("✓ Carte ggplot sauvegardée : output/figures/carte_vulnerabilite_ggplot.png/.pdf\n")
      
    } else {
      cat("\n=== Aucune colonne de région trouvée dans le shapefile ===\n")
      cat("Colonnes disponibles :", paste(names(regions_sf), collapse = ", "), "\n")
      
      # Alternative : barplot
      p_carte_alternative <- vuln_par_region_carte %>%
        mutate(region = fct_reorder(region, indice_moyen)) %>%
        ggplot(aes(x = indice_moyen, y = region, fill = indice_moyen)) +
        geom_col() +
        geom_text(aes(label = round(indice_moyen, 2)), 
                  hjust = -0.2, size = 3) +
        scale_fill_gradient(low = "#2E86AB", high = "#C73E1D", guide = "none") +
        labs(
          title = "Indice de vulnérabilité par région",
          subtitle = "Moyenne pondérée de l'indice composite (barplot alternatif)",
          x = "Indice de vulnérabilité moyen",
          y = "Région"
        ) +
        theme_minimal() +
        theme(
          plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
          plot.subtitle = element_text(size = 11, hjust = 0.5, color = "gray40"),
          axis.text = element_text(size = 9),
          panel.grid.minor = element_blank()
        )
      
      ggsave("output/figures/vulnerabilite_par_region_barplot.png", 
             p_carte_alternative, width = 10, height = 8, dpi = 300)
      ggsave("output/figures/vulnerabilite_par_region_barplot.pdf", 
             p_carte_alternative, width = 10, height = 8)
      cat("✓ Barplot sauvegardé : output/figures/vulnerabilite_par_region_barplot.png/.pdf\n")
    }
  }
  
} else {
  
  cat("\n=== Shapefile non trouvé :", shapefile_path, "===\n")
  cat("Création d'un barplot alternatif...\n")
  
  p_carte_alternative <- vuln_par_region_carte %>%
    mutate(region = fct_reorder(region, indice_moyen)) %>%
    ggplot(aes(x = indice_moyen, y = region, fill = indice_moyen)) +
    geom_col() +
    geom_text(aes(label = round(indice_moyen, 2)), 
              hjust = -0.2, size = 3) +
    scale_fill_gradient(low = "#2E86AB", high = "#C73E1D", guide = "none") +
    labs(
      title = "Indice de vulnérabilité par région",
      subtitle = "Moyenne pondérée de l'indice composite",
      x = "Indice de vulnérabilité moyen",
      y = "Région"
    ) +
    theme_minimal() +
    theme(
      plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
      plot.subtitle = element_text(size = 11, hjust = 0.5, color = "gray40"),
      axis.text = element_text(size = 9),
      panel.grid.minor = element_blank()
    )
  
  ggsave("output/figures/vulnerabilite_par_region_barplot.png", 
         p_carte_alternative, width = 10, height = 8, dpi = 300)
  ggsave("output/figures/vulnerabilite_par_region_barplot.pdf", 
         p_carte_alternative, width = 10, height = 8)
  
  cat("✓ Barplot sauvegardé : output/figures/vulnerabilite_par_region_barplot.png/.pdf\n")
}
# ============================================================================

# 3.14 Composer une figure unique regroupant trois graphiques
# ----------------------------------------------------------------------------

cat("\n=== 3.14 Figure composite avec patchwork ===\n")

library(patchwork)

# Graphique 1 : Distribution de l'indice de vulnérabilité
p1 <- plan_sondage %>%
  group_by(indice_vulnerabilite = round(indice_vulnerabilite, 1)) %>%
  summarise(prop = survey_mean()) %>%
  ggplot(aes(x = indice_vulnerabilite, y = prop)) +
  geom_col(fill = "#2E86AB", alpha = 0.8) +
  labs(
    title = "A. Distribution de la vulnérabilité",
    x = "Indice de vulnérabilité",
    y = "Proportion de ménages"
  ) +
  scale_y_continuous(labels = scales::percent) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 11, face = "bold"),
    axis.text = element_text(size = 8),
    panel.grid.minor = element_blank()
  )

# Graphique 2 : Catégories de vulnérabilité
p2 <- plan_sondage %>%
  group_by(categorie_vulnerabilite) %>%
  summarise(prop = survey_mean()) %>%
  filter(!is.na(categorie_vulnerabilite)) %>%
  mutate(categorie_vulnerabilite = factor(categorie_vulnerabilite,
                                          levels = c("Faible", "Modérée", "Élevée", "Très élevée"))) %>%
  ggplot(aes(x = categorie_vulnerabilite, y = prop, fill = categorie_vulnerabilite)) +
  geom_col() +
  geom_text(aes(label = paste0(round(prop * 100, 1), "%")), 
            vjust = -0.5, size = 3.5) +
  scale_fill_manual(
    values = c("Faible" = "#2E86AB", "Modérée" = "#F18F01", 
               "Élevée" = "#C73E1D", "Très élevée" = "#8B0000"),
    guide = "none"
  ) +
  labs(
    title = "B. Catégories de vulnérabilité",
    x = "Catégorie",
    y = "Proportion de ménages"
  ) +
  scale_y_continuous(labels = scales::percent) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 11, face = "bold"),
    axis.text = element_text(size = 8),
    panel.grid.minor = element_blank()
  )

# Graphique 3 : Score de chocs vs adaptation
p3 <- menages_impute %>%
  filter(!is.na(score_chocs) & !is.na(score_adaptation)) %>%
  ggplot(aes(x = score_chocs, y = score_adaptation)) +
  geom_jitter(alpha = 0.3, size = 1, color = "#2E86AB") +
  geom_smooth(method = "lm", color = "#C73E1D", se = TRUE) +
  labs(
    title = "C. Relation chocs - stratégies d'adaptation",
    x = "Nombre de chocs subis",
    y = "Nombre de stratégies d'adaptation"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(size = 11, face = "bold"),
    axis.text = element_text(size = 8),
    panel.grid.minor = element_blank()
  )

# Combiner les trois graphiques avec patchwork
figure_composite <- (p1 | p2) / p3 +
  plot_annotation(
    title = "Analyse de la vulnérabilité des ménages",
    subtitle = "Distribution, catégories et relation chocs-adaptation",
    theme = theme(
      plot.title = element_text(size = 16, face = "bold", hjust = 0.5),
      plot.subtitle = element_text(size = 12, hjust = 0.5, color = "gray40")
    )
  ) +
  plot_layout(heights = c(0.6, 0.4))

# Afficher
print(figure_composite)

# Sauvegarder
ggsave("output/figures/figure_composite_vulnerabilite.png", 
       figure_composite, width = 12, height = 10, dpi = 300)
ggsave("output/figures/figure_composite_vulnerabilite.pdf", 
       figure_composite, width = 12, height = 10)

cat("✓ Figure composite sauvegardée : output/figures/figure_composite_vulnerabilite.png/.pdf\n")

# ============================================================================

# 3.15 Exporter l'ensemble des figures du rapport
# ----------------------------------------------------------------------------

cat("\n=== 3.15 Export des figures en PNG et PDF ===\n")

# Liste de toutes les figures à exporter
figures_a_exporter <- list(
  "figure_composite_vulnerabilite" = figure_composite,
  "dist_revenu" = p_distribution_revenu,
  "boxplot_revenu" = p_boxplot_revenu
)

# Ajouter la carte si elle existe
if (exists("p_carte_ggplot")) {
  figures_a_exporter$carte_vulnerabilite <- p_carte_ggplot
}

# Exporter chaque figure en PNG et PDF
for (nom_fig in names(figures_a_exporter)) {
  fig <- figures_a_exporter[[nom_fig]]
  
  # Déterminer les dimensions
  if (nom_fig == "figure_composite_vulnerabilite") {
    w <- 12; h <- 10
  } else if (nom_fig == "dist_revenu") {
    w <- 14; h <- 10
  } else if (nom_fig == "boxplot_revenu") {
    w <- 12; h <- 8
  } else {
    w <- 10; h <- 8
  }
  
  # Sauvegarder en PNG
  ggsave(paste0("output/figures/", nom_fig, ".png"), 
         fig, width = w, height = h, dpi = 300)
  
  # Sauvegarder en PDF
  ggsave(paste0("output/figures/", nom_fig, ".pdf"), 
         fig, width = w, height = h)
  
  cat(" ", nom_fig, ".png / .pdf\n")
}

cat("\n=== Toutes les figures ont été exportées ===\n")
cat("Dossier : output/figures/\n")