# #############################################################################
# ##                                                                         ##
# ##   MEMO R — SCRIPT DE REFERENCE POUR L'EXAMEN                            ##
# ##   Projet Statistique sous R — ENSAE ISE 1                              ##
# ##   Enquetes GHS Nigeria (Wave 4) & EHCVM Senegal 2021                   ##
# ##                                                                         ##
# ##   Auteurs : Herman YAMAHA | Bourama DIALLO                             ##
# ##                                                                         ##
# ##   USAGE : ce fichier N'EST PAS a executer d'un bloc. C'est un          ##
# ##   REPERTOIRE de codes usuels. Pour retrouver un bloc rapidement,       ##
# ##   fais Ctrl+F sur la balise entre crochets, ex : [WILC], [HIST].       ##
# ##                                                                         ##
# #############################################################################


# =============================================================================
#   SOMMAIRE  (Ctrl+F sur la balise pour sauter directement au bloc)
# =============================================================================
#
#   PARTIE 0 — ARCHITECTURE DU PROJET (approche modulaire)
#     [ARCH]   Arborescence des dossiers
#     [MAIN]   Template du point d'entree main.R
#
#   PARTIE 1 — MISE EN PLACE
#     [PKG]    Installation automatique des packages
#     [DIRS]   Creation des dossiers de sortie
#     [DL]     Telechargement des donnees depuis GitHub
#
#   PARTIE 2 — IMPORT ET NETTOYAGE
#     [READ]   Lecture d'un fichier .dta (Stata)
#     [POIDS]  Recuperation des poids de sondage (wt_wave4)
#     [LABELS] Extraction des libelles de variables vers Excel
#     [KEY]    Cle unique menage x individu + doublons
#     [NADIAG] Diagnostic des valeurs manquantes
#     [RECODE] Recodage en facteurs (factor / case_when / cut)
#     [AGG]    Agregation au niveau menage (group_by + summarise)
#     [SAVE]   Sauvegarde .rds et rechargement conditionnel
#
#   PARTIE 3 — JOINTURES
#     [JOIN]   Les 6 jointures dplyr (left/right/inner/full/semi/anti)
#
#   PARTIE 4 — PLAN DE SONDAGE ET STATISTIQUES PONDEREES
#     [DESIGN] Declaration du plan (svydesign / as_survey_design)
#     [WSTAT]  Stats ponderees (survey_mean/total/quantile/var)
#     [WPROP]  Proportions ponderees avec IC 95%
#     [WMEAN]  weighted.mean / wtd.quantile (Hmisc)
#
#   PARTIE 5 — TESTS STATISTIQUES
#     [CHI2]   Chi-deux pondere (svychisq) + V de Cramer
#     [KW]     Kruskal-Wallis + test post-hoc de Dunn
#     [WILC]   Wilcoxon-Mann-Whitney + r de Rosenthal (taille d'effet)
#     [SHAP]   Test de normalite de Shapiro-Wilk
#     [SPEAR]  Correlation de Spearman ponderee (wCorr)
#
#   PARTIE 6 — GRAPHIQUES ggplot2
#     [THEME]  Theme personnalise + palettes
#     [HIST]   Histogramme pondere (+ ligne de moyenne)
#     [BOX]    Boxplot pondere (+ losange moyenne)
#     [VIOL]   Violin plot (+ boxplot interne)
#     [BAR]    Barplots : horizontal, empile 100%, groupe (+ IC)
#     [PYR]    Pyramide des ages ponderee
#     [HEAT]   Heatmap (carte de chaleur) par Etat
#     [SCAT]   Nuage de points + tendance
#     [PATCH]  Composition multi-panneaux (patchwork)
#
#   PARTIE 7 — RECODAGES PAR DICTIONNAIRE
#     [DICT]   Recodage via vecteur nomme
#     [CONV]   Conversion d'unites de superficie (zone-specifique)
#
#   PARTIE 8 — EXPORTS DE TABLEAUX
#     [GTS]    Tableau descriptif gtsummary pondere
#     [XLSX]   Export Excel stylise (openxlsx)
#     [XLSXW]  Export Excel simple (writexl)
#
# =============================================================================




# #############################################################################
#   PARTIE 0 — ARCHITECTURE DU PROJET (approche modulaire)
# #############################################################################

# -----------------------------------------------------------------------------
# [ARCH] Arborescence standard d'un projet modulaire
# -----------------------------------------------------------------------------
# Principe : on separe le CHARGEMENT/NETTOYAGE (script 01) de l'ANALYSE (script
# 02). main.R orchestre le tout. Les objets intermediaires transitent par des
# fichiers .rds dans data/processed/.
#
#   Projet/
#   |-- main.R                      <- point d'entree unique
#   |-- scripts/
#   |    |-- 01_import_nettoyage.R  <- telechargement, import, recodages
#   |    |-- 02_analyses.R          <- stats, tests, graphiques, exports
#   |-- data/
#   |    |-- raw/                   <- fichiers .dta bruts (auto-telecharges)
#   |    |-- processed/             <- objets R intermediaires (.rds)
#   |-- outputs/
#        |-- figures/               <- graphiques .png
#        |-- tables/                <- tableaux .xlsx
#
# COMMENT UTILISER : reproduis cette structure. Le script 01 finit par des
# saveRDS() ; le script 02 commence par des readRDS(). main.R appelle les deux
# via source().


# -----------------------------------------------------------------------------
# [MAIN] Template du point d'entree main.R
# -----------------------------------------------------------------------------
# COMMENT UTILISER : c'est le SEUL fichier que l'on lance (source("main.R")).
# Il installe les packages, cree les dossiers, telecharge les donnees, puis
# execute les scripts dans l'ordre.

# ---- 1. Verification et installation des dependances ----
packages_necessaires <- c(
  "haven", "dplyr", "tidyr", "forcats", "ggplot2", "rstatix",
  "ggpubr", "gtsummary", "viridis", "patchwork", "scales",
  "survey", "srvyr",          # plan de sondage pondere
  "openxlsx",                 # export Excel
  "knitr"
)
a_installer <- packages_necessaires[
  !packages_necessaires %in% installed.packages()[, "Package"]
]
if (length(a_installer) > 0) {
  message("Installation des packages manquants : ",
          paste(a_installer, collapse = ", "))
  install.packages(a_installer, repos = "https://cloud.r-project.org")
}

# ---- 2. Creation des dossiers ----
dir.create("data/raw",       showWarnings = FALSE, recursive = TRUE)
dir.create("data/processed", showWarnings = FALSE, recursive = TRUE)
dir.create("outputs",        showWarnings = FALSE, recursive = TRUE)

# ---- 3. Telechargement des donnees (voir bloc [DL]) ----
# ... (bloc de download.file) ...

# ---- 4. Phase 1 : Import, nettoyage, ponderation ----
cat("=== PHASE 1 : Import et preparation des donnees ===\n")
source("scripts/01_import_nettoyage.R")

# ---- 5. Phase 2 : Analyses descriptives et graphiques ----
cat("\n=== PHASE 2 : Analyses descriptives et graphiques ===\n")
source("scripts/02_analyses.R")

cat("\n=== Traitement termine avec succes ! ===\n")




# #############################################################################
#   PARTIE 1 — MISE EN PLACE
# #############################################################################

# -----------------------------------------------------------------------------
# [PKG] Installation automatique des packages (variante boucle require)
# -----------------------------------------------------------------------------
# COMMENT UTILISER : en tete de chaque script. La boucle installe ET charge.
# Avantage sur le bloc de main.R : charge aussi les packages (library).
packages_requis <- c("haven", "dplyr", "naniar")  # <- adapter la liste
for (pkg in packages_requis) {
  if (!require(pkg, character.only = TRUE)) {
    message(paste("Installation du package:", pkg))
    install.packages(pkg, dependencies = TRUE)
    library(pkg, character.only = TRUE)
  }
}


# -----------------------------------------------------------------------------
# [DIRS] Creation des dossiers de sortie
# -----------------------------------------------------------------------------
dir.create("outputs",          showWarnings = FALSE, recursive = TRUE)
dir.create("outputs/figures",  showWarnings = FALSE, recursive = TRUE)
dir.create("outputs/tables",   showWarnings = FALSE, recursive = TRUE)
dir.create("data/processed",   showWarnings = FALSE, recursive = TRUE)
# Variante avec le package here() (chemins robustes) :
#   library(here)
#   dir.create(here("outputs", "figures"), showWarnings = FALSE, recursive = TRUE)


# -----------------------------------------------------------------------------
# [DL] Telechargement des donnees depuis GitHub
# -----------------------------------------------------------------------------
# COMMENT UTILISER : remplace base_url (branche + dossier) et la liste fichiers.
# Le test if(!file.exists) evite de retelecharger a chaque execution.
options(timeout = 300)   # important : gros fichiers .dta

base_url <- paste0(
  "https://raw.githubusercontent.com/",
  "UTILISATEUR/DEPOT/",       # <- a remplacer
  "main/",                    # <- branche (ou hash de commit)
  "DOSSIER/"                  # <- sous-dossier des .dta
)
fichiers <- c("fichier1.dta", "fichier2.dta")   # <- a remplacer

for (f in fichiers) {
  dest <- file.path("data/raw", f)
  if (!file.exists(dest)) {
    cat("  Telechargement :", f, "...\n")
    tryCatch(
      download.file(paste0(base_url, f), destfile = dest, mode = "wb"),
      error = function(e) cat("  Erreur pour", f, ":", conditionMessage(e), "\n")
    )
  } else {
    cat("  ", f, "deja present.\n")
  }
}




# #############################################################################
#   PARTIE 2 — IMPORT ET NETTOYAGE
# #############################################################################

library(haven); library(dplyr)

# -----------------------------------------------------------------------------
# [READ] Lecture d'un fichier .dta (Stata)
# -----------------------------------------------------------------------------
df_brut <- read_dta("data/raw/fichier.dta")
cat("->", nrow(df_brut), "observations x", ncol(df_brut), "variables\n")


# -----------------------------------------------------------------------------
# [POIDS] Recuperation des poids de sondage (wt_wave4)
# -----------------------------------------------------------------------------
# COMMENT UTILISER : les poids sont dans secta_harvestw4.dta au niveau MENAGE
# (hhid). On les selectionne puis on les joint (voir [JOIN]). Chaque individu
# d'un meme menage herite du meme poids.
df_poids <- read_dta("data/raw/secta_harvestw4.dta") %>%
  select(hhid, wt_wave4, zone, state, lga, sector)   # + ea si besoin

cat("wt_wave4 : min =", round(min(df_poids$wt_wave4, na.rm = TRUE), 1),
    "| max =", round(max(df_poids$wt_wave4, na.rm = TRUE), 1),
    "| NA =",  sum(is.na(df_poids$wt_wave4)), "\n")


# -----------------------------------------------------------------------------
# [LABELS] Extraction des libelles de variables vers Excel
# -----------------------------------------------------------------------------
# COMMENT UTILISER : tres utile pour retrouver le sens des variables codees
# (s1q2, s4aq3...). Necessite labelled + writexl.
library(labelled); library(writexl)
meta <- data.frame(
  variable = names(df_brut),
  label    = sapply(df_brut, function(x) {
    lab <- var_label(x)
    if (is.null(lab)) NA else lab
  })
)
write_xlsx(meta, "outputs/tables/labels_variables.xlsx")


# -----------------------------------------------------------------------------
# [KEY] Cle unique menage x individu + detection des doublons
# -----------------------------------------------------------------------------
df_brut$cle_unique <- paste(df_brut$hhid, df_brut$indiv, sep = "_")
n_doublons <- sum(duplicated(df_brut$cle_unique))
cat("Doublons sur hhid x indiv :", n_doublons, "\n")


# -----------------------------------------------------------------------------
# [NADIAG] Diagnostic des valeurs manquantes
# -----------------------------------------------------------------------------
library(naniar)
cat("Valeurs manquantes totales :", n_miss(df_brut), "\n")
# Comptage cible variable par variable :
df_brut %>%
  summarise(
    age    = sum(is.na(age)),
    genre  = sum(is.na(genre)),
    milieu = sum(is.na(milieu))
  )
# Proportion de NA sur une variable :
na_pct <- round(sum(is.na(df_brut$une_var)) / nrow(df_brut) * 100, 2)


# -----------------------------------------------------------------------------
# [RECODE] Recodage en facteurs — factor / case_when / cut
# -----------------------------------------------------------------------------
# COMMENT UTILISER : traduire les codes numeriques du codebook en facteurs
# lisibles. Trois techniques a connaitre :
#   factor(...)    -> variable a modalites connues (sexe, milieu)
#   case_when(...) -> regroupement conditionnel (lien de parente)
#   cut(...)       -> decouper une variable continue en classes (tranches d'age)
df_brut <- df_brut %>%
  mutate(
    # -- variable continue
    age = as.numeric(s1q4),
    
    # -- factor a 2 niveaux (1=Homme, 2=Femme)
    genre = factor(as.numeric(s1q2), levels = c(1, 2),
                   labels = c("Homme", "Femme")),
    
    # -- milieu de residence (1=Urbain, 2=Rural)
    milieu = factor(as.numeric(sector), levels = c(1, 2),
                    labels = c("Urbain", "Rural")),
    
    # -- zone geopolitique (1 a 6)
    zone_geo = factor(as.numeric(zone), levels = 1:6,
                      labels = c("North Central", "North East", "North West",
                                 "South East", "South South", "South West")),
    
    # -- regroupement conditionnel avec case_when
    lien_code = as.numeric(as.character(s1q3)),
    lien_parente = factor(
      case_when(
        lien_code == 1 ~ "Chef de menage",
        lien_code == 2 ~ "Conjoint(e)",
        lien_code == 3 ~ "Enfant",
        TRUE           ~ "Autre membre"
      ),
      levels = c("Chef de menage", "Conjoint(e)", "Enfant", "Autre membre")
    ),
    
    # -- decoupage en classes avec cut (tranches d'age quinquennales)
    tranche_age = cut(
      age,
      breaks = c(0, 5, 10, 15, 20, 25, 30, 35, 40, 45,
                 50, 55, 60, 65, 70, 75, 80, Inf),
      labels = c("0-4","5-9","10-14","15-19","20-24","25-29","30-34","35-39",
                 "40-44","45-49","50-54","55-59","60-64","65-69","70-74",
                 "75-79","80+"),
      right = FALSE, include.lowest = TRUE
    )
  )

# Variante de tranches d'age plus larges (utilisee pour la morbidite) :
#   groupe_age = cut(age, breaks = c(0,14,24,34,44,54,64,Inf),
#                    labels = c("0-14","15-24","25-34","35-44","45-54","55-64","65+"),
#                    right = TRUE, include.lowest = TRUE)

# Indicatrice 0/1 a partir d'une condition (ex : malade si s4aq3 == 1) :
#   malade = if_else(s4aq3 == 1, 1L, 0L, missing = NA_integer_)


# -----------------------------------------------------------------------------
# [AGG] Agregation au niveau menage (group_by + summarise)
# -----------------------------------------------------------------------------
# COMMENT UTILISER : passer de la table INDIVIDU a la table MENAGE.
# n() = taille du menage ; first() pour les variables constantes par menage.
df_menages <- df_brut %>%
  group_by(hhid) %>%
  summarise(
    taille   = n(),
    milieu   = first(milieu),
    zone_geo = first(zone_geo),
    wt_wave4 = first(wt_wave4),
    .groups  = "drop"
  )

# Agregation "au moins une fois" (ex : menage adoptant si UNE parcelle adopte) :
#   df %>% group_by(hhid) %>%
#     summarise(engrais_inorg = any(engrais_inorg, na.rm = TRUE), .groups = "drop")


# -----------------------------------------------------------------------------
# [SAVE] Sauvegarde .rds et rechargement conditionnel
# -----------------------------------------------------------------------------
# Fin du script 01 : on persiste les objets prepares.
dir.create("data/processed", showWarnings = FALSE, recursive = TRUE)
saveRDS(df_brut,     "data/processed/df_brut.rds")
saveRDS(df_menages,  "data/processed/df_menages.rds")

# Debut du script 02 : on relance le 01 seulement si les .rds sont absents.
if (!file.exists("data/processed/df_brut.rds")) {
  cat("Objets absents — execution de 01_import_nettoyage.R...\n")
  source("scripts/01_import_nettoyage.R")
}
df_brut    <- readRDS("data/processed/df_brut.rds")
df_menages <- readRDS("data/processed/df_menages.rds")




# #############################################################################
#   PARTIE 3 — JOINTURES
# #############################################################################

# -----------------------------------------------------------------------------
# [JOIN] Les 6 jointures dplyr — clef "by"
# -----------------------------------------------------------------------------
# COMMENT UTILISER : cle commune ex "hhid". Deux familles :
#   MUTATING (ajoutent des colonnes) : left, right, inner, full
#   FILTERING (filtrent les lignes)  : semi, anti
#
# Astuce type : convertir la cle au meme type des deux cotes AVANT de joindre :
#   base <- base %>% mutate(hhid = as.character(hhid))

# -- MUTATING JOINS -----------------------------------------------------------
# left_join  : garde TOUT A (gauche), ajoute B quand ca correspond (sinon NA)
res_left  <- left_join(base_A, base_B, by = "hhid")
# right_join : garde TOUT B (droite). left_join(A,B) = right_join(B,A)
res_right <- right_join(base_A, base_B, by = "hhid")
# inner_join : garde uniquement les correspondances presentes DANS LES DEUX
res_inner <- inner_join(base_A, base_B, by = "hhid")
# full_join  : garde TOUT des deux cotes (NA la ou pas de correspondance)
res_full  <- full_join(base_A, base_B, by = "hhid")

# -- FILTERING JOINS (colonnes de A seulement) --------------------------------
# semi_join : lignes de A QUI ONT une correspondance dans B (sans colonnes de B)
res_semi <- semi_join(base_A, base_B, by = "hhid")
# anti_join : lignes de A QUI N'ONT PAS de correspondance -> test de coherence.
#             0 ligne = base propre (aucun orphelin).
res_anti <- anti_join(base_A, base_B, by = "hhid")

# Jointure avec suffixe pour distinguer les colonnes homonymes :
#   left_join(A, B, by = c("hhid","plotid"), suffix = c("_A","_B"))

# Joindre uniquement les poids a une base de travail :
#   base <- base %>% left_join(df_poids %>% select(hhid, wt_wave4), by = "hhid")




# #############################################################################
#   PARTIE 4 — PLAN DE SONDAGE ET STATISTIQUES PONDEREES
# #############################################################################

library(survey); library(srvyr)

# -----------------------------------------------------------------------------
# [DESIGN] Declaration du plan de sondage
# -----------------------------------------------------------------------------
# RAPPEL : toute stat descriptive doit etre PONDEREE par wt_wave4 pour etre
# representative de la population (et non du seul echantillon).
# Toujours filtrer les poids manquants avant : filter(!is.na(wt_wave4)).
#
# Deux syntaxes equivalentes :

# -- Style srvyr (dplyr-friendly, recommande pour les summarise) --
design <- df %>%
  filter(!is.na(wt_wave4)) %>%
  as_survey_design(ids = hhid, weights = wt_wave4, nest = TRUE)

# -- Style survey classique (necessaire pour svychisq, svymean, svyquantile) --
plan <- svydesign(ids = ~1, weights = ~wt_wave4, data = df)
# Plan multi-degres avec grappes (ea) et strates (zone) :
#   plan <- svydesign(ids = ~ea, strata = ~zone, weights = ~wt_wave4,
#                     data = df, nest = TRUE)
svy <- as_survey_design(plan)   # pour repasser en style srvyr


# -----------------------------------------------------------------------------
# [WSTAT] Statistiques ponderees (survey_mean/total/quantile/var)
# -----------------------------------------------------------------------------
# vartype = "ci" ajoute les bornes IC 95% (colonnes _low et _upp).
# vartype = NULL n'ajoute pas d'incertitude.
stats <- design %>%
  summarise(
    n_pond   = survey_total(vartype = NULL),                     # effectif pondere
    moyenne  = survey_mean(age, na.rm = TRUE, vartype = "ci"),   # moyenne + IC
    variance = survey_var(age, vartype = NULL),                  # variance
    Q1       = survey_quantile(age, quantiles = 0.25, vartype = NULL),
    mediane  = survey_quantile(age, quantiles = 0.50, vartype = NULL),
    Q3       = survey_quantile(age, quantiles = 0.75, vartype = NULL)
  )
# Ecart-type = racine de la variance : sqrt(stats$variance)

# Stats ponderees PAR GROUPE :
stats_grp <- design %>%
  group_by(milieu) %>%
  summarise(moy = survey_mean(taille, vartype = "ci"),
            med = survey_quantile(taille, quantiles = 0.5, vartype = NULL))


# -----------------------------------------------------------------------------
# [WPROP] Proportions ponderees avec IC 95%
# -----------------------------------------------------------------------------
# survey_mean d'une CONDITION logique = proportion ponderee.
prop <- design %>%
  group_by(niveau_educ) %>%
  summarise(prop = survey_mean(vartype = "ci")) %>%      # proportion de chaque modalite
  mutate(pct = prop * 100, etiq = paste0(round(pct, 1), "%"))

# Proportion d'une modalite precise :
#   summarise(pct_urbain = survey_mean(milieu == "Urbain", na.rm = TRUE, vartype = "ci"))

# Alternative "a la main" (part ponderee) sans survey :
#   df %>% group_by(cat) %>%
#     summarise(n_pond = sum(wt_wave4, na.rm = TRUE)) %>%
#     mutate(pct = n_pond / sum(n_pond) * 100)


# -----------------------------------------------------------------------------
# [WMEAN] weighted.mean / wtd.quantile (approche hors-survey)
# -----------------------------------------------------------------------------
# COMMENT UTILISER : quand on veut des quantiles/moyennes ponderes rapides sans
# declarer de plan. wtd.quantile vient du package Hmisc.
library(Hmisc)
moy_p <- weighted.mean(df$x, df$wt_wave4, na.rm = TRUE)
med_p <- wtd.quantile(df$x, weights = df$wt_wave4, probs = 0.5)
# Deciles ponderes :
#   wtd.quantile(df$x, weights = df$wt_wave4, probs = seq(0, 1, by = 0.1))

# Avec le plan survey (svyquantile) :
#   med <- coef(svyquantile(~x, plan, quantiles = 0.5, na.rm = TRUE))




# #############################################################################
#   PARTIE 5 — TESTS STATISTIQUES
# #############################################################################

# -----------------------------------------------------------------------------
# [CHI2] Chi-deux d'independance pondere (svychisq) + V de Cramer
# -----------------------------------------------------------------------------
# COMMENT UTILISER : tester l'association entre 2 variables categorielles.
# svychisq (methode de Rao-Scott) = version ponderee du chi-deux.
test_chi2 <- svychisq(~ var1 + var2,
                      design = svydesign(ids = ~hhid, weights = ~wt_wave4,
                                         data = df %>% filter(!is.na(wt_wave4))))
print(test_chi2)

# V de Cramer (taille d'effet) — calcule sur la table NON ponderee :
tab      <- table(df$var1, df$var2)
chi2     <- suppressWarnings(chisq.test(tab)$statistic)
n_total  <- sum(tab)
dim_min  <- min(nrow(tab) - 1, ncol(tab) - 1)
v_cramer <- sqrt(chi2 / (n_total * dim_min))
cat("V de Cramer :", round(v_cramer, 4), "\n")


# -----------------------------------------------------------------------------
# [KW] Kruskal-Wallis (>2 groupes) + post-hoc de Dunn
# -----------------------------------------------------------------------------
# COMMENT UTILISER : comparer une variable numerique entre PLUSIEURS groupes
# (ex : rendement par Etat). Non parametrique.
test_kw <- kruskal.test(valeur ~ groupe, data = df)
print(test_kw)   # H = statistic, p = p.value

# Variante rstatix (renvoie un data.frame propre) :
library(rstatix)
kw   <- df %>% kruskal_test(valeur ~ groupe)         # colonnes statistic, p
dunn <- df %>% dunn_test(valeur ~ groupe, p.adjust.method = "bonferroni")


# -----------------------------------------------------------------------------
# [WILC] Wilcoxon-Mann-Whitney (2 groupes) + r de Rosenthal
# -----------------------------------------------------------------------------
# COMMENT UTILISER : comparer une variable numerique entre 2 groupes
# (ex : urbain vs rural). r de Rosenthal = taille d'effet.
# NOTE : pas d'equivalent pondere standard -> test sur donnees brutes, mais on
# reporte des stats descriptives ponderees a cote.
res_w <- wilcox.test(valeur ~ groupe, data = df,
                     conf.int = TRUE, conf.level = 0.95, exact = FALSE)

N     <- nrow(df)
Z     <- qnorm(res_w$p.value / 2)
r_eff <- abs(Z) / sqrt(N)                 # r de Rosenthal = |Z| / racine(N)
categorie_effet <- dplyr::case_when(
  r_eff < 0.10 ~ "Negligeable",
  r_eff < 0.30 ~ "Petit",
  r_eff < 0.50 ~ "Moyen",
  TRUE         ~ "Grand"
)
cat("W =", res_w$statistic, "| p =", format(res_w$p.value, scientific = TRUE),
    "| r =", round(r_eff, 3), "(", categorie_effet, ")\n")

# Fonction utilitaire prete a l'emploi :
#   calc_r <- function(test, n) abs(qnorm(test$p.value / 2)) / sqrt(n)

# Version gtsummary/survey du Wilcoxon pondere : add_p(test = ~ "svy.wilcox.test")


# -----------------------------------------------------------------------------
# [SHAP] Test de normalite de Shapiro-Wilk
# -----------------------------------------------------------------------------
# COMMENT UTILISER : Shapiro est limite a 5000 obs -> on tire un echantillon.
# p < 0.05 => distribution NON normale (justifie l'usage de tests non param.).
set.seed(2025)
echantillon <- sample(na.omit(df$age), size = 5000)
test_sw <- shapiro.test(echantillon)
cat("W =", round(test_sw$statistic, 5),
    "| p =", format(test_sw$p.value, scientific = TRUE), "\n")


# -----------------------------------------------------------------------------
# [SPEAR] Correlation de Spearman ponderee (wCorr)
# -----------------------------------------------------------------------------
# COMMENT UTILISER : correlation de rang entre 2 variables numeriques, ponderee.
library(wCorr)
rho <- weightedCorr(df$x, df$y, method = "Spearman", weights = df$wt_wave4)
cat("Spearman pondere rho =", round(rho, 3), "\n")




# #############################################################################
#   PARTIE 6 — GRAPHIQUES ggplot2
# #############################################################################

library(ggplot2); library(scales); library(forcats)

# -----------------------------------------------------------------------------
# [THEME] Theme personnalise + palettes
# -----------------------------------------------------------------------------
# COMMENT UTILISER : definir UNE fois, reutiliser sur tous les graphiques (+ theme_projet).
theme_projet <- theme_minimal(base_size = 12) +
  theme(
    plot.title       = element_text(face = "bold", size = 13, color = "#1A1A2E"),
    plot.subtitle    = element_text(color = "grey45", size = 10),
    plot.caption     = element_text(color = "grey55", size = 8.5, hjust = 1),
    panel.grid.minor = element_blank()
  )

palette_milieu <- c("Urbain" = "#C0392B", "Rural" = "#1A5276")
palette_genre  <- c("Homme"  = "#1A5276", "Femme" = "#C0392B")

# Point "moyenne" reutilisable (losange orange) a ajouter a un boxplot/violin :
mean_point <- stat_summary(fun = mean, geom = "point", shape = 23, size = 3,
                           fill = "#F39C12", colour = "#2C3E50", stroke = 0.5)

# RAPPEL PONDERATION dans ggplot : aes(weight = wt_wave4) pondere l'histogramme
# et le boxplot au niveau de la population.


# -----------------------------------------------------------------------------
# [HIST] Histogramme pondere + ligne de moyenne
# -----------------------------------------------------------------------------
moy <- weighted.mean(df$age, df$wt_wave4, na.rm = TRUE)
p_hist <- ggplot(df %>% filter(!is.na(age), !is.na(wt_wave4)),
                 aes(x = age, weight = wt_wave4)) +
  geom_histogram(binwidth = 5, fill = "#1A5276", color = "white", alpha = 0.82) +
  geom_vline(xintercept = moy, color = "#E67E22", linetype = "dashed", linewidth = 0.9) +
  annotate("label", x = moy + 5, y = Inf, vjust = 1.5,
           label = paste0("Moyenne = ", round(moy, 1)),
           color = "#E67E22", fill = "white", fontface = "bold", size = 3.5) +
  scale_y_continuous(labels = comma) +
  labs(title = "Distribution de l'age", x = "Age", y = "Effectifs") +
  theme_projet
ggsave("outputs/figures/hist_age.png", p_hist, width = 10, height = 5.5, dpi = 150)

# Echelle log (utile pour depenses/superficies tres etalees) :
#   + scale_x_log10(labels = label_comma(big.mark = " "))


# -----------------------------------------------------------------------------
# [BOX] Boxplot pondere + losange moyenne
# -----------------------------------------------------------------------------
p_box <- ggplot(df %>% filter(!is.na(milieu), !is.na(wt_wave4)),
                aes(x = milieu, y = taille, fill = milieu)) +
  geom_boxplot(aes(weight = wt_wave4), alpha = 0.72, width = 0.48,
               outlier.color = "grey55", outlier.size = 0.75, outlier.alpha = 0.45) +
  geom_jitter(width = 0.14, alpha = 0.07, size = 0.55, color = "grey35") +
  mean_point +
  scale_fill_manual(values = palette_milieu) +
  labs(title = "Taille des menages par milieu", x = NULL, y = "Nombre de membres") +
  theme_projet + theme(legend.position = "none")
ggsave("outputs/figures/box_menages.png", p_box, width = 10, height = 6, dpi = 150)


# -----------------------------------------------------------------------------
# [VIOL] Violin plot (+ boxplot interne + mediane)
# -----------------------------------------------------------------------------
p_violin <- ggplot(df, aes(x = groupe, y = valeur, fill = groupe)) +
  geom_violin(trim = FALSE, alpha = 0.55, color = NA) +
  geom_boxplot(width = 0.12, fill = "white", color = "grey30",
               outlier.shape = NA, linewidth = 0.7) +
  stat_summary(fun = median, geom = "point", shape = 18, size = 4, color = "#E63946") +
  scale_y_log10(labels = label_comma(big.mark = " ")) +
  labs(title = "Distribution par groupe", x = NULL, y = "Valeur (log)") +
  theme_projet + theme(legend.position = "none")
# Facettes (un panneau par culture, echelles libres) :
#   + facet_wrap(~ crop_label, scales = "free_y")


# -----------------------------------------------------------------------------
# [BAR] Barplots — horizontal ordonne, empile 100%, groupe (+ IC)
# -----------------------------------------------------------------------------
# -- Barres horizontales ordonnees par frequence, avec barres d'erreur IC --
p_bar <- ggplot(prop, aes(x = pct, y = fct_reorder(categorie, pct), fill = categorie)) +
  geom_col(width = 0.55, color = "grey20", linewidth = 0.3) +
  geom_errorbarh(aes(xmin = prop_low * 100, xmax = prop_upp * 100),
                 height = 0.25, color = "grey30") +
  geom_text(aes(x = prop_upp * 100, label = etiq), hjust = -0.25,
            size = 3.6, fontface = "bold") +
  scale_x_continuous(expand = expansion(mult = c(0, 0.22)),
                     labels = function(x) paste0(x, "%")) +
  labs(x = "Pourcentage", y = NULL) + theme_projet

# -- Barres empilees a 100% (composition par groupe) --
p_stack <- ggplot(tab, aes(x = groupe, y = pct / 100, fill = modalite)) +
  geom_col(color = "grey30", width = 0.45) +
  geom_text(aes(label = paste0(round(pct, 1), "%")),
            position = position_stack(vjust = 0.5), size = 3.1,
            color = "white", fontface = "bold") +
  scale_y_continuous(labels = percent_format()) +
  coord_flip() + theme_projet

# -- Barres groupees (dodge) avec IC (ex : taux par zone x milieu) --
dodge <- position_dodge(0.78)
p_dodge <- ggplot(tab, aes(x = zone, y = taux * 100, fill = milieu,
                           ymin = ic_inf * 100, ymax = ic_sup * 100)) +
  geom_col(position = dodge, width = 0.70, alpha = 0.88) +
  geom_errorbar(position = dodge, width = 0.22, color = "grey30") +
  geom_text(aes(y = ic_sup * 100, label = paste0(round(taux * 100, 1), "%")),
            position = dodge, vjust = -0.45, size = 2.6, fontface = "bold") +
  scale_fill_manual(values = palette_milieu, name = "Milieu") + theme_projet
# ASTUCE labels : placer le texte a y = ic_sup (pas y = taux) evite le
# chevauchement avec les barres d'erreur.
# str_wrap(x, width = 10) dans scale_x_discrete pour couper les longs libelles.


# -----------------------------------------------------------------------------
# [PYR] Pyramide des ages ponderee
# -----------------------------------------------------------------------------
# COMMENT UTILISER : effectifs ponderes par tranche x sexe, valeurs NEGATIVES
# pour un des deux sexes, puis coord_flip().
df_pyr <- df %>%
  filter(!is.na(tranche_age), !is.na(genre), !is.na(wt_wave4)) %>%
  group_by(tranche_age, genre) %>%
  summarise(eff = sum(wt_wave4), .groups = "drop") %>%
  mutate(eff_aff = ifelse(genre == "Homme", -eff, eff))
maxv <- max(df_pyr$eff)
p_pyr <- ggplot(df_pyr, aes(x = tranche_age, y = eff_aff, fill = genre)) +
  geom_bar(stat = "identity", alpha = 0.85) +
  coord_flip() +
  scale_y_continuous(breaks = pretty(c(-maxv, maxv), n = 8),
                     labels = function(x) comma(abs(x))) +
  scale_fill_manual(values = palette_genre, name = "Sexe") +
  labs(title = "Pyramide des ages", x = "Tranche d'age", y = "Effectifs") +
  theme_projet + theme(legend.position = "bottom")


# -----------------------------------------------------------------------------
# [HEAT] Heatmap (carte de chaleur) par Etat
# -----------------------------------------------------------------------------
# COMMENT UTILISER : geom_tile, ordonner les lignes par valeur (fct_reorder),
# annoter chaque case avec le pourcentage.
p_heat <- ggplot(df_hm, aes(x = 1, y = fct_reorder(state_name, pct), fill = pct)) +
  geom_tile(color = "white", linewidth = 0.3) +
  geom_text(aes(label = paste0(round(pct, 1), "%")),
            size = 2.8, color = "white", fontface = "bold") +
  scale_fill_viridis_c(option = "magma", direction = -1, name = "%") +
  labs(x = NULL, y = NULL) +
  theme_light(base_size = 10) +
  theme(axis.text.x = element_blank(), axis.ticks.x = element_blank(),
        panel.grid = element_blank())
# Variante gradient simple :
#   scale_fill_gradient(low = "#d0e8f5", high = "#08306b", name = "Mediane")


# -----------------------------------------------------------------------------
# [SCAT] Nuage de points + courbe de tendance
# -----------------------------------------------------------------------------
p_scat <- ggplot(df, aes(x = x, y = y, weight = wt_wave4)) +
  geom_point(alpha = 0.4, color = "#2E86AB", size = 1.5) +
  geom_smooth(method = "loess", se = TRUE, color = "red", linewidth = 1) +
  scale_y_log10() +
  labs(title = "y vs x", x = "x", y = "y (log)") + theme_projet
# Ligne 45 degres (comparer declare vs mesure) :
#   + geom_abline(slope = 1, intercept = 0, color = "red", linetype = "dashed")


# -----------------------------------------------------------------------------
# [PATCH] Composition multi-panneaux (patchwork)
# -----------------------------------------------------------------------------
library(patchwork)
combi <- p_hist + p_box                 # cote a cote
# combi <- p_hist / p_box               # l'un au-dessus de l'autre
combi <- (p_hist + p_box) +
  plot_annotation(
    title = "Titre global de la figure combinee",
    theme = theme(plot.title = element_text(face = "bold", size = 15))
  )
ggsave("outputs/figures/figure_combinee.png", combi, width = 12, height = 6, dpi = 150)




# #############################################################################
#   PARTIE 7 — RECODAGES PAR DICTIONNAIRE
# #############################################################################

# -----------------------------------------------------------------------------
# [DICT] Recodage via vecteur nomme (code -> libelle)
# -----------------------------------------------------------------------------
# COMMENT UTILISER : ideal quand il y a beaucoup de codes (maladies, cultures,
# prestataires). On indexe le vecteur par le code converti en caractere.
maladie_labels <- c("1" = "Paludisme", "2" = "Tuberculose", "6" = "Diarrhee",
                    "13" = "Hypertension", "18" = "Diabete")   # ... etc
categorie_maladie <- c("1" = "Infectieuse", "2" = "Infectieuse",
                       "13" = "Chronique", "18" = "Chronique")

df <- df %>%
  mutate(
    code_str  = as.character(as.integer(code_brut)),
    maladie   = maladie_labels[code_str],
    categorie = categorie_maladie[code_str]
  ) %>%
  filter(!is.na(maladie))

# Regrouper des codes disperses vers une meme categorie (ex : prestataires) :
#   groupe <- c("2" = "Hopital", "3" = "Hopital", "7" = "Pharmacie", "8" = "Pharmacie")
#   df <- df %>% mutate(groupe_lab = groupe[as.character(code)])


# -----------------------------------------------------------------------------
# [CONV] Conversion d'unites de superficie (zone-specifique)
# -----------------------------------------------------------------------------
# COMMENT UTILISER : convertir des unites locales (heap/ridge/stand) et
# standard (acre/ha/m2) en hectares. La conversion des unites locales depend
# de la zone geopolitique -> matrice conv_zone.
conv_generale <- c("5" = 0.4, "6" = 1, "7" = 0.0001)   # 5=acre, 6=ha, 7=m2
conv_zone <- matrix(
  c(0.00012, 0.0027,  0.00006,
    0.00016, 0.004,   0.00016,
    0.00011, 0.00494, 0.00004,
    0.00019, 0.0023,  0.00004,
    0.00021, 0.0023,  0.00013,
    0.00012, 0.00001, 0.00041),
  nrow = 6, byrow = TRUE, dimnames = list(1:6, c("1", "2", "3")))  # 1=heap,2=ridge,3=stand

convert_ha_single <- function(valeur, unite, zone) {
  if (is.na(valeur) | is.na(unite)) return(NA_real_)
  u <- as.character(unite)
  if (u %in% names(conv_generale)) return(valeur * conv_generale[u])
  if (u %in% c("1", "2", "3") & !is.na(zone))
    return(valeur * conv_zone[as.character(zone), u])
  return(NA_real_)
}
# Application vectorisee avec mapply :
#   df <- df %>% mutate(superficie_ha = mapply(convert_ha_single, valeur, unite, zone))

# Conversion simple m2 -> ha : superficie_ha = surface_m2 / 10000




# #############################################################################
#   PARTIE 8 — EXPORTS DE TABLEAUX
# #############################################################################

# -----------------------------------------------------------------------------
# [GTS] Tableau descriptif gtsummary pondere
# -----------------------------------------------------------------------------
# COMMENT UTILISER : tableau "profil par groupe" avec test automatique. On part
# d'un plan svydesign, puis tbl_svysummary. add_p ajoute les p-valeurs.
library(gtsummary)
svy_tab <- svydesign(ids = ~1, weights = ~wt_wave4, data = df_tab)
tbl <- svy_tab %>%
  tbl_svysummary(
    by        = milieu,
    include   = c(age, genre, taille_menage),
    statistic = list(all_continuous()  ~ "{mean} ({sd})\nMediane {median} [{p25} ; {p75}]",
                     all_categorical() ~ "{n} ({p}%)"),
    label     = list(age ~ "Age (annees)", genre ~ "Sexe"),
    missing   = "ifany", missing_text = "Non renseigne"
  ) %>%
  add_overall(last = FALSE) %>%
  add_p(test = list(all_continuous()  ~ "svy.wilcox.test",
                    all_categorical() ~ "svy.chisq.test"),
        pvalue_fun = ~ style_pvalue(.x, digits = 3)) %>%
  bold_labels() %>%
  bold_p(t = 0.05)
# Recuperer le tableau en data.frame (pour l'exporter) :
#   df_export <- as_tibble(tbl)


# -----------------------------------------------------------------------------
# [XLSX] Export Excel stylise (openxlsx)
# -----------------------------------------------------------------------------
# COMMENT UTILISER : classeur avec titre, en-tetes colorees, lignes alternees,
# note de bas. Structure reutilisable via la fonction add_feuille ci-dessous.
library(openxlsx)

sty_titre  <- createStyle(fontName = "Arial", fontSize = 13, textDecoration = "bold",
                          fontColour = "#1A5276")
sty_source <- createStyle(fontName = "Arial", fontSize = 9, fontColour = "grey50",
                          textDecoration = "italic")
sty_header <- createStyle(fontName = "Arial", fontSize = 11, textDecoration = "bold",
                          halign = "center", fgFill = "#1A5276", fontColour = "white",
                          border = "TopBottomLeftRight", borderColour = "white")
sty_cell   <- createStyle(fontName = "Arial", fontSize = 10, halign = "center",
                          border = "TopBottomLeftRight", borderColour = "#CCCCCC",
                          wrapText = TRUE)
sty_alt    <- createStyle(fgFill = "#EAF2F8")
sty_note   <- createStyle(fontName = "Arial", fontSize = 9, fontColour = "grey50",
                          textDecoration = "italic")

# Fonction : ajoute une feuille mise en forme a partir d'un data.frame.
add_feuille <- function(wb, nom, titre, source_txt, df_data, note = NULL) {
  addWorksheet(wb, nom)
  writeData(wb, nom, titre,      startRow = 1, startCol = 1)
  writeData(wb, nom, source_txt, startRow = 2, startCol = 1)
  writeData(wb, nom, df_data,    startRow = 4, startCol = 1, headerStyle = sty_header)
  nr <- nrow(df_data); nc <- ncol(df_data)
  addStyle(wb, nom, sty_cell, rows = 4:(nr + 4), cols = 1:nc, gridExpand = TRUE, stack = TRUE)
  for (i in seq(2, nr, by = 2))                              # lignes alternees
    addStyle(wb, nom, sty_alt, rows = i + 4, cols = 1:nc, gridExpand = TRUE, stack = TRUE)
  addStyle(wb, nom, sty_titre,  rows = 1, cols = 1)
  addStyle(wb, nom, sty_source, rows = 2, cols = 1)
  if (!is.null(note)) {
    writeData(wb, nom, note, startRow = nr + 6, startCol = 1)
    addStyle(wb, nom, sty_note, rows = nr + 6, cols = 1)
  }
}

wb <- createWorkbook()
add_feuille(wb, "Feuille1", "Titre du tableau",
            "Source : GHS-W4 | Ponderation : wt_wave4",
            df_export, note = "Note : effectifs ponderes.")
setColWidths(wb, "Feuille1", cols = 1:ncol(df_export), widths = 18)
saveWorkbook(wb, "outputs/tables/tableau.xlsx", overwrite = TRUE)

# Format des nombres dans une cellule : createStyle(numFmt = "0.00") ou "#,##0.00"
# Fusionner des cellules (titre sur plusieurs colonnes) :
#   mergeCells(wb, "Feuille1", cols = 1:5, rows = 1)


# -----------------------------------------------------------------------------
# [XLSXW] Export Excel simple (writexl) — sans mise en forme
# -----------------------------------------------------------------------------
# COMMENT UTILISER : le plus rapide quand la mise en forme n'importe pas.
library(writexl)
write_xlsx(df_export, "outputs/tables/tableau_simple.xlsx")
# Plusieurs feuilles : write_xlsx(list(Feuille1 = df1, Feuille2 = df2), "sortie.xlsx")


# #############################################################################
#   FIN DU MEMO
# #############################################################################