# Examen de Projet Statistique sous R — Partie 1
## Vulnérabilité aux chocs et sécurité alimentaire des ménages (ENSAN 2026)

---

## Auteur

| Nom | Prénom | Établissement |
|:----|:-------|:--------------|
| NGAKE YAMAHA | Herman Parfait | ENSAE Pierre NDIAYE, Dakar — ISE 1 Cycle Long |

**Superviseur :** M. Aboubacar HEMA, Analyste de recherche / Data Scientist, IFPRI
**Année académique :** 2025 – 2026
**Cours :** Projet Statistique sous R — Session d'examen 2025/2026

---

## 1. Description du projet

Ce projet répond à la **Partie 1** de l'examen : produire, pour la direction des statistiques agricoles et de la sécurité alimentaire d'un institut national de statistique sahélien, une **note technique reproductible** identifiant les déterminants de l'insécurité alimentaire des ménages, la vulnérabilité différenciée par région et par milieu, ainsi que des recommandations opérationnelles de ciblage.

Les données proviennent de l'**Enquête Nationale sur la Sécurité Alimentaire et les stratégies d'adaptation des Ménages (ENSAN 2026)**, conduite après une combinaison de chocs : sécheresse dans les régions du nord, hausse durable des prix des céréales et recrudescence de l'insécurité civile dans certaines zones frontalières.

L'échantillon couvre **3 540 ménages**, **23 régions**, **284 grappes** et **45 strates**. Toutes les estimations mobilisent la pondération `poids_final` sous plan de sondage stratifié à grappes, afin de garantir la représentativité nationale des résultats.

### Questions traitées

| Section | N° | Objet d'analyse | Livrable principal |
|:--------|:---|:----------------|:-------------------|
| **1. Import & nettoyage** | 1 – 3 | Import des 5 sources, jointures contrôlées, harmonisation des libellés de régions | `menages_enrichi.rds` |
| | 4 | Diagnostic des valeurs manquantes avec `naniar` (résumé, visualisations, cooccurrences, NA tagués Stata) | Figures `vis_miss_*`, `heatmap_miss_*` |
| | 5 | Hypothèse de non-réponse (MAR) et imputation multiple par équations chaînées (`mice`) | `menages_impute.rds`, `imputation_mice.rds` |
| | 6 | Recodages : milieu, éducation du chef, quintiles de revenu par tête | `menages_final.csv` |
| **2. Statistiques pondérées** | 7 | Déclaration du plan de sondage avec `srvyr` | `plan_sondage.rds` |
| | 8 | Score de diversité alimentaire (HDDS) et classification FAO | `hdds_par_region.csv`, `fao_classification_ponderee.csv` |
| | 9 | Indice composite de vulnérabilité aux chocs | `indice_vulnerabilite_par_region.csv` |
| | 10 | Tableau descriptif pondéré de type « Tableau 1 » (`gtsummary`) | `tableau1_pondere_complet.html` / `.csv` |
| | 11 | Coefficient de Gini du revenu par tête, national et régional, IC bootstrap | `gini_national.csv`, `gini_par_region.csv` |
| **3. Visualisation** | 12 – 15 | Distributions du revenu, cartographie de la vulnérabilité, figure composite `patchwork`, exports PNG + PDF | `output/figures/` |
| **5. Communication** | 16 – 17 | Rapport R Markdown unique compilant en Word et HTML, avec table des matières, sections numérotées et résultats chiffrés en *inline code* | `docs/rapport.Rmd` → `.docx` / `.html` |

> **Note :** la **Partie 2** (récupération de données via l'API SDG) n'est pas couverte par ce dépôt.

---

## 2. Sources de données

Les fichiers bruts sont fournis avec le sujet et déposés dans `data/raw/`. **Aucun fichier n'a été modifié manuellement en dehors de R.**

| Fichier | Contenu | Format |
|:--------|:--------|:-------|
| `ensan_menages.dta` | Module ménage : `hhid`, région, milieu, grappe, strate, `poids_final`, revenu, taille du ménage | Stata `.dta`, avec labels |
| `ensan_individus.csv` | Module individu : âge, sexe, niveau d'éducation, rang dans le ménage | CSV, UTF-8 |
| `ensan_consommation.xlsx` | Feuille `Consommation_groupes` (12 groupes alimentaires FAO, 0/1) et feuille `Depenses_menage` (dépenses par poste) | Excel multi-feuilles |
| `chocs_menages.csv` | 4 chocs subis (sécheresse, hausse des prix, conflit, maladie) et 4 stratégies d'adaptation (vente d'actifs, réduction des repas, migration, endettement) | CSV |
| `prix_marches.csv` | Prix mensuels des céréales par marché sur 24 mois (format type WFP) | CSV |
| `tcd_admin1.shp` (+ `.dbf`, `.shx`, `.prj`, `.cpg`) | Limites administratives des régions | Shapefile |

---

## 3. Approche méthodologique

### 3.1 Jointures et contrôle d'intégrité

Les cinq sources sont fusionnées par `left_join()` sur `hhid`, en partant du module ménage. Après **chaque** jointure, le nombre de lignes est vérifié par `stopifnot(nrow(menages_enrichi) == nrow(menages))`.

Ce contrôle a permis de détecter une anomalie : **15 ménages comportaient deux individus de rang 1** (deux chefs déclarés), ce qui faisait passer la table de 3 540 à 3 555 lignes. La correction retenue conserve le premier chef rencontré (`distinct(hhid, .keep_all = TRUE)`), ce qui rétablit la cardinalité 1:1.

### 3.2 Harmonisation des libellés de régions

Le fichier `chocs_menages.csv` utilise des libellés en majuscules avec des graphies concurrentes : `GUERA` / `GUÉRA`, `OUADAI` / `OUADDAÏ`, `TANDJILÉ` / `TANDJILLE`, `NDJAMENA` vs `N'Djamena`. Une **table de correspondance explicite** (26 libellés sources → 23 régions cibles) est appliquée avant toute jointure spatiale. La vérification finale (`setdiff()`) renvoie `character(0)` : plus aucune région orpheline.

### 3.3 Valeurs manquantes et imputation

| Variable | NA | Taux |
|:---------|---:|-----:|
| `revenu` | 369 | 10,4 % |
| `educ_chef` | 185 | 5,2 % |
| `taille_menage` | 150 | 4,2 % |
| `age_chef` | 74 | 2,1 % |

Le taux global de cellules manquantes est de **0,52 %**. Aucune **valeur manquante taguée Stata** (`.a`, `.b`, `.d`) n'a été détectée : la seule variable `haven_labelled` importée est `milieu`, dont les labels (`Urbain`, `Rural`) sont des modalités valides et non des codes de non-réponse.

**Mécanisme retenu : MAR.** La probabilité de non-réponse sur le revenu dépend de caractéristiques observées (milieu, région, taille du ménage) plutôt que du revenu lui-même. L'imputation est réalisée avec `mice` : **5 imputations, 10 itérations**, `pmm` pour les variables continues, `logreg`/`polyreg` pour les variables catégorielles, `seed = 123` pour la reproductibilité. Les densités observé vs imputé et les traces de convergence sont exportées dans `output/figures/mice_*`.

### 3.4 Plan de sondage

```r
plan_sondage <- menages_impute |>
  as_survey_design(ids = grappe, strata = strate,
                   weights = poids_final, nest = TRUE)
```

Toutes les moyennes, proportions, médianes et erreurs types présentées comme représentatives sont calculées via `survey_mean()`, `survey_total()` et `survey_median()`. Aucune strate ne compte moins de 5 ménages, ce qui autorise l'estimation de la variance sur l'ensemble du plan.

### 3.5 Score de diversité alimentaire (HDDS)

Le HDDS est la somme des 12 indicatrices `cons_*` (céréales, tubercules, légumineuses, légumes, fruits, viande, poisson, œufs, lait, huile, sucre, condiments), soit un score de 0 à 12. La classification FAO retenue est :

| Catégorie | Seuil |
|:----------|:------|
| Sécurité alimentaire | HDDS ≥ 6 |
| Insécurité modérée | 4 ≤ HDDS ≤ 5 |
| Insécurité sévère | HDDS ≤ 3 |

### 3.6 Indice composite de vulnérabilité

```
score_chocs        = somme des 4 chocs subis            (0 – 4)
score_adaptation   = somme des 4 stratégies mobilisées  (0 – 4)
indice_vulnerabilite = (score_chocs + score_adaptation) / 2   (0 – 4)
```

**Justification de la pondération.** Les deux composantes reçoivent un poids identique : l'enquête ne fournit aucune mesure de gravité déclarée des chocs, ce qui rendrait toute pondération différenciée arbitraire. Le recours à une stratégie d'adaptation est traité comme un signal de vulnérabilité **révélée**, complémentaire de l'exposition brute aux chocs.

**Seuils.** Ils découlent de la distribution empirique de l'indice (médiane = 1, 3ᵉ quartile = 1,5) :

| Catégorie | Indice |
|:----------|:-------|
| Faible | < 1 |
| Modérée | 1 – 2 |
| Élevée | 2 – 3 |
| Très élevée | ≥ 3 |

### 3.7 Coefficient de Gini et bootstrap

Le Gini du revenu par tête (`revenu / taille_menage`) est calculé **pondéré** avec `DescTools::Gini(x, weights = poids_final)`. Les intervalles de confiance à 95 % proviennent d'un bootstrap non paramétrique (`boot`, **1 000 réplications**, `seed = 123`), en méthode percentile et BCa au niveau national, percentile au niveau régional.

### 3.8 Cartographie

La carte choroplèthe s'appuie sur `tcd_admin1.shp` lu avec `sf`. Le shapefile ne contenant pas de colonne `NAME_1` mais `adm1_name`, le script détecte automatiquement la colonne de libellés parmi une liste de noms candidats et bascule sur un **barplot de repli** (`vulnerabilite_par_region_barplot.png`) si aucune correspondance n'est trouvée — comportement documenté ici par souci de transparence.

---

## 4. Structure du projet

```
Examen_R_2026_Herman_YAMAHA/
│
├── main.R                                   ← Point d'entrée unique
├── Examen_R_2026_Herman_YAMAHA.Rproj
├── README.md
├── renv.lock                                ← Verrouillage des dépendances
│
├── script/
│   ├── section_1_Import_structuration_nettoyage.R   ← Q1 à Q6
│   ├── section_2_statistiques_descriptives_ponderees_indices_composites.R  ← Q7 à Q11
│   ├── section_3_visualisation.R                    ← Q12 à Q15
│
├── docs/
│   ├── rapport.Rmd                          ← Rapport unique → Word + HTML
│   ├── rapport.docx                         ← Rapport Word compilé
│   ├── rapport.html                         ← Rapport HTML compilé
│   └── reference.docx                       ← Template Word (styles, en-têtes)
│
├── img/                                     ← Logos de la page de garde
│   ├── logo_republique_senegal.png
│   ├── logo_ansd.png
│   └── logo_ensae.jpeg
│
├── data/
│   ├── raw/                                 ← Fichiers bruts fournis (vide, d'après la demande de l'examinateur)
│   │
│   └── processed/                           ← Objets intermédiaires (.rds)
│       ├── menages_enrichi.rds              ← Table fusionnée avant imputation
│       ├── chocs_corrige.rds                ← Chocs avec régions harmonisées
│       ├── imputation_mice.rds              ← Objet mids (5 imputations)
│       ├── menages_impute.rds               ← Table finale analysée
│       ├── menages_final.csv                ← Export CSV de contrôle
│       └── plan_sondage.rds                 ← Design srvyr
│
└── output/
    ├── figures/                             ← Toutes les figures en PNG (300 dpi) + PDF
    │   ├── vis_dat_menages.*                ← Structure des données
    │   ├── vis_miss_menages.*               ← Carte des valeurs manquantes
    │   ├── heatmap_miss_var.*               ← % de NA par variable
    │   ├── heatmap_miss_region.*            ← % de NA par région × variable
    │   ├── top_na_combinations.*            ← Cooccurrences de NA
    │   ├── na_standards_vs_tagged.*         ← NA standards vs NA tagués Stata
    │   ├── mice_convergence.png             ← Traces de convergence mice
    │   ├── mice_comparison_*.png            ← Densités observé vs imputé
    │   ├── hdds_distribution.*              ← Distribution pondérée du HDDS
    │   ├── fao_classification_region.*      ← Classification FAO par région
    │   ├── vuln_distribution.*              ← Distribution de l'indice
    │   ├── vuln_categories.*                ← Catégories de vulnérabilité
    │   ├── vuln_by_region.*                 ← Indice moyen par région
    │   ├── vulnerabilite_par_region_barplot.* ← Repli cartographique
    │   ├── gini_par_region.*                ← Gini régional + IC bootstrap
    │   ├── gini_bootstrap_distribution.*    ← Distributions bootstrap
    │   ├── distribution_revenu_par_region.* ← Densités du revenu (échelle log)
    │   ├── boxplot_revenu_par_region.*      ← Boxplots du revenu (échelle log)
    │   └── figure_composite_vulnerabilite.* ← Figure patchwork 3 panneaux
    │
    └── tables/                              ← Tableaux exportés
        ├── na_summary.csv / na_patterns.csv / na_cooccurrence.csv
        ├── na_standards_vs_tagged.csv
        ├── hdds_par_region.csv / hdds_summary.csv
        ├── fao_classification_ponderee.csv
        ├── indice_vulnerabilite_par_region.csv
        ├── categories_vulnerabilite_par_region.csv
        ├── gini_national.csv / gini_par_region.csv
        └── tableau1_pondere_complet.html / .csv
```

---

## 5. Exécution

### Prérequis

- **R** ≥ 4.4.0 (développé et testé sous R 4.5.1)
- **RStudio** recommandé
- **Pandoc** (fourni avec RStudio) pour la compilation du rapport
- Aucune connexion internet n'est nécessaire : les données sont livrées dans `data/raw/`

### Lancement en trois commandes

```r
# 1. Ouvrir Examen_R_2026_Herman_YAMAHA.Rproj dans RStudio

# 2. Restaurer l'environnement exact des packages
renv::restore()

# 3. Exécuter l'ensemble de la chaîne de traitement
source("main.R")
```

### Ce que fait `main.R`

| Étape | Action |
|:------|:-------|
| **0** | Vérification et installation des packages manquants |
| **1** | Création de `data/processed/`, `output/figures/`, `output/tables/` |
| **2** | Import, jointures contrôlées, harmonisation des régions, diagnostic NA, imputation `mice`, recodages (`section_1`) |
| **3** | Plan de sondage, HDDS, indice de vulnérabilité, Tableau 1, Gini bootstrap (`section_2`) |
| **4** | Distributions, cartographie, figure composite, exports PNG + PDF (`section_3`) |
| **5** | Compilation du rapport en Word et HTML |

### Compilation manuelle du rapport

```r
rmarkdown::render("docs/rapport.Rmd", output_format = "all")   # Word + HTML
```

Alternative : ouvrir `docs/rapport.Rmd` dans RStudio → **Knit**. Le rapport lit les objets de `data/processed/` : il faut donc avoir exécuté les scripts d'analyse au préalable, sinon les `.rds` n'existent pas encore.

---

## 6. Résultats produits

### Principaux résultats chiffrés

| Indicateur | Valeur pondérée |
|:-----------|:----------------|
| HDDS moyen national | **6,48 groupes / 12** |
| Ménages en sécurité alimentaire | **63,2 %** |
| Ménages en insécurité modérée | **24,5 %** |
| Ménages en insécurité sévère | **12,3 %** |
| Écart HDDS urbain – rural | 7,16 vs 5,96 |
| Indice moyen de vulnérabilité | **1,20 / 4** |
| Ménages en vulnérabilité élevée ou très élevée | **22,5 %** |
| Choc le plus fréquent | Hausse des prix (**60,5 %**) |
| Stratégie la plus mobilisée | Réduction des repas (**37,7 %**) |
| Gini national du revenu par tête | **0,442** — IC 95 % [0,429 ; 0,456] |

> Ces valeurs sont reprises dans le rapport via des **appels *inline code***, et se recalculent automatiquement si les données changent.

### Rapport

`docs/rapport.Rmd` produit un document unique compilant en **Word** (`officedown::rdocx_document` avec `reference.docx`, page de garde, table des matières, liste des tableaux, liste des figures, sections numérotées) et en **HTML** (`html_document` avec table des matières flottante). Au moins une quinzaine de résultats chiffrés y sont intégrés par *inline code*.

---

## 7. Packages utilisés

| Package | Rôle |
|:--------|:-----|
| `haven` | Lecture des fichiers Stata `.dta` avec labels |
| `readxl` | Lecture des feuilles Excel |
| `readr`, `dplyr`, `tidyr`, `purrr`, `stringr`, `forcats` | Chaîne tidyverse, pipe natif `\|>` |
| `janitor` | Nettoyage des noms de colonnes (`clean_names`) |
| `naniar`, `visdat`, `UpSetR` | Diagnostic et visualisation des valeurs manquantes |
| `mice` | Imputation multiple par équations chaînées |
| `survey`, `srvyr` | Plan de sondage complexe et statistiques pondérées |
| `gtsummary`, `gt`, `flextable` | Tableaux descriptifs et tableaux de rapport |
| `DescTools` | Coefficient de Gini pondéré |
| `boot` | Intervalles de confiance par bootstrap |
| `ggplot2`, `scales`, `patchwork` | Visualisation et composition multi-panneaux |
| `sf`, `tmap` | Lecture du shapefile et cartographie |
| `rmarkdown`, `knitr`, `officer`, `officedown` | Compilation du rapport Word / HTML |
| `here` | Chemins relatifs robustes à la racine du projet |
| `renv` | Gestion et verrouillage des dépendances |

---

## 8. Notes techniques et limites

### Portée des résultats

Conformément aux consignes, **tous les résultats régionaux sont présentés comme descriptifs et associatifs**. Aucun modèle causal n'est estimé : les écarts observés entre régions ou entre milieux ne doivent pas être lus comme des effets.

### Limites méthodologiques

- **Pondération de l'indice de vulnérabilité** : le choix d'un poids égal pour les chocs et les stratégies d'adaptation est transparent mais arbitraire ; une analyse en composantes principales déplacerait légèrement le classement régional.
- **Hypothèse MAR** : elle n'est pas testable. Si les ménages les plus pauvres refusent davantage de déclarer leur revenu (MNAR), le Gini est sous-estimé.
- **Effectifs régionaux** : entre 78 et 198 ménages par région, ce qui élargit les intervalles de confiance des estimations régionales, en particulier pour N'Djamena.
- **Endogénéité des stratégies d'adaptation** : un ménage qui n'adopte aucune stratégie peut être soit peu exposé, soit dépourvu de toute marge de manœuvre. L'indice ne distingue pas ces deux situations.

### Reproductibilité

- Toutes les procédures aléatoires (imputation `mice`, bootstrap) fixent `set.seed(123)`.
- Les objets intermédiaires sont persistés en `.rds` dans `data/processed/`, ce qui permet de relancer une section sans réexécuter les précédentes.
- L'environnement de packages est verrouillé par `renv.lock` : `renv::restore()` reconstitue à l'identique les versions utilisées.
- L'historique Git local retrace les grandes étapes du travail (import et nettoyage, diagnostic des NA et imputation, statistiques pondérées et indices, visualisations, rapport et documentation).

---

*Projet réalisé dans le cadre de l'examen de Projet Statistique sous R — ENSAE Pierre NDIAYE, ISE 1, 2025-2026.*
*Données : Enquête Nationale sur la Sécurité Alimentaire et les stratégies d'adaptation des Ménages (ENSAN 2026).*