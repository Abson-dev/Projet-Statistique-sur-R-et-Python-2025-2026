# =============================================================================
# Examen de Projet Statistique sous R — ENSAE ISE 1, 2025-2026
#
# Auteur      : Herman YAMAHA, étudiant en ISE1-Cycle Long à l'ENSAE de Dakar
# Superviseur  : M. Aboubacar HEMA, Data Scientist à IFPRI




# ── Packages requis ───────────────────────────────────────────────────────────
packages_requis <- c(
  "haven",       # lecture des fichiers .dta Stata
  "dplyr",       # manipulation des données
  "tidyr",       # restructuration
  "forcats",     # réordonner les facteurs
  "ggplot2",     # visualisation
  "scales",      # formatage des axes
  "rstatix",     # tests statistiques (Kruskal-Wallis, Wilcoxon)
  "ggpubr",      # combinaison de graphiques
  "patchwork",   # layout multi-panneaux
  "survey",      # plan de sondage complexe
  "srvyr",       # interface dplyr pour survey
  "openxlsx",    # export Excel
  "purrr",       # programmation fonctionnelle
  "stringr",     # manipulation de chaînes (str_wrap)
  "knitr",       # compilation du rapport
  "kableExtra",  # tableaux LaTeX dans le rapport PDF
  "xfun",         # utilitaires knitr
  "DescTools"
  
)

a_installer <- packages_requis[!packages_requis %in% rownames(installed.packages())]
if (length(a_installer) > 0) {
  message("Installation des packages manquants : ", paste(a_installer, collapse=", "))
  install.packages(a_installer, repos="https://cloud.r-project.org")
}

# ── Création des dossiers de sortie ──────────────────────────────────────────
dir.create("data/raw",       showWarnings=FALSE, recursive=TRUE)
dir.create("data/processed", showWarnings=FALSE, recursive=TRUE)
dir.create("output/figures",        showWarnings=FALSE, recursive=TRUE)
dir.create("output/tables",        showWarnings=FALSE, recursive=TRUE)



# ── SECTION 1 : Import, structuration et nettoyage ─────────────

cat("\n========================================\n")
cat("  SECTION 1 :  Import, structuration et nettoyage\n")
cat("========================================\n")
source("R/section_1_Import_structuration_nettoyage.R")



# ── SECTION 2 : Statistiques descriptives pondérées et indices composites ────────────────────────────
cat("\n========================================\n")
cat("  SECTION 2 : Statistiques descriptives pondérées et indices composites\n")
cat("========================================\n")
source("R/section_2_statistiques_descriptives_pondérées_indices_composites.R")




# ── SECTION 3 : Visualisation  ───────────────────────
cat("\n========================================\n")
cat("  SECTION 3 : Visualisation\n")
cat("========================================\n")
source("R/section_3_visualisation.R")


# ── SECTION 4 : Reproductibilité et communication   ───────────────────────
cat("\n========================================\n")
cat("  SECTION 4 : Reproductibilité et communication \n")
cat("========================================\n")

cat("\n Rapport à compiler :\n")
cat("  -> docs/rapport.Rmd\n")
cat("  -> Ouvrir dans RStudio, cliquer sur Knit -> Word Document\n")
