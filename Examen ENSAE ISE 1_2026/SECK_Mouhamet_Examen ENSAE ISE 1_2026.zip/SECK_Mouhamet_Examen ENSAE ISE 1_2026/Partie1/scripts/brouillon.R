################################################################################



################################################################################

library(haven)
library(readxl)
library(readr)
library(dplyr)
library(lubridate)
library(sf)

# Menages (Stata)
menages <- read_dta("ensan_menages.dta")
# hhid est character, on le garde tel quel

# Individus (CSV)
individus <- read_csv("ensan_individus.csv") %>%
  mutate(hhid = sprintf("%05d", hhid))

# Consommation (Excel) - feuille 1
consommation <- read_excel("ensan_consommation.xlsx", sheet = 1)
# hhid est character, OK

# Depenses (Excel) - feuille 2
depenses <- read_excel("ensan_consommation.xlsx", sheet = 2)

# Chocs (CSV)
chocs <- read_csv("chocs_menages.csv") %>%
  mutate(hhid = sprintf("%05d", hhid))

# Prix (CSV)
prix <- read_csv("prix_marches.csv") %>%
  mutate(mois = ymd(mois))

# Shapefile
regions <- st_read("regions.shp")


################################################################################



################################################################################


ensan_menage <- menages %>%
  left_join(consommation, by = "hhid") %>%
  left_join(depenses, by = "hhid") %>%
  left_join(chocs, by = "hhid")
# Pour les individus, vous pouvez les agréger (ex. composition, âge moyen) ou les garder séparément.


################################################################################



################################################################################




# Chargement des librairies
library(haven)
library(readr)
library(readxl)
library(dplyr)
library(lubridate)
library(sf)

# 1. Menages
menages <- read_dta("ensan_menages.dta")
# Vérifier que hhid est character
menages <- menages %>% mutate(hhid = as.character(hhid))

# 2. Individus
individus <- read_csv("ensan_individus.csv") %>%
  mutate(hhid = sprintf("%05d", hhid))

# 3. Consommation (feuille 1)
consommation <- read_excel("ensan_consommation.xlsx", sheet = 1)

# 4. Depenses (feuille 2)
depenses <- read_excel("ensan_consommation.xlsx", sheet = 2)

# 5. Chocs
chocs <- read_csv("chocs_menages.csv") %>%
  mutate(hhid = sprintf("%05d", hhid))

# 6. Prix
prix <- read_csv("prix_marches.csv") %>%
  mutate(mois = ymd(mois))

# 7. Shapefile
regions <- st_read("regions.shp")

# Fusion des tables ménage
ensan <- menages %>%
  left_join(consommation, by = "hhid") %>%
  left_join(depenses, by = "hhid") %>%
  left_join(chocs, by = "hhid")

# Création d'indicateurs
ensan <- ensan %>%
  mutate(
    score_alimentaire = rowSums(select(., starts_with("cons_")), na.rm = TRUE),
    depenses_totales = dep_alimentaire + dep_sante + dep_education + dep_logement + dep_autres,
    nb_chocs = rowSums(select(., starts_with("choc_")), na.rm = TRUE),
    a_utilise_strat = ifelse(strat_vente_actifs == 1 | strat_reduction_repas == 1 |
                               strat_migration == 1 | strat_endettement == 1, 1, 0)
  )

# Exemple de statistique pondérée avec survey
library(survey)
design <- svydesign(id = ~grappe, strata = ~strate, weights = ~poids_final, data = ensan)
svymean(~revenu + depenses_totales + score_alimentaire, design, na.rm = TRUE)

