# ==============================================================================
# Examen ENSAE ISE 1_2026 : PARTIE 1
# ==============================================================================


# ==============================================================================
# Section 1. Import, structuration et nettoyage
# ==============================================================================

if (!require("pacman")) install.packages("pacman")
library(pacman)
p_load(haven, dplyr, ggplot2, tidyr, sf, scales, rstatix,
       viridis, ggrepel, patchwork, readxl, ggplot2, naniar, survey, srvyr)


#dir.create("outputs/tables", recursive = TRUE, showWarnings = FALSE)
#dir.create("outputs/graphs", recursive = TRUE, showWarnings = FALSE)



## 1. Import des cinq sources avec les packages appropriés

ensan_menages <- read_dta("Partie1/data/raw/ensan_menages.dta")

ensan_individus <- read.csv("Partie1/data/raw/ensan_individus.csv", sep =",", dec = ".") |> 
  mutate(hhid = sprintf("%05d", hhid))

ensan_consommation <- read_xlsx("Partie1/data/raw/ensan_consommation.xlsx")

chocs_menages <- read.csv("Partie1/data/raw/chocs_menages.csv", sep =",", dec = ".") |> 
  mutate(hhid = sprintf("%05d", hhid))

shapefile_path <- "Partie1/data/raw/tcd_admin1.shp"
if (!file.exists(shapefile_path)) {
  stop("Shapefile non trouvé. Vérifiez le chemin.")
}

tcd_admin1 <- st_read(shapefile_path)
  
prix_marches <-  read.csv("Partie1/data/raw/prix_marches.csv", sep =",", dec = ".")



## Fusion des modules en un jeu de données
# nombre de ligne avant : 3540

nrow(ensan_menages)

str(ensan_individus)
str(ensan_menages)

ensan_menages$rang <- "1"

ensan_menages$hhid <-  as.numeric(ensan_menages$hhid)
ensan_menages$rang <-  as.numeric(ensan_menages$rang)

ensan_individus$hhid <-  as.numeric(ensan_individus$hhid)
ensan_individus$rang <-  as.numeric(ensan_individus$rang)


ensan_menages <- ensan_menages |> 
  mutate(hhid = sprintf("%05d", hhid))

ensan_individus <- ensan_individus |> 
  mutate(hhid = sprintf("%05d", hhid))

str(ensan_menages)
str(ensan_individus)


ensan_menages1 <- ensan_menages |>
  left_join(ensan_individus, by = c("hhid", "rang"))

nrow(ensan_menages1)


menage <- ensan_menages1 |>
  left_join(ensan_consommation, by = "hhid") |>
  left_join(chocs_menages, by = "hhid")

nrow(menage)

# nombre de ligne aprés : 3540 . Le nombre de ligne avant et aprés reste inchangé.


## 3. Identification et correction des libellés de régions incohérents

admin_labels      <- attr(menage$region, "labels")
admin_codes       <- as.numeric(admin_labels)
admin_names_raw   <- names(admin_labels)
admin_names_clean <- gsub("^[0-9]+\\.\\s*", "", admin_names_raw)
code_to_name      <- data.frame(
  admin_code = admin_codes,
  admin_name = admin_names_clean,
  stringsAsFactors = FALSE
)



## 4. Diagnostic complet des valeurs manquantes avec naniar (résumé, visualisation, cooccurrences)

# Graphique gg_miss_var
p_miss_menage <- menage |>
  select(any_of(names(menage))) |>
  gg_miss_var(show_pct = TRUE) +
  labs(
    title = "Valeurs manquantes",
    x = "Variable",
    y = "% de NA"
  ) +
  theme_minimal()

print(p_miss_menage)
ggsave("Partie1/outputs/graphs/missing_menage.png", p_miss_menage, width = 8, height = 5, dpi = 300)

# Graphique vis_miss pour les patterns

p_vis_menage <- menage |>
  select(any_of(names(menage))) |>
  vis_miss(warn_large_data = FALSE) +
  labs(title = "Patterns de valeurs manquantes")

print(p_vis_menage)
ggsave("Partie1/outputs/graphs/vis_miss_menage.png", p_vis_menage, width = 8, height = 5, dpi = 300)

# Tableau récapitulatif des NA (toutes variables)

missing_menage <- menage |>
  summarise(across(everything(), ~ sum(is.na(.)))) |>
  pivot_longer(everything(), names_to = "variable", values_to = "nb_na") |>
  mutate(pct_na = round(nb_na / nrow(menage) * 100, 2)) |>
  arrange(desc(nb_na))

write.csv(missing_menage, "Partie1/outputs/tables/missing_summary_menage.csv", row.names = FALSE)


## 5. Imputation 

vars_little <- menage |>
  select(revenu, taille_menage) |>
  as.data.frame()

# Test de Little (package naniar)
mcar_test(vars_little)

# le p_value est > 0.05, donc one ne peut pas rejetter l'hypothèse MCAR

library("mice")
library(mice) 

# Imputation multiple (M = 5 jeux de données imputés) 

imp <- mice( 
  menage |> select(revenu, taille_menage, milieu), 
  m     = 5,          # Nombre de jeux imputés 
  maxit = 20,         # Itérations de convergence 
  method = "pmm",     # Predictive Mean Matching (recommandé pour variables continues) 
  seed  = 42 
) 


# Vérifier la convergence 
plot(imp) 

## 6. Recodage des variables catégorielles 

str(menage$milieu)
str(menage$niveau_educ)
str(menage$revenu)

menage$revenu_par_tete <- if_else(menage$taille_menage == 0 | is.na(menage$taille_menage),NA, menage$revenu / menage$taille_menage)

menage <- menage |>
  mutate(
    milieu     = case_when(
      milieu == 1 ~ "Urbain",
      milieu == 2 ~ "Rural",
      TRUE       ~ NA_character_
    )
  )

# ==============================================================================
# Section 2. Statistiques descriptives pondérées et indices composites
# ==============================================================================

## 7. Declation du plan de sondage

design_menage <- svydesign(
  ids     = ~hhid,
  strata = ~strate,
  weights = ~poids_final,
  data    = menage |> filter(!is.na(poids_final))
)

## 8. Construction du score de diversité alimentaire des ménages (HDDS)

menage <- menage |> 
  mutate( 
    # Score HDDS:somme des 12 groupes alimentaires 
    hdds = rowSums(across(starts_with("cons_")), na.rm = TRUE), 
    
    # Classification FAO 
    securite_alim = case_when( 
      hdds <= 3  ~ "Insécurité alimentaire sévère", 
      hdds <= 6  ~ "Insécurité alimentaire modérée", 
      hdds <= 9  ~ "Sécurité alimentaire acceptable", 
      TRUE       ~ "Bonne diversité alimentaire" 
    ) |> factor(levels = c("Insécurité alimentaire sévère", 
                           "Insécurité alimentaire modérée", 
                           "Sécurité alimentaire acceptable", 
                           "Bonne diversité alimentaire"), ordered = TRUE) 
  ) 


## 9. Construction d'un indice composite de vulnérabilité aux chocs

menage <- menage |> 
  mutate( 
    # Score HDDS:somme des 12 groupes alimentaires 
    vuln = rowSums(across(starts_with("choc_")) / 4, na.rm = TRUE) 
    ) 

# seuil de 50%

## tableau descriptif gtsummary 

design_menage <- svydesign(
  ids     = ~hhid,
  strata = ~strate,
  weights = ~poids_final,
  data    = menage |> filter(!is.na(poids_final))
)


tableau <- tbl_svysummary(
  data = design_final,
  by = zone,
  include = c(region, hdds, vuln),
  statistic = list(
    age           ~ "{mean} ({sd})",
    taille_menage ~ "{median} ({p25}, {p75})",
    sexe          ~ "{n_unweighted} ({p}%)"
  ),
  digits = list(age = 1, taille_menage = 0, sexe = 0),
  label = list(
    age           = "Âge (années)",
    sexe          = "Sexe",
    taille_menage = "Taille du ménage"
  )
) %>%
  add_p(
    test = list(
      age           ~ "svy.wilcox.test",
      taille_menage ~ "svy.wilcox.test",
      sexe          ~ "svy.chisq.test"
    )
  ) %>%
  add_overall() %>%
  modify_header(label = "**Caractéristique**") %>%
  modify_spanning_header(c("stat_1", "stat_2") ~ "**Zone de résidence**") %>%
  modify_caption("**Tableau 1 : Caractéristiques démographiques des ménages selon la zone**")

tableau


# 6.6. Export du tableau (HTML et TXT)

tableau %>%
  as_gt() %>%
  gt::gtsave(filename = "outputs/tables/tableau_recap_demographie.html")

tableau %>%
  as_kable() %>%
  writeLines("outputs/tables/tableau_recap_demographie.txt")














## 11. Calculer le coefficient de Gini du revenu par tête au niveau national et par région

#

library(ineq) 

# Coefficient de Gini 
gini_national <- ineq(menage$revenu_par_tete, type = "Gini", na.rm = TRUE) 

# Gini par région 
menage |> 
  group_by(region) |> 
  summarise(gini = ineq(revenu_par_tete, type = "Gini", na.rm = TRUE)) |> 
  arrange(desc(gini)) 

# Courbe de Lorenz 

library(gglorenz) 
p <- ggplot(menage, aes(revenu_par_tete)) + 
  stat_lorenz(color = "#2E75B6", size = 1.2) + 
  geom_abline(linetype = "dashed", color = "gray50") + 
  annotate("text", x = 0.25, y = 0.75, 
           label = paste0("Gini = ", round(gini_national, 3)), 
           size = 4, color = "#1F4E79") + 
  labs(title = "Courbe de Lorenz — Revenu par tête", 
       x = "Part cumulée de la population", 
       y = "Part cumulée du revenu") + 
  theme_minimal(base_size = 12) 


print(p)
ggsave("Partie1/outputs/graphs/Courbe_Lorenz_Revenu_par_tete.png", p, width = 8, height = 5, dpi = 300)



# ==============================================================================
# Section 3. Visualisation 
# ==============================================================================

## 12. Distribution du revenu par tete par région


p_hist <- ggplot(
  menage %>% filter(revenu_par_tete > 0),
  aes(x = revenu_par_tete)
) +
  geom_histogram(bins = 40, fill = "steelblue", color = "white") +
  scale_x_log10(labels = scales::comma) +
  labs(
    x = "Revenu par tete (echelle log)",
    y = "Effectif"
  ) +
  theme_minimal()

ggsave("Partie1/outputs/graphs/Distribution_Revenu_par_tete_log.png", p_hist,
       width = 6, height = 4, dpi = 300)
print(p_hist)


## 13. Carte choroplèthe de l’indice de vulnérabilité par région



# 7.3. Superficie médiane par État (données brutes — non pondérées)
# IMPORTANT : Le plan de sondage du GHS-Panel n'est pas conçu pour produire
# des estimations représentatives au niveau des États (représentatif au niveau
# national et par zone géopolitique uniquement). Les superficianes médianes
# ci-dessous sont calculées sur données brutes et fournies à titre indicatif.

vuln_region <- menage %>%
  group_by(admin_codes = region) %>%
  summarise(
    vuln_moy = mean(vuln, na.rm = TRUE),
    .groups           = "drop"
  ) %>%
  left_join(code_to_name, by = "state_code") %>%
  mutate(
    state_name = case_when(
      state_name == "Federal Capital Territory" ~ "FCT",
      state_name == "Akwa Ibom"                ~ "Akwa Ibom",
      TRUE                                     ~ state_name
    )
  )

print(superf_etat)
write.csv(superf_etat, "outputs/tables/superf_mediane_par_etat.csv",
          row.names = FALSE)



map_data <- tcd_admin1 %>%
  left_join(menage, by = c("adm1_name" = "region"))


# 7.5. Calcul des centroïdes pour les étiquettes

centroids <- st_centroid(map_data)


# 7.6. Carte choroplèthe

p_carte <- ggplot(data = map_data) +
  geom_sf(aes(fill = vuln), color = "white", size = 0.2) +
  geom_sf_text(data = centroids, aes(label = NAME_1),
               size = 2.5, color = "white", fontface = "bold") +
  scale_fill_viridis_c(option   = "plasma",
                       na.value = "grey50",
                       name     = "Superficie\nmediane (ha)") +
  theme_minimal() +
  theme(
    axis.text       = element_blank(),
    axis.title      = element_blank(),
    panel.grid      = element_blank(),
    legend.position = "right"
  )

print(p_carte)
ggsave("outputs/graphs/carte_superf_mediane_par_etat.png", p_carte,
       width = 7, height = 4, dpi = 300)



