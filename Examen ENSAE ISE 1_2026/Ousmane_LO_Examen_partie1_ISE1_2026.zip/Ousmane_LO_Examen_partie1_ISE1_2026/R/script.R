#Packages nécessaires
library(haven)
library(readxl)
library(tidyverse)
library(stringr)
library(naniar)

#======================================================
# Section 1 Import, structuration et nettoyage
#=====================================================

# 1. Importation des cinq sources 
chocs_menage <-read.csv("data/raw/chocs_menages.csv", header= TRUE, sep= ",")
ensan_consommation <- read_excel("data/raw/ensan_consommation.xlsx")
ensan_individu <- read.csv( "data/raw/ensan_individus.csv" , header= TRUE , sep =",")
prix_marches <- read.csv("data/raw/prix_marches.csv", header = TRUE, sep= ",")
ensan_menages <- read_dta("data/raw/ensan_menages.dta")

# 2. Fusion des bases

# On constate que les base ensan_individu , ensan_consommation et ensan_individu  comporte tous une colonne
# hhid. Par conséquent la fusion se fait sur cette colonne

# fusion entre base ensan_individu et base chocs_menage
indiv_chocs_menage <- ensan_individu|>
    inner_join(chocs_menage , by = "hhid")
# on regarde si si la base obtenue comporte le même nombre de lignes
nrow_menage <- nrow(ensan_menages)
nrow_menage_choc_menage
# fusion entre ensan_meange et ensan_consommatoin
menage_consommation <- ensan_menages |>
    inner_join(
        ensan_consommation , 
        by = "hhid"
    )

# fusion complete des base 
# Comme la variables hhid dans les deux base n'est pas de même type, on transforme l'une avant toute jointure

menage_enrechi<- menage_consommation |>
    mutate(
        hhid = as.numeric(hhid)
    ) |> left_join(
        indiv_chocs_menage , by = "hhid"
    )

# 3. Identification et correction des libellé des régions

# on peut constater les certains région porte le même nom mais avec des casses différentes.
# on rammene tout en minuscule
menage_enrechi <- menage_enrechi |>
    mutate(
        region = str_to_lower(region)
    )

# 4. Diagnostic des valeurs manquantes
nb_manquante <- sum(is.na(menage_enrechi))
nan <- naniar::vis_miss(menage_enrechi)
ggsave(nan, file = "output/figures/nan.png")
# Graphique des valeurs manquantes
gg_nan <- naniar::gg_miss_var(menage_enrechi) 
ggsave(gg_nan , file = "output/figures/gg_mis_var.png")


#===================================================================
#Section 2. Statistique descriptives pondérées et indices composite
#==================================================================

    
# 7. Déclaration du plan de sondage avec survey
survey <- survey_desig
#==================================================================
# Section 3 Visualisation
#=================================================================

# 12. Distribution du revenu par tête par region
 # Comme le revenu est le reveu mensuel par menage alors, on doit calculer le reveu par tête
menage_enrechi <- menage_enrechi |>
    filter(!is.na(region))|>
    mutate(
        revenu_par_tete = revenu/taille_menage
    )
 # Distribution du revenu par tete

revenu_region <- menage_enrechi |>
    select(region, poids_final, revenu_par_tete)|>
    filter(!is.na(revenu_par_tete))|>
    filter(!is.na(poids_final))|>
    group_by(region) |>
    summarise(
        effectif = n(),
        rev = sum(revenu_par_tete*poids_final)/ n()
    )
# representation graphique

    

