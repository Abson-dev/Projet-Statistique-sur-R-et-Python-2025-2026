
#Library necessaires:

library("tidyverse")
library("haven")
library("readxl")
library("dplyr")
library("tidyr")
library("sf")
library("janitor")
library("naniar")
library("survey")
library("srvyr")

#1.Importer les cinq sources avec les packages appropriés,
#---------------------------------------------------------------------------------------
ensan_menages <- read_dta("data/raw/ensan_menages.dta")
ensan_individus<-read_csv("data/raw/ensan_individus.csv")
chocs_menages<-read_csv("data/raw/chocs_menages.csv")
prix_marches<-read_csv("data/raw/prix_marches.csv")
ensan_consommation<-read_excel("data/raw/ensan_consommation.xlsx")

#Netoyage des noms de variables incoherent avec Janitor avant le jointure
clean_names(chocs_menages)
clean_names(ensan_consommation)
clean_names(ensan_individus)
clean_names(ensan_menages)

#2.Fusionner deux à deux les bases: premiers bases: chocs_menages et ensan_consommation
#---------------------------------------------------------------------------------------

base1_choc_consomm <- left_join(chocs_menages, ensan_consommation, by="hhid")
base2_choc_consomm_ensmen<- left_join(base1_choc_consomm, ensan_menages, by="hhid")
#base3_choc_consomm_indiv<- left_join(base2_choc_consomm_indiv, ensan_menages, by="hhid")

#On doit préparer la base menage correspondant à la base ensan_individus pour faire le jointure suivant
base_chefs <- ensan_individus %>%
  filter(rang == 1) %>%
  distinct(hhid, .keep_all = TRUE) 
#(on a gardé le rang =1 qui correspond au chef de ménage).

#Maintenant on peut joindre ce nouvelle base au base precedent
base_all<- left_join(base2_choc_consomm_ensmen,base_chefs, by="hhid")




#sauvegarde des données dans data/processed
write_dta(base_all,"data/processed/base_all.dta")

#3.Identifier et corriger les libellés de régions
#--------------------------------------------------------------------------------------
clean_names(base_all)

#recapitulatif des valeurs manquantes evec le package naniar:
all_miss(base_all)
all_na(base_all)
#il n'y a pas de valeur manquante d'après le résultat

#Section2: plan de sondage
plan_sondage <- base_all |> as_survey_design( ids = grappe, # Identifiant des grappes (PSU) 
                                             strata = strate,  # Variable de stratification 
                                             weights = poids_final, # Poids de sondage finaux nest = TRUE 
                                             )
                                             
#Section2: Construction de score de diversité alimentaire (on somme juste les variables dichotomiques consommations sauf le condiment)
menage <- base_all %>%
  mutate(HDDS = rowSums(across(c(cons_cereales, cons_tubercules, cons_legumineuses , cons_legumes, cons_fruits, cons_viande, cons_poisson, cons_oeufs, cons_lait, cons_huile, cons_sucre)), na.rm = TRUE))

#Construction des indices composites de vulnérabilité aux choc (on somme tous les chocs et les stratégies adoptés)
menage <- base_all %>%
  mutate(indic_vulnerability = rowSums(across(c(choc_secheresse, choc_hausse_prix, choc_conflit , choc_maladie, strat_vente_actifs, strat_reduction_repas, strat_migration, strat_endettement)), na.rm = TRUE))




