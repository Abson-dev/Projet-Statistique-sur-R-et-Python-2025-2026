# ============================================================================
# PARTIE 1 : Vulnerabilite aux chocs et securite alimentaire
# ============================================================================

## ---- libraries 
library(tidyverse)   
library(haven)       
library(readxl)      
library(janitor)     
library(naniar)      
library(mice)        
library(srvyr)       
library(survey)      
library(gtsummary)   
library(sf)          
library(scales)      


## ===========================================================================
## SECTION 1 IMPORT, STRUCTURATION, NETTOYAGE
## ===========================================================================

# ---- Q1. Import des cinq sources -------------------------------------------
menage <- read_dta("data/raw/ensan_menages.dta")   

individu <- read_csv(
  "data/raw/ensan_individus.csv",
  col_types = cols(
    hhid        = col_integer(),   
    rang        = col_integer(),
    age         = col_double(),
    sexe        = col_integer(),
    niveau_educ = col_character()
  ),
  locale = locale(encoding = "UTF-8")
)

# Consommation 
conso    <- read_excel("data/raw/ensan_consommation.xlsx", sheet = "Consommation_groupes")
depenses <- read_excel("data/raw/ensan_consommation.xlsx", sheet = "Depenses_menage")

choc <- read_csv(
  "data/raw/chocs_menages.csv",
  col_types = cols(hhid = col_integer(), region_lib = col_character(),
                   .default = col_integer()),
  locale = locale(encoding = "UTF-8")
)

prix <- read_csv(
  "data/raw/prix_marches.csv",
  col_types = cols(marche = col_character(), region = col_character(),
                   produit = col_character(), mois = col_date("%Y-%m-%d"),
                   prix_fcfa_kg = col_double()),
  locale = locale(encoding = "UTF-8")
)

admin1 <- st_read("data/raw/tcd_admin1.shp", quiet = TRUE)

# ---- Verification des doublons ---------------------------------------------
sum(duplicated(menage))                 # 0 
n_dup_ind <- individu |> janitor::get_dupes(hhid, rang) |> nrow()
cat("Doublons individus (hhid, rang) :", n_dup_ind, "\n")
individu <- distinct(individu)          # on retire les doublons exacts
sum(duplicated(conso)); sum(duplicated(choc)); sum(duplicated(prix))

# ---- Q3. Harmonisation des libelles de region
harmoniser_region <- function(x) {
  cle <- x |>
    str_to_upper() |>
    stringi::stri_trans_general("Latin-ASCII") |>   
    str_replace_all("[_'’-]", " ") |>
    str_squish()
  cle <- case_match(cle,
                    "OUADAI" ~ "OUADDAI", "TANDJILLE" ~ "TANDJILE",
                    "NDJAMENA" ~ "N DJAMENA", .default = cle)
  corr <- c(
    "BARH EL GAZEL"="Barh El Gazel","BATHA"="Batha","BORKOU"="Borkou",
    "CHARI BAGUIRMI"="Chari Baguirmi","ENNEDI EST"="Ennedi Est",
    "ENNEDI OUEST"="Ennedi Ouest","GUERA"="Guéra","HADJER LAMIS"="Hadjer Lamis",
    "KANEM"="Kanem","LAC"="Lac","LOGONE OCCIDENTAL"="Logone Occidental",
    "LOGONE ORIENTAL"="Logone Oriental","MANDOUL"="Mandoul",
    "MAYO KEBBI EST"="Mayo Kebbi Est","MAYO KEBBI OUEST"="Mayo Kebbi Ouest",
    "MOYEN CHARI"="Moyen Chari","N DJAMENA"="N'Djamena","OUADDAI"="Ouaddaï",
    "SALAMAT"="Salamat","SILA"="Sila","TANDJILE"="Tandjilé","TIBESTI"="Tibesti",
    "WADI FIRA"="Wadi Fira")
  unname(corr[cle])
}

menage  <- menage |> mutate(hhid = as.character(hhid))   # deja "00001"
choc    <- choc   |> mutate(region = harmoniser_region(region_lib))
admin1  <- admin1 |> mutate(region = harmoniser_region(adm1_name))
stopifnot(all(choc$region  %in% menage$region),
          all(admin1$region %in% menage$region))

# ---- Q2. Fusion en un jeu menages enrichi 
cle5 <- function(x) str_pad(as.character(as.integer(x)), 5, pad = "0")

# chef de menage = rang 1
chefs <- individu |>
  mutate(hhid = cle5(hhid)) |>
  filter(rang == 1) |>
  transmute(hhid,
            age_chef  = age,
            sexe_chef = factor(sexe, 1:2, c("Homme","Femme")),
            educ_chef = niveau_educ)

n0 <- nrow(menage)
base <- menage |>
  left_join(chefs,                    by = "hhid"); stopifnot(nrow(base)==n0)
base <- base |>
  left_join(mutate(conso,    hhid=cle5(hhid)), by="hhid"); stopifnot(nrow(base)==n0)
base <- base |>
  left_join(mutate(depenses, hhid=cle5(hhid)), by="hhid"); stopifnot(nrow(base)==n0)
base <- base |>
  left_join(mutate(choc, hhid=cle5(hhid)) |> select(-region_lib, -region),
            by="hhid"); stopifnot(nrow(base)==n0)
cat("Fusion OK :", nrow(base), "lignes (=", n0, ")\n")

# ---- Q4. Diagnostic des valeurs manquantes ---------------------------------
sapply(c("revenu","taille_menage"), \(v) sum(haven::is_tagged_na(base[[v]])))
base <- base |> haven::zap_missing() |> haven::zap_labels()

miss_var_summary(base) |> filter(pct_miss > 0) |> print()
gg_miss_var(base, show_pct = TRUE)  


# ---- Q5. Mecanisme de non-reponse + imputation mice 
# revenu   : la non-reponse depend de variables OBSERVEES (milieu, depenses) :
#            hypothese MAR verifiee : le taux de NA differe selon le milieu).
# educ_chef: MAR conditionnellement a age et milieu.
base <- base |>
  mutate(milieu = haven::as_factor(zap_labels(read_dta("data/raw/ensan_menages.dta")$milieu)))

base |> group_by(milieu = haven::as_factor(menage$milieu)) |>
  summarise(pct_na_revenu = mean(is.na(revenu))*100) |> print()

a_imputer <- base |>
  select(hhid, revenu, taille_menage, age_chef, educ_chef,
         dep_alimentaire, dep_sante, choc_secheresse, choc_hausse_prix) |>
  mutate(educ_chef = factor(educ_chef,
                            levels=c("Aucun","Primaire","Secondaire","Superieur"),
                            ordered = TRUE))

meth <- make.method(a_imputer); meth[] <- ""
meth[c("revenu","taille_menage","age_chef")] <- "pmm"
meth["educ_chef"] <- "polr"
pred <- make.predictorMatrix(a_imputer)
pred[,"hhid"] <- 0; pred["hhid",] <- 0

imp <- mice(a_imputer, m = 5, maxit = 10, method = meth,
            predictorMatrix = pred, seed = 2026, printFlag = FALSE)
plot(imp)                                                 # convergence

# jeu complete (imputation n0 1) reinjecte dans base
comp1 <- complete(imp, 1) |> select(hhid, revenu, taille_menage, educ_chef, age_chef)
base <- base |>
  select(-revenu, -taille_menage, -educ_chef, -age_chef) |>
  left_join(comp1, by = "hhid")

# ---- Q6. Recodages categoriels 
base <- base |>
  mutate(
    milieu = haven::as_factor(menage$milieu) |> fct_relevel("Urbain","Rural"),
    educ_chef = factor(educ_chef,
                       levels=c("Aucun","Primaire","Secondaire","Superieur"),
                       ordered = TRUE),
    revenu_pc = revenu / taille_menage                    # revenu par tete
  )
# quintiles de revenu par tete PONDERES
o  <- order(base$revenu_pc)
Fw <- cumsum(base$poids_final[o]) / sum(base$poids_final)
seuils <- sapply(seq(.2,.8,.2), \(p) base$revenu_pc[o][which.min(abs(Fw-p))])
base <- base |>
  mutate(quintile_rev = cut(revenu_pc, c(-Inf, seuils, Inf), labels=paste0("Q",1:5)))

## ===========================================================================
## SECTION 2 -- STATISTIQUES PONDEREES ET INDICES
## ===========================================================================

# ---- Q8. HDDS + classification FAO
groupes_fao <- c("cons_cereales","cons_tubercules","cons_legumineuses",
                 "cons_legumes","cons_fruits","cons_viande","cons_poisson","cons_oeufs",
                 "cons_lait","cons_huile","cons_sucre","cons_condiments")
base <- base |>
  mutate(hdds = rowSums(across(all_of(groupes_fao))),
         hdds_classe = cut(hdds, c(-Inf,4,6,Inf),
                           labels=c("Faible (<=4)","Moyenne (5-6)","Elevee (>=7)")),
         insecure_alim = hdds <= 4)

# ---- Q9. Indice composite de vulnerabilite ---------------------------------
# 1/2 exposition (chocs ponderes par gravite) + 1/2 adaptation (strategies
# ponderees par severite), chaque composante normalisee min-max sur [0,1].
pc <- c(choc_hausse_prix=1, choc_secheresse=2, choc_maladie=2, choc_conflit=3)
ps <- c(strat_reduction_repas=1, strat_endettement=2,
        strat_vente_actifs=3, strat_migration=4)
nrm <- function(x) (x-min(x,na.rm=TRUE))/(max(x,na.rm=TRUE)-min(x,na.rm=TRUE))
base <- base |>
  mutate(
    exposition = as.numeric(as.matrix(pick(all_of(names(pc)))) %*% pc),
    adaptation = as.numeric(as.matrix(pick(all_of(names(ps)))) %*% ps),
    indice_vuln = 0.5*nrm(exposition) + 0.5*nrm(adaptation))

# ---- Q7. Plan de sondage srvyr ---------------------------------------------
plan <- base |>
  as_survey_design(ids = grappe, strata = strate,
                   weights = poids_final, nest = TRUE)

# indicateurs ponderes de cadrage
plan |> summarise(
  hdds_moyen    = survey_mean(hdds, vartype="ci"),
  part_insecure = survey_mean(insecure_alim, vartype="ci"),
  vuln_moyenne  = survey_mean(indice_vuln, vartype="ci")) |> print()

ind_region <- plan |>
  group_by(region) |>
  summarise(hdds = survey_mean(hdds),
            insecure = survey_mean(insecure_alim),
            vuln = survey_mean(indice_vuln),
            n = unweighted(n())) |>
  arrange(desc(vuln))
print(ind_region, n = 23)

# ---- Q10. Tableau 1 pondere -------------------------------------------------
tbl1 <- plan |>
  select(milieu, hdds, insecure_alim, indice_vuln, revenu_pc,
         taille_menage, sexe_chef, educ_chef) |>
  tbl_svysummary(by = milieu,
                 statistic = list(all_continuous() ~ "{mean} ({sd})",
                                  all_categorical() ~ "{p}%"),
                 missing = "no") |>
  add_p() |> add_overall() |> add_n() |>
  modify_caption("**Tableau 1. Indicateurs cles par milieu (ponderes)**")
tbl1

# ---- Q11. Gini du revenu par tete + IC bootstrap ---------------------------
gini_pondere <- function(y, w) {
  ok <- !is.na(y) & !is.na(w); y<-y[ok]; w<-w[ok]; o<-order(y); y<-y[o]; w<-w[o]
  p <- w/sum(w); cp <- cumsum(p); cy <- cumsum(p*y)/sum(p*y)
  1 - 2*sum(diff(c(0,cp))*(cy+lag(cy,default=0))/2)
}
boot_gini <- function(d, B=1000){
  psu <- distinct(d, strate, grappe)
  replicate(B, {
    t <- psu |> group_by(strate) |> slice_sample(prop=1, replace=TRUE) |> ungroup()
    e <- left_join(t, d, by=c("strate","grappe"), relationship="many-to-many")
    gini_pondere(e$revenu_pc, e$poids_final)
  })
}
g_nat <- gini_pondere(base$revenu_pc, base$poids_final)
ic    <- quantile(boot_gini(base, 1000), c(.025,.975))
cat(sprintf("Gini national : %.3f  IC95 [%.3f ; %.3f]\n", g_nat, ic[1], ic[2]))

## ===========================================================================
## SECTION 3 -- VISUALISATION
## ===========================================================================
theme_set(theme_minimal(base_size = 11))
pal <- c("#1B7837","#2166AC")

# ---- Q12. Densites du revenu par tete (echelle log) ------------------------
g12 <- base |>
  ggplot(aes(revenu_pc, colour = milieu, fill = milieu)) +
  geom_density(alpha=.25) +
  scale_x_log10(labels = label_number(big.mark=" ")) +
  scale_colour_manual(values=pal) + scale_fill_manual(values=pal) +
  facet_wrap(~region, ncol=4, scales="free_y") +
  labs(title="Revenu par tete par region (echelle log)",
       x="Revenu par tete (FCFA, log10)", y="Densite", colour=NULL, fill=NULL)
g12

# ---- Q13. Carte choroplethe de la vulnerabilite ----------------------------
vr <- plan |> group_by(region) |>
  summarise(vuln = survey_mean(indice_vuln)) |> select(region, vuln)
carte <- admin1 |> left_join(vr, by="region")
g13 <- ggplot(carte) +
  geom_sf(aes(fill=vuln), colour="white", linewidth=.3) +
  scale_fill_gradientn(colours=c("#1B7837","#F7F7F7","#B2182B")) +
  labs(title="Indice de vulnerabilite par region", fill="Vulnerabilite") +
  theme(axis.text=element_blank(), panel.grid=element_blank())
g13
# Version interactive tmap (si installe) :
# library(tmap); tmap_mode("view"); tm_shape(carte)+tm_polygons("vuln")

# ---- Q14/Q15. Figure composee patchwork + exports --------------------------
library(patchwork)
gA <- ind_region |> ggplot(aes(reorder(region,hdds), hdds)) +
  geom_col(fill=pal[1]) + coord_flip() + labs(title="HDDS par region", x=NULL,y="HDDS")
gB <- base |> ggplot(aes(quintile_rev, fill=milieu)) + geom_bar(position="fill") +
  scale_fill_manual(values=pal) + labs(title="Milieu par quintile", x=NULL,y=NULL,fill=NULL)
fig <- (gA | gB) + plot_annotation(tag_levels="A")
fig
dir.create("output/figures", recursive = TRUE, showWarnings = FALSE)
ggsave("output/figures/densite_revenu.png", g12, width=11, height=9, dpi=300)
ggsave("output/figures/carte_vuln.png",     g13, width=9,  height=8, dpi=300)
ggsave("output/figures/figure_composee.png",fig, width=12, height=6, dpi=300)
ggsave("output/figures/figure_composee.pdf",fig, width=12, height=6)

