# Devoir — Projet Statistique sous R (ISE 1, 2025-2026)

**Auteur :** Prénom NOM
**Données :** Nigeria General Household Survey (GHS) Panel — Vague 4 (2018), LSMS-ISA / Banque Mondiale

## Question de recherche
_À compléter (1-2 phrases)._

## Structure du dépôt
```
.
├── projet.Rproj          # ouvrir CE fichier dans RStudio
├── data/
│   ├── raw/              # .dta bruts — JAMAIS modifiés (non versionnés si lourds)
│   └── processed/        # données nettoyées
├── R/  (ou scripts/)     # scripts .R numérotés (01_import.R, 02_nettoyage.R...)
├── output/
│   ├── figures/          # graphiques exportés (png/pdf)
│   └── tables/           # tableaux exportés
├── rapport/
│   └── rapport_final.Rmd # rapport R Markdown (Word + HTML)
└── README.md
```

## Comment reproduire
1. Ouvrir `projet.Rproj` dans RStudio.
2. Placer les fichiers `.dta` dans `data/raw/`.
3. Ouvrir `rapport/rapport_final.Rmd` et cliquer **Knit**.

## Indicateurs construits
- Crowding index (indice d'affluence)
- FCS / SCA (Score de Consommation Alimentaire)
- rCSI (indice réduit des stratégies de survie)

## Reproductibilité
- `set.seed(42)` pour tout tirage aléatoire.
- Packages gérés via `pacman::p_load()` (voir en-tête du .Rmd).
```
```
