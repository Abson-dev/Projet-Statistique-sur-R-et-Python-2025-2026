# Chargement des packages
library(tidyverse)
library(gtsummary)
library(janitor)
library(naniar) 
renv::snapshot() 
library(mice)

library(survey)