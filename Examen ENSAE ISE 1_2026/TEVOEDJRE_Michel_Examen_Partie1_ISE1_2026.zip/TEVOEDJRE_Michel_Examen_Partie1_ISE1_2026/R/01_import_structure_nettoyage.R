# cgemins vers les bases et chargement des bases
menages <- read_dta(here("data", "raw", "ensan_menages.dta")) |>
  mutate(milieu = as_factor(milieu))
individus <- read_csv(here("data", "raw", "ensan_individus.csv"), show_col_types = FALSE)
conso_groupes <- read_excel(here("data", "raw", "ensan_consommation.xlsx"),
                            sheet = "Consommation_groupes")
depenses      <- read_excel(here("data", "raw", "ensan_consommation.xlsx"),
                            sheet = "Depenses_menage")
chocs <- read_csv(here("data", "raw", "chocs_menages.csv"), show_col_types = FALSE)
prix <- read_csv(here("data", "raw", "prix_marches.csv"), show_col_types = FALSE) |>
  mutate(mois = as.Date(mois))
tcd_admin1 <- st_read(here("data", "raw", "tcd_admin1.shp"), quiet = TRUE)

# exploration globale des données
#View(menages)
#View(chocs)
#View(conso_groupes)
#View(depenses)
#View(individus)
#View(prix)
cat(sprintf("menages       : %d obs x %d vars\n", nrow(menages),       ncol(menages)))
cat(sprintf("individus     : %d obs x %d vars\n", nrow(individus),     ncol(individus)))
cat(sprintf("conso_groupes : %d obs x %d vars\n", nrow(conso_groupes), ncol(conso_groupes)))
cat(sprintf("depenses      : %d obs x %d vars\n", nrow(depenses),      ncol(depenses)))
cat(sprintf("chocs         : %d obs x %d vars\n", nrow(chocs),         ncol(chocs)))
cat(sprintf("prix          : %d obs x %d vars\n", nrow(prix),          ncol(prix)))
cat(sprintf("tcd_admin1    : %d entites (sf)\n",   nrow(tcd_admin1)))
print(names(tcd_admin1))

# verification doublons
cat("Doublons hhid (menages) :", sum(duplicated(menages$hhid)), "\n")
cat("Doublons hhid (conso)   :", sum(duplicated(conso_groupes$hhid)), "\n")
cat("Doublons hhid (chocs)   :", sum(duplicated(chocs$hhid)), "\n")
cat("Doublons hhid (depenses)   :", sum(duplicated(depenses$hhid)), "\n")
cat("Doublons hhid (individus)   :", sum(duplicated(individus$hhid)), "\n")
## normal (plusieurs individus dans un meme menage)

# agregation chef menage (on va choisir le chef )
chef_menage <- individus |>
  filter(rang == 1) |>
  group_by(hhid) |>
  slice_max(age, n = 1, with_ties = FALSE) |>
  ungroup() |>
  transmute(
    hhid,
    age_chef       = age,
    sexe_chef      = factor(sexe, levels = c(1, 2), labels = c("Homme", "Femme")),
    educ_chef      = factor(niveau_educ,
                            levels = c("Aucun", "Primaire", "Secondaire", "Superieur"))
  )
#View(chef_menage)

# aggregation des individus
menage_indiv <- individus |>
  group_by(hhid) |>
  summarise(
    taille_observee = n(),
    n_hommes        = sum(sexe == 1, na.rm = TRUE),
    n_femmes        = sum(sexe == 2, na.rm = TRUE),
    age_moyen       = mean(age, na.rm = TRUE),
    .groups = "drop"
  ) |>
  left_join(chef_menage,by = "hhid")

#View(menage_indiv)

# jointure menage
df_menage <- menages |>
  left_join(menage_indiv, by = "hhid") |>
  left_join(conso_groupes, by = "hhid") |>
  left_join(depenses,      by = "hhid")

#View(df_menage)

# verification des problemes region
cat("\nLibelles distincts region (df_menage)    :", n_distinct(df_menage$region), "\n")
cat("Libelles distincts region_lib (chocs)   :", n_distinct(chocs$region_lib), "\n")
print(sort(unique(chocs$region_lib)))

# correction region
correction_region <- tribble(
  ~region_lib,          ~region,
  "BARH_EL_GAZEL",      "Barh El Gazel",
  "BATHA",              "Batha",
  "BORKOU",             "Borkou",
  "CHARI_BAGUIRMI",     "Chari Baguirmi",
  "ENNEDI_EST",         "Ennedi Est",
  "ENNEDI_OUEST",       "Ennedi Ouest",
  "GUERA",              "Guéra",
  "GUÉRA",         "Guéra",
  "HADJER_LAMIS",       "Hadjer Lamis",
  "KANEM",              "Kanem",
  "LAC",                "Lac",
  "LOGONE_OCCIDENTAL",  "Logone Occidental",
  "LOGONE_ORIENTAL",    "Logone Oriental",
  "MANDOUL",            "Mandoul",
  "MAYO_KEBBI_EST",     "Mayo Kebbi Est",
  "MAYO_KEBBI_OUEST",   "Mayo Kebbi Ouest",
  "MOYEN_CHARI",        "Moyen Chari",
  "NDJAMENA",           "N'Djamena",
  "OUADAI",             "Ouaddaï",
  "OUADDAÏ",       "Ouaddaï",
  "SALAMAT",            "Salamat",
  "SILA",               "Sila",
  "TANDJILLE",          "Tandjilé",
  "TANDJILÉ",      "Tandjilé",
  "TIBESTI",            "Tibesti",
  "WADI_FIRA",          "Wadi Fira"
)

# correction region dans chocs
chocs <- chocs |> left_join(correction_region, by = "region_lib")
chocs <- chocs |> select(-region_lib)
#View(chocs)
cat("regViewion_lib non recodes apres jointure :", sum(is.na(chocs$region)), "\n")

# jointure regions correctes
df_menage <- df_menage |> select(-region) |>
  left_join(chocs, by = "hhid")
# View(df_menage)

# confirmation
cat("\nLibelles distincts region (df_menage)    :", n_distinct(df_menage$region), "\n")
cat("Libelles distincts region_lib (chocs)   :", n_distinct(chocs$region), "\n")
print(sort(unique(chocs$region)))

# diagnostic des valeurs manquantes
vars_diag <- df_menage |> select(hhid, region, milieu, revenu, taille_menage, poids_final)
miss_summary <- miss_var_summary(vars_diag)
print(miss_summary)

fig00 <- vis_miss(vars_diag |> select(-hhid), sort_miss = TRUE) +
  labs(title = "Diagnostic des valeurs manquantes",
       subtitle = "Menages -- ENSAN 2026",
       caption = source_ensan) +
  theme_ensan(base_size = 10) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
ggsave(here("output", "figures", "fig00_diagnostic_NA.png"), fig00, width = 9, height = 4.5, dpi = 300)

# distinctions entre NA stata
sapply(df_menage, function(x) if (is.double(x)) sum(haven::is_tagged_na(x)) else NA)

# Revenu par tete  quintiles 
df_menage <- df_menage |>
  mutate(
    revenu_par_tete = revenu / taille_menage,
    quintile        = ntile(revenu_par_tete, 5),
    quintile_f      = factor(quintile, levels = 1:5,
                             labels = c("Q1 (plus pauvre)", "Q2", "Q3", "Q4",
                                        "Q5 (plus riche)"))
  )

# milieu géré lors de l'importation de la base "menages)
# education du CM géré lors de agregation chef menage


print("Fin de la section 1")