# Thème graphique ENSAN 2026 (Tchad)

couleur_ensan <- list(
  fond       = "#F7F5F0",
  texte      = "#2B2B2B",
  grille     = "#D9D5CB",
  principal  = "#1B6B5A",
  secondaire = "#C96A2C",
  palette_d  = c(
    "#1B6B5A", "#C96A2C", "#2E6F9E", "#B0413E",
    "#8C6D46", "#4E8B3B", "#7A5C99", "#C9A227"
  ),
  palette_c  = c("#F7F5F0", "#C96A2C", "#8C1D1D")
)

# Thème général : graphiques ggplot2
theme_ensan <- function(base_size = 11, base_family = "") {
  theme_minimal(base_size = base_size, base_family = base_family) %+replace%
    theme(
      plot.title = element_text(
        face = "bold", size = rel(1.15), colour = couleur_ensan$texte,
        hjust = 0, margin = margin(b = 4)
      ),
      plot.subtitle = element_text(
        size = rel(0.9), colour = couleur_ensan$texte,
        hjust = 0, margin = margin(b = 8)
      ),
      plot.caption = element_text(
        size = rel(0.65), colour = "grey40", hjust = 1, margin = margin(t = 8)
      ),
      plot.background  = element_rect(fill = couleur_ensan$fond, colour = NA),
      panel.background = element_rect(fill = couleur_ensan$fond, colour = NA),
      panel.grid.major = element_line(colour = couleur_ensan$grille, linewidth = 0.3),
      panel.grid.minor = element_blank(),
      axis.title  = element_text(colour = couleur_ensan$texte, size = rel(0.85)),
      axis.text   = element_text(colour = couleur_ensan$texte, size = rel(0.8)),
      legend.title      = element_text(size = rel(0.85), face = "bold"),
      legend.text       = element_text(size = rel(0.8)),
      legend.background = element_rect(fill = couleur_ensan$fond, colour = NA),
      legend.key        = element_rect(fill = couleur_ensan$fond, colour = NA),
      strip.text       = element_text(face = "bold", colour = couleur_ensan$texte),
      strip.background = element_rect(fill = "grey90", colour = NA),
      plot.margin = margin(10, 12, 10, 12)
    )
}

# Variante pour les cartes (sf) : masque les axes/graticules
theme_ensan_carte <- function(base_size = 11, base_family = "") {
  theme_ensan(base_size = base_size, base_family = base_family) %+replace%
    theme(
      axis.text   = element_blank(),
      axis.title  = element_blank(),
      axis.ticks  = element_blank(),
      panel.grid  = element_blank(),
      panel.background = element_rect(fill = couleur_ensan$fond, colour = NA)
    )
}

# Échelles discrètes / continues assorties à la palette ENSAN
# La palette de base (8 teintes) est interpolée si le nombre de
# modalités à colorer est plus grand (ex. les 23 régions du Tchad).
palette_ensan_d <- function(n) {
  base <- couleur_ensan$palette_d
  if (n <= length(base)) base[seq_len(n)] else grDevices::colorRampPalette(base)(n)
}

scale_fill_ensan_d <- function(...) {
  discrete_scale(aesthetics = "fill", palette = palette_ensan_d, ...)
}

scale_color_ensan_d <- function(...) {
  discrete_scale(aesthetics = "colour", palette = palette_ensan_d, ...)
}

scale_fill_ensan_c <- function(...) {
  scale_fill_gradientn(colours = couleur_ensan$palette_c, ...)
}

scale_color_ensan_c <- function(...) {
  scale_color_gradientn(colours = couleur_ensan$palette_c, ...)
}
