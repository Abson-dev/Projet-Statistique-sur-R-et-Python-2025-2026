# Représenter la distribution du revenu par tête par région
fig01 <- df_menage |>
  filter(!is.na(revenu_par_tete)) |>
  ggplot(aes(
    x = revenu_par_tete, y = fct_reorder(region, revenu_par_tete, .fun = median),
    fill = fct_reorder(region, revenu_par_tete, .fun = median)
  )) +
  geom_boxplot(outlier.alpha = 0.4, show.legend = FALSE) +
  scale_x_log10(labels = scales::label_number(big.mark = " ")) +
  scale_fill_ensan_d() +
  labs(
    title = "Revenu par tête, par région",
    x = "Revenu par tête (FCFA, échelle log)", y = NULL,
    caption = source_ensan
  ) +
  theme_ensan(base_size = 10)
fig01
ggsave(here("output", "figures", "fig01_revenu_tete_region.png"), fig01, width = 8, height = 7, dpi = 300)

# Carte choroplethe de l'indice de vulnerabilite par region (sf + ggplot2, puis tmap)
seuil_pauvrete <- df_menage |>
  filter(!is.na(revenu_par_tete)) |>
  summarise(med = median(revenu_par_tete)) |>
  pull(med)

normalise <- function(x, inverser = FALSE) {
  r <- (x - min(x)) / (max(x) - min(x))
  if (inverser) 1 - r else r
}

vuln_region <- plan_svy |>
  filter(!is.na(region)) |>
  mutate(pauvre = as.integer(revenu_par_tete < seuil_pauvrete)) |>
  group_by(region) |>
  summarise(
    taux_pauvrete  = survey_mean(pauvre, na.rm = TRUE) * 100,
    sda_moyen      = survey_mean(sda_score, na.rm = TRUE),
    taux_choc      = survey_mean(a_subi_choc, na.rm = TRUE) * 100,
    strategies_moy = survey_mean(n_strategies, na.rm = TRUE),
    part_alim_moy  = survey_mean(part_alimentaire, na.rm = TRUE) * 100
  ) |>
  select(region, taux_pauvrete, sda_moyen, taux_choc, strategies_moy, part_alim_moy) |>
  mutate(
    z_pauvrete   = normalise(taux_pauvrete),
    z_diversite  = normalise(sda_moyen, inverser = TRUE),
    z_choc       = normalise(taux_choc),
    z_strategies = normalise(strategies_moy),
    z_alim       = normalise(part_alim_moy),
    indice_vuln  = 100 * (z_pauvrete + z_diversite + z_choc + z_strategies + z_alim) / 5
  )

# jointure au fond de carte
carte_vuln <- tcd_admin1 |>
  mutate(region = str_to_title(adm1_name)) |>
  mutate(region = if_else(region == "N'djamena", "N'Djamena", region)) |>
  left_join(vuln_region, by = "region")

# carte statique
fig02 <- ggplot(carte_vuln) +
  geom_sf(aes(fill = indice_vuln), color = "white", linewidth = 0.2) +
  scale_fill_ensan_c(name = "Indice de\nvulnérabilité") +
  labs(
    title = "Indice de vulnérabilité, par région",
    subtitle = "Pauvreté, diversité alimentaire, chocs, stratégies d'adaptation, part alimentaire",
    caption = source_ensan
  ) +
  theme_ensan_carte(base_size = 10)
fig02
ggsave(here("output", "figures", "fig02_carte_vulnerabilite.png"), fig02, width = 8, height = 7, dpi = 300)

# carte tmap
tmap_mode("view")

carte_interactive <- tm_shape(carte_vuln) +
  tm_polygons(
    fill = "indice_vuln",
    fill.scale = tm_scale_continuous(values = "-inferno"),
    fill.legend = tm_legend(title = "Indice de vulnérabilité"),
    id = "region",
    popup.vars = c(
      "Indice" = "indice_vuln", "Taux pauvreté (%)" = "taux_pauvrete",
      "Taux choc (%)" = "taux_choc", "Score diversité" = "sda_moyen"
    )
  ) +
  tm_title("Indice composite de vulnérabilité, par région (ENSAN 2026, Tchad)")
carte_interactive
tmap_save(carte_interactive, here("output", "figures", "fig02_carte_vulnerabilite_interactive.html"))

# Figure patchwork
fig_combinee <- (fig00 | fig01) / fig02 +
  plot_layout(heights = c(1, 1.3)) +
  plot_annotation(
    title = "Portrait de la vulnérabilité et des revenus des ménages -- ENSAN 2026, Tchad",
    subtitle = "Diagnostic des données manquantes, dispersion du revenu par tête et indice de vulnérabilité, par région",
    caption = source_ensan,
    theme = theme_ensan(base_size = 12)
  ) &
  theme(plot.background = element_rect(fill = couleur_ensan$fond, colour = NA))
fig_combinee
ggsave(here("output", "figures", "fig03_panel_synthese.png"), fig_combinee, width = 13, height = 11, dpi = 300)

print("Fin de la section 3")