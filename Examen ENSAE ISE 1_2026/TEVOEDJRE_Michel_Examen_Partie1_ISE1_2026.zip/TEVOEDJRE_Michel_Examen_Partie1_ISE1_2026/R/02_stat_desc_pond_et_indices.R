# declarer le plan de sondage
plan_svy <- df_menage |>
  filter(!is.na(poids_final)) |>
  as_survey_design(ids = grappe, strata = strate, weights = poids_final, nest = TRUE)

cat(sprintf("Menages dans le plan de sondage : %d / %d\n",
            nrow(df_menage |> filter(!is.na(poids_final))), nrow(df_menage)))

# score de diversite alimentaire HDDS
groupes_fao <- c("cons_cereales", "cons_tubercules", "cons_legumineuses",
                 "cons_legumes", "cons_fruits", "cons_viande", "cons_poisson",
                 "cons_oeufs", "cons_lait", "cons_huile", "cons_sucre",
                 "cons_condiments")
df_menage <- df_menage |>
  mutate(sda_score = rowSums(across(all_of(groupes_fao)), na.rm = TRUE))

# chocs et adaptation
vars_chocs   <- c("choc_secheresse", "choc_hausse_prix", "choc_conflit", "choc_maladie")
vars_strat   <- c("strat_vente_actifs", "strat_reduction_repas", "strat_migration",
                  "strat_endettement")
df_menage <- df_menage |>
  mutate(
    n_chocs        = rowSums(across(all_of(vars_chocs)), na.rm = TRUE),
    a_subi_choc    = as.integer(n_chocs > 0),
    n_strategies   = rowSums(across(all_of(vars_strat)), na.rm = TRUE),
    a_une_strategie = as.integer(n_strategies > 0)
  )
## on utilise la somme pour le nombre de chocs, l'indicatrice pour savoir s'il y a choc
## on utilise la somme pour le nombre de strategies, l'indicatrice pour savoir s'il y a strategie

# CALCULS AVANT LE GT SUMMARY
# depenses : total et parts
df_menage <- df_menage |>
  mutate(
    dep_totale         = dep_alimentaire + dep_sante + dep_education + dep_logement + dep_autres,
    part_alimentaire   = dep_alimentaire / dep_totale,
    part_sante         = dep_sante       / dep_totale,
    part_education     = dep_education   / dep_totale,
    part_logement      = dep_logement    / dep_totale,
    part_autres        = dep_autres      / dep_totale
  )

# groupes age du chef menage
df_menage <- df_menage |>
  mutate(
    groupe_age_chef = cut(
      age_chef,
      breaks = c(0, 25, 35, 45, 55, 65, Inf),
      labels = c("<25", "25-34", "35-44", "45-54", "55-64", "65+"),
      right = FALSE
    )
  )

# nouvelle declaration du plan de sondage
plan_svy <- df_menage |>
  filter(!is.na(poids_final)) |>
  as_survey_design(ids = grappe, strata = strate, weights = poids_final, nest = TRUE)

# tableau de synthese gtsummary
# Revenu, taille de menage : global
stats_globales <- plan_svy |>
  summarise(
    revenu_moyen     = survey_mean(revenu, na.rm = TRUE, vartype = "ci"),
    revenu_median    = survey_median(revenu, na.rm = TRUE, vartype = "ci"),
    taille_moyenne   = survey_mean(taille_menage, na.rm = TRUE, vartype = "ci"),
    part_alim_moyenne = survey_mean(part_alimentaire, na.rm = TRUE, vartype = "ci")
  )
print(stats_globales)

# Par milieu (Urbain / Rural)
stats_milieu <- plan_svy |>
  group_by(milieu) |>
  summarise(
    n              = unweighted(n()),
    revenu_moyen   = survey_mean(revenu, na.rm = TRUE, vartype = "ci"),
    taux_choc      = survey_mean(a_subi_choc, na.rm = TRUE, vartype = "ci") * 100
  )
print(stats_milieu)

# Par region (23 provinces)
stats_region <- plan_svy |>
  group_by(region) |>
  summarise(
    n            = unweighted(n()),
    revenu_moyen = survey_mean(revenu, na.rm = TRUE),
    taux_choc    = survey_mean(a_subi_choc, na.rm = TRUE) * 100,
    sda_moyen    = survey_mean(sda_score, na.rm = TRUE)
  ) |>
  arrange(desc(revenu_moyen))
print(stats_region, n = 23)

# Par quintile de revenu par tete : parts budgetaires
stats_quintile <- plan_svy |>
  filter(!is.na(quintile_f)) |>
  group_by(quintile_f) |>
  summarise(
    part_alimentaire = survey_mean(part_alimentaire, na.rm = TRUE),
    part_sante       = survey_mean(part_sante, na.rm = TRUE),
    part_education   = survey_mean(part_education, na.rm = TRUE)
  )
print(stats_quintile)

# Tableau de synthese gtsummary pondere (par milieu)
tab_synthese <- plan_svy |>
  srvyr::filter(!is.na(milieu)) |>
  gtsummary::tbl_svysummary(
    by = milieu,
    include = c(revenu, taille_menage, sda_score, n_chocs, part_alimentaire),
    label = list(
      revenu ~ "Revenu mensuel (FCFA)", taille_menage ~ "Taille du menage",
      sda_score ~ "Score de diversite alimentaire (/12)",
      n_chocs ~ "Nombre de chocs subis", part_alimentaire ~ "Part budget alimentaire"
    ),
    statistic = list(gtsummary::all_continuous() ~ "{mean} ({sd})"),
    missing = "no"
  ) |>
  gtsummary::add_overall(last = FALSE) |>
  gtsummary::add_p()
tab_synthese |> gtsummary::as_gt() |> gt::gtsave(here("output", "tables", "tab_synthese_milieu.html"))

# Tableau de synthese gtsummary pondere (par milieu)
tab_synthese <- plan_svy |>
  srvyr::filter(!is.na(region)) |>
  gtsummary::tbl_svysummary(
    by = region,
    include = c(revenu, taille_menage, sda_score, n_chocs, part_alimentaire),
    label = list(
      revenu ~ "Revenu mensuel (FCFA)", taille_menage ~ "Taille du menage",
      sda_score ~ "Score de diversite alimentaire (/12)",
      n_chocs ~ "Nombre de chocs subis", part_alimentaire ~ "Part budget alimentaire"
    ),
    statistic = list(gtsummary::all_continuous() ~ "{mean} ({sd})"),
    missing = "no"
  ) |>
  gtsummary::add_overall(last = FALSE) |>
  gtsummary::add_p()
tab_synthese |> gtsummary::as_gt() |> gt::gtsave(here("output", "tables", "tab_synthese_region.html"))

# GINI
df_menage |> summarise(
  n = n(),
  n_na = sum(is.na(revenu_par_tete)),
  n_neg = sum(revenu_par_tete < 0, na.rm = TRUE),
  n_zero = sum(revenu_par_tete == 0, na.rm = TRUE),
  min = min(revenu_par_tete, na.rm = TRUE),
  max = max(revenu_par_tete, na.rm = TRUE)
)

# gini pondere 
plan_gini <- df_menage |>
  filter(!is.na(poids_final), !is.na(revenu_par_tete)) |>
  as_survey_design(ids = grappe, strata = strate, weights = poids_final, nest = TRUE)

# nombre de grappes (PSU) par strate
psu_par_strate <- df_menage |>
  filter(!is.na(poids_final), !is.na(revenu_par_tete)) |>
  distinct(strate, grappe) |>
  count(strate) |>
  summarise(min_psu = min(n), max_psu = max(n), n_strates = n())
psu_par_strate

plan_rep <- as.svrepdesign(plan_gini, type = "bootstrap", replicates = 500)
plan_rep <- convey_prep(plan_rep)

# Gini national
gini_national <- svygini(~revenu_par_tete, design = plan_rep)
confint(gini_national)

gini_region <- svyby(~revenu_par_tete, ~region, design = plan_rep, FUN = svygini, na.rm.all = TRUE)
gini_region_ci <- confint(gini_region)

tab_gini_region <- gini_region |>
  as_tibble() |>
  rename(gini = revenu_par_tete) |>
  bind_cols(as_tibble(gini_region_ci) |> rename(ci_bas = `2.5 %`, ci_haut = `97.5 %`)) |>
  arrange(desc(gini))

# mise en forme et sauvegarde des tableaux Gini (national + region)
tab_gini_national <- tibble(
  niveau  = "National",
  gini    = coef(gini_national)[[1]],
  se      = SE(gini_national)[[1]],
  ci_bas  = confint(gini_national)[1, 1],
  ci_haut = confint(gini_national)[1, 2]
)

gt_gini_national <- tab_gini_national |>
  gt::gt() |>
  gt::fmt_number(columns = c(gini, ci_bas, ci_haut), decimals = 3) |>
  gt::tab_header(title = "Coefficient de Gini du revenu par tete - National") |>
  gt::tab_footnote("IC a 95% obtenu par bootstrap (500 repliques, plan de sondage pris en compte).")
gt::gtsave(gt_gini_national, here("output", "tables", "tab_gini_national.html"))
write_csv(tab_gini_national, here("output", "tables", "tab_gini_national.csv"))

gt_gini_region <- tab_gini_region |>
  gt::gt() |>
  gt::fmt_number(columns = c(gini, ci_bas, ci_haut), decimals = 3) |>
  gt::tab_header(title = "Coefficient de Gini du revenu par tete - Par region") |>
  gt::tab_footnote("IC a 95% obtenu par bootstrap (500 repliques, plan de sondage pris en compte).")
gt::gtsave(gt_gini_region, here("output", "tables", "tab_gini_region.html"))
write_csv(tab_gini_region, here("output", "tables", "tab_gini_region.csv"))

print("Fin de la section 2")