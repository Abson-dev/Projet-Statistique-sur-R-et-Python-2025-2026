# installation des packages
pkgs <- c(
  "tidyverse", "haven", "labelled", "here", "scales",
  "naniar", "moments", "rstatix", "srvyr", "survey",
  "sf", "readxl", "gtsummary", "flextable", "officer",
  "broom", "stringi", "convey", "tmap", "patchwork"
)
manquants <- pkgs[!pkgs %in% installed.packages()[, 1]]
if (length(manquants) > 0) {
  message(">>> Installation en cours : ", paste(manquants, collapse = ", "))
  install.packages(manquants, repos = "https://cloud.r-project.org")
}
invisible(lapply(pkgs, library, character.only = TRUE))

# fixer notre graine aléatoire
set.seed(2070)
options(scipen = 999)

# précision d la source
source_ensan <- "Source : ENSAN 2026, Tchad (donnees simulees, ENSAE ISE1 2025-2026). Calculs des auteurs."

# Téléchargement des données depuis GitHub 
options(timeout = 300)

base_url <- paste0(
  "https://raw.githubusercontent.com/",
  "micheltev229/michel-ensae-2025-2026/main/",
  "Projet%20Statistique%20sous%20R%20ou%20Python/Examen/"
)
fichiers_examen <- c(
  "chocs_menages.csv",
  "dictionnaire_variables_ENSAN2026_Tchad.xlsx",
  "ensan_consommation.xlsx",
  "ensan_individus.csv",
  "ensan_menages.dta",
  "prix_marches.csv",
  "tcd_admin1.cpg",
  "tcd_admin1.dbf",
  "tcd_admin1.prj",
  "tcd_admin1.shp",
  "tcd_admin1.shx"
)
for (f in fichiers_examen) {
  dest_file <- file.path("data/raw", f)
  if (!file.exists(dest_file)) {
    url_file <- paste0(base_url, f)
    tryCatch({
      download.file(url_file, destfile = dest_file, mode = "wb", quiet = TRUE)
      cat("  Téléchargé :", f, "\n")
    }, error = function(e) {
      cat("  Erreur sur :", f, "—", conditionMessage(e), "\n")
    })
  } else {
    cat("  Déjà présent :", f, "\n")
  }
}

# lancement des scripts
source("R/00_theme_ensan.R")
source("R/01_import_structure_nettoyage.R")
source("R/02_stat_desc_pond_et_indices.R")
source("R/03_visualisation.R")

# rapport
rapport_rmd <- here("rapport", "rapport.Rmd")
rapport_out <- here("rapport", "rapport.docx")

tryCatch({
  rmarkdown::render(
    input         = rapport_rmd,
    output_format = "word_document",
    output_file   = rapport_out,
    quiet         = FALSE
  )
  cat(sprintf("\n  [OK] Rapport généré : rapports/rapport.docx\n"))
}, error = function(e) {
  cat(sprintf("\n  [!] Erreur lors du rendu : %s\n", conditionMessage(e)))
})

print("Terminé")