---
title: "Rapport ENSAN 2026 — Tchad"
subtitle: "Sécurité alimentaire, revenus et vulnérabilité des ménages"
author: "TEVOEDJRE Michel"
date: "01 août 2026"
output:
  html_document:
    toc: true
    toc_depth: 3
    number_sections: true
    theme: flatly
  word_document:
    toc: true
    reference_docx: reference.docx
---



# Introduction

Ce rapport présente les principaux résultats de l'enquête ENSAN 2026 au Tchad : revenus des ménages, sécurité alimentaire, exposition aux chocs et vulnérabilité régionale.

# Données et méthodologie

L'échantillon comprend 3540 ménages, répartis dans 23 régions. Les estimations sont pondérées à l'aide du plan de sondage (grappes, strates, poids `poids_final`).

# Résultats

## Revenu et inégalités

Le revenu moyen par tête est de 87 812 FCFA, avec un coefficient de Gini national de 0.454.

<div class="figure" style="text-align: center">
<img src="figure/fig-revenu-1.png" alt="plot of chunk fig-revenu"  />
<p class="caption">plot of chunk fig-revenu</p>
</div>

## Sécurité alimentaire et chocs

83% des ménages ruraux déclarent avoir subi au moins un choc.

<div class="figure" style="text-align: center">
<img src="figure/fig-diagnostic-1.png" alt="plot of chunk fig-diagnostic"  />
<p class="caption">plot of chunk fig-diagnostic</p>
</div>

## Vulnérabilité régionale

<div class="figure" style="text-align: center">
<img src="figure/fig-vuln-1.png" alt="plot of chunk fig-vuln"  />
<p class="caption">plot of chunk fig-vuln</p>
</div>

<div class="figure" style="text-align: center">
<img src="figure/fig-panel-1.png" alt="plot of chunk fig-panel"  />
<p class="caption">plot of chunk fig-panel</p>
</div>

# Conclusion

Les résultats mettent en évidence des disparités régionales marquées en matière de revenu et de vulnérabilité au Tchad. Ces constats appellent un ciblage différencié des interventions de sécurité alimentaire selon les profils régionaux identifiés.
