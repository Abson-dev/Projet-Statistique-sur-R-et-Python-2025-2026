# EXAMEN DE PROJET STATISTIQUE SOUS R

# Section 1 : Importation, structuration et nettoyage

install.packages("tidyverse")      
install.packages("haven")         
install.packages("readxl")         
install.packages("janitor")        
install.packages("gtsummary")      
install.packages("survey")         
install.packages("sf")              
install.packages("renv")  
install.packages("naniar")
install.packages("mice")
install.packages("srvyr")
install.packages("gt")
install.packages("ineq")
install.packages("gglorenz")
install.packages("ggridges")
install.packages("ggbeeswarm")
install.packages("tmap")

library("tidyverse")
library("haven")
library("readxl")
library("janitor")
library("gtsummary")
library("survey")
library("sf")
library("renv")

RAW <- "data/raw"

message("1. Importation des cinq sources avec les packages appropriés, en respectant les types de colonnes et les encodages.")

menage <- read_dta(file.path(RAW, "ensan_menages.dta"))
individu <- read.csv(file.path(RAW, "ensan_individus.csv"))
consommation <- read_xlsx(file.path(RAW, "ensan_consommation.xlsx"))
choc <- read.csv(file.path(RAW, "chocs_menages.csv"))
prix <- read.csv(file.path(RAW, "prix_marches.csv"))
shapefile <- read_sf(file.path(RAW, "tcd_admin1.shp"))

message("2. Fusionner les modules en un jeu de données ménages enrichi comportant les caractéristiques du chef de ménage, 
la consommation alimentaire agrégée et les chocs subis, par des jointures adaptées. Vérifier explicitement que 
le nombre de lignes du jeu de données ménages reste inchangé après chaque jointure..")

# Joidre les caractéristiques du chef de ménages
chefs_menage <- individu |> 
  filter(rang == 1) |>   
  select(hhid, sexe_cm = sexe, age_cm = age, educ_cm = niveau_educ) 

# calcul de la consommation totale du ménage
consommation$cons_totale <- consommation$cons_cereales+consommation$cons_tubercules+consommation$cons_legumineuses+consommation$cons_legumes+consommation$cons_fruits+consommation$cons_viande+consommation$cons_poisson+consommation$cons_oeufs+consommation$cons_lait+consommation$cons_huile+consommation$cons_sucre+consommation$cons_condiments

# Agrégation de la consommation par chef de ménage
consommation_agrege <- consommation |>
  dplyr::filter(!is.na(cons_totale)) |>
  dplyr::group_by(hhid) |>
  dplyr::summarise(cons_moyen = mean(cons_totale), .groups = "drop")

# avoir le meme type avant de joindre
menage$hhid <- as.integer(menage$hhid)
chefs_menage$hhid <- as.integer(chefs_menage$hhid)
consommation_agrege$hhid <- as.integer(consommation_agrege$hhid)
choc$hhid <- as.integer(choc$hhid)

# Fusion
menage_fusion <- menage |> 
  left_join(chefs_menage, by = "hhid") |>          
  left_join(consommation_agrege, by = "hhid") |> 
  left_join(choc, by = "hhid")

# Vérification:le nombre de lignes ne doit pas avoir changé 
nrow(menage_fusion) == nrow(menage)           

message("3. Identifier et corriger les libellés de régions incohérents entre fichiers avant toute jointure spatiale.")

regions_shp <- sort(unique(shapefile$adm1_name))
regions_data <- sort(unique(menage_fusion$region))
if (!setequal(regions_shp, regions_data)) {
  stop("Désaccord entre les provinces du shapefile et celles des données : \n",
       "Dans le shapefile mais pas les données : ", paste(setdiff(regions_shp, regions_data), collapse = ", "), "\n",
       "Dans les données mais pas le shapefile : ", paste(setdiff(regions_data, regions_shp), collapse = ", "))
}
message("La correspondance entre shapefile et données vérifiée : ", length(regions_shp), " provinces, jointure OK.")

# Pour corriger celà, on tranforme les données de la base ménage en majuscule
menage_fusion$region <- str_to_upper(menage_fusion$region)

message("4. Produire un diagnostic complet des valeurs manquantes avec naniar (résumé, visualisation, cooccurrences), en 
distinguant les valeurs manquantes standards des valeurs manquantes taguées Stata.")

# Explorer les valeurs manquantes 
library(naniar) 

# Matrice de co-occurrence des NA:quelles variables sont manquantes ensemble ? 
matrice_de_covariance <- gg_miss_upset(menage_fusion, nsets = 8) 
ggsave("output/figures/matrice_de_covariance.png",
       matrice_de_covariance, width = 10, height = 8, dpi = 300)
message("✓ Figure 2 sauvegardée")

# Pattern spatial des NA dans le dataset 
vis_miss(menage_fusion, sort_miss = TRUE) 

vis_miss(menage_fusion)              
miss_var_summary(menage_fusion)       
gg_miss_var(menage_fusion)            

# Distribution des variables catégorielles 
menage_fusion |> count(milieu, sort = TRUE) 
menage_fusion |> count(region, milieu)     

# Distribution des variables numériques 
valeurs_manquantes_numeric <- menage_fusion |> 
  select(where(is.numeric)) |> 
  pivot_longer(everything()) |> 
  ggplot(aes(x = value)) + 
  geom_histogram(fill = "#2E75B6", bins = 30) + 
  facet_wrap(~name, scales = "free") + 
  theme_minimal() 

ggsave("output/figures/valeurs_manquante_numériques.png",
       valeurs_manquantes_numeric, width = 10, height = 8, dpi = 300)
message("✓ Figure 1 sauvegardée")


message("4. Justifier, pour deux variables clés de votre choix, une hypothèse de mécanisme de non-réponse (MCAR, MAR 
ou MNAR) et appliquer une imputation multiple par équations chaînées adaptée avec mice.")

library(mice) 

# Imputation multiple (M = 5 jeux de données imputés) 
imp <- mice( 
  menage_fusion |> select(revenu, age_cm, educ_cm, taille_menage, milieu, region), 
  m     = 5,          # Nombre de jeux imputés 
  maxit = 20,         # Itérations de convergence 
  method = "pmm",     # Predictive Mean Matching (recommandé pour variables continue) 
seed  = 42)

# Vérifier la convergence 
plot(imp) 

# Analyser sur les 5 jeux imputés et combiner (règles de Rubin)
fit_imputed <- with(imp, lm(log(revenu) ~ age_cm + educ_cm + taille_menage + 
                              milieu)) 
pool(fit_imputed) |> summary()

message("6. Recoder les variables catégorielles nécessaires à l’analyse (milieu, niveau d’éducation du chef de ménage, 
quintiles de revenu par tête). ")

menage_fusion$revenu_par_tete <- menage_fusion$revenu/menage_fusion$taille_menage

menage_fusion <- menage_fusion |> 
  mutate( 
    # Recodage avec case_when (plus flexible que if_else) 
    milieu_label = case_when( 
      milieu == 1 ~ "Urbain", 
      milieu == 2 ~ "Rural", 
      TRUE        ~ NA_character_ 
    ),
    # Création d'une variable catégorielle ordonnée 
    niveau_vie = case_when( 
      revenu_par_tete < 500  ~ "Très pauvre", 
      revenu_par_tete < 1000 ~ "Pauvre", 
      revenu_par_tete < 2000 ~ "Intermédiaire", 
      TRUE             ~ "Non pauvre" 
    ) |> factor(levels = c("Très pauvre", "Pauvre", "Intermédiaire", "Non pauvre"), 
                ordered = TRUE))
    
# Pipeline de manipulation complet 
analyse_revenu <- menage_fusion |> 
  filter(revenu > 0, !is.na(revenu)) |> 
  select(hhid, region, milieu, revenu, taille_menage, poids_final) |> 
  mutate( 
    revenu_par_tete    = revenu / taille_menage,           # Revenu par tête 
    log_revenu   = log(revenu_par_tete),                   # Transformation log 
    quintile     = ntile(revenu_par_tete, 5),              # Quintiles de revenu 
    pauvre       = if_else (revenu_par_tete < 0,60 * 12429, 1L, 0L)  # Seuil BM en USD 
  ) |> 
  group_by(region, milieu) |> 
  summarise( 
    n          = n(), 
    revenu_moy = weighted.mean(revenu_par_tete, poids_final, na.rm = TRUE), 
    tx_pauvrete = weighted.mean(pauvre, poids_final, na.rm = TRUE), 
    .groups = "drop" 
  ) |>arrange(desc(tx_pauvrete)) 

# SECTION 2 : STATISTIQUES DESCRIPTIVES
message("7. Déclarer le plan de sondage complet (grappes, strates, poids finaux) avec srvyr.")

library(srvyr)

menage_fusion$pauvre <- if_else (menage_fusion$revenu_par_tete < 0,60 * 12429, 1L, 0L)
# 1. Déclarer le plan de sondage 
plan_sondage <- menage_fusion |> 
  as_survey_design( 
    ids     = grappe,          # Identifiant des grappes (PSU) 
    strata  = strate,          # Variable de stratification 
    weights = poids_final,     # Poids de sondage finaux 
    nest    = TRUE 
  ) 

# 2. Statistiques pondérées avec intervalles de confiance à 95% 
plan_sondage |> 
  group_by(region, milieu) |> 
  summarise( 
    revenu_moyen    = survey_mean(revenu_par_tete, vartype = "ci"), 
    tx_pauvrete     = survey_mean(pauvre, vartype = "ci"), 
    effectif_estime = survey_total(vartype = "ci") 
  ) 

# 3. Ratio pondéré 
plan_sondage |> 
  summarise( 
    gini = survey_ratio( 
      numerator   = revenu_par_tete * (rank(revenu_par_tete) / n()), 
      denominator = revenu_par_tete
    ) 
  ) 

message("8. Construire le score de diversité alimentaire des ménages (HDDS) et la classification FAO associée. ")
menage_fusion <- menage_fusion |> 
  mutate( 
    # Score HDDS:somme des 12 groupes alimentaires 
    hdds = rowSums(across(starts_with("cons_")), na.rm = TRUE), 
    
    # Classification FAO 
    securite_alim = case_when( 
      hdds <= 3  ~ "Insécurité alimentaire sévère", 
      hdds <= 6  ~ "Insécurité alimentaire modérée", 
      hdds <= 9  ~ "Sécurité alimentaire acceptable", 
      TRUE       ~ "Bonne diversité alimentaire" 
    ) |> factor(levels = c("Insécurité alimentaire sévère", 
                           "Insécurité alimentaire modérée", 
                           "Sécurité alimentaire acceptable", 
                           "Bonne diversité alimentaire"), ordered = TRUE) 
  ) 

message("9. Construire un indice composite de vulnérabilité aux chocs, combinant le nombre et la gravité des chocs subis 
avec l’intensité des stratégies d’adaptation mobilisées. La construction, la pondération des composantes et les 
choix de seuils doivent être explicitement justifiés dans le rapport. ")
menage_fusion$nombre_de_chocs <- menage_fusion$choc_conflit+menage_fusion$choc_hausse_prix+menage_fusion$choc_maladie+menage_fusion$choc_secheresse
menage_fusion$gravite_choc <- if_else (menage_fusion$nombre_de_chocs < 2, 1L, 0L)
menage_fusion$intensite_strategie <- menage_fusion$strat_vente_actifs+menage_fusion$strat_reduction_repas+menage_fusion$strat_migration+menage_fusion$strat_endettement

score_composite <- function(data, vars, poids = NULL, na_rm = TRUE) {
  mat <- as.matrix(data[, vars, drop = FALSE])
  if (is.null(poids)) poids <- rep(1, length(vars))
  if (length(poids) != length(vars)) stop("'poids' doit avoir la même longueur que 'vars'.")
  
  mat_ponderee <- sweep(mat, 2, poids, `*`)
  rowSums(mat_ponderee, na.rm = na_rm)
}

score_composite(menage_fusion,menage_fusion["nombre_de_choc","gravite_choc","intensite_strategie"],menage_fusion$poids_final)

message("10. Produire un tableau descriptif pondéré de type Tableau 1 avec gtsummary, comparant les indicateurs clés par 
milieu et par région, avec test de comparaison et colonne d’effectifs. ")

library(gt)
tableau1 <- analyse_revenu |> 
  gt() |> 
  tab_header( 
    title    = "Tableau 1 — Indicateurs de pauvreté par région", 
    subtitle = "Source:ensan_menage.dta — Estimations pondérées" 
  ) |> 
  fmt_percent(columns = c(tx_pauvrete), decimals = 1) |> 
  fmt_number(columns = revenu_moy, sep_mark = " ", dec_mark = ",", decimals = 
               0, 
             suffix = " FCFA") |> 
  cols_label( 
    region           ~ "Région", 
    tx_pauvrete      ~ "Taux de pauvreté", 
    revenu_moy     ~ "Revenu moyen" 
  ) |> 
  data_color( 
    columns = tx_pauvrete, 
    palette = "RdYlGn", reverse = TRUE   # Rouge = pauvreté élevée 
  ) |> 
  tab_footnote( 
    footnote = "Seuil de pauvreté nationale 2021", 
    locations = cells_column_labels(columns = tx_pauvrete) 
  ) |> 
  tab_style( 
    style = cell_text(weight = "bold"),
    locations = cells_column_labels() 
  ) 

print(tableau1)

messsage("11. Calculer le coefficient de Gini du revenu par tête au niveau national et par région, avec un intervalle de confiance 
obtenu par bootstrap. ")

library("ineq")
# Coefficient de Gini 
gini_national <- ineq(menage_fusion$revenu_par_tete, type = "Gini", na.rm = TRUE) 

# Gini par région 
menage_fusion |> 
  group_by(region) |> 
  summarise(gini = ineq(revenu_par_tete, type = "Gini", na.rm = TRUE)) |> 
  arrange(desc(gini)) 

# Courbe de Lorenz 
library(gglorenz) 
courbe_lorenz <- ggplot(menage_fusion, aes(revenu_par_tete)) + 
  stat_lorenz(color = "#2E75B6", size = 1.2) + 
  geom_abline(linetype = "dashed", color = "gray50") + 
  annotate("text", x = 0.25, y = 0.75, 
           label = paste0("Gini = ", round(gini_national, 3)), 
           size = 4, color = "#1F4E79") + 
  labs(title = "Courbe de Lorenz — Revenu par tête", 
       x = "Part cumulée de la population", 
       y = "Part cumulée du revenu") + 
  theme_minimal(base_size = 12) 

ggsave("output/figures/courbe_lorenz.png",
       courbe_lorenz, width = 10, height = 8, dpi = 300)
message("✓ Figure 1 sauvegardée")

# SECTION 3 : VISUALISATION
message("12. Représenter la distribution du revenu par tête par région (graphique de densités superposées ou équivalent), 
avec une échelle adaptée à l’asymétrie de la variable. ")

library(ggplot2) 
library(ggridges) 

# Histogramme avec densité 
histogramme_densite <- ggplot(menage_fusion, aes(x = revenu_par_tete)) + 
  geom_histogram(aes(y = after_stat(density)), 
                 fill = "#2E75B6", alpha = 0.7, bins = 40) + 
  geom_density(color = "#1F4E79", linewidth = 1) + 
  scale_x_log10(labels = scales::comma) + 
  labs(title = "Distribution du revenu par tête", 
       subtitle = "Échelle logarithmique ", 
       x = "Revenu par tête (FCFA/mois, log10)", 
       y = "Densité") + 
  theme_minimal(base_size = 12) + 
  theme(plot.title = element_text(face = "bold")) 

ggsave("output/figures/histogramme_densite.png",
       histogramme_densite, width = 10, height = 8, dpi = 300)
message("✓ Figure 1 sauvegardée")

# Graphique de densités par région (ridgeline plot) 
densite_par_region <- ggplot(menage_fusion, aes(x = revenu_par_tete, y = fct_reorder(region, revenu_par_tete, median), 
                    fill = after_stat(x))) + 
  geom_density_ridges_gradient(scale = 2, rel_min_height = 0.01) + 
  scale_x_log10() + 
  scale_fill_viridis_c(option = "plasma", name = "Revenu") + 
  labs(title = "Distribution du revenu par tête selon la région", 
       x = "Revenu par tête (log)", y = NULL) + 
  theme_ridges() 

ggsave("output/figures/densite_par_region.png",
       densite_par_region, width = 10, height = 8, dpi = 300)
message("✓ Figure 1 sauvegardée")


library(ggbeeswarm) 

# Boxplot enrichi avec points individuels 
boxplot_revenu_par_tete <- ggplot(menage_fusion |> sample_n(2000), 
       aes(x = milieu, y = revenu_par_tete, fill = milieu)) + 
  geom_violin(alpha = 0.4, trim = FALSE) + 
  geom_boxplot(width = 0.15, outlier.shape = NA, fill = "white") + 
  geom_beeswarm(alpha = 0.2, size = 0.8, color = "#1F4E79") + 
  scale_y_log10(labels = scales::comma) + 
  scale_fill_manual(values = c("#2E75B6", "#E67E22")) + 
  labs(title = "Revenu par tête:urbain vs rural", 
       y = "Revenu par tête (FCFA/mois)", x = NULL) + 
  theme_minimal() + 
  theme(legend.position = "none") 
ggsave("output/figures/boxplot_revenu_par_tete.png",
       boxplot_revenu_par_tete, width = 10, height = 8, dpi = 300)
message("✓ Figure 1 sauvegardée")

# Nuage de points annoté avec régression 
nuage_de_point <- ggplot(menage_fusion, aes(x = age_cm, y = revenu_par_tete, color = milieu)) + 
  geom_point(alpha = 0.3, size = 0.8) + 
  geom_smooth(method = "loess", se = TRUE) + 
  scale_y_log10() + 
  facet_wrap(~region, ncol = 4) + 
  scale_color_manual(values = c("#2E75B6", "#E67E22")) + 
  theme_minimal(base_size = 10) 
ggsave("output/figures/nuage_de_point.png",
       nuage_de_point, width = 10, height = 8, dpi = 300)
message("✓ Figure 1 sauvegardée")

theme_ensae <- function(base_size = 12) { 
  theme_minimal(base_size = base_size) %+replace% 
    theme( 
      text              = element_text(family = "Arial"), 
      plot.title        = element_text(size = rel(1.3), face = "bold", 
                                       color = "#1F4E79", hjust = 0), 
      plot.subtitle     = element_text(size = rel(1.0), color = "#555555", 
                                       hjust = 0, margin = margin(b = 10)), 
      plot.caption      = element_text(size = rel(0.8), color = "#888888", hjust = 1), 
      axis.title        = element_text(size = rel(0.95), color = "#444444"), 
      panel.grid.major  = element_line(color = "#EEEEEE", linewidth = 0.5), 
      panel.grid.minor  = element_blank(), 
      legend.position   = "bottom", 
      legend.title      = element_text(face = "bold") 
    ) 
} 

# Graphique avec annotations et export haute résolution 
p <- ggplot(analyse_revenu, aes(x = fct_reorder(region, tx_pauvrete), 
                                 y = tx_pauvrete, fill = milieu)) + 
  geom_col(position = "dodge") + 
  geom_text(aes(label = scales::percent(tx_pauvrete, accuracy = 0.1)), 
            position = position_dodge(0.9), vjust = -0.3, size = 3) + 
  scale_y_continuous(labels = scales::percent) + 
  scale_fill_manual(values = c("#2E75B6", "#E67E22"), name = "Milieu") + 
  labs(title = "Taux de pauvreté par région et milieu", 
       subtitle = "Source:ensan_menages.dta — Estimations pondérées", 
       x = NULL, y = "Taux de pauvreté (%)", 
       caption = "Note:seuil de pauvreté national") + 
  theme_ensae() + 
  coord_flip() 

# Export haute résolution pour publication 
ggsave("output/figures/pauvrete_region.png", p, 
       width = 18, height = 12, units = "cm", dpi = 300) 
ggsave("output/figures/pauvrete_region.pdf", p, 
       width = 18, height = 12, units = "cm", device = cairo_pdf) 

message("13. Produire une carte choroplèthe de l’indice de vulnérabilité par région avec sf et ggplot2, ainsi qu’une version 
interactive avec tmap. ")

# 1. Charger le shapefile des régions du Sénégal 
tchad_regions <- read_sf(file.path(RAW, "tcd_admin1.shp")) |> 
  st_transform(crs = 4326) 

# 2. Joindre les données statistiques 
carte_data <- tchad_regions |> 
  left_join(analyse_revenu |> select(region, tx_pauvrete, revenu_moy), 
            by = c("adm1_name" = "region")) 

# 3. Carte choroplèthe avec ggplot2 
carte_choroplete <- ggplot(carte_data) + 
  geom_sf(aes(fill = tx_pauvrete), color = "white", linewidth = 0.3) + 
  scale_fill_distiller(palette = "YlOrRd", direction = 1, 
                       labels = scales::percent, 
                       name = "Taux de 
pauvreté") + 
  labs(title = "Taux de pauvreté par région — Sénégal 2021", 
       subtitle = "Source:EHCVM 2021, calculs de l'auteur", 
       caption = "Projection:WGS84") + 
  theme_void(base_size = 12) + 
  theme(legend.position = c(0.15, 0.5)) 

ggsave("output/figures/carte_choroplete.png",
       carte_choroplete, width = 10, height = 8, dpi = 300)
message("✓ Figure 1 sauvegardée")

# 4. Carte interactive avec tmap 
library("tmap")
tmap_mode("view")   # Mode interactif (basculer en "plot" pour statique) 
carte_tmap <- tm_shape(carte_data) + 
  tm_polygons("tx_pauvrete", 
              title    = "Taux de pauvreté (%)", 
              palette  = "YlOrRd", 
              style    = "quantile", 
              n        = 5, 
              popup.vars = c("adm1_name", "tx_pauvrete", "revenu_moy")) + 
  tm_layout(title = "Pauvreté régionale — Sénégal 2021") 
ggsave("output/figures/carte_tmap.png",
       carte_tmap, width = 10, height = 8, dpi = 300)
message("✓ Figure 1 sauvegardée")

message("14. Composer une figure unique regroupant au moins trois graphiques avec patchwork, en appliquant un thème 
graphique cohérent et personnalisé sur l’ensemble des graphiques du rapport. ")

p1 <- ggplot(menage_fusion, aes(x = milieu, y = revenu_par_tete)) + 
  geom_violin(fill = "#2E75B6", alpha = 0.7) + theme_ensae() + 
  labs(title = "A. Distribution des revenus", x = NULL, y = "Revenu/tête") 
ggsave("output/figures/p1.png",
       p1, width = 10, height = 8, dpi = 300)
message("✓ Figure 1 sauvegardée")

p2 <- ggplot(analyse_revenu, aes(x = tx_pauvrete, y = revenu_moy)) + 
  geom_point(aes(size = length(menage_fusion)), color = "#2E75B6") + 
  geom_text(aes(label = region), vjust = -0.8, size = 3) + 
  theme_ensae() + 
  labs(title = "B. Pauvreté vs revenu moyen", x = "Taux de pauvreté", y = "Revenu 
moyen") 
ggsave("output/figures/p2.png",
       p2, width = 10, height = 8, dpi = 300)
message("✓ Figure 1 sauvegardée")

# Composition:p1 à gauche, carte à droite, p2 en bas 
(p1 | carte_data) / p2 + 
  plot_annotation( 
    title   = "Figure 1 — Analyse de la pauvreté monétaire, Sénégal 2021", 
    caption = "", 
    theme   = theme(plot.title = element_text(size = 14, face = "bold")) 
  )



