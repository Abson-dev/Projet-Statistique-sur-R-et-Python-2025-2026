#**************** Section 1. Import, structuration et nettoyage******************************#

#*
# 1. LIBRAIRIES
# ===============================
library(readxl)
library(tidyverse) 
library(haven)
library(dplyr)
library(ggplot2)
library(ggrepel)
library(scales)
library(patchwork)
library(rstatix)
library(viridis)
library(srvyr)
library(here)
library(naniar) 
library(mice) 

#*************************** 1.  Importer les 5 sources avec les packqges appropriés******************#
#*
chocs_menages <- read_csv(here("data", "raw", "chocs_menages.csv"),
                          col_types = cols(
                            hhid = col_character(),
                            region_lib = col_factor(),
                            choc_secheresse = col_factor(),
                            choc_hausse_prix = col_factor(),
                            choc_conflit = col_factor(),
                            choc_maladie = col_factor(),
                            strat_vente_actifs = col_factor(),
                            strat_reduction_repas = col_factor(),
                            strat_migration = col_factor(),
                            strat_endettement = col_factor()
                          ))
ensan_consommation <- read_excel(here("data", "raw", "ensan_consommation.xlsx"))
ensan_individus <- read_csv(here("data", "raw", "ensan_individus.csv"),
                            col_types = cols(
                              hhid = col_character(),
                                rang = col_integer(),
                                age = col_double(),
                                sexe = col_factor(),
                                niveau_educ = col_factor()
                                ))
ensan_menages <- read_dta(here("data", "raw", "ensan_menages.dta"))
prix_marches <- read_csv(here("data", "raw", "prix_marches.csv"),
                         col_types = cols(
                           marche = col_character(),
                             region = col_character(),
                             produit = col_character(),
                             mois = col_date(format = "%Y-%m-%d"),
                             prix_fcfa_kg = col_double()
                           
                         ))

#|********************* Visualiser les bases

glimpse(chocs_menages)
glimpse(ensan_consommation)
glimpse(ensan_individus)
glimpse(ensan_menages)
glimpse(prix_marches)

#*********************2. Fusionner les modules en un jeu de données ménages enrichi comportant les caractéristiques du chef de ménage, 
#la consommation alimentaire agrégée et les chocs subis, par des jointures adaptées. Vérifier explicitement que 
#le nombre de lignes du jeu de données ménages reste inchangé après chaque jointure.

# Les caractéristiques du CM

chefs_menage <- ensan_individus |> 
  filter(rang == 1) |>   # Rang 1 = chef de ménage 
  select(hhid, sexe_cm = sexe, age_cm = age, educ_cm = niveau_educ) 

#************3.Identifier et corriger les libellés de régions incohérents entre fichiers avant toute jointure spatiale.
# On Va procéder comme suit, je fusionne les bases, après je supprime la variable region_lab

# Fusionner les base

base_menage <- ensan_menages |>
  left_join(chefs_menage, by = "hhid")|>
  left_join(ensan_consommation, by = "hhid")|>
  left_join(chocs_menages, by = "hhid")
#anti_join(menages_exclus, by = "hhid")
  

# Exploration de base 
dim(base_menage)          # Dimensions:lignes x colonnes 
names(base_menage)        # Noms de toutes les variables 
glimpse(base_menage)      # Types et premières valeurs 
summary(base_menage)      # Statistiques descriptives par variable

# Corriger la variable region_lib, se trouvant dans la base chocs_menages
#########################################################################

## Supprimer la variable region_lab
base_menage <- base_menage



# Vérification

nrow(ensan_menages)
nrow(chefs_menage)
nrow(ensan_consommation)
nrow(chocs_menages)
nrow(base_menage)

# Conserver seulement les ménages qui apparaissent dans toutes les base


nrow(base_menage) == nrow(ensan_menages)

# Les ménages à exclure

  
#************3.Identifier et corriger les libellés de régions incohérents entre fichiers avant toute jointure spatiale.

view(base_menage)

unique(base_menage$region)
unique(base_menage$region_lib)


## 4. Produire un diagnostic complet des valeurs manquantes avec naniar (résumé, visualisation, cooccurrences), en 
#distinguant les valeurs manquantes standards des valeurs manquantes taguées Stata.
cartographieNA1<-vis_miss(base_menage)              # Visualisation cartographique des NA 
miss_var_summary(base_menage)     # % de NA par variable 
visualusationNA <-gg_miss_var(base_menage) 

# Matrice de co-occurrence des NA:quelles variables sont manquantes ensemble ? 
gg_miss_upset(base_menage, nsets = 8) 

# Pattern spatial des NA dans le dataset 


## 5. Justifier, pour deux variables clés de votre choix, une hypothèse de mécanisme de non-réponse (MCAR, MAR 
#ou MNAR) et appliquer une imputation multiple par équations chaînées adaptée avec mice. 

miss_var_summary(base_menage)      # % de NA par variable 



# Imputation multiple (M = 5 jeux de données imputés) 
imp <- mice( 
  base_menage|>select(revenu, age_cm, educ_cm, taille_menage), 
  m     = 5,          # Nombre de jeux imputés 
  maxit = 20,         # Itérations de convergence 
  method = "pmm",     # Predictive Mean Matching (recommandé pour variables continues) 
seed  = 42 
) 

# Vérifier la convergence 
plot(imp) 

# Analyser sur les 5 jeux imputés et combiner (règles de Rubin)
fit_imputed <- with(imp, lm(log(revenu) ~ age_cm + educ_cm + taille_menage
                              )) 
pool(fit_imputed) |> summary()




### 6. Recoder les variables catégorielles nécessaires à l’analyse (milieu, niveau d’éducation du chef de ménage, 
#quintiles de revenu par tête). 
#base_menage <- base_menage |> 
 # mutate( 
    # Recodage avec case_when (plus flexible que if_else) 
  #  milieu_label = case_when( 
  #    milieu == 1 ~ "Urbain", 
  #    milieu == 2 ~ "Rural", 
  #    TRUE        ~ NA_character_ 
   # ))


#export
saveRDS(base_menage,  here("data", "processed", "base_menage.rds"))


  

