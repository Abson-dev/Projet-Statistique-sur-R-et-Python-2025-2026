
library(tidyverse)      # Collection principale:ggplot2, dplyr, tidyr, readr... 
library(haven)          # Import données Stata (.dta) et SPSS (.sav) 
library(readxl)         # Import fichiers Excel 
library(janitor)        # Nettoyage des noms de colonnes 
library(gtsummary)      # Tableaux statistiques publication-ready 
library(survey)         # Analyses pondérées (sondages) 
#library(sf)             # Données spatiales (shapefiles) 
library(renv)           # Gestion des dépendances du projet 
library(readr)
library(sjlabelled)
library(naniar)        # diagnostic des valeurs manquantes (vis_miss, gg_miss_var)
library(Amelia)
library(mice) 



#Section 1. Import, structuration et nettoyage  
#1. Importer les cinq sources avec les packages appropriés, en respectant les types de colonnes et les encodages.


ensan_menages <- read_dta("data/raw/ensan_menages.dta")
ensan_individus <- read_csv("data/raw/ensan_individus.csv", 
                            locale = locale(encoding = "UTF-8", decimal_mark = ","))

chocs_menages <- read_csv("data/raw/chocs_menages.csv")


ensan_consommation <- read_excel("data/raw/ensan_consommation.xlsx")
#prix_marches <- read_csv("data/raw/prix_marches.csv")



#2. Fusionner les modules en un jeu de données ménages enrichi comportant les caractéristiques du chef de ménage, 
#la consommation alimentaire agrégée et les chocs subis, par des jointures adaptées. Vérifier explicitement que 
#le nombre de lignes du jeu de données ménages reste inchangé après chaque jointure. 

names(ensan_consommation)
names(ensan_menages)
names(ensan_individus)

names(chocs_menages)
#names(prix_marche)


summary(ensan_consommation)

depenses_agregees <- ensan_consommation |> 
  group_by(hhid) |> 
  summarise( 
    cons_cereales    = sum(cons_cereales), 
    cons_tubercules     = sum(cons_tubercules), 
    cons_legumineuses = sum(cons_legumineuses) ,
    cons_legumes = sum(cons_legumes),
    cons_fruits = sum(cons_fruits),
    cons_viande = sum(cons_viande),
    cons_poisson=sum(cons_poisson)
    
  ) 

# Joindre les caractéristiques du chef de ménage aux données ménage 
chefs_menage <- ensan_individus |> 
  filter(rang == 1) |>   # Rang 1 = chef de ménage 
  select(hhid, sexe_cm = sexe, age_cm = age, educ_cm = niveau_educ) 

dim(chefs_menage)
dim(ensan_menages)

menages_enrichis <- ensan_menages |> 
  left_join(chefs_menage, by = "hhid")        # Conserver tous les ménages 
         # Exclure les ménages problématiques 


menages_enrichis <- menages_enrichis |> 
  left_join(depenses_agregees, by = "hhid") 


menages_enrichis <- menages_enrichis|> 
  left_join(chocs_menages, by = "hhid") 

# Vérification:le nombre de lignes ne doit pas avoir changé 
nrow(menages_enrichis) == nrow(chefs_menage)           # Doit retourner TRUE 


#3. Identifier et corriger les libellés de régions incohérents entre fichiers avant toute jointure spatiale. 

get_label(menages_enrichis)

clean_names(menages_enrichis) 

#4. Produire un diagnostic complet des valeurs manquantes avec naniar (résumé, visualisation, cooccurrences), en 
#distinguant les valeurs manquantes standards des valeurs manquantes taguées Stata. 

dim(menages_enrichis)
glimpse(menages_enrichis)
summary(menages_enrichis)

#Valeurs manquantes -------------------------------------------------------
# Vue d'ensemble du taux de NA par variable
naniar::miss_var_summary(menages_enrichis)
missmap(menages_enrichis)

# --- Sauvegarde --------------------------------------------------------------
saveRDS(menages_enrichis,  "data/raw/menages_enrichis")
#5. Justifier, pour deux variables clés de votre choix, une hypothèse de mécanisme de non-réponse (MCAR, MAR 
 #ou MNAR) et appliquer une imputation multiple par équations chaînées adaptée avec mice. 

# Imputation multiple (M = 5 jeux de données imputés) 
imp <- mice( 
  menages_enrichis |> select(revenu, age_cm, educ_cm, taille_menage), 
  m     = 5,          # Nombre de jeux imputés 
  maxit = 20,         # Itérations de convergence 
  method = "pmm",     # Predictive Mean Matching (recommandé pour variables continues) 
  seed  = 42 
) 


# Vérifier la convergence 
plot(imp) 

fit_imputed <- with(imp, lm(log(revenu) ~ age_cm + educ_cm + taille_menage
                              )) 
pool(fit_imputed) |> summary() 



#6. Recoder les variables catégorielles nécessaires à l’analyse (milieu, niveau d’éducation du chef de ménage, 

get_labels(menages_enrichis$milieu)
get_labels(menages_enrichis$educ_cm)



saveRDS(menages_enrichis,  "data/processed/menages_enrichis")