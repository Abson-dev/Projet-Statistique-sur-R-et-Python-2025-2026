# Script d'inspection des fichiers de données brutes
# Permet de visualiser les premières lignes des fichiers disponibles avant nettoyage.

library(readr)
library(readxl)

project_root <- normalizePath(getwd())
raw_dir <- file.path(project_root, "data", "raw", "raw")

files <- list.files(raw_dir, recursive = TRUE, full.names = TRUE)
cat("Fichiers bruts trouvés dans", raw_dir, "\n")
print(files)

show_preview <- function(path, n = 5) {
  cat("\n===", basename(path), "===\n")
  if (grepl("\\.(csv|txt)$", path, ignore.case = TRUE)) {
    df <- read_csv(path, n_max = n, locale = locale(encoding = "UTF-8"))
    print(head(df, n))
  } else if (grepl("\\.xlsx$", path, ignore.case = TRUE)) {
    sheets <- excel_sheets(path)
    cat("Feuilles:", paste(sheets, collapse = ", "), "\n")
    for (sheet in sheets) {
      cat("Sheet:", sheet, "\n")
      df <- read_excel(path, sheet = sheet, n_max = n)
      print(head(df, n))
      cat("\n")
    }
  } else if (grepl("\\.dta$", path, ignore.case = TRUE)) {
    library(haven)
    df <- read_dta(path)
    print(head(df, n))
  } else {
    cat("Type de fichier non pris en charge pour l'aperçu.\n")
  }
}

for (file_path in files) {
  tryCatch(
    show_preview(file_path),
    error = function(e) cat("Erreur en lisant", file_path, ":", e$message, "\n")
  )
}
