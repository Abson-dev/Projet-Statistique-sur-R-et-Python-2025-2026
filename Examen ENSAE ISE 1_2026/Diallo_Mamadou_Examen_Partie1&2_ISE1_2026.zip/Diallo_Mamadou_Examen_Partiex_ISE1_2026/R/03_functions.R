## Fonctions utilitaires partagées
suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(janitor)
  library(stringr)
})

project_root <- normalizePath(getwd())
processed_dir <- file.path(project_root, "data", "processed")
fig_dir <- file.path(project_root, "output", "figures")
table_dir <- file.path(project_root, "output", "tables")
if (!dir.exists(processed_dir)) dir.create(processed_dir, recursive = TRUE)
if (!dir.exists(fig_dir)) dir.create(fig_dir, recursive = TRUE)
if (!dir.exists(table_dir)) dir.create(table_dir, recursive = TRUE)

gini_coefficient <- function(x, weights = NULL) {
  # Compute weighted or unweighted Gini coefficient (Brown formula)
  df <- data.frame(x = as.numeric(x), w = if (is.null(weights)) 1 else as.numeric(weights))
  df <- df[is.finite(df$x) & df$w > 0, , drop = FALSE]
  if (nrow(df) == 0) return(NA_real_)
  df <- df[order(df$x), ]
  df$cumw <- cumsum(df$w)
  df$pw <- df$w / sum(df$w)
  df$pxw <- cumsum(df$w * df$x)
  mu <- sum(df$w * df$x) / sum(df$w)
  n <- nrow(df)
  if (mu == 0) return(0)
  # Gini = 1 - (1/mu) * sum_i w_i * (S_{i-1} + S_i)
  S <- c(0, df$pxw[-n])
  gi <- 1 - (1 / (mu * sum(df$w))) * sum(df$w * (S + df$pxw))
  as.numeric(gi)
}
