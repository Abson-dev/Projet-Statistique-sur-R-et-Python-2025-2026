# Script d'import et de nettoyage initial
# Ce script extrait les fichiers depuis l'archive fournie, importe les données
# et prépare un jeu de données ménage enrichi minimalement exploitable.

suppressPackageStartupMessages({
  library(readr)
  library(readxl)
  library(haven)
  library(dplyr)
  library(purrr)
  library(stringr)
  library(tidyr)
  library(janitor)
})

project_root <- normalizePath(getwd())
raw_dir <- file.path(project_root, "data", "raw")
processed_dir <- file.path(project_root, "data", "processed")

if (!dir.exists(raw_dir)) {
  dir.create(raw_dir, recursive = TRUE, showWarnings = FALSE)
}

if (!dir.exists(processed_dir)) {
  dir.create(processed_dir, recursive = TRUE, showWarnings = FALSE)
}

# Décompresser l'archive si nécessaire
archive_path <- file.path(project_root, "raw.zip")
if (file.exists(archive_path) && !dir.exists(file.path(raw_dir, "raw"))) {
  unzip(archive_path, exdir = raw_dir)
}

# Import des fichiers
menages_raw <- read_dta(file.path(raw_dir, "raw", "ensan_menages.dta"))
individus <- read_csv(file.path(raw_dir, "raw", "ensan_individus.csv"), locale = locale(encoding = "UTF-8"), show_col_types = FALSE)
consommation_groupes <- read_excel(file.path(raw_dir, "raw", "ensan_consommation.xlsx"), sheet = "Consommation_groupes")
consommation_depenses <- read_excel(file.path(raw_dir, "raw", "ensan_consommation.xlsx"), sheet = "Depenses_menage")
chocs <- read_csv(file.path(raw_dir, "raw", "chocs_menages.csv"), locale = locale(encoding = "UTF-8"), show_col_types = FALSE)
prix <- read_csv(file.path(raw_dir, "raw", "prix_marches.csv"), locale = locale(encoding = "UTF-8"), show_col_types = FALSE)

# Nettoyage minimal
menages <- menages_raw |>
  mutate(
    hhid = as.character(hhid),
    region = str_squish(str_to_title(region)),
    milieu = as.character(milieu),
    grappe = as.character(grappe),
    strate = as.character(strate),
    poids_final = as.numeric(poids_final),
    revenu = as.numeric(revenu),
    taille_menage = as.numeric(taille_menage)
  )

individus <- individus |>
  clean_names() |>
  mutate(
    hhid = as.character(hhid),
    rang = as.integer(rang),
    age = as.numeric(age),
    sexe = case_when(
      sexe %in% c(1, "1") ~ "Homme",
      sexe %in% c(2, "2") ~ "Femme",
      TRUE ~ as.character(sexe)
    ),
    niveau_educ = as.character(niveau_educ)
  )

consommation_groupes <- consommation_groupes |>
  clean_names() |>
  mutate(hhid = as.character(hhid))

consommation_depenses <- consommation_depenses |>
  clean_names() |>
  mutate(hhid = as.character(hhid))

consommation <- consommation_groupes |>
  full_join(consommation_depenses, by = "hhid")

chocs <- chocs |>
  clean_names() |>
  mutate(
    hhid = as.character(hhid),
    region_lib = str_squish(str_to_title(region_lib)),
    across(starts_with("choc_"), ~ as.integer(.x)),
    across(starts_with("strat_"), ~ as.integer(.x))
  )

prix <- prix |>
  clean_names() |>
  mutate(
    marche = as.character(marche),
    region = str_squish(str_to_title(region)),
    produit = as.character(produit),
    mois = lubridate::ymd(mois),
    prix_fcfa_kg = as.numeric(prix_fcfa_kg)
  )

menages_full <- menages |>
  left_join(consommation, by = "hhid") |>
  left_join(chocs %>% select(-region_lib), by = "hhid")

# Sauvegarde des fichiers nettoyés
saveRDS(menages, file.path(processed_dir, "menages_clean.rds"))
saveRDS(individus, file.path(processed_dir, "individus_clean.rds"))
saveRDS(consommation, file.path(processed_dir, "consommation_clean.rds"))
saveRDS(chocs, file.path(processed_dir, "chocs_clean.rds"))
saveRDS(prix, file.path(processed_dir, "prix_clean.rds"))
saveRDS(menages_full, file.path(processed_dir, "menages_full.rds"))

cat("Import et nettoyage terminés.\n")
cat("Nombres de lignes :\n")
cat(sprintf("- ménages : %d\n", nrow(menages)))
cat(sprintf("- individus : %d\n", nrow(individus)))
cat(sprintf("- consommation groupes : %d\n", nrow(consommation_groupes)))
cat(sprintf("- chocs : %d\n", nrow(chocs)))
cat(sprintf("- prix : %d\n", nrow(prix)))
cat(sprintf("- ménages full : %d\n", nrow(menages_full)))
