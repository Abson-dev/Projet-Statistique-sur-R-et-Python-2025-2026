# Script d'installation des packages R nécessaires au projet
# Exécutez ce script avant de lancer les scripts R du projet.

required_packages <- c(
  "renv",
  "tidyverse",
  "haven",
  "readr",
  "readxl",
  "survey",
  "srvyr",
  "gtsummary",
  "gt",
  "naniar",
  "mice",
  "sf",
  "tmap",
  "patchwork",
  "scales",
  "janitor",
  "glue",
  "knitr",
  "rmarkdown",
  "xml2",
  "curl",
  "openssl",
  "units",
  "s2",
  "terra",
  "systemfonts",
  "raster",
  "lubridate"
)

missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]

if (length(missing_packages) == 0) {
  message("Tous les packages requis sont déjà installés.")
} else {
  message("Packages manquants : ", paste(missing_packages, collapse = ", "))
  install.packages(missing_packages, dependencies = TRUE, repos = "https://cloud.r-project.org")
}

message("\nSi certains packages échouent encore, installez d'abord ces dépendances système :")
message("  sudo apt-get install cmake pkg-config libudunits2-dev libfontconfig1-dev libfreetype6-dev libabsl-dev libgdal-dev libproj-dev libgeos-dev")
message("Puis relancez ce script.")
