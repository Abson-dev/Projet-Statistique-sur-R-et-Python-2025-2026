## Construction des indices : HDDS et indice de vulnérabilité
suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
})

source('R/03_functions.R')

menages_path <- file.path(processed_dir, 'menages_imputed.rds')
if (!file.exists(menages_path)) menages_path <- file.path(processed_dir, 'menages_full.rds')
menages <- readRDS(menages_path)

# 8. HDDS : somme des consommations de groupes alimentaires (colonnes commençant par 'cons_')
cons_cols <- grep('^cons_', names(menages), value = TRUE)
if (length(cons_cols) > 0) {
  menages <- menages %>%
    mutate(hdds = rowSums(across(all_of(cons_cols)), na.rm = TRUE)) %>%
    mutate(hdds_cat = dplyr::case_when(
      hdds <= 3 ~ 'Low',
      hdds <= 5 ~ 'Medium',
      TRUE ~ 'High'
    ))
}

# 9. Indice composite de vulnérabilité
# Simple construction : normaliser le nombre de chocs et l'intensité des stratégies
shock_cols <- grep('^choc_', names(menages), value = TRUE)
strat_cols <- grep('^strat_', names(menages), value = TRUE)
if (length(shock_cols) > 0) {
  menages <- menages %>%
    mutate(n_shocks = rowSums(across(all_of(shock_cols)), na.rm = TRUE))
}
if (length(strat_cols) > 0) {
  menages <- menages %>%
    mutate(strat_intensity = rowSums(across(all_of(strat_cols)), na.rm = TRUE))
}

if (exists('n_shocks', where = menages) && exists('strat_intensity', where = menages)) {
  # Normalize to 0-1 and average (weights can be adjusted)
  menages <- menages %>%
    mutate(
      n_shocks_s = (n_shocks - min(n_shocks, na.rm = TRUE)) / (max(n_shocks, na.rm = TRUE) - min(n_shocks, na.rm = TRUE) + 1e-9),
      strat_s = (strat_intensity - min(strat_intensity, na.rm = TRUE)) / (max(strat_intensity, na.rm = TRUE) - min(strat_intensity, na.rm = TRUE) + 1e-9),
      vuln_index = 0.6 * n_shocks_s + 0.4 * strat_s
    )
}

saveRDS(menages, file.path(processed_dir, 'menages_indices.rds'))
write_csv(menages %>% select(hhid, region, n_shocks, strat_intensity, vuln_index, hdds, hdds_cat), file.path(processed_dir, 'menages_indices.csv'))

cat('Indices computed and saved.\n')
