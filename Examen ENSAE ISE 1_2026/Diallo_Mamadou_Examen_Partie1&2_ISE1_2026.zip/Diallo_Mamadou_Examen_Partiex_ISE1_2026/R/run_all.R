## Runner script: exécute la chaîne complète de traitement et génère rapports
source('R/03_functions.R')
cat('Running full pipeline...\n')
# Core steps
system('Rscript R/01_import_clean.R')
system('Rscript R/04_missingness.R')
system('Rscript R/05_indices.R')
# Harmonize spatial labels and check shapefile
system('Rscript R/08_spatial_validation.R')
# Tableau 1 and Gini
system('Rscript R/07_tableau1_gini.R')
# Descriptives and main analyses
system('Rscript R/02_descriptives.R')
# Visualizations
system('Rscript R/06_visualization.R')
# Render master report (national)
if (file.exists('R/03_report.Rmd')) {
  rmarkdown::render('R/03_report.Rmd', output_file = 'rapport/report_national.html')
}
cat('Pipeline finished.\n')
