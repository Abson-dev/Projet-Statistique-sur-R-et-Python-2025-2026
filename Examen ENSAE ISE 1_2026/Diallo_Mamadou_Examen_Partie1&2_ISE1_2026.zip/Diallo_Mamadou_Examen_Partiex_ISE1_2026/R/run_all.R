## Runner script: exécute la chaîne complète de traitement et génère rapports
source('R/03_functions.R')
cat('Running full pipeline...\n')
# Core steps
system('Rscript R/01_import_clean.R')
system('Rscript R/04_missingness.R')
system('Rscript R/05_indices.R')
# Harmonize spatial labels and check shapefile
system('Rscript R/08_spatial_validation.R')
# Tableau 1 and Gini
system('Rscript R/07_tableau1_gini.R')
# Descriptives and main analyses
system('Rscript R/02_descriptives.R')
# API extraction and processing (Partie 2)
if (file.exists('R/09_api_sdg.R')) {
  system('Rscript R/09_api_sdg.R')
}
# Visualizations
system('Rscript R/06_visualization.R')
# Render master report (national)
if (file.exists('R/03_report.Rmd')) {
  rmarkdown::render('R/03_report.Rmd', output_format = 'all', output_dir = 'rapport')
}
# Generate regional reports automatically in one command
if (file.exists('R/generate_region_reports.R')) {
  system('Rscript R/generate_region_reports.R')
}
cat('Pipeline finished.\n')
