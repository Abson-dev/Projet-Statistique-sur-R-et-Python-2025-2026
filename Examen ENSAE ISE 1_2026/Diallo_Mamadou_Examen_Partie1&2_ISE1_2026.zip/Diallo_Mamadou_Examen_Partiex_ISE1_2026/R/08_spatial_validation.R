## Validation et harmonisation des étiquettes régionales entre données et shapefile
suppressPackageStartupMessages({
  library(dplyr)
  library(stringr)
  library(readr)
  library(sf)
  library(stringi)
})

source('R/03_functions.R')

menages <- readRDS(file.path(processed_dir, 'menages_indices.rds'))
shp_path <- file.path('data','raw','raw','tcd_admin1.shp')
if (!file.exists(shp_path)) {
  cat('Shapefile not found at', shp_path, '\n')
} else {
  shp <- st_read(shp_path, quiet = TRUE)
  # Normalize region names: remove accents, trim, title case
  norm <- function(x) {
    x <- stringi::stri_trans_general(x, 'Latin-ASCII')
    x <- str_squish(x)
    x <- str_to_title(x)
    x
  }
  shp$region_norm <- norm(shp$NAME_1 %||% shp$NAME)
  menages$region_norm <- norm(menages$region)
  # Regions in data not matched in shapefile
  missing_regions <- setdiff(unique(menages$region_norm), unique(shp$region_norm))
  if (length(missing_regions) > 0) {
    write_csv(tibble(missing_region = missing_regions), file.path(processed_dir, 'region_label_mismatches.csv'))
    cat('Wrote region_label_mismatches.csv with', length(missing_regions), 'entries\n')
  } else {
    cat('All regions match shapefile after normalization.\n')
  }
  # Save joined shapefile for later mapping
  shp2 <- left_join(shp, menages %>% group_by(region_norm) %>% summarize(vuln = mean(vuln_index, na.rm = TRUE)), by = 'region_norm')
  st_write(shp2, file.path(processed_dir, 'tcd_admin1_joined.geojson'), delete_dsn = TRUE, quiet = TRUE)
  cat('Saved joined geojson to', file.path(processed_dir, 'tcd_admin1_joined.geojson'), '\n')
}
