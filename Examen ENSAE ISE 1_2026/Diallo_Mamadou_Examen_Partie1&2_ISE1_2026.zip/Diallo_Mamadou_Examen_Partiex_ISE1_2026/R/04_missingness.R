## Diagnostic et imputation des valeurs manquantes
suppressPackageStartupMessages({
  library(naniar)
  library(dplyr)
  library(readr)
  library(mice)
  library(janitor)
  library(haven)
})

source('R/03_functions.R')

menages_path <- file.path(processed_dir, 'menages_full.rds')
menages <- readRDS(menages_path)

# 4. Diagnostic complet des valeurs manquantes
miss_summary <- naniar::miss_var_summary(menages)
write_csv(miss_summary, file.path(processed_dir, 'missing_summary.csv'))

# Cooccurrence
miss_pairs <- naniar::miss_case_summary(menages)
write_csv(miss_pairs, file.path(processed_dir, 'missing_case_summary.csv'))

# Tagged missing values (Stata)
tagged_missing <- sapply(menages, function(col) {
  if (any(class(col) %in% c('labelled', 'haven_labelled'))) {
    sum(haven::is_tagged_na(col), na.rm = TRUE)
  } else {
    0
  }
})
tagged_missing_df <- tibble(variable = names(tagged_missing), tagged_missing = unname(tagged_missing)) |>
  filter(tagged_missing > 0)
write_csv(tagged_missing_df, file.path(processed_dir, 'missing_tagged_summary.csv'))

if (nrow(tagged_missing_df) > 0) {
  cat('Valeurs manquantes taguées détectées pour', nrow(tagged_missing_df), 'variables.\n')
}

# Visualisations enregistrées (si environnement graphique disponible)
try({
  p1 <- naniar::gg_miss_var(menages) + ggplot2::theme_minimal()
  ggplot2::ggsave(filename = file.path(fig_dir, 'miss_var.png'), plot = p1, width = 7, height = 4)
}, silent = TRUE)

# 5. Imputation multiple pour deux variables clés: 'revenu' et 'dep_alimentaire'
imp_vars <- c('revenu', 'dep_alimentaire')
imp_present <- imp_vars[imp_vars %in% names(menages)]
if (length(imp_present) > 0) {
  imp_data <- menages %>% select(all_of(c('hhid', imp_present, 'taille_menage', 'poids_final')))
  imp_data <- imp_data %>% mutate(across(where(is.character), as.factor))
  ini <- mice::mice(imp_data %>% select(-hhid), maxit = 0, printFlag = FALSE)
  set.seed(2026)
  imp <- mice::mice(imp_data %>% select(-hhid), m = 5, maxit = 10, seed = 2026, printFlag = FALSE)
  completed <- mice::complete(imp, action = 'long', include = TRUE)
  write_csv(completed, file.path(processed_dir, 'mice_imputed_long.csv'))
  menages_imp <- menages
  comp1 <- mice::complete(imp, 1)
  for (v in imp_present) {
    menages_imp[[v]] <- comp1[[v]]
  }
  saveRDS(menages_imp, file.path(processed_dir, 'menages_imputed.rds'))
  write_lines(glue::glue('Imputation multiple appliquée sur {paste(imp_present, collapse = ", ")} avec hypothèse MAR.'), file.path(processed_dir, 'imputation_notes.txt'))
}

cat('Missingness diagnostics and imputation saved to', processed_dir, '\n')
