## Visualisations : densités, carte, composition de figures
suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
  library(sf)
  library(readr)
  library(patchwork)
  library(stringr)
})

source('R/03_functions.R')

menages <- readRDS(file.path(processed_dir, 'menages_indices.rds'))

# 12. Densité du revenu par tête par région
p_density <- NULL
if ('revenu_par_personne' %in% names(menages) && any(!is.na(menages$revenu_par_personne))) {
  p_density <- ggplot(menages %>% filter(!is.na(revenu_par_personne)), aes(x = revenu_par_personne, color = region)) +
    geom_density() +
    scale_x_continuous(trans = 'log1p') +
    labs(title = 'Distribution du revenu par tête par région', x = 'Revenu par tête (log1p)', y = 'Densité') +
    theme_minimal()
  ggsave(file.path(fig_dir, 'revenu_density_by_region.png'), p_density, width = 8, height = 5)
}

# 13. Carte choroplèthe de l'indice de vulnérabilité
p_map <- NULL
shp_path <- file.path('data', 'raw', 'raw', 'tcd_admin1.shp')
if (file.exists(shp_path) && 'vuln_index' %in% names(menages)) {
  shp <- st_read(shp_path, quiet = TRUE)
  if ('NAME_1' %in% names(shp)) {
    shp$region <- stringr::str_squish(stringr::str_to_title(shp$NAME_1))
    map_df <- menages %>%
      group_by(region) %>%
      summarise(vuln = mean(vuln_index, na.rm = TRUE), .groups = 'drop')
    shp2 <- suppressMessages(left_join(shp, map_df, by = 'region'))

    if ('vuln' %in% names(shp2)) {
      p_map <- ggplot(shp2) + geom_sf(aes(fill = vuln), color = 'grey40') +
        scale_fill_viridis_c(option = 'magma', na.value = 'grey90') +
        labs(title = 'Indice de vulnérabilité par région') + theme_minimal()
      ggsave(file.path(fig_dir, 'vuln_map.png'), p_map, width = 8, height = 6)

      if (requireNamespace('tmap', quietly = TRUE)) {
        tryCatch({
          tmap::tmap_save(
            tmap::tm_shape(shp2) + tmap::tm_polygons(col = 'vuln'),
            filename = file.path(fig_dir, 'vuln_map.html'),
            quiet = TRUE
          )
        }, error = function(e) invisible(NULL))
      }
    }
  }
}

# 14. Composer une figure avec au moins trois graphiques
plots <- list()
if (!is.null(p_density) && is.ggplot(p_density)) plots[[length(plots) + 1]] <- p_density
if (!is.null(p_map) && is.ggplot(p_map)) plots[[length(plots) + 1]] <- p_map
if ('dep_alimentaire' %in% names(menages)) {
  p_bar <- ggplot(menages, aes(x = factor(0), y = dep_alimentaire)) +
    geom_boxplot() +
    labs(title = 'Dépenses alimentaires (boxplot)') +
    theme_minimal()
  plots[[length(plots) + 1]] <- p_bar
}
if (length(plots) >= 1) {
  comp <- if (length(plots) == 1) {
    plots[[1]]
  } else {
    wrap_plots(plots[1:min(3, length(plots))], ncol = 1)
  }
  ggsave(file.path(fig_dir, 'composed_figure.png'), comp, width = 8, height = 12)
  ggsave(file.path(fig_dir, 'composed_figure.pdf'), comp, width = 8, height = 12)
}

cat('Visualizations saved to', fig_dir, '\n')
