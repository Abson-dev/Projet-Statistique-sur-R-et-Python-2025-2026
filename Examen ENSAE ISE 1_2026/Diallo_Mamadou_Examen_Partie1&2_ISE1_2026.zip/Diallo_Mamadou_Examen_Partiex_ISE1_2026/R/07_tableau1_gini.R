## Tableau 1 pondéré (gtsummary) et coefficient de Gini par région (bootstrap)
suppressPackageStartupMessages({
  library(dplyr)
  library(gtsummary)
  library(srvyr)
  library(readr)
})

source('R/03_functions.R')

menages <- readRDS(file.path(processed_dir, 'menages_indices.rds'))

# Déclarer plan de sondage : utiliser grappe/strate si disponibles
if (all(c('grappe','strate','poids_final') %in% names(menages))) {
  design <- menages %>% srvyr::as_survey_design(ids = grappe, strata = strate, weights = poids_final)
} else if ('poids_final' %in% names(menages)) {
  design <- menages %>% srvyr::as_survey_design(weights = poids_final)
} else {
  design <- menages %>% srvyr::as_survey_design()
}

# Variables pour le tableau 1
tbl_vars <- c('revenu_par_personne','dep_alimentaire','dep_sante','dep_education','dep_logement','dep_totale')

tbl <- tryCatch({
  if ("survey.design" %in% names(formals(gtsummary::tbl_svysummary))) {
    gtsummary::tbl_svysummary(
      survey.design = srvyr::as_survey_design(design),
      include = all_of(tbl_vars),
      by = 'milieu',
      statistic = all_continuous() ~ "{mean} ({sd})",
      digits = all_continuous() ~ 2
    )
  } else {
    gtsummary::tbl_svysummary(
      data = srvyr::as_survey_design(design),
      include = all_of(tbl_vars),
      by = 'milieu',
      statistic = all_continuous() ~ "{mean} ({sd})",
      digits = all_continuous() ~ 2
    )
  } %>%
    add_n(location = 'label') %>%
    add_p()
}, error = function(e){
  # fallback to unweighted gtsummary
  menages %>% select(all_of(tbl_vars), milieu) %>% tbl_summary(by = 'milieu')
})

# Exporter tableau
try({
  as_gt(tbl) %>% gt::gtsave(file.path(processed_dir, 'tableau1.html'))
}, silent = TRUE)

# 11. Calcul du Gini par région avec bootstrap
gini_by_region <- function(df, region_col = 'region', value_col = 'revenu_par_personne', weight_col = 'poids_final', B = 500) {
  regions <- unique(df[[region_col]])
  out <- list()
  for (r in regions) {
    sub <- df %>% filter((.data[[region_col]]) == r)
    vals <- sub[[value_col]]
    wts <- if (weight_col %in% names(sub)) sub[[weight_col]] else NULL
    g0 <- gini_coefficient(vals, weights = wts)
    # bootstrap by sampling rows with replacement, prob proportional to weights if available
    n <- nrow(sub)
    if (n <= 1 || all(is.na(vals))) {
      out[[as.character(r)]] <- tibble(region = r, gini = NA_real_, gini_l = NA_real_, gini_u = NA_real_, n = n)
      next
    }
    probs <- if (!is.null(wts)) { wts / sum(wts, na.rm = TRUE) } else rep(1/n, n)
    boots <- numeric(B)
    set.seed(2026)
    for (b in seq_len(B)) {
      idx <- sample(seq_len(n), size = n, replace = TRUE, prob = probs)
      vals_b <- vals[idx]
      wts_b <- if (!is.null(wts)) wts[idx] else NULL
      boots[b] <- gini_coefficient(vals_b, weights = wts_b)
    }
    ci <- quantile(boots, probs = c(0.025, 0.975), na.rm = TRUE)
    out[[as.character(r)]] <- tibble(region = r, gini = g0, gini_l = ci[1], gini_u = ci[2], n = n)
  }
  bind_rows(out)
}

gini_df <- gini_by_region(menages)
write_csv(gini_df, file.path(processed_dir, 'gini_by_region.csv'))

cat('Tableau 1 and Gini by region saved to', processed_dir, '\n')
