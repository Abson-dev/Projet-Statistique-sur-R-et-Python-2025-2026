# Script de descriptives pondérées et d'analyses thématiques

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(lubridate)
  library(survey)
  library(srvyr)
  library(gtsummary)
  library(gt)
  library(readr)
  library(janitor)
})

project_root <- normalizePath(getwd())
processed_dir <- file.path(project_root, "data", "processed")

menages_full <- readRDS(file.path(processed_dir, "menages_full.rds"))

menages_full <- menages_full %>%
  mutate(
    revenu = as.numeric(revenu),
    taille_menage = as.numeric(taille_menage),
    poids_final = as.numeric(poids_final),
    revenu_par_personne = revenu / pmax(taille_menage, 1),
    revenu_par_personne = if_else(is.finite(revenu_par_personne), revenu_par_personne, NA_real_),
    dep_alimentaire = as.numeric(dep_alimentaire),
    dep_sante = as.numeric(dep_sante),
    dep_education = as.numeric(dep_education),
    dep_logement = as.numeric(dep_logement),
    dep_autres = as.numeric(dep_autres),
    dep_totale = rowSums(across(starts_with("dep_")), na.rm = TRUE)
  )

svy_design <- svydesign(ids = ~1, weights = ~poids_final, data = menages_full)

# Moyennes pondérées
revenu_mean <- svymean(~revenu_par_personne, svy_design, na.rm = TRUE)
dep_mean <- svymean(~dep_alimentaire + dep_sante + dep_education + dep_logement + dep_autres, svy_design, na.rm = TRUE)
shock_vars <- c("choc_secheresse", "choc_hausse_prix", "choc_conflit", "choc_maladie")
shock_rates <- svymean(as.formula(paste0("~", paste(shock_vars, collapse = "+"))), svy_design, na.rm = TRUE)

shock_summary <- tibble(
  variable = names(shock_rates),
  rate = as.numeric(shock_rates),
  se = as.numeric(SE(shock_rates))
) %>%
  mutate(rate = scales::percent(rate, accuracy = 0.1), se = scales::percent(se, accuracy = 0.1))

summary_table <- menages_full %>%
  summarise(
    revenu_par_personne_mean = mean(revenu_par_personne, na.rm = TRUE),
    dep_alimentaire_mean = mean(dep_alimentaire, na.rm = TRUE),
    dep_sante_mean = mean(dep_sante, na.rm = TRUE),
    dep_education_mean = mean(dep_education, na.rm = TRUE),
    dep_logement_mean = mean(dep_logement, na.rm = TRUE),
    dep_autres_mean = mean(dep_autres, na.rm = TRUE),
    dep_totale_mean = mean(dep_totale, na.rm = TRUE)
  ) %>%
  pivot_longer(everything(), names_to = "variable", values_to = "mean")

write_rds(svy_design, file.path(processed_dir, "survey_design.rds"))
write_rds(menages_full, file.path(processed_dir, "menages_enriched.rds"))
write_csv(shock_summary, file.path(processed_dir, "shock_rates.csv"))
write_csv(summary_table, file.path(processed_dir, "descriptives_summary.csv"))

cat("Descriptives terminées.\n")
cat(sprintf("Revenue moyenne par personne : %0.2f\n", coef(revenu_mean)))
cat(sprintf("Nombre de ménages analysés : %d\n", nrow(menages_full)))
