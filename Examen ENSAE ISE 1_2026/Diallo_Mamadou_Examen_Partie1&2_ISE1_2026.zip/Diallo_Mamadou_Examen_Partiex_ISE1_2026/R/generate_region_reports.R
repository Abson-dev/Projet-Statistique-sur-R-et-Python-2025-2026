## Génération automatisée de rapports régionaux paramétrés
suppressPackageStartupMessages({
  library(rmarkdown)
  library(dplyr)
})

source('R/03_functions.R')

regions <- sort(unique(readRDS(file.path(processed_dir, 'menages_indices.rds'))$region))

for (reg in regions) {
  out <- sprintf('rapport/report_%s.html', gsub('\\s+', '_', reg))
  params <- list(region = reg)
  rmarkdown::render('R/03_report.Rmd', output_file = out, params = params, envir = new.env())
  cat('Rendered region', reg, '->', out, '\n')
}
