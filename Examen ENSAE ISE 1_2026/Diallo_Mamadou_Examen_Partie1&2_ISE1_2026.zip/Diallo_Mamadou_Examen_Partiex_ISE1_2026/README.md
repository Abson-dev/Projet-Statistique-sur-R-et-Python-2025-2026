# Données de l'examen : ENSAN 2026, Tchad

Ces données sont simulées à des fins pédagogiques pour l'examen pratique
« Projet Statistique sous R », ENSAE ISE1, session 2025 2026. Les 23
provinces, leurs pcodes et leurs superficies officielles proviennent du
jeu de données HDX / OCHA COD-AB Tchad, fourni par l'utilisateur.

## Structure du projet

- data/raw : données brutes extraites de l’archive fournie
- data/processed : jeux de données nettoyés et résultats intermédiaires
- R : scripts R organisés par étape
- output/figures : figures exportées
- output/tables : tables exportées
- rapport : rapport R Markdown

## Exécution complète en R

1. Ouvrir le projet dans RStudio via `Projet_R.Rproj` ou utiliser un terminal dans le dossier du projet.
2. Installer les dépendances R :
   - `Rscript R/install_packages.R`
3. Exécuter les scripts dans l’ordre :
   - `Rscript R/01_import_clean.R`
   - `Rscript R/02_descriptives.R`
4. Compiler le rapport :
   - `Rscript -e "rmarkdown::render('R/03_report.Rmd', output_format = 'all')"`

## Dépendances système recommandées

Sur Ubuntu, installez d'abord :

```bash
sudo apt-get install cmake pkg-config libudunits2-dev libfontconfig1-dev libfreetype6-dev libabsl-dev libgdal-dev libproj-dev libgeos-dev
```

## Contenu de data/raw/

- `ensan_menages.dta` : module ménage avec `hhid`, `region`, `milieu`, `grappe`, `strate`, `poids_final`, `revenu`, `taille_menage`.
- `ensan_individus.csv` : module individu avec `hhid`, `rang`, `age`, `sexe`, `niveau_educ`.
- `ensan_consommation.xlsx` : deux feuilles `Consommation_groupes` et `Depenses_menage`.
- `chocs_menages.csv` : chocs et stratégies d'adaptation par ménage.
- `prix_marches.csv` : prix mensuels de produits par région.
- `tcd_admin1.*` : shapefile administratif du Tchad.

## Résultat attendu

- `data/processed/menages_full.rds` : jeu de données ménage unifié et nettoyé.
- `data/processed/survey_design.rds` : objet `survey` pour analyses pondérées.
- `data/processed/menages_enriched.rds` : ménage enrichi avec variables dérivées.
- `data/processed/shock_rates.csv` : prévalences pondérées des chocs.
- `R/03_report.html` et `R/03_report.docx` : rapport généré.

