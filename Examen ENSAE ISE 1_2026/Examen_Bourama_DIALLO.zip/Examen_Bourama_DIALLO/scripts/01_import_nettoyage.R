# =============================================================================
# Installation automatique des packages manquants
# =============================================================================
# Packages installables via CRAN normalement
packages_cran <- c(
  "gtsummary",
  "haven",        # Importation des fichiers
  "tidyverse",    # Manipulation des données
  "naniar",       # Valeurs manquantes
  "here",         # Gestion des chemins
  "survey",       # Gestion de la pondération
  "scales",       # Mise en forme des échelles dans les graphiques
  "wCorr",         # Corrélation de Spearman pondérée (utilisée en Q20)
  "labelled",     # Gestion des labels
  "writexl"       # Création et exportation de fichiers excels
)

# Packages à installer via GitHub (problèmes de dépendances sur CRAN)
packages_github <- list(
  "Hmisc" = "harrelfe/Hmisc"    # Outils pour la gestion, description et analyse des données
)

# Installation CRAN
for(pkg in packages_cran) {
  if(!require(pkg, character.only = TRUE)) {
    message(paste("Installation CRAN:", pkg))
    install.packages(pkg, dependencies = TRUE)
    library(pkg, character.only = TRUE)
  }
}

# Installation GitHub
if(!require("remotes", character.only = TRUE)) {
  install.packages("remotes")
  library(remotes)
}

for(pkg in names(packages_github)) {
  if(!require(pkg, character.only = TRUE)) {
    message(paste("Installation GitHub:", pkg))
    remotes::install_github(packages_github[[pkg]])
    library(pkg, character.only = TRUE)
  }
}


#==================================================
#Partie 1:
#=================================================
#=====================================================
#SECTION 1:
#=======================================================

#1. importation des sources de données:
#base ménages:
library(haven)
ensan_menages <- read_dta(here("data","raw","ensan_menages.dta"))

#base individus
library(readr)
ensan_individus <- read_csv(here("data","raw","ensan_individus.csv"))


#base consommation:
#feuille 1:
library(readxl)
consommation_groupe <- read_excel(here("data","raw","ensan_consommation.xlsx", 
                                 sheet = "Consommation_groupes"))

#base consommation
#feuille 2:
library(readxl)
depense_menage <- read_excel(here("data","raw","ensan_consommation.xlsx", 
                                 sheet = "Depenses_menage"))


#base chocs_ménages:
library(readr)
chocs_menages <- read_csv(here("data","raw","chocs_menages.csv"))
View(chocs_menages)

#base prix_marchés
library(readr)
prix_marches <- read_csv(here("data","raw","prix_marches.csv"))
View(prix_marches)



#------------------------------------------------------------------
#2. jointure des bases de données
#-----------------------------------------------------------------

#Jointure base menage avec la base individus:

base_menages_individus  <-  ensan_menages |> left_join(ensan_individus, by = "hhid")    # cle = hhid


# DETECTER les doublons
doublons <-  base_menages_individus|> get_dupes(hhid)
cat("Nombre de lignes en double :", nrow(doublons), "\n")

# Enlever les doublons puis produire un TABLEAU DE FREQUENCES decore
base_menages_individus_sans_doublons<- base_menages_individus |>distinct(hhid, .keep_all = TRUE)

#============================================================================
#Jointure base menage avec la base de la feuille  1 de la base consommation:
#============================================================================
base_menages_indiv_conso_group  <-  base_menages_individus_sans_doublons |> left_join(consommation_groupe, by = "hhid")    # cle = hhid

# DETECTER les doublons
doublons <-  base_menages_indiv_conso_group|> get_dupes(hhid)
cat("Nombre de lignes en double :", nrow(doublons), "\n")

# Enlever les doublons puis produire un TABLEAU DE FREQUENCES decore
base_menages_indiv_conso_group_sans_doub <- base_menages_indiv_conso_group |>distinct(hhid, .keep_all = TRUE)

#=======================================================================
#Jointure base menage avec la base de la feuille 2 de la base consommation:
#===========================================================================

base_menages_indiv_conso_group_depense  <-  base_menages_indiv_conso_group_sans_doub |> left_join(depense_menage, by = "hhid")    # cle = hhid

# DETECTER les doublons
doublons <- base_menages_indiv_conso_group_depense |> get_dupes(hhid)
cat("Nombre de lignes en double :", nrow(doublons), "\n")

# Enlever les doublons puis produire un TABLEAU DE FREQUENCES decore
base_menages_indiv_conso_group_depense_sans_doub <- base_menages_indiv_conso_group_depense |>distinct(hhid, .keep_all = TRUE)

#===========================================================================
#Jointure base menage avec la base chocs_menages:
#==========================================================================

base_menages_indiv_conso_group_depense_choc  <-  base_menages_indiv_conso_group_depense_sans_doub |> left_join(chocs_menages, by = "hhid")    # cle = hhid

# DETECTER les doublons
doublons <- base_menages_indiv_conso_group_depense_choc |> get_dupes(hhid)
cat("Nombre de lignes en double :", nrow(doublons), "\n")

# Enlever les doublons puis produire un TABLEAU DE FREQUENCES decore
base_menages_indiv_conso_group_depense_choc_sans_doub <- base_menages_indiv_conso_group_depense_choc |>distinct(hhid, .keep_all = TRUE)

base_finale <- base_menages_indiv_conso_group_depense_choc_sans_doub

#=======================================================
#Exportation des bases de données
#=======================================================

#===================================
#4. Valeurs manquantes
#====================================

# Avec le package naniar (diagnostic complet) :
library(naniar)
n_miss(base_finale)                          # nombre total de NA dans la table
pct_miss(base_finale)                        # % total de NA
miss_var_summary(base_finale)                # NA par variable, trie
vis_miss(base_finale)                        # graphique des NA (echantillon si gros)
gg_miss_var(base_finale)                     # graphique NA par variable


#imputation par la moyenne pour le revenu:
moyenne_revenu <- mean(base_finale$revenu,na.rm = TRUE)
base_finale <- base_finale |>
  mutate(revenu = replace_na_with(revenu, round(moyenne_revenu,0)))

#imputation par la moyenne pour la taille du ménage
moyenne_taille <- mean(base_finale$taille_menage,na.rm = TRUE)
base_finale <- base_finale |>
  mutate(revenu = replace_na_with(taille_menage, round(moyenne_taille,0)))

#===================================================
#6. recodage des variables categorielles
#====================================================
# milieu de résidence
base_finale$milieu <- haven::as_factor(base_finale$milieu)

base_finale <- base_finale |>
  mutate(
    milieu = case_when(
      as.numeric(milieu) == 1 ~ "Urbain",
      as.numeric(milieu) == 2 ~ "Rural",
     )
  )


#niveau d'éducation du chef de ménage
base_finale$niveau_educ <- haven::as_factor(base_finale$niveau_educ)




