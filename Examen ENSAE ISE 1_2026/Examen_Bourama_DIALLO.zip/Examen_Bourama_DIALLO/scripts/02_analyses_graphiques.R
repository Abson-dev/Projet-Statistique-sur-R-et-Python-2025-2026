#======================================================================
#Section 2: Statistiques descriptives
#=====================================================================

#QUESTION 10:

# TABLEAU DESCRIPTIF PAR MILIEU, avec Ensemble, tests, et mise en forme
library(gtsummary)
tableau <- base_finale|>
  tbl_summary(
    by = milieu,
    statistic = list(all_continuous()  ~ "{mean} ({sd})",
                     all_categorical() ~ "{n} ({p}%)"),
    digits  = all_continuous() ~ 1,
    missing = "ifany"
  ) |>
  add_overall() |>                                   # colonne Ensemble
  add_p() |>                                        # p-values
  bold_labels() |>
  bold_p(t = 0.05) |>
  modify_header(label ~ "**Caracteristique**") |>
  modify_caption("**Tableau 1. Profil des menages selon le milieu**")
tableau      # afficher

#EXPORTER en Word (decommenter si besoin)


#====================================================================
#Section 3: Visualisation
#====================================================================

 ggsave(here("outputs", "figures", "hist_superficie_parcelle.png"),
        plot = hist_parcelle, width = 10, height = 7, dpi = 300)
 



#===================================================================
#Section 4: Reproductibilité
#===================================================================
#Les questions sont repondues dans le projet.


