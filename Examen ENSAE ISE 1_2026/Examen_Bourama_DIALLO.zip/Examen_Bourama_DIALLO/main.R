# =============================================================================
# main.R — POINT D'ENTREE DU PROJET  (le "chef d'orchestre")
# Projet Statistique sous R — Examen Projet Statistique sous R, Session 2025-2026
#
# Auteur(s) : Bourama DIALLO
# Sujet     : Vulnérabilité aux chocs et sécurité alimentaire des ménages
#
# COMMENT LANCER LE PROJET :
#   1. Ouvrir Projet_Examen_R.Rproj dans RStudio (IMPORTANT : passe par le .Rproj
#      pour que tous les chemins relatifs fonctionnent).
#   2. Deposer les fichiers .dta dans data/raw/.
#   3. Executer ce fichier :  source("main.R")   (ou bouton "Source").
# =============================================================================


# --------------------------------------------------------------------------
# 0. PACKAGES : installer le manquant, puis tout charger
# --------------------------------------------------------------------------
packages <- c(
  "tidyverse",   # dplyr, tidyr, ggplot2, forcats, stringr, readr...
  "janitor",     # clean_names, tabyl, adorn_*, get_dupes
  "gtsummary",   # tableaux de synthese
  "haven",       # lire les .dta (Stata)
  "scales",      # formatage des axes des graphiques
  "openxlsx"     # export Excel
)
a_installer <- packages[!packages %in% rownames(installed.packages())]
if (length(a_installer) > 0) {
  message("Installation des packages manquants : ",
          paste(a_installer, collapse = ", "))
  install.packages(a_installer, repos = "https://cloud.r-project.org")
}
invisible(lapply(packages, library, character.only = TRUE))


# --------------------------------------------------------------------------
# 1. CREER LES DOSSIERS DE SORTIE (sans erreur s'ils existent deja)
# --------------------------------------------------------------------------
dir.create("data/raw",         showWarnings = FALSE, recursive = TRUE)
dir.create("data/processed",   showWarnings = FALSE, recursive = TRUE)
dir.create("outputs/figures",  showWarnings = FALSE, recursive = TRUE)
dir.create("outputs/tables",   showWarnings = FALSE, recursive = TRUE)


# --------------------------------------------------------------------------
# 2. LANCER LES ETAPES DANS L'ORDRE
# --------------------------------------------------------------------------
cat("========================================\n")
cat("  ETAPE 1 : Import et nettoyage\n")
cat("========================================\n")
source("scripts/01_import_nettoyage.R")

cat("\n========================================\n")
cat("  ETAPE 2 : Analyses et graphiques\n")
cat("========================================\n")
source("scripts/02_analyses_graphiques.R")


# --------------------------------------------------------------------------
# 3. RECAPITULATIF
# --------------------------------------------------------------------------
cat("\n========================================\n")
cat("  PROJET TERMINE\n")
cat("========================================\n")
cat("Sorties produites dans outputs/ :\n")
for (f in list.files("outputs", recursive = TRUE)) cat("  ->", f, "\n")
cat("\nRapport a compiler : rapport/rapport.Rmd  (bouton Knit)\n")
