# =============================================================
# Q5 : Mécanisme de non-réponse (MCAR/MAR/MNAR) et imputation
#      multiple par équations chaînées (mice)
# =============================================================

vars_imputation <- c(
  "revenu", "taille_menage", "milieu", "region",
  "age_chef", "sexe_chef", "niveau_educ_chef"
)
stopifnot(all(vars_imputation %in% names(menages_enrichi)))

donnees_mice <- menages_enrichi |>
  dplyr::select(hhid, dplyr::all_of(vars_imputation)) |>
  dplyr::mutate(
    milieu           = as.factor(milieu),
    region            = as.factor(region),
    sexe_chef         = as.factor(sexe_chef),
    niveau_educ_chef  = as.factor(niveau_educ_chef)
  )

methode <- mice::make.method(donnees_mice)
methode["hhid"] <- ""                      # identifiant : jamais imputé
methode["revenu"] <- "pmm"                 # continue -> pattern matching
methode["niveau_educ_chef"] <- "polyreg"   # catégorielle nominale
methode[!names(methode) %in% c("revenu", "niveau_educ_chef")] <- ""

pred <- mice::make.predictorMatrix(donnees_mice)
pred[, "hhid"] <- 0
pred["hhid", ] <- 0

mice_fit <- mice::mice(
  donnees_mice, m = 5, method = methode, predictorMatrix = pred,
  seed = 2026, printFlag = FALSE
)

imputes_completes <- mice::complete(mice_fit, action = "long", include = FALSE) |>
  dplyr::group_by(hhid) |>
  dplyr::summarise(
    revenu_impute           = mean(revenu, na.rm = TRUE),
    niveau_educ_chef_impute = names(which.max(table(niveau_educ_chef))),
    .groups = "drop"
  )

menages_enrichi <- menages_enrichi |>
  dplyr::left_join(imputes_completes, by = "hhid") |>
  dplyr::mutate(
    revenu           = dplyr::coalesce(revenu, revenu_impute),
    niveau_educ_chef = dplyr::coalesce(niveau_educ_chef, niveau_educ_chef_impute)
  ) |>
  dplyr::select(-revenu_impute, -niveau_educ_chef_impute)

message("Q5 : imputation multiple (mice, m=5) appliquée à revenu et niveau_educ_chef.")


# =============================================================
# Q6 : Recodage des variables catégorielles
# =============================================================
menages_enrichi <- menages_enrichi |>
  dplyr::mutate(
    milieu = forcats::fct_recode(
      as.factor(milieu),
      "Urbain" = "1", "Rural" = "2"         
    ),
    niveau_educ_chef = factor(
      niveau_educ_chef,
      levels = c("Aucun", "Primaire", "Secondaire", "Superieur"), 
      ordered = TRUE
    ),
    revenu_par_tete = revenu / pmax(taille_menage, 1)
  )

seuils_quintiles <- quantile_pondere(
  menages_enrichi$revenu_par_tete, menages_enrichi$poids_final,
  probs = seq(0, 1, 0.2)
)
seuils_quintiles[1] <- -Inf
seuils_quintiles[length(seuils_quintiles)] <- Inf

menages_enrichi <- menages_enrichi |>
  dplyr::mutate(
    quintile_revenu = cut(
      revenu_par_tete, breaks = seuils_quintiles,
      labels = paste0("Q", 1:5), include.lowest = TRUE
    )
  )

message("Q6 : milieu, niveau_educ_chef et quintile_revenu (pondéré) recodés.")



# =============================================================
# Section 2 — Q7 : Plan de sondage complet (srvyr)
# =============================================================
plan_sondage <- menages_enrichi |>
  srvyr::as_survey_design(
    ids      = grappe,
    strata   = strate,
    weights  = poids_final,
    nest     = TRUE
  )

message("Q7 : plan de sondage déclaré (grappe = grappe, strate = strate, poids = poids_final).")


# =============================================================
# Q8 : Score de diversité alimentaire des ménages (HDDS) + FAO
# =============================================================
groupes_fao <- c(
  "cons_cereales", "cons_tubercules", "cons_legumineuses", "cons_legumes",
  "cons_fruits", "cons_viande", "cons_poisson", "cons_oeufs", "cons_lait",
  "cons_huile", "cons_sucre", "cons_condiments"
)  # confirmé par inspection de data/processed/menages_enrichi.rds
stopifnot(all(groupes_fao %in% names(menages_enrichi)))

menages_enrichi <- menages_enrichi |>
  dplyr::mutate(
    hdds = rowSums(dplyr::across(dplyr::all_of(groupes_fao)), na.rm = TRUE),
    classe_hdds = dplyr::case_when(
      hdds <= 3            ~ "Faible diversité",
      hdds >= 4 & hdds <= 5 ~ "Diversité moyenne",
      hdds >= 6            ~ "Diversité élevée",
      TRUE ~ NA_character_
    ),
    classe_hdds = factor(
      classe_hdds,
      levels = c("Faible diversité", "Diversité moyenne", "Diversité élevée")
    )
  )

plan_sondage <- menages_enrichi |>
  srvyr::as_survey_design(ids = grappe, strata = strate, weights = poids_final, nest = TRUE)

message("Q8 : HDDS calculé (0-12) et classé selon les seuils FAO (<=3 / 4-5 / >=6).")

# =============================================================
# Q9 : Indice composite de vulnérabilité aux chocs
# =============================================================

vars_chocs <- c("choc_secheresse", "choc_hausse_prix", "choc_conflit", "choc_maladie")
poids_strategies <- c(
  strat_reduction_repas = 1,
  strat_vente_actifs    = 2,
  strat_migration        = 2,
  strat_endettement      = 2
)

menages_enrichi <- menages_enrichi |>
  dplyr::mutate(
    nb_chocs = rowSums(dplyr::across(dplyr::all_of(vars_chocs)), na.rm = TRUE),
    score_strategies =
      strat_reduction_repas * poids_strategies["strat_reduction_repas"] +
      strat_vente_actifs    * poids_strategies["strat_vente_actifs"] +
      strat_migration        * poids_strategies["strat_migration"] +
      strat_endettement      * poids_strategies["strat_endettement"],
    chocs_norm      = scales::rescale(nb_chocs, to = c(0, 1)),
    strategies_norm = scales::rescale(score_strategies, to = c(0, 1)),
    indice_vulnerabilite = 0.5 * chocs_norm + 0.5 * strategies_norm,
    classe_vulnerabilite = dplyr::ntile(indice_vulnerabilite, 3),
    classe_vulnerabilite = factor(
      classe_vulnerabilite, levels = 1:3,
      labels = c("Faible", "Moyenne", "Élevée")
    )
  )

plan_sondage <- menages_enrichi |>
  srvyr::as_survey_design(ids = grappe, strata = strate, weights = poids_final, nest = TRUE)

message("Q9 : indice composite de vulnérabilité construit (chocs 50% / stratégies 50%).")



# =============================================================
# Q10 : Tableau 1 pondéré (gtsummary) par milieu et par région
# =============================================================
vars_tableau1 <- c(
  "revenu_par_tete", "taille_menage", "hdds", "classe_hdds",
  "indice_vulnerabilite", "classe_vulnerabilite", "niveau_educ_chef"
)

tableau1_milieu <- plan_sondage |>
  gtsummary::tbl_svysummary(
    by      = milieu,
    include = dplyr::all_of(vars_tableau1),
    statistic = list(
      gtsummary::all_continuous()  ~ "{mean} ({sd})",
      gtsummary::all_categorical() ~ "{p}%"
    ),
    digits = gtsummary::all_continuous() ~ 1
  ) |>
  gtsummary::add_p() |>
  gtsummary::add_n() |>
  gtsummary::modify_caption("**Tableau 1. Indicateurs clés par milieu (statistiques pondérées)**")

tableau1_region <- plan_sondage |>
  gtsummary::tbl_svysummary(
    by      = region,
    include = dplyr::all_of(vars_tableau1),
    statistic = list(
      gtsummary::all_continuous()  ~ "{mean} ({sd})",
      gtsummary::all_categorical() ~ "{p}%"
    ),
    digits = gtsummary::all_continuous() ~ 1
  ) |>
  gtsummary::add_p() |>
  gtsummary::add_n() |>
  gtsummary::modify_caption("**Tableau 1bis. Indicateurs clés par région (statistiques pondérées)**")


sauver_table_html <- function(tbl_gtsummary, nom_fichier) {
  chemin <- here("output", "tables", nom_fichier)
  tryCatch({
    gtsummary::as_gt(tbl_gtsummary) |> gt::gtsave(chemin)
  }, error = function(e) {
    message("gtsave() a échoué (", conditionMessage(e), "), repli sur as_raw_html().")
    html <- gtsummary::as_gt(tbl_gtsummary) |> gt::as_raw_html()
    writeLines(html, chemin)
  })
  message("Tableau sauvegardé : ", nom_fichier)
}

sauver_table_html(tableau1_milieu, "Q10_tableau1_milieu.html")
sauver_table_html(tableau1_region, "Q10_tableau1_region.html")
message("Q10 : Tableau 1 pondéré (milieu, région) exporté dans output/tables/.")


# =============================================================
# Q11 : Coefficient de Gini du revenu par tête + IC bootstrap
# =============================================================
gini_national <- gini_avec_ic(
  menages_enrichi$revenu_par_tete, menages_enrichi$poids_final, R = 1000
) |>
  dplyr::mutate(region = "National", .before = 1)

gini_regional <- menages_enrichi |>
  dplyr::group_by(region) |>
  dplyr::group_modify(~ gini_avec_ic(.x$revenu_par_tete, .x$poids_final, R = 1000)) |>
  dplyr::ungroup()

gini_complet <- dplyr::bind_rows(gini_national, gini_regional)
sauvegarder_tab(gini_complet, "Q11_gini_revenu_par_tete.csv")
message(
  "Q11 : Gini national = ", round(gini_national$gini, 3),
  " [", round(gini_national$ic_bas, 3), " ; ", round(gini_national$ic_haut, 3), "] (IC bootstrap 95%)."
)




# =============================================================
# Section 3 — Q12 : Distribution du revenu par tête par région
# =============================================================
p_densite_revenu <- ggplot(menages_enrichi, aes(x = revenu_par_tete, fill = region, weight = poids_final)) +
  geom_density(alpha = 0.35, color = NA) +
  scale_x_log10(labels = scales::label_comma()) +  
  labs(
    title = "Distribution du revenu par tête par région",
    subtitle = "Densités pondérées, échelle logarithmique",
    x = "Revenu par tête (FCFA, échelle log)", y = "Densité", fill = "Région"
  ) +
  theme(legend.position = "none")   # 23 régions 

p_densite_revenu_facette <- p_densite_revenu +
  facet_wrap(~region, scales = "free_y") +
  theme(strip.text = element_text(size = 7))

sauvegarder_fig(p_densite_revenu, "Q12_densite_revenu_par_tete.png")
sauvegarder_fig(p_densite_revenu_facette, "Q12_densite_revenu_par_tete_facette.png", largeur = 14, hauteur = 12)



# =============================================================
# Q13 : Carte choroplèthe de l'indice de vulnérabilité (sf + tmap)
# =============================================================
vulnerabilite_region <- plan_sondage |>
  srvyr::group_by(region_pcode, region) |>
  srvyr::summarise(indice_vulnerabilite_moy = srvyr::survey_mean(indice_vulnerabilite, na.rm = TRUE)) |>
  dplyr::ungroup()

carte_regions <- sf::st_read(here("data", "raw", "tcd_admin1.shp"), quiet = TRUE) |>
  dplyr::rename(region_pcode = adm1_pcode) |>          # confirmé (region_pcode déjà présent dans menages_enrichi.rds)
  dplyr::left_join(vulnerabilite_region, by = "region_pcode")

p_carte_vulnerabilite <- ggplot(carte_regions) +
  geom_sf(aes(fill = indice_vulnerabilite_moy), color = "white", linewidth = 0.2) +
  scale_fill_viridis_c(option = "magma", direction = -1, na.value = "grey85") +
  labs(
    title = "Indice de vulnérabilité aux chocs par région",
    fill  = "Indice moyen\n(pondéré)"
  ) +
  theme_void() +
  theme(legend.position = "right", plot.title = element_text(face = "bold"))

sauvegarder_fig(p_carte_vulnerabilite, "Q13_carte_vulnerabilite.png", largeur = 9, hauteur = 8)

# Version interactive (tmap)
tmap::tmap_mode("view")
carte_interactive <- tmap::tm_shape(carte_regions) +
  tmap::tm_polygons(
    fill = "indice_vulnerabilite_moy",
    fill.scale = tmap::tm_scale_continuous(values = "-magma"),
    fill.legend = tmap::tm_legend(title = "Indice de vulnérabilité"),
    popup.vars = c("Région" = "region", "Indice" = "indice_vulnerabilite_moy")
  )
tmap::tmap_save(carte_interactive, here("output", "figures", "Q13_carte_vulnerabilite_interactive.html"))
message("Q13 : carte statique (ggplot2/sf) et interactive (tmap) exportées.")



# =============================================================
# Q14 : Figure composite (patchwork), thème graphique cohérent
# =============================================================
p_hdds_milieu <- ggplot(menages_enrichi, aes(x = milieu, y = hdds, weight = poids_final)) +
  geom_boxplot(fill = "#2C7FB8", alpha = 0.7) +
  labs(title = "Diversité alimentaire (HDDS) par milieu", x = NULL, y = "HDDS")

p_vulnerabilite_quintile <- menages_enrichi |>
  dplyr::group_by(quintile_revenu) |>
  dplyr::summarise(vuln_moy = weighted.mean(indice_vulnerabilite, poids_final, na.rm = TRUE)) |>
  ggplot(aes(x = quintile_revenu, y = vuln_moy)) +
  geom_col(fill = "#D95F0E", alpha = 0.85) +
  labs(title = "Vulnérabilité moyenne par quintile de revenu", x = "Quintile de revenu par tête", y = "Indice moyen")

figure_composite <- (p_densite_revenu + p_hdds_milieu) / p_vulnerabilite_quintile +
  patchwork::plot_annotation(
    title = "Sécurité alimentaire et vulnérabilité aux chocs — ENSAN 2026 (Tchad)",
    theme = theme_ensan()
  )

sauvegarder_fig(figure_composite, "Q14_figure_composite.png", largeur = 12, hauteur = 10)

message("Q14 : figure composite (3 graphiques, patchwork, thème theme_ensan()) exportée.")

# =============================================================
# Q15 : export figures déjà fait via sauvegarder_fig() (PNG+PDF)
# =============================================================
message("Q15 : toutes les figures du rapport sont exportées en PNG + PDF dans output/figures/.")

# Sauvegarde de la version enrichie (hdds, indice_vulnerabilite,
# quintile_revenu...) : c'est ce fichier que rapport.Rmd doit charger.
saveRDS(menages_enrichi, here("data", "processed", "menages_analyse.rds"))
message("Sauvegardé : data/processed/menages_analyse.rds")

