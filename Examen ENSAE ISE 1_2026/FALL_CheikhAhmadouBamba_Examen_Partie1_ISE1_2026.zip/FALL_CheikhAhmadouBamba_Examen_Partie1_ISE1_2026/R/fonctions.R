# =============================================================
# fonctions.R — Fonctions utilitaires réutilisables
# =============================================================
library(here)        # gestion des chemins depuis la racine
library(haven)       # lecture du fichier .dta (ensan_menages)
library(readr)       # lecture des fichiers .csv
library(readxl)      # lecture des fichiers .xlsx
library(sf)          # shapefile des régions (tcd_admin1)
library(stringr)     # nettoyage de chaînes (libellés de région)
library(stringi)     # suppression des accents (stri_trans_general)
library(dplyr)       # manipulation des données (pipe natif |>)
library(vctrs)       # conversion sûre des classes vctrs (pillar_num) avant export CSV
library(tidyr)       # pivotage / imputation (mice)
library(purrr)       # itération (notes régionales, bootstrap par région)
library(ggplot2)     # graphiques
library(srvyr)       # statistiques pondérées (plan de sondage : grappe/strate/poids_final)
library(naniar)      # diagnostic des valeurs manquantes (Q4)
library(mice)        # imputation multiple par équations chaînées (Q5)
library(gtsummary)   # tableaux récapitulatifs (Q10)
library(rstatix)     # tests statistiques
library(DescTools)   # coefficient de Gini pondéré + IC bootstrap (Q11)
library(scales)      # formatage des axes
library(forcats)     # recodage des facteurs
library(patchwork)   # assembler plusieurs graphiques (Q14)
library(tmap)        # carte choroplèthe interactive (Q13)

# --- Thème graphique commun à tout le rapport (Q14) -------------
theme_ensan <- function(base_size = 12) {
  theme_minimal(base_size = base_size) +
    theme(
      plot.title      = element_text(face = "bold", size = rel(1.1)),
      plot.subtitle   = element_text(color = "grey35"),
      plot.caption    = element_text(color = "grey45", size = rel(0.75)),
      panel.grid.minor = element_blank(),
      strip.background = element_rect(fill = "grey92", color = NA),
      strip.text       = element_text(face = "bold"),
      legend.position   = "bottom"
    )
}
theme_set(theme_ensan())

# --- Fonction 1 : Sauvegarder un graphique ggplot (PNG + PDF) ---

sauvegarder_fig <- function(plot, nom_fichier, largeur = 10, hauteur = 7,
                            formats = c("png", "pdf")) {
  base <- tools::file_path_sans_ext(nom_fichier)
  for (fmt in formats) {
    chemin <- here("output", "figures", paste0(base, ".", fmt))
    ggsave(chemin, plot = plot, width = largeur, height = hauteur,
           dpi = 300, bg = "white")
  }
  message("Figure sauvegardée : ", base, " (", paste(formats, collapse = ", "), ")")
}

# --- Fonction 2 : Sauvegarder un tableau (data.frame/tibble) ----

sauvegarder_tab <- function(tableau, nom_fichier) {
  chemin <- here("output", "tables", nom_fichier)
  tableau_propre <- tableau |>
    dplyr::mutate(dplyr::across(
      dplyr::where(~ inherits(.x, "vctrs_vctr") && !is.factor(.x)),
      ~ vctrs::vec_data(.x)
    ))
  readr::write_csv(tableau_propre, chemin)
  message("Tableau sauvegardé : ", nom_fichier)
}

# --- Fonction 3 : Quantiles pondérés (revenu par tête, Q6) ------

quantile_pondere <- function(x, poids, probs = seq(0, 1, 0.2)) {
  ok <- !is.na(x) & !is.na(poids)
  x <- x[ok]; poids <- poids[ok]
  ord <- order(x)
  x <- x[ord]; poids <- poids[ord]
  cum_poids <- cumsum(poids) / sum(poids)
  stats::approx(cum_poids, x, xout = probs, ties = "ordered", rule = 2)$y
}

# --- Fonction 4 : Gini pondéré avec IC bootstrap (Q11) -----------

gini_avec_ic <- function(x, poids, R = 1000, niveau_confiance = 0.95) {
  ok <- !is.na(x) & !is.na(poids) & x >= 0
  res <- DescTools::Gini(
    x[ok], weights = poids[ok],
    conf.level = niveau_confiance, R = R, type = "norm", unbiased = TRUE
  )
  tibble::tibble(
    gini    = unname(res[1]),
    ic_bas  = unname(res[2]),
    ic_haut = unname(res[3]),
    n       = sum(ok)
  )
}