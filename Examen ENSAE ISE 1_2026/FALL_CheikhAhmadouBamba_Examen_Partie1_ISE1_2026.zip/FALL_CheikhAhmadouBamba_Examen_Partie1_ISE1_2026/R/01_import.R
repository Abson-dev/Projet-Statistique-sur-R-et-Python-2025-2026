# =============================================================
# 01_import.R
# Section 1, Question 1 : importation des cinq sources
# =============================================================

# -- Source 1 : ensan_menages.dta (Stata, avec labels) ---------

menages <- haven::read_dta(here("data", "raw", "ensan_menages.dta"))

# -- Source 2 : ensan_individus.csv (CSV, UTF-8) ----------------
individus <- readr::read_csv(
  here("data", "raw", "ensan_individus.csv"),
  locale    = readr::locale(encoding = "UTF-8"),
  col_types = readr::cols(
    hhid        = readr::col_character(),
    rang        = readr::col_integer(),
    age         = readr::col_double(),
    sexe        = readr::col_integer(),
    niveau_educ = readr::col_character()
  )
)

# -- Source 3 : ensan_consommation.xlsx (Excel, 2 feuilles) -----
conso_groupes <- readxl::read_excel(
  here("data", "raw", "ensan_consommation.xlsx"),
  sheet     = "Consommation_groupes",
  col_types = c("text", rep("numeric", 12))
)

depenses_menage <- readxl::read_excel(
  here("data", "raw", "ensan_consommation.xlsx"),
  sheet     = "Depenses_menage",
  col_types = c("text", rep("numeric", 5))
)

# -- Source 4 : chocs_menages.csv (CSV, UTF-8) ------------------
chocs <- readr::read_csv(
  here("data", "raw", "chocs_menages.csv"),
  locale    = readr::locale(encoding = "UTF-8"),
  col_types = readr::cols(
    hhid                  = readr::col_character(),
    region_lib            = readr::col_character(),
    choc_secheresse       = readr::col_integer(),
    choc_hausse_prix      = readr::col_integer(),
    choc_conflit          = readr::col_integer(),
    choc_maladie          = readr::col_integer(),
    strat_vente_actifs    = readr::col_integer(),
    strat_reduction_repas = readr::col_integer(),
    strat_migration       = readr::col_integer(),
    strat_endettement     = readr::col_integer()
  )
)

# -- Source 5 : prix_marches.csv (CSV, séries mensuelles) -------
prix_marches <- readr::read_csv(
  here("data", "raw", "prix_marches.csv"),
  locale    = readr::locale(encoding = "UTF-8"),
  col_types = readr::cols(
    marche       = readr::col_character(),
    region       = readr::col_character(),
    produit      = readr::col_character(),
    mois         = readr::col_date(format = "%Y-%m-%d"),
    prix_fcfa_kg = readr::col_double()
  )
)



