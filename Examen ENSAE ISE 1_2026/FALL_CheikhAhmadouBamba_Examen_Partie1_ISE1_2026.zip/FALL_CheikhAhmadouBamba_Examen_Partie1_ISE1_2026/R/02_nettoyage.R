# =============================================================
# 02_nettoyage.R
# Section 1, Question 2 : fusion des modules en un jeu de
# données ménages enrichi
# =============================================================

n0 <- nrow(menages)
message("Ménages (référence) : ", n0, " lignes")

# --- Caractéristiques du chef de ménage (rang == 1) -----------

chef_menage <- individus |>
  dplyr::filter(rang == 1) |>
  dplyr::distinct(hhid, .keep_all = TRUE) |>
  dplyr::select(
    hhid,
    age_chef         = age,
    sexe_chef        = sexe,
    niveau_educ_chef = niveau_educ
  )

if (dplyr::n_distinct(chef_menage$hhid) != nrow(chef_menage)) {
  warning("Doublons de hhid détectés dans chef_menage après filtrage rang == 1.")
}

menages_enrichi <- menages |>
  dplyr::left_join(chef_menage, by = "hhid")

stopifnot(nrow(menages_enrichi) == n0)
message("Après jointure chef de ménage : ", nrow(menages_enrichi), " lignes (OK)")

# --- Consommation alimentaire agrégée --------------------------

conso_groupes_u   <- dplyr::distinct(conso_groupes, hhid, .keep_all = TRUE)
depenses_menage_u <- dplyr::distinct(depenses_menage, hhid, .keep_all = TRUE)

menages_enrichi <- menages_enrichi |>
  dplyr::left_join(conso_groupes_u, by = "hhid")

stopifnot(nrow(menages_enrichi) == n0)
message("Après jointure consommation (groupes FAO) : ", nrow(menages_enrichi), " lignes (OK)")

menages_enrichi <- menages_enrichi |>
  dplyr::left_join(depenses_menage_u, by = "hhid")

stopifnot(nrow(menages_enrichi) == n0)
message("Après jointure dépenses du ménage : ", nrow(menages_enrichi), " lignes (OK)")

# --- Chocs subis et stratégies d'adaptation --------------------

chocs_u <- chocs |>
  dplyr::distinct(hhid, .keep_all = TRUE) |>
  dplyr::select(-region_lib)

menages_enrichi <- menages_enrichi |>
  dplyr::left_join(chocs_u, by = "hhid")

stopifnot(nrow(menages_enrichi) == n0)
message("Après jointure chocs/stratégies d'adaptation : ", nrow(menages_enrichi), " lignes (OK)")

message(
  "Jeu de données ménages enrichi : ", nrow(menages_enrichi), " lignes, ",
  ncol(menages_enrichi), " colonnes (", n0, " lignes attendues)"
)

# =============================================================
# Section 1, Question 3 : identification et correction des libellés de
# régions incohérents entre fichiers
# =============================================================

normaliser_region <- function(x) {
  x |>
    stringr::str_to_upper() |>
    stringi::stri_trans_general("Latin-ASCII") |>
    stringr::str_remove_all("[^A-Z]")
}


regions_shp <- sf::st_read(
  here("data", "raw", "tcd_admin1.shp"),
  quiet = TRUE
) |>
  sf::st_drop_geometry() |>
  dplyr::transmute(
    region_pcode = adm1_pcode,
    region       = adm1_name,
    cle          = normaliser_region(adm1_name)
  )

stopifnot(nrow(regions_shp) == 23)
message("Référentiel régions (shapefile) : ", nrow(regions_shp), " régions")


diagnostiquer_regions <- function(valeurs, nom_source) {
  cles      <- normaliser_region(unique(stats::na.omit(valeurs)))
  manquants <- setdiff(cles, regions_shp$cle)
  message(
    nom_source, " : ",
    if (length(manquants) == 0) "OK, tous les libellés reconnus après normalisation."
    else paste0("libellés NON reconnus -> ", paste(manquants, collapse = ", "))
  )
  invisible(manquants)
}

diagnostiquer_regions(menages_enrichi$region, "menages")
diagnostiquer_regions(prix_marches$region, "prix_marches")
diagnostiquer_regions(chocs$region_lib, "chocs (region_lib)")


corrections_manuelles <- c(
  "OUADAI"    = "OUADDAI",
  "TANDJILLE" = "TANDJILE"
)

harmoniser_region <- function(valeurs) {
  cle <- normaliser_region(valeurs)
  cle <- dplyr::recode(cle, !!!corrections_manuelles)
  regions_shp$region[match(cle, regions_shp$cle)]
}

pcode_region <- function(valeurs) {
  cle <- normaliser_region(valeurs)
  cle <- dplyr::recode(cle, !!!corrections_manuelles)
  regions_shp$region_pcode[match(cle, regions_shp$cle)]
}

# --- Application : région et pcode harmonisés dans menages_enrichi
menages_enrichi <- menages_enrichi |>
  dplyr::mutate(
    region       = harmoniser_region(region),
    region_pcode = pcode_region(region)
  )

stopifnot(!anyNA(menages_enrichi$region_pcode))
message(
  "menages_enrichi : régions harmonisées, ",
  dplyr::n_distinct(menages_enrichi$region_pcode), " régions distinctes (23 attendues)."
)

# =============================================================
# Section 1, Question 4 : diagnostic complet des valeurs
# manquantes avec naniar
# =============================================================


compter_na_tagues <- function(x) {
  if (!is.double(x)) return(0L)
  sum(haven::is_tagged_na(x))
}

resume_na_tagues <- vapply(menages_enrichi, compter_na_tagues, integer(1))
resume_na_tagues <- resume_na_tagues[resume_na_tagues > 0]

if (length(resume_na_tagues) > 0) {
  message("Valeurs manquantes taguées Stata détectées :")
  print(resume_na_tagues)
  for (var in names(resume_na_tagues)) {
    tags <- haven::na_tag(menages_enrichi[[var]][haven::is_tagged_na(menages_enrichi[[var]])])
    message("  - ", var, " : tag(s) = ", paste(unique(tags), collapse = ", "))
  }
} else {
  message("Aucune valeur manquante taguée Stata détectée dans menages_enrichi.")
}

#--- Valeurs manquantes standards (naniar) -----------------------
  # Résumé quantitatif par variable (nombre + % de NA)
  resume_na <- naniar::miss_var_summary(menages_enrichi) |>
  dplyr::mutate(dplyr::across(
    dplyr::where(~ inherits(.x, "vctrs_vctr") && !is.factor(.x)),
    ~ vctrs::vec_data(.x)
  ))  # dé-classe pct_miss (pillar_num) avant écriture CSV
sauvegarder_tab(resume_na, "Q4_resume_valeurs_manquantes.csv")
print(resume_na)

# Visualisation matricielle des valeurs manquantes
p_miss <- naniar::vis_miss(menages_enrichi, warn_large_data = FALSE)
sauvegarder_fig(p_miss, "Q4_vis_miss.png", largeur = 12, hauteur = 8)

# Cooccurrences des valeurs manquantes 
grDevices::png(
  here("output", "figures", "Q4_cooccurrence_manquantes.png"),
  width = 2400, height = 1600, res = 300
)
print(naniar::gg_miss_upset(menages_enrichi, nsets = 10))
grDevices::dev.off()
message("Figure sauvegardée : Q4_cooccurrence_manquantes.png")

message(
  "Diagnostic Q4 terminé : ",
  sum(resume_na$n_miss > 0), " variable(s) avec au moins une valeur manquante standard ; ",
  length(resume_na_tagues), " variable(s) avec des valeurs manquantes taguées Stata."
)


# --- Sauvegarde --------------------------------------------------
saveRDS(menages_enrichi, here("data", "processed", "menages_enrichi.rds"))
saveRDS(regions_shp, here("data", "processed", "regions_shp.rds"))
message("Sauvegardé : data/processed/menages_enrichi.rds, data/processed/regions_shp.rds")
