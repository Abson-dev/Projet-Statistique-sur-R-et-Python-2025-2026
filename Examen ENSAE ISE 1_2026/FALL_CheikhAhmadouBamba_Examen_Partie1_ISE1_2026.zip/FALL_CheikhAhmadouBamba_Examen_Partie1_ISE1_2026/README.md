# Examen – Partie 1 : Vulnérabilité aux chocs et sécurité alimentaire des ménages
## ENSAN 2026, Tchad — Projet Statistique sous R (ENSAE ISE1, 2025-2026)

## Description du Projet
Note technique reproductible identifiant les déterminants de l'insécurité
alimentaire des ménages, la vulnérabilité différenciée par région et par
milieu, à partir de l'Enquête Nationale sur la Sécurité Alimentaire et
Nutritionnelle (ENSAN 2026, données simulées à des fins pédagogiques,
basées sur les limites administratives officielles du Tchad).

## Auteur
- **Cheikh Ahmadou Bamba FALL**

**Classe :** ISE 1 Cycle long (ISEP 3)
**École :** École Nationale de la Statistique et de l'Analyse Économique Pierre Ndiaye (ENSAE)
**Année académique :** 2025-2026
**Enseignant :** Aboubacar HEMA (IFPRI)

## Structure du Projet
```
FALL_CheikhAhmadouBamba_Examen_Partie1_ISE1_2026/
├── main.R                                                    # Point d'entrée unique — exécuter ce fichier
├── FALL_CheikhAhmadouBamba_Examen_Partie1_ISE1_2026.Rproj    # Fichier projet RStudio
├── .Rprofile                     # Active renv automatiquement
├── .gitignore
├── .git/                         # Dépôt Git local (historique de commits)
├── renv/                         # Gestion des dépendances (renv.lock à générer via renv::snapshot())
├── README.md                     # Ce fichier
├── data/
│   ├── raw/                      # Données brutes fournies (JAMAIS modifiées)
│   │   ├── ensan_menages.dta
│   │   ├── ensan_individus.csv
│   │   ├── ensan_consommation.xlsx
│   │   ├── chocs_menages.csv
│   │   ├── prix_marches.csv
│   │   ├── tcd_admin1.shp (+ .dbf/.shx/.prj/.cpg)
│   │   └── dictionnaire_variables_ENSAN2026_Tchad.xlsx
│   └── processed/                # Données nettoyées et transformées
│       ├── menages_enrichi.rds   # Ménages fusionnés + régions harmonisées (Q2-Q3)
│       └── regions_shp.rds       # Référentiel régions (nom + pcode, sans géométrie)
├── R/
│   ├── fonctions.R               # Fonctions utilitaires réutilisables
│   ├── 01_import.R               # Q1 : import des 5 sources
│   ├── 02_nettoyage.R            # Q2-Q4 : fusion, régions, valeurs manquantes
│   └── 03_analyse.R              # Analyses, graphiques et tableaux
├── output/
│   ├── figures/                  # Graphiques exportés (.png)
│   └── tables/                   # Tableaux exportés (.csv)
└── rapport/
    └── rapport.qmd                # Note technique finale (Quarto → HTML + Word)
```

## Données Utilisées
| Fichier | Contenu | Format |
|---------|---------|--------|
| `ensan_menages.dta` | hhid, région (23 provinces), milieu, grappe, strate, poids_final, revenu, taille du ménage | Stata (labels) |
| `ensan_individus.csv` | âge, sexe, niveau d'éducation, rang dans le ménage | CSV (UTF-8) |
| `ensan_consommation.xlsx` | 12 groupes alimentaires FAO (0/1) et dépenses par poste | Excel, plusieurs feuilles |
| `chocs_menages.csv` | chocs subis (sécheresse, hausse des prix, conflit, maladie) et stratégies d'adaptation | CSV |
| `prix_marches.csv` | prix mensuels de 4 céréales, 24 mois, par marché | CSV |
| `tcd_admin1.shp` (+ fichiers associés) | limites administratives des régions du Tchad | Shapefile (HDX) |

**Source :** données simulées pour l'examen ; limites administratives officielles HDX/OCHA COD-AB Tchad.

## Comment Reproduire les Résultats
1. Ouvrir `FALL_CheikhAhmadouBamba_Examen_Partie1_ISE1_2026.Rproj` dans RStudio (renv s'active automatiquement via `.Rprofile`), puis `renv::restore()`.
2. Exécuter `main.R`.
3. Rendre le rapport : `quarto::quarto_render("rapport/rapport.qmd")` (génère `rapport.html` et `rapport.docx`).
4. Tous les outputs sont générés automatiquement dans `output/`.

## Packages R Utilisés
`here`, `haven`, `readr`, `readxl`, `sf`, `stringr`, `stringi`, `dplyr`,
`ggplot2`, `srvyr`, `naniar`, `gtsummary`, `rstatix`, `scales`, `forcats`,
`patchwork`
