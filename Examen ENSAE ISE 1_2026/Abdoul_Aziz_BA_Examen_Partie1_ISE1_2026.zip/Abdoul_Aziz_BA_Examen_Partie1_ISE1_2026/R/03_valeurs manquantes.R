# 03_valeurs_manquantes.R
install.packages(naniar)
install.packages()
library(tidyverse)
library(naniar)
library(mice)
library(haven)
library(here)

menages_enrichi <- read_rds(here("data/processed/menages_enrichi.rds"))


# 3.1 Distinguer NA standards et valeurs manquantes 
vars_a_verifier <- menages_enrichi |>
  select(where(haven::is.labelled)) |>
  names()

if (length(vars_a_verifier) > 0) {
  synthese_tags <- menages_enrichi |>
    select(all_of(vars_a_verifier)) |>
    map_dfr(~ tibble(tag = haven::na_tag(.x)), .id = "variable") |>
    filter(!is.na(tag)) |>
    count(variable, tag)
  cat("Valeurs manquantes taguees Stata detectees :\n")
  print(synthese_tags)
} else {
  cat("Aucune variable labelled/tagged detectee apres jointures.\n")
}

menages_na_ok <- menages_enrichi |>
  mutate(across(where(haven::is.labelled), haven::zap_labels))


# 3.2 Diagnostic naniar : resume, visualisation, cooccurrences

dir.create(here("output/figures"), showWarnings = FALSE, recursive = TRUE)
dir.create(here("output/tables"),  showWarnings = FALSE, recursive = TRUE)

resume_na <- naniar::miss_var_summary(menages_na_ok)
write_csv(resume_na, here("output/tables/resume_valeurs_manquantes.csv"))
print(resume_na)

fig_na_var <- naniar::gg_miss_var(menages_na_ok, show_pct = TRUE) +
  labs(title = "Part de valeurs manquantes par variable")
ggsave(here("output/figures/na_par_variable.png"), fig_na_var, width = 8, height = 6, dpi = 300)

fig_na_upset <- naniar::gg_miss_upset(menages_na_ok)
# gg_miss_upset renvoie un objet base R (grid) : on l'exporte via un device
png(here("output/figures/na_cooccurrences_upset.png"), width = 2400, height = 1800, res = 300)
print(fig_na_upset)
dev.off()


# 3.3 Hypotheses de mecanisme de non-reponse pour deux variables cles
fig_na_revenu_milieu <- menages_na_ok |>
  mutate(revenu_manquant = is.na(revenu)) |>
  count(milieu, revenu_manquant) |>
  ggplot(aes(x = factor(milieu), y = n, fill = revenu_manquant)) +
  geom_col(position = "fill") +
  labs(title = "Taux de non-reponse au revenu selon le milieu",
       x = "Milieu", y = "Proportion", fill = "Revenu manquant")
ggsave(here("output/figures/na_revenu_par_milieu.png"), fig_na_revenu_milieu,
       width = 7, height = 5, dpi = 300)


# 3.4 Imputation multiple par equations chainees (mice)
vars_imputation <- c("revenu", "taille_menage", "milieu", "age_chef",
                     "sexe_chef", "niveau_educ_chef")

donnees_mice <- menages_na_ok |>
  select(hhid, all_of(vars_imputation)) |>
  mutate(
    milieu           = as.factor(milieu),
    sexe_chef        = as.factor(sexe_chef),
    niveau_educ_chef = as.factor(niveau_educ_chef)
  )

methodes <- make.method(donnees_mice)
methodes["hhid"] <- ""                 # identifiant : jamais impute
methodes["revenu"] <- "pmm"            # continue asymetrique -> pmm
methodes["niveau_educ_chef"] <- "polyreg"  # categorielle > 2 niveaux

pred_matrix <- make.predictorMatrix(donnees_mice)
pred_matrix[, "hhid"] <- 0
pred_matrix["hhid", ] <- 0

imp <- mice(donnees_mice, m = 20, method = methodes,
            predictorMatrix = pred_matrix, seed = 2026, printFlag = FALSE)

# Verification de convergence 
png(here("output/figures/mice_convergence.png"), width = 2000, height = 1400, res = 300)
plot(imp)
dev.off()

# On retient une imputation ponctuelle
implicats <- complete(imp, "long", include = FALSE)

revenu_impute <- implicats |>
  group_by(hhid = rep(donnees_mice$hhid, times = imp$m)) |>
  summarise(revenu_imp = mean(revenu), .groups = "drop")

menages_imputed <- menages_na_ok |>
  left_join(revenu_impute, by = "hhid") |>
  mutate(revenu_final = coalesce(revenu, revenu_imp))

write_rds(imp, here("data/processed/mice_object.rds"))
write_rds(menages_imputed, here("data/processed/menages_imputed.rds"))

cat("Imputation terminee :", sum(is.na(menages_na_ok$revenu)),
    "revenus manquants imputes sur", nrow(menages_na_ok), "menages.\n")