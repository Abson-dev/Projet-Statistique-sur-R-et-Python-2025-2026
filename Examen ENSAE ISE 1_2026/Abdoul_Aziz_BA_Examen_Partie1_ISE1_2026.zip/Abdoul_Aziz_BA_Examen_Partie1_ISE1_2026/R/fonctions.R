# Fonctions personnalisées réutilisables
# Auteur : 
# Date : 


