# 06_tableau1_gini.R
# Tableau 1 pondere (gtsummary) et coefficient de Gini avec IC bootstrap

library(tidyverse)
library(srvyr)
library(gtsummary)
library(here)

menages_final <- read_rds(here("data/processed/menages_final.rds"))
plan_ensan    <- read_rds(here("data/processed/plan_sondage.rds"))

dir.create(here("output/tables"), showWarnings = FALSE, recursive = TRUE)


# 6.1 Tableau 1 pondere par milieu
tbl1_milieu <- plan_ensan |>
  tbl_svysummary(
    include = c(hdds, classe_fao, indice_vulnerabilite, revenu_par_tete,
                niveau_educ_chef_recode, taille_menage),
    by = milieu_lib,
    statistic = list(
      all_continuous()  ~ "{mean} ({sd})",
      all_categorical() ~ "{p}% ({n_unweighted})"
    ),
    digits = all_continuous() ~ 1,
    missing = "ifany"
  ) |>
  add_p() |>
  add_overall() |>
  modify_header(label ~ "**Indicateur**") |>
  modify_caption("**Tableau 1. Indicateurs cles par milieu (statistiques ponderees, ENSAN 2026)**")

# 6.2 Tableau 1 pondere par region
-
  tbl1_region <- plan_ensan |>
  tbl_svysummary(
    include = c(hdds, classe_fao, indice_vulnerabilite, revenu_par_tete),
    by = region_norm,
    statistic = list(
      all_continuous()  ~ "{mean} ({sd})",
      all_categorical() ~ "{p}%"
    ),
    digits = all_continuous() ~ 1
  ) |>
  add_p() |>
  modify_caption("**Tableau 1bis. Indicateurs cles par region (statistiques ponderees)**")

gtsummary::as_gt(tbl1_milieu) |> gt::gtsave(here("output/tables/tableau1_par_milieu.html"))
gtsummary::as_gt(tbl1_region) |> gt::gtsave(here("output/tables/tableau1_par_region.html"))


# 6.3 Coefficient de Gini du revenu par tete, national et par region, avec IC
#     bootstrap (les poids de sondage sont integres a chaque replicat)

library(DescTools)
library(boot)

gini_pondere <- function(data, indices, var = "revenu_par_tete", poids = "poids_final") {
  d <- data[indices, ]
  DescTools::Gini(d[[var]], weights = d[[poids]], unbiased = FALSE)
}

set.seed(2026)

# National
boot_national <- boot(data = menages_final, statistic = gini_pondere, R = 1000)
ic_national <- boot.ci(boot_national, type = "perc")

gini_national <- tibble(
  region    = "National",
  gini      = boot_national$t0,
  ic_bas    = ic_national$percent[4],
  ic_haut   = ic_national$percent[5]
)

# Par region
regions <- menages_final |> distinct(region_norm) |> pull()

gini_regions <- map_dfr(regions, function(r) {
  d_region <- menages_final |> filter(region_norm == r)
  b <- boot(data = d_region, statistic = gini_pondere, R = 1000)
  ic <- boot.ci(b, type = "perc")
  tibble(region = r, gini = b$t0, ic_bas = ic$percent[4], ic_haut = ic$percent[5])
})

gini_final <- bind_rows(gini_national, gini_regions) |>
  arrange(desc(gini))

write_csv(gini_final, here("output/tables/gini_revenu_par_tete.csv"))
print(gini_final)
