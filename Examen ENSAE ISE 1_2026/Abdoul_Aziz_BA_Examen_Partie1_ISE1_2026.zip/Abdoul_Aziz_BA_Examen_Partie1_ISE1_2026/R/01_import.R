# Script d'importation des données

#Installation des packages 
library(haven)
library(dplyr)
library(ggplot2)
library(scales)
library(patchwork)
library(viridis)
library(tidyverse)
library(haven)
library(readxl)
library(here)

#1. Module menage (Stata) 
ensan_menages <- read_dta("data/raw/raw/ensan_menages.dta")

#2. Module individu (CSV, UTF-8) 
ensan_individus <- read_csv(
    "data/raw/raw/ensan_individus.csv",
    locale = locale(encoding = "UTF-8"),
    col_types = cols(
      hhid        = col_character(),
      rang        = col_double(),
      age         = col_double(),
      sexe        = col_double(),
      niveau_educ = col_character()
    )
)
# 3. Module consommation 
feuilles_conso <- excel_sheets(here("data/raw/raw/ensan_consommation.xlsx"))
cat("Feuilles detectees dans ensan_consommation.xlsx :",
    paste(feuilles_conso, collapse = ", "), "\n")
# On importe chaque feuille et on les assemble par hhid 
ensan_consommation <- feuilles_conso |>
  set_names() |>
  map(~ read_excel(here("data/raw/raw/ensan_consommation.xlsx"), sheet = .x)) |>
  reduce(full_join, by = "hhid")

# Chocs et strategies d'adaptation 
chocs_menages <- read_csv("data/raw/raw/chocs_menages.csv")  

# Limites administratives 
tcd_admin1 <- st_read(here("data/raw/tcd_admin1.shp"), quiet = TRUE)

# . Prix des marches 
prix_marches <- read_csv("data/raw/raw/prix_marches.csv")

#glimpse() sur chaque fichier pour repérer les variables utiles
glimpse(ensan_menages)
glimpse(ensan_individus)
glimpse(ensan_consommation)
glimpse(chocs_menages)
glimpse(prix_marches)

# Vérification rapide des dimensions (toujours faire ça en premier)
cat("ensan_menages:", nrow(ensan_menages), "x", ncol(ensan_menages), "\n")
cat(" ensan_individus:", nrow(ensan_individus), "x", ncol(ensan_individus), "\n")
cat("ensan_consommation:", nrow(ensan_consommation), "x", ncol(ensan_consommation), "\n")
cat(" chocs_menages:", nrow(chocs_menages), "x", ncol(chocs_menages), "\n")
cat("prix_marches:", nrow(prix_marches), "x", ncol(prix_marches), "\n")

