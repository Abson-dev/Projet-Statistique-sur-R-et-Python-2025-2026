# 07_visualisations.R
# Theme graphique commun, densites de revenu par region, figure composite
library(tidyverse)
library(srvyr)
library(patchwork)
library(scales)
library(here)

menages_final <- read_rds(here("data/processed/menages_final.rds"))
plan_ensan    <- read_rds(here("data/processed/plan_sondage.rds"))

dir.create(here("output/figures"), showWarnings = FALSE, recursive = TRUE)


# Theme graphique commun a l'ensemble du rapport

theme_ensan <- function(base_size = 12) {
  theme_minimal(base_size = base_size) +
    theme(
      plot.title       = element_text(face = "bold", size = rel(1.1)),
      plot.subtitle    = element_text(color = "grey35"),
      panel.grid.minor = element_blank(),
      legend.position  = "bottom",
      strip.text       = element_text(face = "bold")
    )
}
theme_set(theme_ensan())


# Figure 1 : distribution du revenu par tete par region
# Variable tres asymetrique -> echelle log10 sur l'axe des x, densites
# ponderees par le poids de sondage (density(..., weights = )).
fig_densite_revenu <- menages_final |>
  filter(revenu_par_tete > 0) |>
  ggplot(aes(x = revenu_par_tete, fill = region_norm, weight = poids_final)) +
  geom_density(alpha = 0.35, color = NA) +
  scale_x_log10(labels = label_number(big.mark = " ")) +
  labs(
    title = "Distribution du revenu par tete selon la region",
    subtitle = "Densites ponderees, echelle logarithmique",
    x = "Revenu par tete (FCFA, echelle log10)", y = "Densite", fill = "Region"
  ) +
  theme(legend.position = "right")

ggsave(here("output/figures/fig1_densite_revenu_region.png"), fig_densite_revenu,
       width = 9, height = 6, dpi = 300)
ggsave(here("output/figures/fig1_densite_revenu_region.pdf"), fig_densite_revenu,
       width = 9, height = 6)

# Figure 2 : HDDS moyen pondere par region (barres avec IC)

hdds_region <- plan_ensan |>
  group_by(region_norm) |>
  summarise(hdds_moyen = survey_mean(hdds, vartype = "ci", na.rm = TRUE)) |>
  arrange(hdds_moyen)

fig_hdds_region <- hdds_region |>
  mutate(region_norm = fct_reorder(region_norm, hdds_moyen)) |>
  ggplot(aes(x = hdds_moyen, y = region_norm)) +
  geom_pointrange(aes(xmin = hdds_moyen_low, xmax = hdds_moyen_upp)) +
  labs(title = "Score de diversite alimentaire (HDDS) moyen par region",
       subtitle = "Moyennes ponderees, IC 95%",
       x = "HDDS moyen (0-12)", y = NULL)


# Figure 3 : indice de vulnerabilite selon le milieu (boxplot pondere ~ violon)

fig_vuln_milieu <- menages_final |>
  ggplot(aes(x = milieu_lib, y = indice_vulnerabilite, weight = poids_final)) +
  geom_violin(fill = "grey85", color = NA) +
  geom_boxplot(width = 0.15, outlier.alpha = 0.3) +
  labs(title = "Indice de vulnerabilite aux chocs selon le milieu",
       x = NULL, y = "Indice de vulnerabilite (0-100)")


# Figure composite (>= 3 graphiques) avec patchwork

figure_composite <- (fig_densite_revenu + fig_hdds_region) / fig_vuln_milieu +
  plot_annotation(
    title = "ENSAN 2026 - Vue d'ensemble de la vulnerabilite alimentaire",
    tag_levels = "A"
  ) &
  theme_ensan(base_size = 10)

ggsave(here("output/figures/fig_composite_patchwork.png"), figure_composite,
       width = 12, height = 9, dpi = 300)
ggsave(here("output/figures/fig_composite_patchwork.pdf"), figure_composite,
       width = 12, height = 9)