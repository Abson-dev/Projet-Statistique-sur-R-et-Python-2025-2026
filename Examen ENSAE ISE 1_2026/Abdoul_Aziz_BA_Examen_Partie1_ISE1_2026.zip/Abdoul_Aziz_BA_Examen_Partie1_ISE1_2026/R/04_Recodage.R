# 04_recodage.R
# Recodage des variables categorielles necessaires a l'analyse

library(tidyverse)
library(here)

menages_imputed <- read_rds(here("data/processed/menages_imputed.rds"))

menages_recode <- menages_imputed |>
  mutate(
    milieu_lib = case_when(
      milieu == 1 ~ "Urbain",
      milieu == 2 ~ "Rural",
      TRUE ~ NA_character_
    ) |> factor(levels = c("Urbain", "Rural")),
    
    niveau_educ_chef_recode = niveau_educ_chef |>
      fct_collapse(
        "Aucun"                 = "Aucun",
        "Primaire"              = "Primaire",
        "Secondaire ou plus"    = c("Secondaire", "Superieur")
      ) |>
      fct_explicit_na(na_level = "Non renseigne"),
    
    revenu_par_tete = revenu_final / pmax(taille_menage, 1),
    
    # Quintiles de revenu par tete : calcules sans ponderation ici a titre de
    # variable de recodage
    quintile_revenu_tete = ntile(revenu_par_tete, 5) |>
      factor(labels = paste0("Q", 1:5))
  )

write_rds(menages_recode, here("data/processed/menages_recode.rds"))

cat("Recodage termine. Repartition milieu :\n")
print(count(menages_recode, milieu_lib))
cat("\nRepartition niveau d'education du chef :\n")
print(count(menages_recode, niveau_educ_chef_recode))
