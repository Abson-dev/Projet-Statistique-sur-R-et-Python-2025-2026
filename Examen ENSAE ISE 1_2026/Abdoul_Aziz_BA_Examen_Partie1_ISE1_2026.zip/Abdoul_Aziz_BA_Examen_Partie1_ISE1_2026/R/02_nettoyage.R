# Script de nettoyage des données

# 02_cleaning_jointures.R
# Doublons, harmonisation des libelles de region, fusion des modules
library(tidyverse)
library(here)
library(janitor)

ensan_menages      <- read_rds(here("data/processed/ensan_menages.rds"))
ensan_individus    <- read_rds(here("data/processed/ensan_individus.rds"))
ensan_consommation <- read_rds(here("data/processed/ensan_consommation.rds"))
chocs_menages      <- read_rds(here("data/processed/chocs_menages.rds"))


# 2.1 Doublons dans la base MENAGE 
#Ici on essaie de voir  combien de hhid apparaissent plus d'une fois, et les doublons
# sont-ils des lignes strictement identiques 
n_hhid_dupliques        <- ensan_menages|> count(hhid) |> filter(n > 1) |> nrow()
n_lignes_identiques_dup <- ensan_menages |>
  filter(duplicated(across(everything())) | duplicated(across(everything()), fromLast = TRUE)) |>
  nrow()

cat("Menages - hhid dupliques :", n_hhid_dupliques,
    "| lignes strictement identiques :", n_lignes_identiques_dup, "\n")


# on supprime d'abord les doublons parfaits (toutes colonnes identiques)
ensan_menages_clean <- ensan_menages |>
  distinct(across(everything()), .keep_all = TRUE) |>
  distinct(hhid, .keep_all = TRUE)

cat("Menages avant nettoyage :", nrow(ensan_menages),
    "| apres nettoyage :", nrow(ensan_menages_clean), "\n")

# 2.2 Doublons dans la base INDIVIDU (cle hhid + rang) et extraction du chef
# rang =1 identifie le chef de menage 
# On verifie d'abord qu'aucun hhid ne comporte plusieurs individus a rang 1,
diag_doublons_individus <- ensan_individus |>
  count(hhid, rang, name = "n_occurrences") |>
  filter(n_occurrences > 1)

cat("Couples (hhid, rang) dupliques dans la base individu :",
    nrow(diag_doublons_individus), "\n")

ensan_individus_clean <- ensan_individus |>
  distinct(across(everything()), .keep_all = TRUE) |>
  distinct(hhid, rang, .keep_all = TRUE)

# Nettoyage de l'objet de diagnostic intermediaire 
rm(diag_doublons_individus)

chef_menage <- ensan_individus_clean |>
  filter(rang == 1) |>
  distinct(hhid, .keep_all = TRUE) |>          
  transmute(
    hhid,
    age_chef         = age,
    sexe_chef        = sexe,
    niveau_educ_chef = niveau_educ
  )

cat("Chefs de menage identifies :", nrow(chef_menage),
    "pour", n_distinct(ensan_individus_clean$hhid), "menages dans le module individu\n")


# 2.3 Harmonisation des libelles de region AVANT toute jointure spatiale

normaliser_region <- function(x) {
  x |>
    str_squish() |>
    str_to_lower() |>
    str_to_title()
}

ensan_menages_clean <- ensan_menages_clean |>
  mutate(region_norm = normaliser_region(region))

chocs_menages_clean <- chocs_menages |>
  mutate(region_norm = normaliser_region(region_lib))

# Table de correspondance region_norm(menages) <-> region_norm(chocs), a
regions_menages <- ensan_menages_clean |> distinct(region_norm) |> pull()
regions_chocs   <- chocs_menages_clean |> distinct(region_norm) |> pull()

regions_non_appariees <- union(
  setdiff(regions_menages, regions_chocs),
  setdiff(regions_chocs, regions_menages)
)
if (length(regions_non_appariees) > 0) {
  cat("ATTENTION - libelles de region non apparies apres normalisation :\n")
  print(regions_non_appariees)
  
} else {
  cat("Libelles de region coherents entre ensan_menages et chocs_menages.\n")
}

# 2.4 Agregation de la consommation alimentaire au niveau menage
groupes_fao <- c("cons_cereales", "cons_tubercules", "cons_legumineuses",
                 "cons_legumes", "cons_fruits", "cons_viande", "cons_poisson",
                 "cons_oeufs", "cons_lait", "cons_huile", "cons_sucre",
                 "cons_condiments")

conso_menage <- ensan_consommation |>
  distinct(hhid, .keep_all = TRUE) |>
  select(hhid, all_of(groupes_fao))

# 2.5 Fusion en un jeu de donnees menage enrichi, avec verification du nombre
#     de lignes a CHAQUE etape 

n_avant <- nrow(ensan_menages_clean)
stopifnot(!anyDuplicated(ensan_menages_clean$hhid))

menages_enrichi <- ensan_menages_clean |>
  left_join(chef_menage, by = "hhid")
stopifnot(nrow(menages_enrichi) == n_avant)
cat("Apres jointure chef de menage : ", nrow(menages_enrichi), "lignes (attendu ", n_avant, ")\n")

menages_enrichi <- menages_enrichi |>
  left_join(conso_menage, by = "hhid")
stopifnot(nrow(menages_enrichi) == n_avant)
cat("Apres jointure consommation   : ", nrow(menages_enrichi), "lignes (attendu ", n_avant, ")\n")

menages_enrichi <- menages_enrichi |>
  left_join(
    chocs_menages_clean |> select(-region_lib, -region_norm),
    by = "hhid"
  )
stopifnot(nrow(menages_enrichi) == n_avant)
cat("Apres jointure chocs          : ", nrow(menages_enrichi), "lignes (attendu ", n_avant, ")\n")

cat("\nJeu de donnees menage enrichi : ", nrow(menages_enrichi), "lignes x",
    ncol(menages_enrichi), "colonnes (inchangere par rapport aux",
    n_avant, "menages nettoyes).\n")

write_rds(menages_enrichi, here("data/processed/menages_enrichi.rds"))
