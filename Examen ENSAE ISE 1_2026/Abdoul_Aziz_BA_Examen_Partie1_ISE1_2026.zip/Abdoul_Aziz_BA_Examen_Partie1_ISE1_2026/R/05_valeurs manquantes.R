
# 05_plan_sondage_indices.R
# Declaration du plan de sondage (srvyr), HDDS, indice composite de
# vulnerabilite aux chocs

library(tidyverse)
library(srvyr)
library(here)

menages_recode <- read_rds(here("data/processed/menages_recode.rds"))


# 5.1 Plan de sondage complet (grappes, strates, poids finaux)
plan_ensan <- menages_recode |>
  as_survey_design(
    ids     = grappe,
    strata  = strate,
    weights = poids_final,
    nest    = TRUE
  )


# 5.2 Score de diversite alimentaire des menages (HDDS) et classification FAO
# HDDS = somme des 12 groupes alimentaires FAO consommes (0/1) au cours de la
# periode de reference -> score entre 0 et 12.
groupes_fao <- c("cons_cereales", "cons_tubercules", "cons_legumineuses",
                 "cons_legumes", "cons_fruits", "cons_viande", "cons_poisson",
                 "cons_oeufs", "cons_lait", "cons_huile", "cons_sucre",
                 "cons_condiments")

menages_recode <- menages_recode |>
  rowwise() |>
  mutate(hdds = sum(c_across(all_of(groupes_fao)), na.rm = TRUE)) |>
  ungroup() |>
  mutate(
    # Seuils usuels adaptes du guide FAO/PAM (terciles du score /12) :
    #  0-3  -> consommation alimentaire pauvre
    #  4-5  -> consommation alimentaire limite
    #  6-12 -> consommation alimentaire acceptable
    classe_fao = case_when(
      hdds <= 3 ~ "Pauvre",
      hdds <= 5 ~ "Limite",
      TRUE      ~ "Acceptable"
    ) |> factor(levels = c("Pauvre", "Limite", "Acceptable"))
  )


# 5.3 Indice composite de vulnerabilite aux chocs

poids_chocs <- c(choc_secheresse = 1.5, choc_hausse_prix = 1,
                 choc_conflit = 1.5, choc_maladie = 1)
poids_strategies <- c(strat_vente_actifs = 3, strat_reduction_repas = 1,
                      strat_migration = 2, strat_endettement = 2)

menages_recode <- menages_recode |>
  mutate(
    score_chocs_brut = choc_secheresse * poids_chocs["choc_secheresse"] +
      choc_hausse_prix * poids_chocs["choc_hausse_prix"] +
      choc_conflit * poids_chocs["choc_conflit"] +
      choc_maladie * poids_chocs["choc_maladie"],
    score_strategies_brut = strat_vente_actifs * poids_strategies["strat_vente_actifs"] +
      strat_reduction_repas * poids_strategies["strat_reduction_repas"] +
      strat_migration * poids_strategies["strat_migration"] +
      strat_endettement * poids_strategies["strat_endettement"],
    score_chocs_norm      = score_chocs_brut / max(poids_chocs |> sum()),
    score_strategies_norm = score_strategies_brut / max(poids_strategies |> sum()),
    indice_vulnerabilite  = 100 * (0.5 * score_chocs_norm + 0.5 * score_strategies_norm)
  )

write_rds(menages_recode, here("data/processed/menages_final.rds"))

# Re-declaration du plan de sondage sur la base finale (avec hdds et indice)
plan_ensan <- menages_recode |>
  as_survey_design(ids = grappe, strata = strate, weights = poids_final, nest = TRUE)

write_rds(plan_ensan, here("data/processed/plan_sondage.rds"))

cat("HDDS moyen (pondere) :",
    plan_ensan |> summarise(m = survey_mean(hdds, na.rm = TRUE)) |> pull(m) |> round(2), "\n")
cat("Indice de vulnerabilite moyen (pondere) :",
    plan_ensan |> summarise(m = survey_mean(indice_vulnerabilite, na.rm = TRUE)) |> pull(m) |> round(1), "\n")
