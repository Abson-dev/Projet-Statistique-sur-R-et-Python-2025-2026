# Nom du projet

## Description
Décrivez ici l'objectif du projet.

## Structure du projet
- `data/raw/` : données brutes (jamais modifiées)
- `data/processed/` : données nettoyées et transformées
- `R/` : scripts R numérotés par ordre d'exécution
- `output/figures/` : graphiques exportés
- `output/tables/` : tableaux exportés
- `rapport/` : rapport final (Quarto)

## Auteur

## Date de création
2026-07-31
