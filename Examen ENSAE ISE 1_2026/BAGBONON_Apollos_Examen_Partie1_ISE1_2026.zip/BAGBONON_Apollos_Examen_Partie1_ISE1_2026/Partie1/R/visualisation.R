#Section 3
#12

library(dplyr)
library(ggplot2)

revenu_par_tete<-revenu_par_tete|>
  left_join(menages_enrichi_2|>select(hhid,region), by = "hhid") # On va d'abord joindre au data frame revenu par tete la variable region

# Graphique de densités superposées
ggplot(revenu_par_tete, aes(x = revenu_tete, fill = region)) +
  geom_density(alpha = 0.4) +
  scale_x_log10() +   # transformation logarithmique pour corriger l'asymétrie
  labs(title = "Distribution du revenu par tête par région",
       x = "Revenu par tête (échelle log)",
       y = "Densité") +
  theme_minimal()

## Ici j'ai oublié d'utiliser le plan de sondage. Quand je me suis rappelé il était l'heure. Donc les statistiques du graphique ne sont pas représentatif