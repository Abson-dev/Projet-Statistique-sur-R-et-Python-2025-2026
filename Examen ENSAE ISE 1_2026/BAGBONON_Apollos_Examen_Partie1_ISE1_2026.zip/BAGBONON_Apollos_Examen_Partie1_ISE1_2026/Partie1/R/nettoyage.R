#Section 1
# 1 Importer les cinq sources

library(haven)
library(tidyverse)
ensan_menages <- read_dta("data/raw/ensan_menages.dta") # source ensan_menages importée comportant 3540 obs et 8 variables
View(ensan_menages) 

library(readr)
ensan_individus <- read_csv("data/raw/ensan_individus.csv")  # source ensan_individu importée comportant 22241 obs et 5 variables
View(ensan_individus)

library(readxl)
ensan_consommation <- read_excel("data/raw/ensan_consommation.xlsx")  # source ensan_consommation importée comportant 3540 obs et 13 variables
View(ensan_consommation)

chocs_menages <- read_csv("data/raw/chocs_menages.csv")    # source chocs_menages importée comportant 3540 obs et 10 variables
View(ensan_consommation)
View(chocs_menages)
 
prix_marches <- read_csv("data/raw/prix_marches.csv")   # source prix_marches importée comportant 2208 obs et 5 variables
View(prix_marches)

# 2 Jointure 

menages_enrichi<- ensan_menages|> 
  left_join(ensan_consommation, by = "hhid")          # Conserver tous les ménages auxquels on join les variables de consommation.La nouvelle base comporte 3540 obs et 20 (8+ 13-1) variables
a<- nrow(menages_enrichi) == nrow(ensan_menages)   
print(a)  # a renvoie bel et bien TRUE
  
menages_enrichi<-menages_enrichi|>
left_join(chocs_menages|>select(hhid,choc_secheresse,choc_hausse_prix,choc_conflit,choc_maladie), by = "hhid") #On joint ensuite les variables chocs a la base obtenue précédemment. On obtient une base avec 3540 obs et 24 (20+5-1) variables
b<- nrow(menages_enrichi) == nrow(ensan_menages)   
print(b)  # b renvoie bel et bien TRUE 

# 3 Correction de libéllés incohérents
# On remarque que dans les bases , les libellés des regions ne sont pas tous cohérents. Donc il s'agira de corriger cela.

library(dplyr)
library(stringr)
chocs_menages_2 <- chocs_menages |>
  mutate(region = region_lib |>                 # On renomme la variable pour adapter le nom avec les autres bases.Une nouvelle colonne est crée
           str_to_lower()|>
           str_replace_all(" ", "_")|>
           str_to_sentence())

  
menages_enrichi_2 <- menages_enrichi |>
  mutate(region = region |>                
           str_to_lower()|>
           str_replace_all(" ", "_")|>
           str_to_sentence())


prix_marches_2 <- prix_marches |>
  mutate(region = region |>                
           str_to_lower()|>
           str_replace_all(" ", "_")|>
           str_to_sentence())

# 4 Diagnostic complet des valeurs manquantes 


# 6 Recodons les variables catégorielles nécessaires à l'analyse

## Milieu 

###Modalités distinctes de la variable milieu. En effet il est important de voir d'abord les modalités
menages_enrichi_2 |>
  distinct(milieu)   #On voit deux modalites 1 pour Urbain et 2 ppour Rural


menages_enrichi_2 <- menages_enrichi_2 |>
  mutate(milieu = case_when(
    milieu == 1 ~ "Urbain",
    milieu == 2 ~ "Rural"   
  ))

##Niveau d'éducation du chef de ménage

###Modalités distinctes
ensan_individus|>
  distinct(niveau_educ) 
###On va ensuite recoder pour avoir une autre variable niveau_educ_chef_menage que nous allons joindre avec la base mere "menages_enrichi_2"

niveau_chef <- ensan_individus |>
  filter(rang == 1) |>                      # On va garder uniquement les chefs ménages
  select(hhid, niveau_educ)|>             # On va selectionner hhid et  niveau_educ
  rename(niveau_educ_chef_menage = niveau_educ)  # On renomme la nouvelle colonne crée 

  niveau_chef|>summarise(nb_hhid = n_distinct(hhid))# Pour vérifier le nombre d'observasion de ce nouvel data frame. On a 3555 lignes au lieu de 3540
  ensan_individus|>count(rang) # En cherchant la cause du problème précedent on voit qu' au niveau du rang il y a 3555 observations de la modalité 1 au lieu de 3540 alors qu'il y a 3540 hhid distincts. Surement que dans certains ménages, la  modalité 1 du rang se répète. D'où notre problème
  
# Revenu par tete
## Il faudra calculer le revenu par tete en divisant le revenu de chaque ménage par le nombre de tete dans le menage
  
  revenu_par_tete <- menages_enrichi_2 |>
    select(hhid, revenu,taille_menage)|>
    mutate(revenu_tete = revenu / taille_menage) # On a un data frame commportant le revenu par teet avec 3540 obs

#Section 2
# 7 Plan de sondage
  library(srvyr)
  plan_sondage <- menages_enrichi_2|> 
    as_survey_design( 
      ids     =~ grappe ,          # Identifiant des grappes (PSU) 
      strata  = ~ strate,          # Variable de stratification 
      weights = ~ poids_final,     # Poids de sondage finaux 
      nest    = TRUE 
    ) 
  
 
  