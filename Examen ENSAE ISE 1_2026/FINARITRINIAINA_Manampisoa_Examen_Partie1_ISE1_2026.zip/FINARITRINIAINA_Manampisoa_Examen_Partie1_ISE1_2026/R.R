##Section 1. Import, structuration et nettoyage---

# 1. Importation des données et des packages

# 1.1. Chargement des librairies avec pacman

if (!require("pacman")) install.packages("pacman")
library(pacman)
p_load(haven, dplyr, ggplot2, naniar, tidyr, scales, rstatix, moments, coin, gtsummary, gt, survey, Hmisc, tidyverse, janitor)


# 1.2. Importations des données
menages <- read_dta("Data/raw/ensan_menages.dta")
individus <- read_csv("Data/raw/ensan_individus.csv", show_col_types = FALSE)
consommations <- read_excel("Data/raw/ensan_consommation.xlsx")
chocs_men <- read_csv("Data/raw/chocs_menages.csv", show_col_types = FALSE)
prix_marche <- read_csv("Data/raw/prix_marches.csv", show_col_types = FALSE)


# 1.2. Fusion en un jeu de données
#Données des chefs de ménage
chef_men <- individus |> filter(rang == 1)

#Suppression des doublons
doublons_chef <- chef_men |> 
  group_by(hhid)  |> 
  filter(n() > 1) |> 
  nrow()
cat("\n Doublons dans chef_men est :", doublons_s1, "\n")
chef_men <- chef_men |> distinct(hhid, .keep_all = TRUE)
dim(chef_men)


#Données des consommations agrégées
consommation_agreg <- data.frame(
  hhid=consommations$hhid,
  hdds= rowSums(consommations[ , -1], )
)
dim(consommation_agreg)

fusion_1 <- menages |> left_join(chocs_men, by= "hhid") 
dim(fusion_1)
fusion_2 <- fusion_1 |> left_join(chef_men, by = "hhid")     
dim(fusion_2)
data_complet <- fusion_2 |> left_join(consommation_agreg, by="hhid") 
dim(data_complet)


# 1.3. Vérification des incohérences des données
names(menages)
names(individus)
names(chocs_men)
names(consommations)
names(prix_marche)

#Données sur les régions et hhid
reg1 <- menages |> select(hhid,region)
reg2 <- chocs_men |> select(hhid, region_lib)

data_1 <- reg1 |> left_join(reg2, by="hhid")

# 1.4. Diagnostic des données manquantes

p_miss_s1 <- data_complet |> gg_miss_var(show_pct = TRUE) +
  labs(
    title = "Valeurs manquantes - Données complètes",
    x = "Variable",
    y = "% de NA"
  ) +
  theme_minimal()
ggsave("outputs/figures/missing_data_1.png", p_miss_s1, width = 8, height = 5, dpi = 300)
print(p_miss_s1)


p_vis_s1 <- data_complet|> vis_miss(warn_large_data = FALSE) + labs(title = "Patterns de valeurs manquantes - Données complètes")
print(p_vis_s1)
ggsave("outputs/figures/vis_miss_data_1.png", p_vis_s1, width = 8, height = 5, dpi = 300)


##Section 2. Statistiques descriptives pondérées et indices composites 

# 2.1. Plan de sondage

#2.2. Score de diversité alimentaire des ménages (hdds) et la classification FAO associée.  
score <- data_complet |> select(hhid, region, milieu, grappe, strate, poids_final, hdds)
score <- score |> 
  mutate(
    classe_FAO = case_when( 
      hdds <= 3   ~ "Insécurité alimentaire sévère", 
      hdds <= 6  ~ "Insécurité alimentaire modérée", 
      hdds  <= 9 ~ "Sécurité alimentaire acceptable",
      TRUE       ~ "Bonne diversité alimentaire"
    )  |> factor(levels = c("Insécurité alimentaire sévère", 
                            "Insécurité alimentaire modérée", 
                            "Sécurité alimentaire acceptable", 
                            "Bonne diversité alimentaire"), ordered = TRUE) 
  )
write.csv(score, "outputs/tables/classification_fao.csv", row.names = FALSE)

                                    

#2.3. Construction d'un indice composite de vulnérabilité aux chocs
#Chocs et stratégies
chocs <- data_complet |> select (hhid, choc_secheresse, choc_hausse_prix, choc_conflit, choc_maladie, poids_final)
strat <- data_complet |> select (hhid, strat_vente_actifs, strat_reduction_repas, strat_migration, strat_vente_actifs, poids_final)
tableau_2 <- chocs |> left_join(strat, by= "hhid")
data_indice <- tableau_2 |> mutate (
  choc= rowSums(chocs[ , -1]),
  strat= rowSums(strat[ ,-1])
)
data_indice <- data_indice |> mutate (indice=choc/strat)
indice <- data_indice |> 
  mutate(
    indice_de_vulnerabilite = case_when( 
      indice < 1   ~ "Vulnerable", 
      TRUE       ~ "Non vulnerable"
    )  |> factor(levels = c("Vulnerable", "Non vulnerable"),  ordered = TRUE) 
    )
    

#2.4. Synthèse des score et indice

tab1 <- indice |> select(hhid, indice,poids_final.y)
tab2 <- score |> select(hhid, hdds, poids_final)
table <- tab2 |> left_join(tab1, by ="hhid")
table |> as_gt()|> gt::gtsave(filename = "outputs/tables/tableau_recap_indices.html")


##Section 3. Visualisation

#3.1. Représenter la distribution du revenu par tête par région


