# ==============================================================================
# DEVOIR D'ANALYSE DE DONNEES AVEC LE LOGICIEL R
# Auteurs  : OUATTARA Ousmane, ENSAE ISE1 2025-2026
# Superviseur : M. Aboubacar HEMA
# ==============================================================================

cat("=== Démarrage de 02_analyses.R ===\n")


# ---------------------------------------------------------------------------- #
# 1. CHARGEMENT DES DONNÉES PRÉPARÉES
# ---------------------------------------------------------------------------- #
base     <- readRDS(here("data", "processed", "base.rds"))

base_imputee_long   <- readRDS(here("data", "processed", "base_imputee_long.rds"))

base_mice <- readRDS(here("data", "processed", "base_mice.rds"))

plan_sondage <- readRDS(here("data", "processed", "plan_sondage.rds"))

# # Supprimer les labels Stata pour éviter les erreurs de type haven_labelled
# df_intrants <- labelled::unlabelled(df_intrants)
# poids       <- labelled::unlabelled(poids)

# Référence source pour les légendes
source <- "Source : ENSAN 2026"




# ---------------------------------------------------------------------------- #
# 2. PALETTE DE COULEURS ET THÈME GRAPHIQUE (couleurs agronomiques FAO)
# ---------------------------------------------------------------------------- #
col_cereale       <- "#2E7D32"   # Vert foncé
col_tubercule     <- "#F57F17"   # Ocre
col_legum         <- "#1565C0"   # Bleu
col_rente         <- "#6A1B9A"   # Violet
col_legume        <- "#00838F"   # Teal
col_fruit         <- "#C62828"   # Rouge
col_autre         <- "#546E7A"   # Gris ardoise
col_rural         <- "#4CAF50"
col_urbain        <- "#455A64"
col_npk           <- "#1B5E20"
col_uree          <- "#F9A825"
col_orga          <- "#795548"
col_pest          <- "#B71C1C"
col_secure        <- "#2E7D32"   # Vert foncé - Sécurité alimentaire
col_insec_legere  <- "#F9A825"   # Jaune/Ocre - Insécurité légère
col_insec_modere  <- "#EF6C00"   # Orange - Insécurité modérée
col_insec_severe  <- "#B71C1C"   # Rouge foncé - Insécurité sévère


palette_type <- c(
  "Céréale"          = col_cereale,
  "Tubercule"        = col_tubercule,
  "Légumineuse"      = col_legum,
  "Culture de rente" = col_rente,
  "Légume"           = col_legume,
  "Fruit"            = col_fruit,
  "Autre"            = col_autre
)

theme_tp5 <- theme_minimal(base_size = 10) +
  theme(
    plot.title      = element_text(size = 11, face = "bold", hjust = 0),
    plot.subtitle   = element_text(size = 9,  color = "grey40"),
    plot.caption    = element_text(size = 7,  color = "grey50", hjust = 1),
    axis.title      = element_text(size = 9),
    legend.position = "bottom",
    legend.title    = element_text(size = 8),
    legend.text     = element_text(size = 8)
  )
theme_set(theme_tp5)

# ---------------------------------------------------------------------------- #
# FONCTION UTILITAIRE : formatage flextable style LSMS
# ---------------------------------------------------------------------------- #
style_lsms <- function(ft) {
  vert_h <- "#1B5E20"; vert_c <- "#E8F5E9"; blanc <- "#FFFFFF"
  nr     <- nrow(ft$body$dataset)
  ft |>
    flextable::font(fontname = "Arial", part = "all") |>
    flextable::fontsize(size = 9,   part = "body")   |>
    flextable::fontsize(size = 9.5, part = "header") |>
    flextable::bg(bg = vert_h, part = "header")      |>
    flextable::color(color = blanc, part = "header") |>
    flextable::bold(part = "header")                 |>
    flextable::align(align = "center", part = "header") |>
    flextable::bg(i = seq(1, nr, 2), bg = blanc,  part = "body") |>
    flextable::bg(i = seq(2, nr, 2), bg = vert_c, part = "body") |>
    flextable::align(j = 1, align = "left", part = "body") |>
    flextable::border_outer(
      part   = "all",
      border = officer::fp_border(color = vert_h, width = 1.5)) |>
    flextable::border_inner_h(
      part   = "body",
      border = officer::fp_border(color = "#AAAAAA", width = 0.4)) |>
    flextable::padding(padding.left = 6, padding.right = 6,
                       padding.top  = 3, padding.bottom = 3, part = "all")
}

# ============================================================
# 7. Déclarer le plan de sondage complet (grappes, strates, poids finaux) avec srvyr. 
# Déjà fait vers la fin du ficher preparation des données
# ============================================================




# ---------------------------------------------------------------------------- #
# 8. SCORE DE DIVERSITÉ ALIMENTAIRE (HDDS) ET CLASSIFICATION FAO
# ---------------------------------------------------------------------------- #
cat("\n--- Construction du HDDS et classification FAO ---\n")

# Les 12 variables cons_* de "base" correspondent exactement aux 12 groupes
# alimentaires standards de la méthodologie FAO (2011) pour le Household
# Dietary Diversity Score : céréales, tubercules, légumineuses, légumes,
# fruits, viande, poisson, œufs, lait/produits laitiers, huile/matières
# grasses, sucre, condiments. Ce sont des indicateurs binaires (0/1),
# sans valeur manquante.
cons_vars <- names(base)[str_starts(names(base), "cons_")]

cat(sprintf("Groupes alimentaires identifiés (%d) : %s\n",
            length(cons_vars), paste(cons_vars, collapse = ", ")))
cat(sprintf("NA sur les indicateurs de consommation : %d\n",
            sum(is.na(base[cons_vars]))))

base <- base |>
  mutate(
    # HDDS = nombre de groupes alimentaires consommés (0 à 12)
    hdds = rowSums(across(all_of(cons_vars))),
    # Classification FAO (2011) à 12 groupes :
    #   Faible diversité   : 0 à 3 groupes
    #   Diversité moyenne  : 4 à 5 groupes
    #   Diversité élevée   : 6 groupes ou plus
    hdds_classe = case_when(
      hdds <= 3             ~ "Faible diversité",
      hdds >= 4 & hdds <= 5  ~ "Diversité moyenne",
      hdds >= 6              ~ "Diversité élevée"
    ),
    hdds_classe = factor(hdds_classe,
                         levels = c("Faible diversité", "Diversité moyenne", "Diversité élevée"),
                         ordered = TRUE)
  )

cat("Résumé du HDDS :\n"); print(summary(base$hdds))
cat("Classification FAO :\n"); print(table(base$hdds_classe, useNA = "ifany"))

# fig_hdds <- ggplot(base, aes(x = hdds_classe, fill = hdds_classe)) +
#   geom_bar() +
#   labs(title = "Classification FAO de la diversité alimentaire des ménages",
#        x = NULL, y = "Nombre de ménages")
# 
# ggsave(here("outputs", "figures", "fig_hdds_classe.png"),
#        fig_hdds, width = 5, height = 4, dpi = 50)
# cat("fig_hdds_classe exportée\n")



# 9. Construire un indice composite de vulnérabilité aux chocs,combinant le nombre 
# et la gravité des chocs subis avec l’intensité des stratégies d’adaptation mobilisées.


names(chocs_menages)
str(chocs_menages)

choc_vars  <- c("choc_secheresse", "choc_hausse_prix", "choc_conflit", "choc_maladie")
strat_vars <- c("strat_vente_actifs", "strat_reduction_repas", "strat_migration", "strat_endettement")

sapply(base[choc_vars], function(x) mean(x, na.rm = TRUE))


sum(is.na(base[c(choc_vars, strat_vars)]))


poids_chocs  <- c(choc_secheresse = 3, choc_hausse_prix = 1, choc_conflit = 4, choc_maladie = 2)
poids_strats <- c(strat_vente_actifs = 4, strat_migration = 3, strat_endettement = 2, strat_reduction_repas = 1)

base <- base |>
  mutate(
    nb_chocs     = choc_secheresse + choc_hausse_prix + choc_conflit + choc_maladie,
    gravite_chocs = choc_secheresse * poids_chocs["choc_secheresse"] +
      choc_hausse_prix * poids_chocs["choc_hausse_prix"] +
      choc_conflit     * poids_chocs["choc_conflit"] +
      choc_maladie     * poids_chocs["choc_maladie"],
    nb_strategies = strat_vente_actifs + strat_reduction_repas + strat_migration + strat_endettement,
    intensite_strategies = strat_vente_actifs   * poids_strats["strat_vente_actifs"] +
      strat_migration      * poids_strats["strat_migration"] +
      strat_endettement    * poids_strats["strat_endettement"] +
      strat_reduction_repas* poids_strats["strat_reduction_repas"]
  ) |>
  mutate(
    exposition_chocs = (nb_chocs / 4 + gravite_chocs / sum(poids_chocs)) / 2,
    adaptation_strat  = (nb_strategies / 4 + intensite_strategies / sum(poids_strats)) / 2,
    icv = (exposition_chocs + adaptation_strat) / 2
  )

summary(base$icv)


sum(is.na(base$icv))


design_icv <- svydesign(ids = ~1, weights = ~poids_final, data = base)
seuils_icv <- svyquantile(~icv, design_icv, quantiles = c(1/3, 2/3))
seuils_icv

breaks_icv <- c(-Inf, as.numeric(seuils_icv$icv[, "quantile"]), Inf)
breaks_icv


base <- base |>
  mutate(
    vulnerabilite_classe = cut(icv, breaks = breaks_icv,
                               labels = c("Faible vulnérabilité", "Vulnérabilité modérée", "Vulnérabilité élevée"),
                               include.lowest = TRUE, ordered_result = TRUE)
  )

table(base$vulnerabilite_classe, useNA = "ifany")


base |> group_by(vulnerabilite_classe) |> summarise(icv_min=min(icv), icv_max=max(icv), n=n())

vul_cate <- table(base$vulnerabilite_classe)

pie(vul_cate, col = rainbow(3), radius = 0.9)



# # 10. Produire un tableau descriptif pondéré de type Tableau 1 avec gtsummary, comparant les indicateurs clés par 
# # milieu et par région, avec test de comparaison et colonne d’effectifs. 
# 
# library(gtsummary)
# base |> 
#   select(region, milieu, revenu, taille_menage, age, sexe, niveau_educ) |> 
#   summarise_all(list(mean, sd, min, max, n)) |> 
#   gtsummary::add_stat_label() |> 
#   as_table()
#   gtsummary::add_stat_label() |> 
#   as_table()



## Section 3. Visualisation 


# 12. Représenter la distribution du revenu par tête par région 
# (graphique de densités superposées ou équivalent), 
# avec une échelle adaptée à l’asymétrie de la variable. 

win.graph()
revenu_tete <- ggplot(data = base, aes(x = revenu_par_tete)) +
  geom_density(alpha = 0.5, fill = "blue") +
  facet_wrap(~ region, scales = "free") +
  labs(title = "Distribution du revenu par tête par région",
       x = "Revenu par tête",
       y = "Densité") +
  theme_minimal()

ggsave(here("outputs", "figures", "revenu_tete.png"),
       revenu_tete, width = 7, height = 5, dpi = 300)



# 13. Produire une carte choroplèthe de l’indice de vulnérabilité
# par région avec sf et ggplot2, ainsi qu’une version interactive avec tmap. 



cat("\n=== 02_analyses.R terminé avec succès ===\n")
cat("Figures dans : outputs/figures/\n")
cat("Tableaux dans : data/processed/\n")
