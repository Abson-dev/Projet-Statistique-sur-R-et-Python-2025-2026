# ==============================================================================
# DEVOIR D'ANALYSE DE DONNEES AVEC LE LOGICIEL R
# Auteurs  : OUATTARA Ousmane, ENSAE ISE1 2025-2026
# Superviseur : M. Aboubacar HEMA
# ==============================================================================

# ---------------------------------------------------------------------------- #
# 0. NETTOYAGE DE L'ENVIRONNEMENT
# ---------------------------------------------------------------------------- #
rm(list = ls())
cat("=== Démarrage de 01_preparation.R ===\n")

# ---------------------------------------------------------------------------- #
# CHARGEMENT DES PACKAGES
# ---------------------------------------------------------------------------- #
# Ceci est fait dans le main.R

# ---------------------------------------------------------------------------- #
# CHARGEMENT DES DONNÉES BRUTES
# ---------------------------------------------------------------------------- #
cat("\n--- Chargement des fichiers .dta ---\n")


# 1. Importer les cinq sources avec les packages appropriés, en respectant les types de colonnes et les encodages. 

ensan_menages  <- read_dta(here("data", "raw", "ensan_menages.dta"))


ensan_consommation <- read_excel(here("data", "raw", "ensan_consommation.xlsx"))


ensan_individus <- read_csv(here("data", "raw", "ensan_individus.csv"), show_col_types = FALSE)


chocs_menages <- read_csv(here("data", "raw", "chocs_menages.csv"), show_col_types = FALSE)


prix_marches <- read_csv(here("data", "raw", "prix_marches.csv"), show_col_types = FALSE)


# 2. Fusionner les modules en un jeu de données ménages enrichi comportant les caractéristiques du chef de ménage, 
# la consommation alimentaire agrégée et les chocs subis, par des jointures adaptées.

# Nombre d'individus par ménage (nb de lignes dans ensan_individus par hhid)
nb_individus <- ensan_individus |>
  count(hhid, name = "nb_individus")

chef_men <- ensan_individus |>
  filter(rang == 1) |>
  # 15 ménages ont 2 individus avec rang == 1 (doublon) :
  # on ne garde qu'un chef de ménage par hhid pour ne pas dupliquer
  # de lignes lors de la jointure avec ensan_menages
  distinct(hhid, .keep_all = TRUE) |>
  left_join(nb_individus, by = "hhid")


base <- ensan_menages |>
  left_join(chef_men, by = "hhid") |>
  left_join(chocs_menages, by = "hhid") |>
  left_join(ensan_consommation, by = "hhid")

cat(sprintf("base : %d obs (attendu = nrow(ensan_menages) = %d)\n",
            nrow(base), nrow(ensan_menages)))

# prix_marches n'a pas de hhid (série de prix par marché/région/produit/mois) :
# on l'agrège en un prix moyen par région (tous produits et mois confondus)
# avant de le joindre sur "region", pour ne pas dupliquer les lignes de base

prix_region <- prix_marches |>
  group_by(region) |>
  summarise(prix_moyen_fcfa_kg = mean(prix_fcfa_kg, na.rm = TRUE), .groups = "drop")

base <- base |>
  left_join(prix_region, by = "region")

cat(sprintf("base après ajout des prix : %d obs (attendu = %d)\n",
            nrow(base), nrow(ensan_menages)))
cat(sprintf("NA sur prix_moyen_fcfa_kg : %d\n", sum(is.na(base$prix_moyen_fcfa_kg))))


# ---------------------------------------------------------------------------- #
# 3. COHÉRENCE DES LIBELLÉS DE RÉGION AVANT JOINTURE SPATIALE
# ---------------------------------------------------------------------------- #
cat("\n--- Vérification des libellés de région avant jointure spatiale ---\n")

# Seuls ensan_menages et prix_marches portent une variable "region" ; on
# vérifie qu'aucun libellé ne diffère (accents, casse, espaces) avant de
# les faire correspondre dans une jointure spatiale.
regions_menages <- sort(unique(str_trim(ensan_menages$region)))
regions_prix    <- sort(unique(str_trim(prix_marches$region)))

diff_menages_vs_prix <- setdiff(regions_menages, regions_prix)
diff_prix_vs_menages <- setdiff(regions_prix, regions_menages)

if (length(diff_menages_vs_prix) == 0 && length(diff_prix_vs_menages) == 0) {
  cat(sprintf("Libellés de région cohérents entre les %d fichiers (%d régions).\n",
              2, length(regions_menages)))
} else {
  cat("Incohérences détectées :\n")
  cat("  Dans ensan_menages mais pas dans prix_marches : ",
      paste(diff_menages_vs_prix, collapse = ", "), "\n")
  cat("  Dans prix_marches mais pas dans ensan_menages : ",
      paste(diff_prix_vs_menages, collapse = ", "), "\n")
}

#####################

# Résumé des valeurs manquantes 
miss_var_summary(base) |> filter(pct_miss > 0)

# Matrice de co-occurrence des NA:quelles variables sont manquantes ensemble ? 
gg_miss_upset(base, nsets = 8)

# Pattern spatial des NA dans le dataset 
vis_miss(base, sort_miss = TRUE)

#########################

# ---------------------------------------------------------------------------- #
# 4. DIAGNOSTIC DES VALEURS MANQUANTES (naniar) SUR "base"
# ---------------------------------------------------------------------------- #
cat("\n--- Diagnostic des valeurs manquantes (naniar) sur 'base' ---\n")

# 4.1 Valeurs manquantes taguées Stata (.a à .z) vs NA standards -------------
# Seule ensan_menages provient d'un fichier .dta : c'est la seule source
# susceptible de contenir des valeurs manquantes spéciales Stata, préservées
# par haven sous forme de haven::tagged_na() au sein des colonnes numériques.

cols_numeriques <- base |> select(where(is.numeric)) |> names()

# diag_na_types <- map_dfr(cols_numeriques, function(col) {
#   x <- base[[col]]
#   est_taguee <- haven::is_tagged_na(x)
#   tibble(
#     variable       = col,
#     n_na_total     = sum(is.na(x)),
#     n_na_tagged    = sum(est_taguee),
#     tags_presents  = paste(sort(unique(haven::na_tag(x[est_taguee]))), collapse = ", "),
#     n_na_standard  = sum(is.na(x) & !est_taguee)
#   )
# }) |>
#   filter(n_na_total > 0) |>
#   arrange(desc(n_na_total))
# 
# cat("Valeurs manquantes par variable numérique (taguées Stata vs standards) :\n")
# print(diag_na_types)
# 
# if (sum(diag_na_types$n_na_tagged) == 0) {
#   cat("\n-> Aucune valeur manquante taguée Stata (.a-.z) détectée : ",
#       "toutes les valeurs manquantes de 'base' sont des NA standards (R).\n")
# } else {
#   cat(sprintf("\n-> %d valeurs manquantes taguées Stata détectées (à documenter/recoder).\n",
#               sum(diag_na_types$n_na_tagged)))
# }

# 4.2 Résumé global (naniar) -------------------------------------------------
resume_var  <- miss_var_summary(base)
resume_case <- miss_case_summary(base)

cat(sprintf("\nVariables avec au moins une valeur manquante : %d / %d\n",
            sum(resume_var$n_miss > 0), nrow(resume_var)))
cat(sprintf("Ménages complets (aucune valeur manquante)    : %d / %d (%.1f%%)\n",
            sum(resume_case$n_miss == 0), nrow(base),
            100 * mean(resume_case$n_miss == 0)))
print(resume_var |> filter(n_miss > 0))

# 4.3 Visualisations ----------------------------------------------------------
fig_miss_var <- gg_miss_var(base, show_pct = TRUE) +
  labs(title = "Valeurs manquantes par variable — base ménages enrichie")

fig_miss_upset <- gg_miss_upset(base)

ggsave(here("outputs", "figures", "fig_diag_miss_var.png"),
       fig_miss_var, width = 8, height = 7, dpi = 300)
cat("fig_diag_miss_var exportée\n")

png(here("outputs", "figures", "fig_diag_miss_upset.png"),
    width = 8, height = 6, units = "in", res = 300)
print(fig_miss_upset)
dev.off()
cat("fig_diag_miss_upset exportée\n")


# ---------------------------------------------------------------------------- #
# 5. Justifier, pour deux variables clés de votre choix, une hypothèse de mécanisme de non-réponse (MCAR, MAR 
# ou MNAR) et appliquer une imputation multiple par équations chaînées adaptée avec mice.
# ---------------------------------------------------------------------------- #
cat("\n--- Mécanisme de non-réponse : revenu et age ---\n")

# 5.1 Variable 1 : "revenu" (369 NA, 10,4 %) ---------------------------------
# Hypothèse retenue : MAR (Missing At Random), conditionnellement au milieu
# de résidence. Le taux de non-réponse diffère fortement entre milieux :

base_shadow <- base |> mutate(revenu_miss = is.na(revenu), age_miss = is.na(age))

tab_revenu_milieu <- base_shadow |>
  count(milieu, revenu_miss) |>
  group_by(milieu) |>
  mutate(pct_miss = 100 * n / sum(n)) |>
  filter(revenu_miss)
print(tab_revenu_milieu)

test_revenu_milieu <- chisq.test(table(base_shadow$milieu, base_shadow$revenu_miss))
cat(sprintf("Chi2(milieu, revenu manquant) = %.1f, p %s\n",
            test_revenu_milieu$statistic,
            ifelse(test_revenu_milieu$p.value < 0.001, "< 0.001",
                   sprintf("= %.3f", test_revenu_milieu$p.value))))
cat("-> Le manquant sur revenu est fortement associé au milieu (urbain 17,1 % vs rural 2,9 %),\n",
    "   une variable observée : hypothèse MAR (conditionnelle au milieu et à la région).\n",
    "   Réserve : une non-réponse liée au niveau de revenu lui-même (MNAR, ex. ménages aisés\n",
    "   réticents à déclarer) ne peut être exclue et reste une limite non testable directement.\n", sep = "")

# 5.2 Variable 2 : "age" du chef de ménage (74 NA, 2,1 %) --------------------
# Hypothèse retenue : MCAR. Pas d'association détectée avec le milieu ni le sexe.
test_age_milieu <- chisq.test(table(base_shadow$milieu, base_shadow$age_miss))
tab_age_sexe <- base_shadow |>
  count(sexe, age_miss) |>
  group_by(sexe) |>
  mutate(pct_miss = 100 * n / sum(n)) |>
  filter(age_miss)
print(tab_age_sexe)

cat(sprintf("Chi2(milieu, age manquant) = %.2f, p = %.3f\n",
            test_age_milieu$statistic, test_age_milieu$p.value))
cat("-> Aucune association détectée entre le manquant sur age et le milieu ou le sexe du chef :\n",
    "   compatible avec une hypothèse MCAR (omissions de saisie/collecte indépendantes des\n",
    "   caractéristiques observées et de l'âge lui-même). Hypothèse non prouvée, seulement\n",
    "   non contredite par les tests disponibles.\n", sep = "")

# ---------------------------------------------------------------------------- #
# 5.3 IMPUTATION MULTIPLE PAR ÉQUATIONS CHAÎNÉES (mice)
# ---------------------------------------------------------------------------- #
cat("\n--- Imputation multiple par équations chaînées (mice) ---\n")

# On impute les 4 variables incomplètes de "base" (revenu, age, taille_menage,
# niveau_educ) à partir d'un ensemble de covariables observées pertinentes.
# hhid, rang (constant = 1), region_lib (redondant avec region), grappe et
# strate (identifiants de plan de sondage à forte cardinalité, redondants
# avec region) sont exclus du modèle d'imputation.
df_mice <- base |>
  select(-hhid, -rang, -region_lib, -grappe, -strate) |>
  mutate(
    milieu      = haven::as_factor(milieu),
    sexe        = factor(sexe, levels = c(1, 2), labels = c("Homme", "Femme")),
    region      = factor(region),
    niveau_educ = factor(niveau_educ,
                         levels = c("Aucun", "Primaire", "Secondaire", "Superieur"),
                         ordered = TRUE)
  )

# Méthodes retenues (auto-détectées par mice, explicitées ici) :
#   revenu, taille_menage, age : pmm  (predictive mean matching, préserve
#                                       la forme des distributions, adapté
#                                       aux variables continues asymétriques)
#   niveau_educ                : polr (régression logistique ordinale,
#                                       adaptée à une variable catégorielle
#                                       ordonnée à 4 niveaux)
imp <- mice(df_mice, m = 5, maxit = 20, seed = 6284, printFlag = FALSE)

cat("Méthodes d'imputation utilisées :\n")
print(imp$method[imp$method != ""])


# Diagnostics de convergence et de plausibilité des valeurs imputées
png(here("outputs", "figures", "fig_mice_convergence.png"),
    width = 8, height = 6, units = "in", res = 300)
# plot(imp, c("revenu", "age", "taille_menage", "niveau_educ"), layout = c(2, 4))
# dev.off()

png(here("outputs", "figures", "fig_mice_density_revenu.png"),
    width = 7, height = 5, units = "in", res = 300)
print(densityplot(imp, ~revenu))
dev.off()

png(here("outputs", "figures", "fig_mice_density_age.png"),
    width = 7, height = 5, units = "in", res = 300)
print(densityplot(imp, ~age))
dev.off()

cat("Diagnostics mice (convergence, densités) exportés.\n")

# Ré-attache l'identifiant hhid pour conserver la traçabilité des ménages,
# sur chacun des 5 jeux de données imputés (format long)
base_imputee_long <- complete(imp, action = "long", include = FALSE) |>
  mutate(hhid = rep(base$hhid, times = 5)) |>
  relocate(hhid, .imp, .id)

cat(sprintf("Base imputée (format long) : %d obs (%d ménages x %d imputations)\n",
            nrow(base_imputee_long), nrow(base), imp$m))


# ---------------------------------------------------------------------------- #
# 6. Recoder les variables catégorielles nécessaires à l'analyse (milieu,
# niveau d'éducation du chef de ménage, quintiles de revenu par tête).
# ---------------------------------------------------------------------------- #
cat("\n--- Recodage des variables catégorielles (base) ---\n")

base <- base |>
  mutate(
    # Milieu : facteur propre à partir du label Stata (haven_labelled)
    milieu = haven::as_factor(milieu),
    # Niveau d'éducation du chef de ménage : facteur ordonné (hiérarchie
    # naturelle des niveaux scolaires)
    niveau_educ = factor(niveau_educ,
                         levels = c("Aucun", "Primaire", "Secondaire", "Superieur"),
                         ordered = TRUE),
    # Revenu par tête = revenu du ménage / taille du ménage
    revenu_par_tete = revenu / taille_menage
  )

# Quintiles pondérés (poids de sondage poids_final) du revenu par tête.
# Les ménages avec revenu ou taille_menage manquant héritent d'un NA sur
# le quintile (aucune imputation appliquée ici, cf. section 5 pour la
# version imputée par mice).
design_revenu <- svydesign(
  ids     = ~1,
  weights = ~poids_final,
  data    = base |> filter(!is.na(revenu_par_tete))
)

seuils_quintiles <- svyquantile(~revenu_par_tete, design_revenu,
                                 quantiles = seq(0, 1, 0.2))

breaks_quintiles <- unique(as.numeric(seuils_quintiles$revenu_par_tete[, "quantile"]))
breaks_quintiles[1]                      <- -Inf
breaks_quintiles[length(breaks_quintiles)] <- Inf


base <- base |>
  mutate(
    quintile_revenu = cut(revenu_par_tete, breaks = breaks_quintiles,
                          labels = paste0("Q", 1:5), include.lowest = TRUE)
  )

cat("Répartition milieu :\n");          print(table(base$milieu, useNA = "ifany"))
cat("Répartition niveau_educ :\n");      print(table(base$niveau_educ, useNA = "ifany"))
cat("Répartition quintile_revenu :\n");  print(table(base$quintile_revenu, useNA = "ifany"))


# ---------------------------------------------------------------------------- #
# 7. DÉCLARATION DU PLAN DE SONDAGE (srvyr)
# ---------------------------------------------------------------------------- #
cat("\n--- Déclaration du plan de sondage (srvyr) ---\n")

# Plan de sondage à un degré, stratifié par "strate" (45 strates), avec
# grappes ("grappe", 284 grappes distinctes, non partagées entre strates
# -> nest = TRUE par précaution) et pondération finale "poids_final".
plan_sondage <- base |>
  as_survey_design(
    ids     = grappe,
    strata  = strate,
    weights = poids_final,
    nest    = TRUE
  )

cat(sprintf("Grappes : %d | Strates : %d\n",
            n_distinct(base$grappe), n_distinct(base$strate)))

pop_estimee <- plan_sondage |> summarise(pop_totale = survey_total(1))
cat(sprintf("Population de ménages estimée : %.0f (erreur-type : %.0f)\n",
            pop_estimee$pop_totale, pop_estimee$pop_totale_se))



# ---------------------------------------------------------------------------- #
# 9. SAUVEGARDE
# ---------------------------------------------------------------------------- #
cat("\n--- Sauvegarde des données traitées ---\n")

saveRDS(base,               here("data", "processed", "base.rds"))
saveRDS(imp,                here("data", "processed", "base_mice.rds"))
saveRDS(base_imputee_long,  here("data", "processed", "base_imputee_long.rds"))
saveRDS(plan_sondage,       here("data", "processed", "plan_sondage.rds"))

cat(sprintf("base sauvegardée : %d lignes x %d colonnes\n", nrow(base), ncol(base)))
cat("\n=== 01_preparation.R terminé avec succès ===\n")
