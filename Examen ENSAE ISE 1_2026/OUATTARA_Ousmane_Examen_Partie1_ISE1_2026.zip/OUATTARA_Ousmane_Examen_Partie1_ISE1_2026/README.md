
---

# DEVOIR D'ANALYSE DE DONNEES AVEC LE LOGICIEL R

Ce projet réalise une analyse statistique et sert comme évaluation des compétences acquises lors du cour de R

---

## Structure du Projet
Le projet est organisé de manière modulaire pour garantir la reproductibilité :

```text
Devoir_R_OUATTARA_Ousmane_ISE1_ECO/
├── data/
│   ├── raw/             # Fichiers .dta bruts
│   └── processed/       # Bases de données nettoyées et fichiers .rds pour le rapport
├── scripts/
│   ├── 01_preparation.R    # Import, nettoyage, jointures logiques et gestion des outliers
│   ├── 02_analyses.R       # Calculs statistiques, tests de Wilcoxon/Chi-deux et graphiques
├── outputs/
│   ├── figures/         # Barplots, Boxplots, Violin plots (format PNG)
│   └── tables/          # Tableaux gtsummary exportés
├── rapport/
│   ├── rapport.Rmd      # Source RMarkdown du rapport final
│   └── reference.docx   # Document de style pour la mise en forme Word
└── README.md            # Documentation du projet (ce fichier)
└── main.R               # Script maître (chef d'orchestre) pour tout exécuter
```

---

##  Installation et Prérequis

### 1. Logiciels nécessaires
* **R** (version 4.0 ou supérieure)
* **RStudio**
* **Pandoc** (généralement inclus avec RStudio pour le RMarkdown)

### 2. Librairies R utilisées
Le projet s'appuie sur la suite `tidyverse` et des packages statistiques spécialisés :
```R
install.packages(c("tidyverse", "haven", "here", "labelled", "rstatix", 
                   "ggpubr", "scales", "patchwork", "gtsummary", "rmarkdown"))
```

---

##  Comment exécuter le projet ?

Il n'est pas nécessaire de lancer les scripts un par un. Tout a été automatisé :

1.  **Placer les données** : Copiez vos fichiers Stata (`.dta`) dans le dossier `data/raw/`.
2.  **Ouvrir le projet** : Ouvrez votre session RStudio dans le dossier racine du projet.
3.  **Lancer le script main.R ** : pour lancer, tapez dans la console de R : source("main.R) et tout le projet va s'exécuter.

**Ce que fait le script `main.R` :**
1.  Il initialise l'environnement et charge les librairies.
2.  Il appelle `01_preparation.R` pour fusionner les fichiers de récolte (`harvest`) et de plantation (`planting`).
3.  Il exécute `02_analyses.R` pour générer tous les indicateurs et graphiques.
4.  Il compile automatiquement le fichier `rapport.Rmd` pour générer le rapport final au format Word dans le dossier `outputs/`.

---

##  Auteurs
* **OUATTARA Ousmane** - Élève Ingénieur Statisticien Économiste (ENSAE Dakar)

## Superviseur
* **M. Aboubacar HEMA ** - Research Scientist, IFPRI

