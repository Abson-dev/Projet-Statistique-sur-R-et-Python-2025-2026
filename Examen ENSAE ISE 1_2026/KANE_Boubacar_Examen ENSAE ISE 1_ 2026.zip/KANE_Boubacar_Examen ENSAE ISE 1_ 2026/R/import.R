# Section 1. Import, structuration et nettoyage

## Importatpion des sources de données

library(dplyr)
library(haven)
library(naniar)
library(ggplot2)
library(sjlabelled)
library(rprojroot)
library(tidyverse)
library(readxl)
library(haven)
library(janitor)
library(mice)

# Chargement des bases
menage  <- read_dta("data/raw/ensan_menages.dta")
indivdu <- read_csv( "data/raw/ensan_individus.csv",
                     col_types = cols(
                       hhid = col_character(),# Identifiant ménage:toujours en caractère
                       rang = col_double(), 
                       age = col_double(),
                       sexe = col_factor(),
                       niveau_educ = col_factor(),
                     )
)

consommation  <- read_excel("data/raw/ensan_consommation.xlsx")

choc <- read_csv( "data/raw/chocs_menages.csv",
                     col_types = cols(
                       hhid = col_character(),# Identifiant ménage:toujours en caractère
                     
                       choc_secheresse= col_factor(),
                     )
)

prix <- read_csv( "data/raw/prix_marches.csv",
                  col_types = cols(
                    marche = col_character(),# Identifiant marché :toujours en caractère
                    
                  )
)


# Verification de doublons
## MENAGE

menage[duplicated(menage) | duplicated(menage, fromLast = TRUE), ]
sum(duplicated(menage))


## individu

doublon_indivdu <- indivdu |>
  group_by(hhid,rang) |>
  filter(n() > 1) |>
  ungroup()

cat("Nombre de doublons détectés :", nrow(doublon_indivdu), "\n")

# iL Ya 30 doublons d'individus
indivdu[duplicated(indivdu), ]
indivdu<-unique (indivdu)


# cONSOMMATION
doublon_consommation <- consommation |>
  group_by(hhid) |>
  filter(n() > 1) |>
  ungroup()

cat("Nombre de doublons détectés :", nrow(doublon_consommation), "\n")



doublon_choc <- choc |>
  group_by(hhid) |>
  filter(n() > 1) |>
  ungroup()
cat("Nombre de doublons détectés :", nrow(doublon_choc), "\n")



prix[duplicated(prix) | duplicated(prix, fromLast = TRUE), ]
sum(duplicated(prix))



# Fusionner les modules en un jeu de données ménages

nrow(menage)
nrow(consommation)
nrow(choc)
nrow(indivdu)

base <- menage |>
  left_join(consommation, by = c("hhid"))
nrow(base)

nrow(menage)
View(base)

base <- base |>
  left_join(choc, by = c("hhid"))
nrow(base)
View(base)

# Correction des libelles de region incoherentes

menage$region

# 4. Produire un diagnostic complet des valeurs manquantes 
library(naniar) 

# Résumé des valeurs manquantes
miss_var_summary(base) |> filter(pct_miss > 0) 
# Matrice de co-occurrence des NA:quelles variables sont manquantes ensemble ?
gg_miss_upset(base, nsets = 8) 
# Pattern spatial des NA dans le dataset
vis_miss(base, sort_miss = TRUE)

# Les variables revenu et taille_menage présentent respectpivement
# 10,4 et 4,24 % de manquants. 
# Ces manquants sont MnAR car c'est la nature de la variable qui est sensible
# Les ménages africains ont tendance à ne pas vouloir déclarer leur revenu ainsi que
# la tapille de leur ménages

# imputation multiple par équations chaînées adaptée avec mice.

# Imputation multiple (M = 5 jeux de données imputés)
imp <- mice( base |> select(revenu, taille_menage), 
             m = 5, # Nombre de jeux imputés 
             maxit = 10, # Itérations de convergence 
             method = "pmm", # Predictive Mean Matching (recommandé pour variables continues) 
             seed = 42 ) # Vérifier la convergence plot(imp)

# Vérifier la convergence
plot(imp)

summary(imp)
miss_var_summary(base) |> filter(pct_miss > 0) 


#Analyser sur les 5 jeux imputés et combiner (règles de Rubin)

fit_imputed <- with(imp, lm(log(revenu) ~ taille_menage )) 
pool(fit_imputed) |> summary()



# Recoder les variables catégorielles


base <- base |> 
  mutate( 
  # Recodage avec case_when 
    milieu = case_when(
      milieu == 1 ~ "Urbain", 
      milieu == 2 ~ "Rural",
      TRUE ~ NA_character_ 
                            ))
view(base)





### Section 2. Statistiques descriptives pondérées et indices composites


# 7. Déclarer le plan de sondage complet (grappes, strates, poids finaux) avec srvyr.
base_final <- individu |>
  left_join(base, by = c("hhid"))
nrow(base)

library(srvyr) 
# 1. Déclarer le plan de sondage 
plan_sondage <- menages |> as_survey_design( ids = ~ grappe, # Identifiant des grappes (PSU) strata = ~ strate, # Variable de stratification weights = ~ poids_final, # Poids de sondage finaux nest = TRUE ) # 2. Statistiques pondérées avec intervalles de confiance à 95% plan_sondage |> group_by(region, milieu) |> summarise( revenu_moyen = survey_mean(revenu_pc, vartype = "ci"), tx_pauvrete = survey_mean(pauvre, vartype = "ci"), effectif_estime = survey_total(vartype = "ci") ) # 3. Ratio pondéré plan_sondage |> summarise( gini = survey_ratio( numerator = revenu_pc * (rank(revenu_pc) / n()), denominator = revenu_pc









