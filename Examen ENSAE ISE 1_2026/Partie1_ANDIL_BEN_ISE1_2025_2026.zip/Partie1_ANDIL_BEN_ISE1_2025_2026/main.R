#   EXAMEN PARTIE 1 : 
# Par : Andil ben ENSAE ISE1 2025-2026
# Supervisé par : M. Aboubacar HEMA, IFPRI

