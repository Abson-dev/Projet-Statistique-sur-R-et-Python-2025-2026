library(tidyverse)
library(knitr)
library(flextable)
library(gtsummary)
library(scales)
library(moments)
library(readxl)
library(haven)
#importation des bases 
chefs_menage <- read_dta("data/raw/ensan_menages.dta") 
individus<- read_csv("data/raw/ensan_individus.csv")
consommation<- read_excel("data/raw/ensan_consommation.xlsx")
chocs<- read_csv("data/raw/chocs_menages.csv ")
prix<- read_csv("data/raw/prix_marches.csv ")
#fusion des bases:
menage<-chefs_menage |>
  left_join(chocs, by = "hhid")|>       
  left_join(consommation, by = "hhid")
#Exploration et visualisation des NA
library(naniar)
# Résumé des valeurs manquantes 
miss_var_summary(menage) |> filter(pct_miss > 0) 
miss_var_summary(menage)      # % de NA par variable 
gg_miss_var(menage)           # Graphique des valeurs manquantes 
gg_miss_upset(menage, nsets = 8) # Matrice de co-occurrence des NA
vis_miss(menage, sort_miss = TRUE) # Pattern spatial des NA dans le dataset 

#Imputation des valeurs manquantes ( par équations chaînées (MICE))
"il n'y a que les variables revenu et taille du ménage qui présentent des valeurs manquantes. concernant les Na de taille du ménage, 
il s'agit de valeur manquant aléatoirement par contre ceux du revenu c'est des manquant non aléatoirement,en afrique certains ménage 
ne dévoilent pas leur revenu"
#------------imputation multiple par équations chaînées adaptée avec mice------------

library(mice) 

# Imputation multiple (M = 5 jeux de données imputés) 
imp <- mice( 
  menage |> select(revenu,taille_menage), 
  m     = 5,          # Nombre de jeux imputés 
  maxit = 20,         # Itérations de convergence 
  method = "pmm", 
seed  = 42)
# Vérication de la convergence 
plot(imp)

#----------------recodage des variables qualitative-------------
menage<- menage |> 
  mutate( 
    # Recodage avec case_when (plus flexible que if_else) 
    milieu_label = case_when( 
      milieu == 1 ~ "Urbain", 
      milieu == 2 ~ "Rural", 
      TRUE        ~ NA_character_ 
    ), 
  )

    