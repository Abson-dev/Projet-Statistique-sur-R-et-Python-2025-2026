# Fichier maître (main)


scripts <- c(
  "R/01_import.R",                
  "R/02_nettoyage_jointures.R",    
  "R/03_manquants_imputation.R",   
  "R/04_indices.R",                
  "R/05_descriptif.R",             
  "R/06_visualisation.R"           
)

for (s in scripts) {
  message(sprintf("\n>>> %s", s))
  source(here::here(s))
}

# Rapport principal (HTML + Word).
rmarkdown::render(here::here("rapport", "rapport.Rmd"),
                  output_format = "all", quiet = TRUE)

# Notes regionales.
source(here::here("R", "07_notes_regionales.R"))
