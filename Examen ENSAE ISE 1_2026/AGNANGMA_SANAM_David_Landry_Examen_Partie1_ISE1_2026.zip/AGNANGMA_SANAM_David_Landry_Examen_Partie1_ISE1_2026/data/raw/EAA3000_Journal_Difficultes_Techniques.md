# Journal des difficultés techniques — TP EAA 3000

> Ce document recense, dans l'ordre chronologique, l'ensemble des problèmes techniques rencontrés lors de la mise en place de l'environnement (WampServer, NADA, Metadata Editor) et de la documentation de l'enquête. Il est destiné à alimenter le point 9 du rapport technique (« Difficultés rencontrées et solutions apportées »).

---

## Partie 1 — Installation de WampServer et NADA

| # | Problème | Cause identifiée | Statut / Solution |
|---|----------|-------------------|---------------------|
| 1 | Page d'accueil WampServer plante (`proc_open(): Command conversion failed`) | Bug connu de la page d'accueil de Wamp sous PHP 8.3.28 (script `wampserver.lib.php`) | Cosmétique — Apache, MySQL et phpMyAdmin fonctionnaient normalement. Ignoré sans impact. |
| 2 | `localhost/phpmyadmin` renvoie une erreur 404 | Le dossier phpMyAdmin est versionné (`phpmyadmin5.2.3`), l'URL sans version ne correspond à aucun alias actif | Résolu — accès via le menu de l'icône WampServer, qui génère l'URL exacte avec version. |
| 3 | `localhost/nada` renvoie une erreur 404 après téléchargement de NADA | Les fichiers NADA avaient été placés dans `C:\wamp64\nada` au lieu de `C:\wamp64\www\nada` (Apache ne sert que le contenu de `www`) | Résolu — déplacement du dossier vers `www`. |
| 4 | Erreur PHP au chargement de NADA : `require(...symfony/deprecation-contracts/function.php): Failed to open stream` | Le fichier téléchargé était le « Source code (zip) » générique de GitHub, qui ne contient pas le dossier `vendor` (dépendances Composer) | Résolu — retéléchargement depuis la section *Releases* (package d'installation complet, incluant `vendor`). |
| 5 | Avertissement PHP lors de la création du compte admin NADA : `Undefined property: Install::$error` | Bug d'affichage mineur sous PHP 8 (CodeIgniter accède à une propriété non initialisée au premier chargement) | Résolu — le formulaire de création de compte était présent plus bas sur la même page, simplement masqué par le message d'avertissement. |
| 6 | Erreur bloquante à la création du compte admin : `The configuration file email.php does not exist` | Le fichier de configuration email n'avait pas été créé à partir du modèle fourni | Résolu — copie de `email-sample.php` vers `email.php`. |
| 7 | Page d'accueil et tableau de bord NADA affichent une erreur interne (`Internal Server Error`, `Call to a member function row_array() on false`) | La requête de comptage des études (`get_survey_count`) échoue sur un catalogue vide, incompatibilité mineure avec PHP 8 | Cosmétique — la page d'administration (`/index.php/admin`) fonctionne normalement ; l'erreur disparaît après publication d'une première étude. |

---

## Partie 2 — Installation de Metadata Editor (MDE)

| # | Problème | Cause identifiée | Statut / Solution |
|---|----------|-------------------|---------------------|
| 8 | Premier logiciel téléchargé sous le nom « Metadata Editor » ne correspond pas à l'outil attendu (écran « Select MetaStore instance » avec options « MetaRepo » / « NFDI MatWerk ») | Confusion avec un logiciel homonyme développé par la communauté scientifique allemande NFDI-MatWerk (sciences des matériaux), sans lien avec le standard DDI ni avec NADA | Résolu — identification via le menu « Help/About » puis désinstallation ; téléchargement du bundle officiel `MetadataEditorDesktop-1.0.0.zip` depuis `ihsn.org`. |
| 9 | Tentative d'installation du Visual C++ Redistributable échoue (code `0x80070666`) | Le runtime était déjà installé sur la machine — cette piste, envisagée pour un autre problème (backend Python, cf. #10), a été écartée | Non-problème — confirmation que le composant était déjà présent. |

---

## Partie 5 — Import et documentation des fichiers de données

| # | Problème | Cause identifiée | Statut / Solution |
|---|----------|-------------------|---------------------|
| 10 | Import des fichiers CSV impossible : `cURL error 7: Failed to connect to localhost port 8000` | Le service backend Python (FastAPI/PyDataTools), responsable de l'analyse des fichiers de données et de la génération automatique des statistiques descriptives, ne démarre pas | **Non résolu.** Diagnostics effectués sans succès : redémarrages multiples du bundle, vérification des processus actifs (`python.exe`, `httpd.exe`, `mysqld.exe`), consultation des journaux Apache, réinstallation du Visual C++ Redistributable (déjà présent). Cause profonde non identifiée avec certitude — probable défaut d'installation du composant Python au sein de ce bundle spécifique. |
| 11 | Tentative d'installation de XAMPP comme solution alternative | Fausse piste — XAMPP est un environnement Apache/MySQL/PHP générique sans lien avec le composant Python manquant, et risquait de créer un nouveau conflit de ports (80/443) avec les serveurs déjà actifs | Abandonné avant mise en production ; Apache de XAMPP arrêté immédiatement. |
| 12 | Import en mode « Ne pas stocker de données » échoue avec la même erreur de connexion au port 8000 | Confirmation que **toute** interaction avec le module « Fichiers de données » de MDE dépend du backend Python, y compris sans stockage effectif | Contournement adopté : documentation des fichiers de données via le module **« Ressources externes »**, qui dispose d'un système de téléversement de fichier indépendant du backend défaillant. |

**Solution de contournement retenue pour la Partie 5 :** les deux fichiers CSV (original et anonymisé) ainsi qu'un dictionnaire des variables généré par analyse directe des données (format PDF, 31 puis 27 variables documentées avec libellés, types et statistiques descriptives) ont été déposés comme ressources externes, avec description détaillée, en lieu et place du module d'import automatique indisponible.

---

## Partie 7 — Validation et export DDI/XML

| # | Problème | Cause identifiée | Statut / Solution |
|---|----------|-------------------|---------------------|
| 13 | Export « Exporter le DDI » échoue avec une erreur HTTP 500 (`/api/editor/ddi/2`) | En cours d'investigation (voir détail ci-dessous) | **Non résolu au moment de la rédaction.** |
| 14 | Export « Exporter le paquet (ZIP) » réussit mais ne contient aucun fichier `.xml` DDI exploitable (uniquement des fichiers JSON internes et un fichier RDF) | Le paquet ZIP semble emprunter un chemin de génération différent de celui de l'export DDI direct, qui échoue | Écarté comme solution de substitution — ne répond pas à l'exigence du livrable `.xml`. |

### Détail de l'investigation de l'erreur d'export DDI

Analyse du journal d'erreurs applicatif (`application/logs/log-*.php`) :
```
Severity: Warning --> XMLWriter::openUri(): Unable to resolve file path 
[...] Editor_DDI_Writer.php:170
Severity: error --> Exception: Invalid or uninitialized XMLWriter object 
[...] Editor_DDI_Writer.php:171
```

Étapes de diagnostic menées :
1. Lecture du code source de `Editor_DDI_Writer.php` — confirmation que l'écriture du fichier XML passe par `XMLWriter::openUri($output)`, où `$output` est un chemin de fichier physique (et non le flux standard `php://output`).
2. Remontée de l'appel jusqu'à `Editor_model.php::generate_project_ddi()`, qui construit ce chemin à partir de `get_project_folder($sid)` (interrogation de la table `editor_projects`, colonne `dirpath`) combiné à `get_storage_path()` (valeur de configuration `datafiles/editor`).
3. Vérification en base de données (connexion MySQL directe, port non standard 3308 identifié via `application/config/database.php`) : la valeur `dirpath` du projet est correctement renseignée (`c81e728d9d4c2f636f067f89cc14862c`).
4. Vérification sur le disque : le dossier correspondant existe physiquement et contient l'ensemble des ressources externes précédemment déposées (fichiers CSV, dictionnaire PDF, documents de la Partie 6).
5. Application de permissions étendues (lecture/écriture) sur l'arborescence `datafiles` via `icacls` — sans effet sur l'erreur.
6. Test de l'hypothèse d'un chemin relatif mal résolu par rapport au `DocumentRoot` d'Apache (`.../app`, alors que le dossier de stockage réel se situe sous `.../app/metadata-editor/...`) — création d'une arborescence miroir sous `.../app/datafiles/editor/...` — sans effet sur l'erreur.
7. Vérification de la directive PHP `open_basedir` — confirmée désactivée, cette piste est écartée.
8. Test en cours au moment de la rédaction : script PHP minimal utilisant directement `XMLWriter::openUri()` afin d'isoler si le blocage provient du contexte d'exécution d'Apache (répertoire de travail, compte utilisateur du service) ou d'un défaut propre à la bibliothèque `Editor_DDI_Writer` de ce bundle.

**Conclusion à ce stade :** malgré une investigation méthodique (analyse de code source, vérification base de données, tests de permissions, tests de chemins), la cause exacte du blocage de l'export DDI n'a pas pu être formellement établie. Elle semble indépendante des causes habituelles (permissions, chemin manquant, restriction PHP) et pourrait relever d'un défaut du bundle desktop `MetadataEditorDesktop-1.0.0` lui-même dans la gestion des chemins de fichiers sous Windows.

---

## Observations transverses

- **Conflits d'environnements multiples** : l'exécution simultanée de WampServer, du bundle Metadata Editor Desktop (qui embarque son propre Apache/MySQL) et, ponctuellement, de XAMPP, a généré plusieurs conflits de ports (80, 443, 3306) ayant nécessité l'arrêt systématique des environnements non utilisés pour isoler chaque problème.
- **Configuration PowerShell non standard** : la session PowerShell utilisée pour le diagnostic ne disposait pas d'un `PATH` incluant `C:\Windows\System32`, empêchant l'exécution directe de commandes système courantes (`icacls`, `cmd`) sans spécifier leur chemin complet.
- **Sensibilité à la casse et à la localisation des noms de comptes Windows** : la commande `icacls` a échoué avec le nom de compte anglais standard « Everyone », nécessitant l'utilisation du nom localisé « Tout le monde » sur ce système en français.

---

*Document généré dans le cadre du TP « Anonymisation, Archivage et Diffusion des Microdonnées avec Metadata Editor (MDE) et NADA » — ISE1, module Anonymisation, Archivage numérique et diffusion des microdonnées statistiques.*
