# ENSAN 2026 — Vulnérabilité aux chocs et sécurité alimentaire des ménages

Projet Statistique sous R — ISE1, ENSAE Pierre Ndiaye (2025-2026).
Enseignant : M. Aboubacar HEMA (IFPRI).

Ce dépôt produit un travail reproductible identifiant les déterminants
de l'insécurité alimentaire des ménages tchadiens, la vulnérabilité différenciée
par région et par milieu, et des recommandations opérationnelles de ciblage, à
partir des données de l'enquête ENSAN 2026.

## Données

Cinq sources dans `data/raw/`, décrites en détail dans
`data/raw/dictionnaire_variables_ENSAN2026_Tchad.xlsx` :

- `ensan_menages.dta` — module ménage (Stata, avec labels) : identifiant,
  province, milieu, grappe, strate, poids final, revenu, taille du ménage.
- `ensan_individus.csv` — module individu : âge, sexe, éducation, rang.
- `ensan_consommation.xlsx` — deux feuilles : 12 groupes alimentaires FAO (0/1)
  et postes de dépenses.
- `chocs_menages.csv` — chocs subis et stratégies d'adaptation.
- `prix_marches.csv` — prix mensuels des céréales par marché sur 24 mois.
- `tcd_admin1.shp` (+ fichiers associés) — limites des 23 provinces du Tchad.

## Reproduction des résultats

Le code s'exécute de bout en bout sur R 4.4.x, sans intervention manuelle.

1. Ouvrir `ENSAN2026.Rproj` dans RStudio (le répertoire de travail est fixé à
   la racine du projet).
2. Restaurer l'environnement de packages :

   ```r
   renv::restore()
   ```
3. Lancer tout le travail :

   ```r
   source("main.R")
   ```

   Cette commande enchaîne l'import, le nettoyage, l'imputation, la construction
   des indices, les statistiques pondérées, les figures, la compilation du
   rapport (HTML + Word) et la génération des 23 notes régionales.

## Organisation des scripts

Les scripts de `R/` sont numérotés dans l'ordre d'exécution et chacun
correspond à une étape de l'énoncé :

- `00_fonctions.R` — packages, thème graphique, fonctions.
- `01_import.R` — import des cinq sources.
- `02_nettoyage_jointures.R` — harmonisation, recodages.
- `03_manquants_imputation.R` — diagnostic
- `04_indices.R` — plan de sondage `srvyr`, score HDDS, indice composite de
  vulnérabilité.
- `05_descriptif.R` — Tableau 1 pondéré (`gtsummary`), coefficient de Gini avec
  intervalle de confiance bootstrap, agrégats régionaux.
- `06_visualisation.R` — densités du revenu, carte choroplèthe (`sf`/`ggplot2`)
  et interactive (`tmap`), figure composite (`patchwork`), exports PNG et PDF.
- `07_notes_regionales.R` — génération des notes régionales `rapport/note_regionale.Rmd`.

## Sorties

- `rapport/rapport.html` et `rapport/rapport.docx`
- `output/figures/` — figures en PNG et PDF.
- `output/tables/` — agrégats régionaux et Gini par province (CSV).
- `output/notes_regionales/` — fichier Word.

## Choix méthodologiques (résumé)

- Toutes les statistiques représentatives sont pondérées par `poids_final` et
  tiennent compte du plan complet (grappes, strates) via `srvyr`.
- L'indice de vulnérabilité croise l'exposition aux chocs (pondérée par gravité)
  et l'intensité des stratégies d'adaptation (pondérée par sévérité, dans
  l'esprit de l'échelle stress / crise / urgence). Pondérations et seuils
  sont justifiés dans le rapport.
- Les résultats régionaux sont présentés comme descriptifs et associatifs.

## Note sur reference.docx

Le fichier `rapport/reference.docx` fourni est un modèle Word générique
fonctionnel. Il peut être remplacé par un modèle personnel (même nom, même
dossier) pour appliquer une charte graphique spécifique.
