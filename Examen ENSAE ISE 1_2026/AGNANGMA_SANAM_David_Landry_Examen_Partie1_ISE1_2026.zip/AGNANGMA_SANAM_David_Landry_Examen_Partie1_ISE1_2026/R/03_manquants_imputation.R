
# Fichier de gestions des valeurs manquantes et éventueles imputationss

source(here::here("R", "00_fonctions.R"))

menages_enrichi <- readRDS(here("data", "processed", "02_menages_enrichi.rds"))
src     <- readRDS(here("data", "processed", "01_sources_brutes.rds"))
menages <- src$menages  


na_taguees <- menages |>
  summarise(
    revenu_taguees        = sum(haven::is_tagged_na(revenu)),
    taille_menage_taguees = sum(haven::is_tagged_na(taille_menage))
  )
print(na_taguees)

vars_diag <- c("revenu", "revenu_tete", "taille_menage",
               "age_chef", "educ_chef", "hdds", "dep_totale")

resume_na <- menages_enrichi |>
  select(all_of(vars_diag)) |>
  miss_var_summary()          # % de manquants par variable
message("Résumé des valeurs manquantes par variable :")
print(resume_na)

# par ménages
resume_na_cas <- menages_enrichi |>
  select(all_of(vars_diag)) |>
  miss_case_table()

#visualisation
dir.create(here("output", "figures"), showWarnings = FALSE, recursive = TRUE)

#carte
fig_na <- menages_enrichi |>
  select(all_of(vars_diag)) |>
  vis_miss(warn_large_data = FALSE) +
  labs(title = "Cartographie des valeurs manquantes",
       subtitle = "Variables clés de la nouvelle base de ménages",
       caption = source_ensan) +
  theme_ensan(base_size = 9)

ggsave(here("output", "figures", "fig00_diagnostic_NA.png"),
       fig_na, width = 8, height = 5, dpi = 300, bg = "white")


fig_na_upset <- menages_enrichi |>
  select(all_of(vars_diag)) |>
  gg_miss_upset()

png(here("output", "figures", "fig00b_cooccurrence_NA.png"),
    width = 8, height = 5, units = "in", res = 300, bg = "white")
print(fig_na_upset)
dev.off()


donnees_mice <- menages_enrichi |>
  select(region, milieu, taille_menage, revenu, age_chef, sexe_chef,
         educ_chef, hdds, dep_totale) |>
  mutate(region = factor(region))

methodes <- make.method(donnees_mice)
methodes["revenu"]        <- "pmm"
methodes["taille_menage"] <- "pmm"
methodes["age_chef"]      <- "pmm"
methodes["educ_chef"]     <- "polr"


#imputations
imp <- mice(donnees_mice, m = 5, maxit = 10, method = methodes,
            printFlag = FALSE, seed = 2026)


complet <- complete(imp, 1)

df_clean <- menages_enrichi |>
  mutate(
    revenu        = complet$revenu,
    taille_menage = complet$taille_menage,
    age_chef      = complet$age_chef,
    educ_chef     = complet$educ_chef,
    revenu_tete   = revenu / taille_menage
  )

bornes_q <- quantiles_ponderes(df_clean$revenu_tete, df_clean$poids_final,
                               probs = c(0.2, 0.4, 0.6, 0.8))
df_clean <- df_clean |>
  mutate(quintile_revenu = cut(
    revenu_tete,
    breaks = c(-Inf, bornes_q, Inf),
    labels = c("Q1 (plus pauvre)", "Q2", "Q3", "Q4", "Q5 (plus riche)"),
    ordered_result = TRUE
  ))

na_restants <- df_clean |>
  summarise(across(c(revenu, taille_menage, age_chef, educ_chef, revenu_tete),
                   ~ sum(is.na(.)))) |>
  as.list()


saveRDS(df_clean, here("data", "processed", "df_clean.rds"))
saveRDS(imp,      here("data", "processed", "03_imputation_mice.rds"))
saveRDS(list(resume_na = resume_na, resume_na_cas = resume_na_cas,
             na_taguees = na_taguees),
        here("data", "processed", "03_diagnostic_na.rds"))


