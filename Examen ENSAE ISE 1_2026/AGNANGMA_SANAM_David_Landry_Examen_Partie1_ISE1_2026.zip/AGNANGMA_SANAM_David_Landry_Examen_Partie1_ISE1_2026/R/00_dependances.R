# fichier de dépendances du projet


packages <- c(
  "tidyverse", "haven", "readxl", "sf", "srvyr", "survey", "naniar", "mice",
  "gtsummary", "flextable", "ggridges", "patchwork", "tmap", "scales", "here",
  "knitr", "rmarkdown"
)

manquants <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]

if (length(manquants) == 0) {
  message("Tous les packages requis sont deja installes.")
} else {
  message("Installation des packages manquants : ",
          paste(manquants, collapse = ", "))
  install.packages(manquants, repos = "https://cloud.r-project.org")
}
