# Statistiques descriptives

source(here::here("R", "00_fonctions.R"))

df_clean <- readRDS(here("data", "processed", "df_clean.rds"))
plan_svy <- readRDS(here("data", "processed", "plan_svy.rds"))

dir.create(here("output", "tables"), showWarnings = FALSE, recursive = TRUE)


# TABLEAUX

theme_gtsummary_language("fr", decimal.mark = ",", big.mark = " ")

tableau1 <- plan_svy |>
  tbl_svysummary(
    by = milieu,
    include = c(taille_menage, revenu_tete, age_chef, sexe_chef, educ_chef,
                hdds, hdds_classe, nb_chocs, indice_vuln, vuln_classe),
    label = list(
      taille_menage ~ "Taille du ménage",
      revenu_tete   ~ "Revenu par tête (FCFA)",
      age_chef      ~ "Age du chef",
      sexe_chef     ~ "Sexe du chef",
      educ_chef     ~ "Education du chef",
      hdds          ~ "Score de diversité alimentaire (HDDS)",
      hdds_classe   ~ "Classe de diversité alimentaire",
      nb_chocs      ~ "Nombre de chocs subis",
      indice_vuln   ~ "Indice de vulnerabilité",
      vuln_classe   ~ "Classe de vulnerabilité"
    ),
    statistic = list(
      all_continuous()  ~ "{mean} ({sd})",
      all_categorical() ~ "{p} %"
    ),
    digits = list(all_continuous() ~ 1)
  ) |>
  add_p() |>
  add_n() |>
  add_overall(last = TRUE) |>
  modify_header(label ~ "**Indicateur**") |>
  modify_spanning_header(all_stat_cols() ~ "**Milieu de résidence**") |>
  modify_caption("Tableau 1. Caractéristiques des ménages par milieu (données ponderées)")


#Tableau
tableau1_word <- tableau1 |>
  as_flex_table() |>
  flextable::fontsize(size = 8, part = "all") |>
  flextable::autofit()


# GINI
design_base <- survey::svydesign(
  ids = ~grappe, strata = ~strate, weights = ~poids_final,
  data = df_clean, nest = TRUE
)
design_rep <- survey::as.svrepdesign(design_base, type = "subbootstrap",
                                     replicates = 500)


gini_ic <- function(design) {
  wr  <- survey::withReplicates(
    design,
    function(w, data) gini_pondere(data$revenu_tete, w)
  )
  est <- as.numeric(coef(wr))
  se  <- as.numeric(survey::SE(wr))
  tibble(gini = est, se = se,
         ic_bas = est - 1.96 * se, ic_haut = est + 1.96 * se)
}

# Gini national.
gini_national <- gini_ic(design_rep) |> mutate(niveau = "National", .before = 1)

# Gini par region
regions_liste <- sort(unique(df_clean$region))
gini_regional <- map_dfr(regions_liste, function(r) {
  sous_plan <- subset(design_rep, region == r)
  gini_ic(sous_plan) |> mutate(niveau = r, .before = 1)
})

gini_tout <- bind_rows(gini_national, gini_regional)


agg_region <- plan_svy |>
  group_by(region) |>
  summarise(
    n_menages      = unweighted(n()),
    revenu_tete    = survey_mean(revenu_tete, na.rm = TRUE),
    hdds           = survey_mean(hdds, na.rm = TRUE),
    part_hdds_faible = survey_mean(hdds_classe == "Faible", na.rm = TRUE),
    nb_chocs       = survey_mean(nb_chocs, na.rm = TRUE),
    part_secheresse  = survey_mean(choc_secheresse, na.rm = TRUE),
    part_hausse_prix = survey_mean(choc_hausse_prix, na.rm = TRUE),
    part_conflit     = survey_mean(choc_conflit, na.rm = TRUE),
    indice_vuln    = survey_mean(indice_vuln, na.rm = TRUE),
    part_vuln_elevee = survey_mean(vuln_classe == "Elevée", na.rm = TRUE)
  ) |>
  left_join(gini_regional |> select(region = niveau, gini), by = "region") |>
  arrange(desc(indice_vuln))

agg_milieu <- plan_svy |>
  group_by(milieu) |>
  summarise(
    revenu_tete = survey_mean(revenu_tete, na.rm = TRUE),
    hdds        = survey_mean(hdds, na.rm = TRUE),
    nb_chocs    = survey_mean(nb_chocs, na.rm = TRUE),
    indice_vuln = survey_mean(indice_vuln, na.rm = TRUE)
  )


part_milieu <- plan_svy |>
  group_by(milieu) |>
  summarise(part = survey_mean()) |>
  select(milieu, part)

moy_nat <- plan_svy |>
  summarise(
    revenu_tete   = survey_mean(revenu_tete, na.rm = TRUE),
    hdds          = survey_mean(hdds, na.rm = TRUE),
    part_hdds_faible = survey_mean(hdds_classe == "Faible", na.rm = TRUE),
    part_au_moins_un_choc = survey_mean(nb_chocs >= 1, na.rm = TRUE),
    part_hausse_prix = survey_mean(choc_hausse_prix, na.rm = TRUE),
    part_secheresse  = survey_mean(choc_secheresse, na.rm = TRUE),
    part_conflit     = survey_mean(choc_conflit, na.rm = TRUE),
    part_reduction_repas = survey_mean(strat_reduction_repas, na.rm = TRUE),
    indice_vuln   = survey_mean(indice_vuln, na.rm = TRUE),
    part_vuln_elevee = survey_mean(vuln_classe == "Elevée", na.rm = TRUE)
  )

region_plus_vuln  <- agg_region |> slice_max(indice_vuln, n = 1)
region_moins_vuln <- agg_region |> slice_min(indice_vuln, n = 1)

indicateurs <- list(
  n_menages   = nrow(df_clean),
  n_regions   = n_distinct(df_clean$region),
  n_individus = NA_integer_,
  part_urbain = part_milieu |> filter(milieu == "Urbain") |> pull(part),
  part_rural  = part_milieu |> filter(milieu == "Rural")  |> pull(part),
  revenu_tete_nat   = moy_nat$revenu_tete,
  hdds_nat          = moy_nat$hdds,
  part_hdds_faible  = moy_nat$part_hdds_faible,
  part_au_moins_un_choc = moy_nat$part_au_moins_un_choc,
  part_hausse_prix  = moy_nat$part_hausse_prix,
  part_secheresse   = moy_nat$part_secheresse,
  part_conflit      = moy_nat$part_conflit,
  part_reduction_repas = moy_nat$part_reduction_repas,
  indice_vuln_nat   = moy_nat$indice_vuln,
  part_vuln_elevee  = moy_nat$part_vuln_elevee,
  gini_nat          = gini_national$gini,
  gini_nat_bas      = gini_national$ic_bas,
  gini_nat_haut     = gini_national$ic_haut,
  region_plus_vuln  = region_plus_vuln$region,
  region_plus_vuln_val  = region_plus_vuln$indice_vuln,
  region_moins_vuln = region_moins_vuln$region,
  region_moins_vuln_val = region_moins_vuln$indice_vuln
)

# sauvegarde
saveRDS(tableau1,      here("data", "processed", "tab_tableau1.rds"))
saveRDS(tableau1_word, here("data", "processed", "tab_synthese_word.rds"))
saveRDS(gini_tout,     here("data", "processed", "gini_tout.rds"))
saveRDS(agg_region,    here("data", "processed", "agg_region.rds"))
saveRDS(agg_milieu,    here("data", "processed", "agg_milieu.rds"))
saveRDS(indicateurs,   here("data", "processed", "indicateurs.rds"))

# Exports csv
write_csv(agg_region, here("output", "tables", "agregat_regional.csv"))
write_csv(gini_tout,  here("output", "tables", "gini_par_region.csv"))
