

# On regroupe tous les chargements ici pour ne pas les repeter script par script.
suppressPackageStartupMessages({
  library(tidyverse)
  library(haven)       
  library(readxl)      
  library(sf)         
  library(srvyr)       
  library(survey)      
  library(naniar)      
  library(mice)       
  library(gtsummary)
  library(flextable)   
  library(ggridges)    
  library(patchwork)  
  library(scales)     
  library(here)        
})


options(
  scipen = 999,                    
  survey.lonely.psu = "adjust",
  dplyr.summarise.inform = FALSE
)

set.seed(2026)


couleur_principale <- "#1B5E20"  # vert
couleur_accent     <- "#E36C0A"  # orange
palette_sequentielle <- c("#FBE0C6", "#F3A15A", "#E36C0A", "#B34E00", "#6E2F00")

theme_ensan <- function(base_size = 11) {
  theme_minimal(base_size = base_size) +
    theme(
      plot.title    = element_text(face = "bold", size = rel(1.15),
                                   colour = couleur_principale),
      plot.subtitle = element_text(colour = "grey30", margin = margin(b = 8)),
      plot.caption  = element_text(colour = "grey45", size = rel(0.8), hjust = 0),
      axis.title    = element_text(colour = "grey20"),
      panel.grid.minor = element_blank(),
      panel.grid.major = element_line(colour = "grey90"),
      legend.position  = "bottom",
      strip.text    = element_text(face = "bold", colour = couleur_principale)
    )
}
theme_set(theme_ensan())

source_ensan <- paste(
  "Source : DEVOIR 2026 sur leTchad.",
  "Calculs de l'auteur."
)


fmt <- function(x, d = 1) {
  format(round(x, d), big.mark = " ", decimal.mark = ",",
         nsmall = d, scientific = FALSE, trim = TRUE)
}

# formatage
fmt_pct <- function(p, d = 1) paste0(fmt(100 * p, d), " %")


verifier_lignes <- function(donnees, n_attendu, etape) {
  n_obtenu <- nrow(donnees)
  if (n_obtenu != n_attendu) {
    stop(sprintf(
      "[%s] Le nombre de lignes a changé : attendu %d, obtenu %d.",
      etape, n_attendu, n_obtenu
    ), call. = FALSE)
  }
  message(sprintf("[OK] %s : %d lignes conservées.", etape, n_obtenu))
  invisible(donnees)
}


normaliser_cle_region <- function(x) {
  x |>
    stringi::stri_trans_general("Latin-ASCII") |>
    str_to_upper() |>
    str_replace_all("[^A-Z]", "") |>
    str_replace_all("LL", "L") |>
    str_replace_all("DD", "D")
}

# quantiles
quantiles_ponderes <- function(x, poids, probs) {
  ok <- !is.na(x) & !is.na(poids) & poids > 0
  x <- x[ok]; poids <- poids[ok]
  ordre <- order(x)
  x <- x[ordre]; poids <- poids[ordre]
  cumul <- cumsum(poids) - 0.5 * poids
  cumul <- cumul / sum(poids)
  stats::approx(cumul, x, xout = probs, rule = 2, ties = "ordered")$y
}


gini_pondere <- function(x, poids) {
  ok <- !is.na(x) & !is.na(poids) & poids > 0
  x <- x[ok]; poids <- poids[ok]
  ordre <- order(x)
  x <- x[ordre]; poids <- poids[ordre]
  p <- poids / sum(poids)
  frac_pop  <- cumsum(p)
  frac_rev  <- cumsum(p * x) / sum(p * x)
  # Aire sous la courbe de Lorenz par la methode des trapezes.
  aire <- sum((frac_pop - dplyr::lag(frac_pop, default = 0)) *
                (frac_rev + dplyr::lag(frac_rev, default = 0)) / 2)
  1 - 2 * aire
}

message("00_fonctions.R chargé")
