#fichier de visualisation



source(here::here("R", "00_fonctions.R"))

df_clean   <- readRDS(here("data", "processed", "df_clean.rds"))
agg_region <- readRDS(here("data", "processed", "agg_region.rds"))
regions_sf <- readRDS(here("data", "processed", "02_regions_sf.rds"))
prix       <- readRDS(here("data", "processed", "02_prix_marches.rds"))

dir.create(here("output", "figures"), showWarnings = FALSE, recursive = TRUE)

exporter_figure <- function(plot, nom, largeur = 8, hauteur = 5) {
  ggsave(here("output", "figures", paste0(nom, ".png")),
         plot, width = largeur, height = hauteur, dpi = 300, bg = "white")
  ggsave(here("output", "figures", paste0(nom, ".pdf")),
         plot, width = largeur, height = hauteur, bg = "white")
  invisible(plot)
}

fig01 <- df_clean |>
  mutate(region = fct_reorder(region, revenu_tete, .fun = median)) |>
  ggplot(aes(x = revenu_tete, y = region, fill = after_stat(x))) +
  ggridges::geom_density_ridges_gradient(scale = 2.2, rel_min_height = 0.01,
                                         colour = "white", linewidth = 0.2) +
  scale_x_log10(labels = label_number(big.mark = " ")) +
  scale_fill_gradientn(colours = palette_sequentielle, guide = "none") +
  labs(
    title = "Distribution du revenu par tête selon la province",
    subtitle = "Provinces ordonnées par revenu médian croissant (échelle logarithmique)",
    x = "Revenu par tête (FCFA, echelle log)", y = NULL,
    caption = source_ensan
  )
exporter_figure(fig01, "fig01_densite_revenu_region", hauteur = 7)


carte_data <- regions_sf |>
  left_join(
    agg_region |> mutate(adm1_name = str_to_upper(region)),
    by = "adm1_name"
  )

fig02 <- carte_data |>
  ggplot() +
  geom_sf(aes(fill = indice_vuln), colour = "white", linewidth = 0.2) +
  scale_fill_gradientn(
    colours = palette_sequentielle, na.value = "grey85",
    name = "Indice de\nvulnerabilité"
  ) +
  labs(
    title = "Vulnerabilité aux chocs par province",
    subtitle = "Indice composite moyen pondere (0-100)",
    caption = source_ensan
  ) +
  theme_ensan() +
  theme(axis.text = element_blank(), panel.grid.major = element_blank())
exporter_figure(fig02, "fig02_carte_vulnerabilite", hauteur = 6)

suppressPackageStartupMessages(library(tmap))
tmap_mode("view")
carte_interactive <- tm_shape(carte_data) +
  tm_polygons(
    col = "indice_vuln",
    palette = palette_sequentielle,
    title = "Indice de vulnerabilite",
    id = "region",
    popup.vars = c("Revenu/tete" = "revenu_tete",
                   "HDDS moyen"  = "hdds",
                   "Nb chocs"    = "nb_chocs",
                   "Vulnerabilite" = "indice_vuln"),
    textNA = "Non renseigne"
  ) +
  tm_layout(title = "Vulnerabilité aux chocs")

tmap_save(carte_interactive,
          here("output", "figures", "carte_vulnerabilite_interactive.html"))
tmap_mode("plot")  # on remet le mode statique pour la suite

#HDDS
g_hdds <- df_clean |>
  count(hdds) |>
  ggplot(aes(hdds, n)) +
  geom_col(fill = couleur_principale, width = 0.8) +
  scale_x_continuous(breaks = 0:12) +
  labs(title = "Diversité alimentaire (HDDS)",
       x = "Nombre de groupes alimentaires", y = "Menages")

#prévalence des chocs
g_chocs <- df_clean |>
  summarise(
    Secheresse   = mean(choc_secheresse),
    `Hausse prix` = mean(choc_hausse_prix),
    Conflit      = mean(choc_conflit),
    Maladie      = mean(choc_maladie)
  ) |>
  pivot_longer(everything(), names_to = "choc", values_to = "part") |>
  mutate(choc = fct_reorder(choc, part)) |>
  ggplot(aes(part, choc)) +
  geom_col(fill = couleur_accent, width = 0.7) +
  scale_x_continuous(labels = label_percent()) +
  labs(title = "Prévalence des chocs", x = NULL, y = NULL)


g_prix <- prix |>
  group_by(mois, produit) |>
  summarise(prix = mean(prix_fcfa_kg), .groups = "drop") |>
  ggplot(aes(mois, prix, colour = produit)) +
  geom_line(linewidth = 0.8) +
  scale_colour_manual(values = c(palette_sequentielle[c(3, 5)],
                                 couleur_principale, "grey40")) +
  labs(title = "Prix des cereales sur 24 mois",
       x = NULL, y = "FCFA / kg", colour = NULL)

fig03 <- (g_hdds | g_chocs) / g_prix +
  patchwork::plot_annotation(
    title = "Sécurité alimentaire, chocs et prix : vue d'ensemble",
    theme = theme_ensan()
  )
exporter_figure(fig03, "fig03_synthese_patchwork", hauteur = 7)

