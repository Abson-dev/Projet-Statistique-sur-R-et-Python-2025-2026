# Fichier de jointures

source(here::here("R", "00_fonctions.R"))

src <- readRDS(here("data", "processed", "01_sources_brutes.rds"))
menages       <- src$menages
individus     <- src$individus
conso_groupes <- src$conso_groupes
depenses      <- src$depenses
chocs         <- src$chocs
regions_sf    <- src$regions_sf

N_MENAGES <- nrow(menages)



table_reference <- menages |>
  distinct(region) |>
  mutate(cle = normaliser_cle_region(region))

stopifnot(nrow(table_reference) == n_distinct(table_reference$cle))

chocs <- chocs |>
  mutate(cle = normaliser_cle_region(region_lib)) |>
  left_join(table_reference, by = "cle")

orphelins <- chocs |> filter(is.na(region)) |> distinct(region_lib) |> pull(region_lib)
if (length(orphelins) > 0) {
  stop("Libellés de région non associées : ", paste(orphelins, collapse = ", "))
}
message(sprintf(
  "Harmonisation region : %d libellés bruts ramenés à %d provinces de référence.",
  n_distinct(chocs$region_lib), n_distinct(chocs$region)
))

chocs <- chocs |> select(hhid, choc_secheresse:strat_endettement)

# gérons les cléees des ménages
cles_menages <- sort(unique(str_to_upper(menages$region)))
cles_shp     <- sort(unique(regions_sf$adm1_name))
manquants_carte <- setdiff(cles_menages, cles_shp)
if (length(manquants_carte) > 0) {
  warning("Provinces absentes du shapefile : ", paste(manquants_carte, collapse = ", "))
} else {
  message("Clé spatiale validée : les provinces du module ménnage existent dans le shapefile.")
}

# Ici on gère les modules

n_chefs_brut <- individus |> filter(rang == 1) |> nrow()

chefs <- individus |>
  filter(rang == 1) |>
  arrange(hhid) |>
  group_by(hhid) |>
  slice_head(n = 1) |>
  ungroup() |>
  select(hhid,
         age_chef  = age,
         sexe_chef = sexe,
         educ_chef = niveau_educ)

message(sprintf(
  "Chefs de menage : %d lignes de rang 1 dont %d doublons retirés -> %d chefs uniques.",
  n_chefs_brut, n_chefs_brut - nrow(chefs), nrow(chefs)
))


#aggrégation des alimentations

groupes_fao <- c("cons_cereales", "cons_tubercules", "cons_legumineuses",
                 "cons_legumes", "cons_fruits", "cons_viande", "cons_poisson",
                 "cons_oeufs", "cons_lait", "cons_huile", "cons_sucre",
                 "cons_condiments")

conso_agr <- conso_groupes |>
  mutate(hdds = rowSums(across(all_of(groupes_fao)), na.rm = TRUE)) |>
  select(hhid, all_of(groupes_fao), hdds)

#dépendqnces totales
depenses_agr <- depenses |>
  mutate(dep_totale = rowSums(across(starts_with("dep_")), na.rm = TRUE))


menages_enrichi <- menages |>
  left_join(chefs,        by = "hhid") |>
  verifier_lignes(N_MENAGES, "jointure chefs") |>
  left_join(conso_agr,    by = "hhid") |>
  verifier_lignes(N_MENAGES, "jointure consommation") |>
  left_join(depenses_agr, by = "hhid") |>
  verifier_lignes(N_MENAGES, "jointure depenses") |>
  left_join(chocs,        by = "hhid") |>
  verifier_lignes(N_MENAGES, "jointure chocs")


menages_enrichi <- menages_enrichi |>
  mutate(
    # 1=Urbain / 2=Rural.
    milieu = haven::as_factor(milieu),
    
    sexe_chef = factor(sexe_chef, levels = c(1, 2), labels = c("Homme", "Femme")),
    
    educ_chef = factor(
      educ_chef,
      levels  = c("Aucun", "Primaire", "Secondaire", "Superieur"),
      ordered = TRUE
    ),
    
    revenu_tete = revenu / taille_menage
  )


bornes_q <- quantiles_ponderes(
  menages_enrichi$revenu_tete, menages_enrichi$poids_final,
  probs = c(0.2, 0.4, 0.6, 0.8)
)

menages_enrichi <- menages_enrichi |>
  mutate(
    quintile_revenu = cut(
      revenu_tete,
      breaks = c(-Inf, bornes_q, Inf),
      labels = c("Q1 (plus pauvre)", "Q2", "Q3", "Q4", "Q5 (plus riche)"),
      ordered_result = TRUE
    )
  )

#sauvegarde
saveRDS(menages_enrichi, here("data", "processed", "02_menages_enrichi.rds"))
saveRDS(regions_sf,      here("data", "processed", "02_regions_sf.rds"))
saveRDS(src$prix_marches, here("data", "processed", "02_prix_marches.rds"))


