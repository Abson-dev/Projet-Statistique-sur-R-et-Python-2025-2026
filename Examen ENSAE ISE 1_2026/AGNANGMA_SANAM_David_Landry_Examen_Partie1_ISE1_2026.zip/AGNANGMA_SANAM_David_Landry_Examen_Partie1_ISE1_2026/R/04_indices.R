# Gestion des indices


source(here::here("R", "00_fonctions.R"))

df_clean <- readRDS(here("data", "processed", "df_clean.rds"))


df_clean <- df_clean |>
  mutate(
    hdds_classe = case_when(
      hdds <= 3            ~ "Faible",
      hdds >= 4 & hdds <= 5 ~ "Moyenne",
      hdds >= 6            ~ "Elevee"
    ) |>
      factor(levels = c("Faible", "Moyenne", "Elevée"), ordered = TRUE)
  )


poids_chocs <- c(choc_secheresse = 1.00, choc_hausse_prix = 0.75,
                 choc_conflit = 1.00, choc_maladie = 0.50)
poids_strat <- c(strat_reduction_repas = 1, strat_endettement = 1,
                 strat_vente_actifs = 2, strat_migration = 3)

max_expo  <- sum(poids_chocs)
max_adapt <- sum(poids_strat) 

df_clean <- df_clean |>
  mutate(
    nb_chocs = choc_secheresse + choc_hausse_prix + choc_conflit + choc_maladie,
    
    score_exposition = choc_secheresse * poids_chocs["choc_secheresse"] +
      choc_hausse_prix * poids_chocs["choc_hausse_prix"] +
      choc_conflit     * poids_chocs["choc_conflit"] +
      choc_maladie     * poids_chocs["choc_maladie"],
    
    score_adaptation = strat_reduction_repas * poids_strat["strat_reduction_repas"] +
      strat_endettement     * poids_strat["strat_endettement"] +
      strat_vente_actifs    * poids_strat["strat_vente_actifs"] +
      strat_migration       * poids_strat["strat_migration"],
    
    indice_vuln = 100 * (0.5 * (score_exposition / max_expo) +
                           0.5 * (score_adaptation / max_adapt))
  ) |>
  mutate(across(c(score_exposition, score_adaptation, indice_vuln), as.numeric))


#classification
bornes_vuln <- quantiles_ponderes(df_clean$indice_vuln, df_clean$poids_final,
                                  probs = c(1/3, 2/3))
df_clean <- df_clean |>
  mutate(
    vuln_classe = cut(
      indice_vuln,
      breaks = c(-Inf, bornes_vuln, Inf),
      labels = c("Faible", "Moderée", "Elevée"),
      ordered_result = TRUE
    )
  )


plan_svy <- df_clean |>
  as_survey_design(
    ids     = grappe,
    strata  = strate,
    weights = poids_final,
    nest    = TRUE
  )

#sauvegarde
saveRDS(df_clean, here("data", "processed", "df_clean.rds"))
saveRDS(plan_svy, here("data", "processed", "plan_svy.rds"))

