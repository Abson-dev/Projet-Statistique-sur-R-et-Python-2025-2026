
# fichier d'import des données

source(here::here("R", "00_fonctions.R"))

harmoniser_hhid <- function(x) str_pad(as.character(x), width = 5, pad = "0")

menages <- read_dta(here("data", "raw", "ensan_menages.dta")) |>
  mutate(hhid = as.character(hhid)) 

individus <- read_csv(
  here("data", "raw", "ensan_individus.csv"),
  locale = locale(encoding = "UTF-8"),
  col_types = cols(
    hhid        = col_integer(),
    rang        = col_integer(),
    age         = col_double(),
    sexe        = col_integer(),
    niveau_educ = col_character()
  )
) |>
  mutate(hhid = harmoniser_hhid(hhid))

#consommation
conso_groupes <- read_excel(
  here("data", "raw", "ensan_consommation.xlsx"),
  sheet = "Consommation_groupes"
) |>
  mutate(hhid = harmoniser_hhid(hhid))

depenses <- read_excel(
  here("data", "raw", "ensan_consommation.xlsx"),
  sheet = "Depenses_menage"
) |>
  mutate(hhid = harmoniser_hhid(hhid))

#chocs
chocs <- read_csv(
  here("data", "raw", "chocs_menages.csv"),
  locale = locale(encoding = "UTF-8"),
  col_types = cols(
    hhid       = col_integer(),
    region_lib = col_character(),
    .default   = col_integer()
  )
) |>
  mutate(hhid = harmoniser_hhid(hhid))

#prix céreales

prix_marches <- read_csv(
  here("data", "raw", "prix_marches.csv"),
  locale = locale(encoding = "UTF-8"),
  col_types = cols(
    marche       = col_character(),
    region       = col_character(),
    produit      = col_character(),
    mois         = col_date(format = "%Y-%m-%d"),
    prix_fcfa_kg = col_double()
  )
)

#shapefiles

regions_sf <- st_read(here("data", "raw", "tcd_admin1.shp"), quiet = TRUE)



dir.create(here("data", "processed"), showWarnings = FALSE, recursive = TRUE)
saveRDS(
  list(
    menages = menages, individus = individus,
    conso_groupes = conso_groupes, depenses = depenses,
    chocs = chocs, prix_marches = prix_marches, regions_sf = regions_sf
  ),
  here("data", "processed", "01_sources_brutes.rds")
)
