# Précisions de notes régionales


source(here::here("R", "00_fonctions.R"))
library(rmarkdown)

agg_region <- readRDS(here("data", "processed", "agg_region.rds"))

generer_notes_regionales <- function(regions = sort(unique(agg_region$region))) {
  
  dossier_sortie <- here("output", "notes_regionales")
  dir.create(dossier_sortie, showWarnings = FALSE, recursive = TRUE)
  
  purrr::walk(regions, function(r) {
    fichier <- paste0("note_", str_replace_all(normaliser_cle_region(r), " ", "_"), ".docx")
    rmarkdown::render(
      input       = here("rapport", "notes_regionales.Rmd"),
      output_file = fichier,
      output_dir  = dossier_sortie,
      params      = list(region = r),
      quiet       = TRUE,
      envir       = new.env(parent = globalenv())
    )
    message(sprintf("  Note generee : %s", fichier))
  })
  
  message(sprintf("%d notes regionales ecrites dans %s",
                  length(regions), dossier_sortie))
  invisible(dossier_sortie)
}

generer_notes_regionales()