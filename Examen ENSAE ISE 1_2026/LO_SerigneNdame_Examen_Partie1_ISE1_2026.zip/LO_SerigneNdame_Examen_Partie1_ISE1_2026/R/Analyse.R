# =============================================================================
# Installation automatique des packages manquants
# =============================================================================
packages_cran <- c(
  "haven", "tidyverse", "naniar", "here",
  "survey", "srvyr", "scales",
  "ineq", "gglorenz", "gtsummary", "flextable"
)

for (pkg in packages_cran) {
  if (!require(pkg, character.only = TRUE)) {
    message(paste("Installation CRAN:", pkg))
    install.packages(pkg, dependencies = TRUE)
    library(pkg, character.only = TRUE)
  }
}

# --------------------------------------------------------------------------
# Création des dossiers de sortie
# (l'énoncé impose "output", pas "outputs")
# --------------------------------------------------------------------------
dir.create(here("output", "figures"), showWarnings = FALSE, recursive = TRUE)
dir.create(here("output", "tables"),  showWarnings = FALSE, recursive = TRUE)

# --------------------------------------------------------------------------
# Chargement des objets préparés par le script précédent
# --------------------------------------------------------------------------
chemin_data <- here("data", "processed", "menages_enrichi_corr.drs")

# Si le fichier n'existe pas, on relance le script de nettoyage
if (!file.exists(chemin_data)) {
  cat("Objet intermédiaire absent — exécution du script de nettoyage...\n")
  source(here("R", "import_nettoyage.R"))   
}

menages_enrichi_corr <- readRDS(chemin_data)

# Contrôle immédiat : les variables attendues sont-elles là ?
names(menages_enrichi_corr)



# -----------------------------------------------------------------------------
# 7. Déclaration du plan de sondage
# -----------------------------------------------------------------------------

plan_de_sondage <- menages_enrichi_corr |>
  as_survey_design(
    ids     = grappe,
    strata  = strate,
    weights = poids_final,
    nest    = TRUE
  )

plan_de_sondage



# -----------------------------------------------------------------------------
# 8. Score de diversité alimentaire des ménages (HDDS)
# -----------------------------------------------------------------------------
# On écrit le résultat DANS menages_enrichi_corr pour ne pas perdre la variable
menages_enrichi_corr <- menages_enrichi_corr |>
  mutate(
    # Somme des 12 groupes alimentaires (variables 0/1)
    hdds = rowSums(across(starts_with("cons_")), na.rm = TRUE),
    
    # Classification FAO
    securite_alim = case_when(
      hdds <= 3 ~ "Insécurité alimentaire sévère",
      hdds <= 6 ~ "Insécurité alimentaire modérée",
      hdds <= 9 ~ "Sécurité alimentaire acceptable",
      TRUE      ~ "Bonne diversité alimentaire"
    ) |> factor(levels = c("Insécurité alimentaire sévère",
                           "Insécurité alimentaire modérée",
                           "Sécurité alimentaire acceptable",
                           "Bonne diversité alimentaire"), ordered = TRUE)
  )

# Contrôle : hdds doit être compris entre 0 et 12
summary(menages_enrichi_corr$hdds)


# -----------------------------------------------------------------------------
# 9. Indice composite de vulnérabilité
# -----------------------------------------------------------------------------
menages_enrichi_corr <- menages_enrichi_corr |>
  mutate(
    # Composante 1 : exposition aux chocs
    score_chocs = (1.0 * choc_secheresse +
                     1.0 * choc_conflit +
                     0.5 * choc_hausse_prix +
                     0.5 * choc_maladie) / 3,
    
    # Composante 2 : intensité de l'adaptation
    score_strategies = (1.0 * strat_vente_actifs +
                          1.0 * strat_migration +
                          0.5 * strat_reduction_repas +
                          0.5 * strat_endettement) / 3,
    
    # Indice composite : pondération 50/50
    indice_vuln = 0.5 * score_chocs + 0.5 * score_strategies,
    
    # Classification par seuils (tiers de l'échelle [0 ; 1])
    classe_vuln = case_when(
      indice_vuln <  1/3 ~ "Faible",
      indice_vuln <  2/3 ~ "Moyenne",
      TRUE               ~ "Elevee"
    ) |> factor(levels = c("Faible", "Moyenne", "Elevee"), ordered = TRUE)
  )   # <- plus de virgule avant cette parenthèse

summary(menages_enrichi_corr$indice_vuln)
count(menages_enrichi_corr, classe_vuln)

# -----------------------------------------------------------------------------
# 10. Tableau descriptif pondéré
# -----------------------------------------------------------------------------
tableau1 <- plan_de_sondage |>
  tbl_svysummary(
    by = milieu,
    include = c(hdds, securite_alim, indice_vuln, classe_vuln,
                revenu_tete, taille_menage, nb_chocs),
    statistic = list(all_continuous()  ~ "{mean} ({sd})",
                     all_categorical() ~ "{n} ({p}%)"),
    digits = all_continuous() ~ 1,
    missing = "ifany"
  ) |>
  add_p() |>
  add_overall() |>
  add_n() |>
  bold_labels() |>
  

tableau1

tableau1 |>
  as_flex_table() |>
  save_as_docx(path = here("output", "tables", "tableau1.docx"))


# -----------------------------------------------------------------------------
# 11. Coefficient de Gini pondéré avec IC bootstrap
# -----------------------------------------------------------------------------
# Poids population : chaque ménage compte pour sa taille
menages_enrichi_corr <- menages_enrichi_corr |>
  mutate(poids_pop = poids_final * taille_menage)

# Fonction de Gini pondéré (courbe de Lorenz discrétisée)
gini_pondere <- function(x, w) {
  ok <- !is.na(x) & !is.na(w)
  x <- x[ok]; w <- w[ok]
  o <- order(x); x <- x[o]; w <- w[o]
  p <- c(0, cumsum(w) / sum(w))            # part cumulée de population
  s <- c(0, cumsum(w * x) / sum(w * x))    # part cumulée de revenu
  1 - sum((s[-1] + s[-length(s)]) * diff(p))
}

# Gini national
gini_national <- gini_pondere(menages_enrichi_corr$revenu_tete,
                              menages_enrichi_corr$poids_pop)
gini_national

# IC bootstrap : rééchantillonnage des ménages avec remise
set.seed(2026)
boot_gini <- replicate(500, {
  i <- sample(nrow(menages_enrichi_corr), replace = TRUE)
  gini_pondere(menages_enrichi_corr$revenu_tete[i],
               menages_enrichi_corr$poids_pop[i])
})
ic_national <- quantile(boot_gini, c(0.025, 0.975))
ic_national

# Gini par région
gini_region <- menages_enrichi_corr |>
  group_by(region) |>
  summarise(gini = gini_pondere(revenu_tete, poids_pop)) |>
  arrange(desc(gini))
gini_region

# Courbe de Lorenz
ggplot(menages_enrichi_corr, aes(revenu_tete)) +
  stat_lorenz(color = "#2E75B6", linewidth = 1.2) +
  geom_abline(linetype = "dashed", color = "gray50") +
  annotate("text", x = 0.25, y = 0.75,
           label = paste0("Gini = ", round(gini_national, 3)),
           size = 4, color = "#1F4E79") +
  labs(title = "Courbe de Lorenz — Revenu par tête",
       x = "Part cumulée de la population",
       y = "Part cumulée du revenu") +
  theme_minimal(base_size = 12)







