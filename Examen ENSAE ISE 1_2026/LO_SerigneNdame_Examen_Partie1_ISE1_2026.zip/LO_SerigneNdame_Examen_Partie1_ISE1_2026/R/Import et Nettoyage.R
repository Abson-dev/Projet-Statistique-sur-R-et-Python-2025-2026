# =============================================================================
# FICHIER : Import_Nettoyage.R
# =============================================================================

# =============================================================================
# REPRODUCTIBILITÉ
#   → Ce script doit être exécuté EN PREMIER, depuis la racine du projet
#     (là où se trouve le fichier .Rproj).
#   → Ordre d'exécution : (1) Import_Nettoyage.R  →  (2) Analyse.R
#   → Les données brutes doivent être dans : data/raw/
#   → Les sorties nettoyées seront dans    : data/processed/
#   → Aucune graine aléatoire (set.seed) n'est nécessaire : toutes les
#     opérations sont déterministes.
# =============================================================================


# -----------------------------------------------------------------------------
# 0. PACKAGES
# -----------------------------------------------------------------------------
library(haven)      # Lecture fichiers .dta Stata
library(readr)      # Lecture fichiers .csv 
library(readxl)     # Lecture fichiers .xlsx Excel
library(dplyr)      # Manipulation de données
library(tidyr)      # Reshaping / gestion NA
library(ggplot2)    # Visualisation exploratoire
library(scales)     # Formatage axes
library(labelled)   # Labels Stata
library(janitor)    # Nettoyage noms colonnes
library(sf)         # Lecture du fichier .shp
library(naniar)     # Traitement valeurs manquantes
library(srvyr)      # Plan de sondage
library(ineq)       # Indice de Gini
library(here)
# -----------------------------------------------------------------------------
# 1. IMPORTATION DES DONNÉES BRUTES
# -----------------------------------------------------------------------------

# Module ménage
ensan_menages <- read_dta("data/raw/ensan_menages.dta")

# Module individu
ensan_individus <- read_csv("data/raw/ensan_individus.csv")

# Consommation des 12 groupes alimentaires FAO (0/1) et dépenses par poste
ensan_consommation <- read_excel("data/raw/ensan_consommation.xlsx")

# Chocs subis et stratégies d’adaptation
chocs_menages <- read_csv("data/raw/chocs_menages.csv")

# Prix mensuels des céréales par marché sur 24 mois
prix_marches <- read_csv("data/raw/prix_marches.csv")

# Limites administratives des régions du pays 
regions_sf <- st_read("data/raw/tcd_admin1.shp")


# -----------------------------------------------------------------------------
# 2. Fusionner les modules en un jeu de données ménages enrichi 
# -----------------------------------------------------------------------------

# Filtrons d'abord pour obtenir les chefs de ménage
chefs <- ensan_individus |>
  filter(rang == 1)
View (chefs)

# Nombre de lignes de référence
n_menages <- nrow(ensan_menages)
n_menages   


# =========================================================
# Jointure 1 : caractéristiques du chef de ménage
# =========================================================
menages_enrichi <- ensan_menages |>
  left_join(chefs, by = "hhid")

# Vérification
nrow(menages_enrichi)                 
nrow(menages_enrichi) == n_menages    # doit renvoyer TRUE


# =========================================================
# Jointure 2 : consommation alimentaire 
# =========================================================
menages_enrichi <- menages_enrichi |>
  left_join(ensan_consommation, by = "hhid")

# Vérification
nrow(menages_enrichi)
nrow(menages_enrichi) == n_menages


# =========================================================
# Jointure 3 : chocs subis et stratégies d'adaptation
# =========================================================
menages_enrichi <- menages_enrichi |>
  left_join(chocs_menages, by = "hhid")

# Vérification
nrow(menages_enrichi)
nrow(menages_enrichi) == n_menages


# Nombre de ménages ayant 2 chefs ou plus (rang=1 mais hhid differents)...
chefs |>
  count(hhid) |>
  filter(n > 1)
 

# Il y a exactement 15 ménages concernés qui est bien la différence entre n_menages(3540) et nrow(menages enrichi), il faut donc les enlever

chefs_corrigés <- ensan_individus |>
filter(rang == 1) |>
distinct(hhid, .keep_all = TRUE)

# Contrôle avant jointure
nrow(chefs_corrigés)                              
View(chefs_corrigés)

# On refait les jointures
# =========================================================
# Jointure 1 : caractéristiques du chef de ménage
# =========================================================
menages_enrichi_corr <- ensan_menages |>
  left_join(chefs_corrigés, by = "hhid")

# Vérification
nrow(menages_enrichi_corr)                 
nrow(menages_enrichi_corr) == n_menages    # doit renvoyer TRUE


# =========================================================
# Jointure 2 : consommation alimentaire 
# =========================================================
menages_enrichi_corr <- menages_enrichi_corr |>
  left_join(ensan_consommation, by = "hhid")

# Vérification
nrow(menages_enrichi_corr)
nrow(menages_enrichi_corr) == n_menages


# =========================================================
# Jointure 3 : chocs subis et stratégies d'adaptation
# =========================================================
menages_enrichi_corr <- menages_enrichi_corr |>
  left_join(chocs_menages, by = "hhid")

# Vérification
nrow(menages_enrichi_corr)
nrow(menages_enrichi_corr) == n_menages

View(menages_enrichi_corr)


# -----------------------------------------------------------------------------
# 3. Correction des libellés des régions 
# -----------------------------------------------------------------------------

# Identifier le nom de la colonne des régions
View(regions)


# =========================================================
# Étape 1 : voir les écarts entre les deux sources
# =========================================================
sort(unique(menages_enrichi_corr$region))
sort(unique(regions_sf$adm1_name))          

setdiff(unique(menages_enrichi_corr$region), unique(regions_sf$adm1_name))


# =========================================================
# Étape 2 : créer une clé propre dans chaque table
# =========================================================
# make_clean_names() met en minuscules, enlève les accents,les espaces et la ponctuation

menages_enrichi_corr <- menages_enrichi_corr |>
  mutate(region_cle = make_clean_names(region))

regions_sf <- regions_sf |>
  mutate(region_cle = make_clean_names(adm1_name))


# =========================================================
# Étape 3 : Jointure spatiale
# =========================================================

menages_enrichi_corr <- menages_enrichi_corr |>
  left_join(regions_sf, by = "region_cle")

View(menages_enrichi_corr)

# -----------------------------------------------------------------------------
# 4. Exploration et visualisation des NA
# -----------------------------------------------------------------------------


# Résumé des valeurs manquantes 
miss_var_summary(menages_enrichi_corr) |> filter(pct_miss > 0) 

# Matrice de co-occurrence des NA:quelles variables sont manquantes ensemble ? 
gg_miss_upset(menages_enrichi_corr, nsets = 8) 

# Pattern spatial des NA dans le dataset 
vis_miss(menages_enrichi_corr, sort_miss = TRUE) 

names(menages_enrichi_corr$niveau_educ)
# -----------------------------------------------------------------------------
# 6. Recodage des variables catégorielles 
# -----------------------------------------------------------------------------

menages_enrichi <- menages_enrichi |>
  mutate(

# Plus le niveau d'instruction est élevé, plus la valeur est élevée

   educ_chef = case_when(
      niveau_educ == "Aucun"      ~ 1,
      niveau_educ == "Primaire"   ~ 2,
      niveau_educ == "Secondaire" ~ 3,
      niveau_educ == "Superieur"  ~ 4
    ),
    
# Revenu par tête
    revenu_tete = revenu / taille_menage,
    
# Quintiles de revenu par tête 
    quintile_revenu = ntile(revenu_tete, 5)
  )


# =============================================================================
# Sauvegarde des objets intermédiaires pour le script 02
# =============================================================================

saveRDS(menages_enrichi_corr, here("data", "processed", "menages_enrichi_corr.drs"))





