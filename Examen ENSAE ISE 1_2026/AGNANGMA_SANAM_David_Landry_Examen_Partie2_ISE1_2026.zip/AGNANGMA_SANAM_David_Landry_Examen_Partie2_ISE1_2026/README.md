# ENSAN 2026 — Partie 2 : récupération de données via l'API des ODD

Projet Statistique sous R — ISE1, ENSAE Pierre Ndiaye (2025-2026).
Partie 2 de l'examen.

Cette partie récupère six indicateurs de la base mondiale des ODD (UNSD SDG API),
applique la chaîne de traitement demandée (fusion d'indicateurs, filtrage,
recodages, jointure avec un fichier de correspondance pays-région, arrondis,
contrôle des doublons) et exporte le jeu final en `.csv`.

## Prérequis

- R 4.4 avec les packages `tidyverse`, `httr2`, `janitor`, `here`.
- Un accès internet vers `https://unstats.un.org` (API SDG).
- Le fichier de correspondance pays-région fourni

## Exécution

```r
source("R/script_api.R")
```



## Étapes couvertes

