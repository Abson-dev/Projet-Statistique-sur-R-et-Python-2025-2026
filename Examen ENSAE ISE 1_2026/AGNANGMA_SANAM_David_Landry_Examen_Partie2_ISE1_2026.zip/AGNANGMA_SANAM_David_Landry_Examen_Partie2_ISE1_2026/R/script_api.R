# script partie 2
# gestion package


install.packages("janitor")
suppressPackageStartupMessages({
  library(tidyverse)
  library(httr2)    
  library(janitor)
  library(here)
})

series <- c(
  "SP_DYN_MRBF15",
  "SP_DYN_MRBF18",  
  "SH_STA_MORT",
  "SL_TLF_NEET",    
  "SP_DYN_ADKL",    
  "SH_STA_BRTC"
)

CHEMIN_CORRESPONDANCE <- here("data", "raw", "correspondance_pays_region.csv")
API_DATACSV <- "https://unstats.un.org/sdgapi/v1/sdg/Series/DataCSV"

dir.create(here("data", "raw"),       showWarnings = FALSE, recursive = TRUE)
dir.create(here("data", "processed"), showWarnings = FALSE, recursive = TRUE)

#requête API
reponse <- request(API_DATACSV) |>
  req_body_form(seriesCodes = paste(series, collapse = ",")) |>
  req_headers(Accept = "text/csv") |>
  req_perform()

fichier_brut <- here("data", "raw", "sdg_indicateurs_bruts.csv")
writeBin(resp_body_raw(reponse), fichier_brut)


donnees_api <- read_csv(fichier_brut, show_col_types = FALSE) |> clean_names()
print(head(donnees_api, 10))



# On a une Erreur pour la question précédente mais on écrit les codes des questions suivantes sans exection
# 5 Fusion des indicateurs
col_serie <- names(donnees_api)[str_detect(names(donnees_api),
                                           "series.*code|seriescode")][1]

donnees <- donnees_api |>
  mutate(
    marie_avant_age = case_when(
      .data[[col_serie]] == "SP_DYN_MRBF15" ~ "avant_age_15",
      .data[[col_serie]] == "SP_DYN_MRBF18" ~ "avant_age_18",
      TRUE ~ NA_character_
    ),
    
    series_description = if_else(
      .data[[col_serie]] %in% c("SP_DYN_MRBF15", "SP_DYN_MRBF18"),
      "Proportion combinee de femmes agées de 20 a 24 ans mariees avant 18 ans",
      as.character(series_description)
    )
  )

# 6 - conservation des valeurs soit vides soit qui valent "A"

col_obs <- names(donnees)[str_detect(names(donnees), "observation_status")][1]
donnees <- donnees |>
  filter(is.na(.data[[col_obs]]) | .data[[col_obs]] == "" | .data[[col_obs]] == "A")

# 7 Remplacement de "-" par ""_"
cols_desag <- names(donnees)[str_detect(
  names(donnees), "^(age|sex|location|reporting_type|urbanisation|disability|quantile|freq|composite)"
)]
donnees <- donnees |>
  mutate(across(all_of(cols_desag), ~ str_replace_all(as.character(.), "-", "_")))




