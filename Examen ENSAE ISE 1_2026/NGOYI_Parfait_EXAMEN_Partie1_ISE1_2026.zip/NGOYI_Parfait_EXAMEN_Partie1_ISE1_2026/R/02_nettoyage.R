# Suppression des doublons du fichier individus
individus <- individus |>
  distinct()

# Informations concernant le chef de ménage
chefs <- individus |>
  filter(rang == 1) |>
  transmute(
    hhid,
    age_cm = age,
    sexe_cm = factor(sexe, c(1, 2), c("Homme", "Femme")),
    education_cm = recode(niveau_educ, "Superieur" = "Supérieur")
  )

# Harmonisation des provinces
menages <- menages |>
  mutate(
    milieu = as_factor(milieu),
    region_cle = nettoyer_region(region)
  )

chocs <- chocs |>
  mutate(region_chocs = nettoyer_region(region_lib)) |>
  select(-region_lib)

regions <- carte |>
  st_drop_geometry() |>
  transmute(
    region_cle = nettoyer_region(adm1_name),
    pcode = adm1_pcode
  )

# Jointures et contrôle du nombre de ménages
n_depart <- nrow(menages)
n_depart
# Il y a 3540 menages au depart
base <- menages |> left_join(chefs, by = "hhid")
n_chefs <- nrow(base)
n_chefs
## Il y a 3540 menages au depart

base <- base |> left_join(groupes, by = "hhid")
n_groupes <- nrow(base)
n_groupes
# Il y a 3540 menages apres jointure. Donc, la taille des menages est maintenue.

base <- base |> left_join(depenses, by = "hhid")
n_depenses <- nrow(base)
n_depenses
# Il y a 3540 menages, ce qui est conforme a ce qui est attendue.

base <- base |> left_join(chocs, by = "hhid")
n_chocs <- nrow(base)
n_chocs
# Il y a 3540 menages comme au depart. Donc, le resultat est satisfaisant.

# On fait un control de jointure
controle_jointures <- tibble(
  etape = c("Départ", "Chefs", "Consommation", "Dépenses", "Chocs"),
  nombre_lignes = c(n_depart, n_chefs, n_groupes, n_depenses, n_chocs)
)

stopifnot(all(controle_jointures$nombre_lignes == n_depart))
stopifnot(all(base$region_cle == base$region_chocs))

# On constitue consolidee finale. On cree un nouvel identifiant region_cle.
base <- base |>
  left_join(regions, by = "region_cle")

# Diagnostic des valeurs manquantes avant imputation
base_avant_imputation <- base
diagnostic_na <- miss_var_summary(base_avant_imputation)
graphique_na <- gg_miss_var(base_avant_imputation, show_pct = TRUE)

na_stata <- tibble(
  variable = c("revenu", "taille_menage"),
  na_stata = c(
    sum(is_tagged_na(menages$revenu)),
    sum(is_tagged_na(menages$taille_menage))
  )
)

# Imputation MICE du revenu et de la taille du ménage
base_mice <- base |>
  select(revenu, taille_menage, poids_final, milieu, region) |>
  mutate(
    milieu = as.factor(milieu),
    region = as.factor(region)
  )

methode <- c("pmm", "pmm", "", "", "")

imputation <- mice(
  base_mice,
  m = 5,
  maxit = 5,
  method = methode,
  seed = 123,
  printFlag = FALSE
)

base_completee <- complete(imputation, 1)

base <- base |>
  mutate(
    revenu = base_completee$revenu,
    taille_menage = base_completee$taille_menage,
    education_cm = factor(
      education_cm,
      levels = c("Aucun", "Primaire", "Secondaire", "Supérieur"),
      ordered = TRUE
    ),
    revenu_pc = revenu / taille_menage
  )

# Quintiles pondérés du revenu par tête
plan_temporaire <- survey::svydesign(
  ids = ~grappe,
  strata = ~strate,
  weights = ~poids_final,
  data = base,
  nest = TRUE
)

quantiles_revenu <- survey::svyquantile(
  ~revenu_pc,
  plan_temporaire,
  quantiles = c(0.20, 0.40, 0.60, 0.80),
  ci = FALSE,
  na.rm = TRUE
)

bornes <- as.numeric(coef(quantiles_revenu))

base <- base |>
  mutate(
    quintile_revenu = cut(
      revenu_pc,
      breaks = c(-Inf, bornes, Inf),
      labels = paste0("Q", 1:5),
      ordered_result = TRUE
    )
  )

# Enregistrement des données nettoyées
write_csv(controle_jointures, "output/tables/controle_jointures.csv")
write_csv(diagnostic_na, "output/tables/diagnostic_na.csv")
write_csv(na_stata, "output/tables/na_stata.csv")
ggsave(
  "output/figures/valeurs_manquantes.png",
  graphique_na,
  width = 8,
  height = 5,
  dpi = 300
)

saveRDS(base, "data/processed/menages_nettoyes.rds")
saveRDS(carte, "data/processed/carte_tchad.rds")
