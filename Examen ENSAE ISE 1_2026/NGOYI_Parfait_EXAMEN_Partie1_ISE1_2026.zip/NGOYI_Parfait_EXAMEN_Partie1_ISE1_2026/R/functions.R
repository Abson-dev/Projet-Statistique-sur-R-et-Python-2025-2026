# Mettre les identifiants sur cinq chiffres
format_hhid <- function(x) {
  sprintf("%05d", as.integer(x))
}

# Mettre les noms de province sous une forme commune
nettoyer_region <- function(x) {
  x <- iconv(x, to = "ASCII//TRANSLIT") |>
    stringr::str_to_upper() |>
    stringr::str_replace_all("[^A-Z]", "")

  x <- dplyr::recode(
    x,
    "OUADAI" = "OUADDAI",
    "TANDJILLE" = "TANDJILE"
  )

  x
}

# Calcul simple du coefficient de Gini pondéré
gini_pondere <- function(x, poids) {
  garder <- !is.na(x) & !is.na(poids) & poids > 0
  x <- x[garder]
  poids <- poids[garder]

  ordre <- order(x)
  x <- x[ordre]
  poids <- poids[ordre]

  part_population <- c(0, cumsum(poids) / sum(poids))
  part_revenu <- c(0, cumsum(x * poids) / sum(x * poids))

  1 - sum(
    (part_revenu[-1] + part_revenu[-length(part_revenu)]) *
      diff(part_population)
  )
}
