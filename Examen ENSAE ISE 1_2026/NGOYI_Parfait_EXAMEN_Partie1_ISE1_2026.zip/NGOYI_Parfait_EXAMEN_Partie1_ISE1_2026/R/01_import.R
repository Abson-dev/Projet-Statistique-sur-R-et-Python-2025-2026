if (!requireNamespace("renv", quietly = TRUE)) {
  install.packages("renv")
}
# On fig3 les versions des packages pour assurer la reproductibilite
renv::init()

install.packages(c(
  "tidyverse", "haven", "readxl", "janitor", "naniar", "mice",
  "srvyr", "survey", "gtsummary", "sf", "tmap", "patchwork",
  "scales", "convey", "httr2", "rmarkdown", "knitr"
))

renv::snapshot()
renv::restore() # p our restorer les packages.
# Packages utilisés dans le projet
library(tidyverse)
library(haven)
library(dplyr)
library(readxl)
library(janitor)
library(naniar)
library(mice)
library(srvyr)
library(gtsummary)
library(sf)
library(tmap)
library(patchwork)

source("R/functions.R", encoding = "UTF-8") # Pour importer les fonctions déclarées dans le fichier functions.R

# Importation des fichiers
menages <- read_dta("data/raw/ensan_menages.dta") |>
  clean_names() |>
  mutate(hhid = format_hhid(hhid))

individus <- read_csv("data/raw/ensan_individus.csv", show_col_types = FALSE) |>
  clean_names() |>
  mutate(hhid = format_hhid(hhid))

groupes <- read_excel(
  "data/raw/ensan_consommation.xlsx",
  sheet = "Consommation_groupes"
) |>
  clean_names() |>
  mutate(hhid = format_hhid(hhid))

depenses <- read_excel(
  "data/raw/ensan_consommation.xlsx",
  sheet = "Depenses_menage"
) |>
  clean_names() |>
  mutate(hhid = format_hhid(hhid))

chocs <- read_csv("data/raw/chocs_menages.csv", show_col_types = FALSE) |>
  clean_names() |>
  mutate(hhid = format_hhid(hhid))

prix <- read_csv("data/raw/prix_marches.csv", show_col_types = FALSE) |>
  clean_names()

carte <- st_read("data/raw/tcd_admin1.shp", quiet = TRUE) |>
  clean_names()

