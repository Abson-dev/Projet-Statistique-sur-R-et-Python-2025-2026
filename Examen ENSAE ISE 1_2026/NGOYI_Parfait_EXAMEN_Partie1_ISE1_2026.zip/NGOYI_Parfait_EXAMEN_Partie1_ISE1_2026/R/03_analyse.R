# Lecture des données nettoyées
base <- readRDS("data/processed/menages_nettoyes.rds")
carte <- readRDS("data/processed/carte_tchad.rds")

# Score de diversité alimentaire (HDDS)
variables_hdds <- names(base)[str_detect(names(base), "^cons_")]

base <- base |>
  mutate(
    hdds = rowSums(pick(all_of(variables_hdds))),
    classe_hdds = case_when(
      hdds <= 3 ~ "Faible",
      hdds <= 5 ~ "Moyenne",
      TRUE ~ "Élevée"
    ) |>
      factor(levels = c("Faible", "Moyenne", "Élevée"), ordered = TRUE)
  )

# Indice de vulnérabilité aux chocs
base <- base |>
  mutate(
    score_chocs = 2 * choc_secheresse + choc_hausse_prix +
      3 * choc_conflit + choc_maladie,
    score_strategies = 2 * strat_vente_actifs +
      3 * strat_reduction_repas + 2 * strat_migration +
      strat_endettement,
    indice_vulnerabilite = 100 * (
      0.60 * score_chocs / 7 + 0.40 * score_strategies / 8
    ),
    classe_vulnerabilite = case_when(
      indice_vulnerabilite < 33.33 ~ "Faible",
      indice_vulnerabilite < 66.67 ~ "Modérée",
      TRUE ~ "Élevée"
    ) |>
      factor(levels = c("Faible", "Modérée", "Élevée"), ordered = TRUE)
  )

# Plan de sondage
plan <- base |>
  as_survey_design(
    ids = grappe,
    strata = strate,
    weights = poids_final,
    nest = TRUE
  )

# Résultats pondérés
indicateurs_nationaux <- plan |>
  summarise(
    hdds_moyen = survey_mean(hdds, na.rm = TRUE),
    vulnerabilite_moyenne = survey_mean(
      indice_vulnerabilite,
      na.rm = TRUE
    ),
    part_vulnerabilite_elevee = survey_mean(
      classe_vulnerabilite == "Élevée",
      na.rm = TRUE
    )
  )

synthese_milieu <- plan |>
  group_by(milieu) |>
  summarise(
    hdds_moyen = survey_mean(hdds, na.rm = TRUE),
    vulnerabilite_moyenne = survey_mean(
      indice_vulnerabilite,
      na.rm = TRUE
    )
  )

synthese_region <- plan |>
  group_by(region, pcode) |>
  summarise(
    effectif = unweighted(n()),
    hdds_moyen = survey_mean(hdds, na.rm = TRUE),
    vulnerabilite_moyenne = survey_mean(
      indice_vulnerabilite,
      na.rm = TRUE
    )
  ) |>
  arrange(desc(vulnerabilite_moyenne))

# Tableau 1 avec gtsummary
tableau_1 <- plan |>
  tbl_svysummary(
    by = milieu,
    include = c(
      taille_menage,
      revenu_pc,
      education_cm,
      hdds,
      classe_hdds,
      indice_vulnerabilite,
      classe_vulnerabilite
    ),
    statistic = list(
      all_continuous() ~ "{mean} ({sd})",
      all_categorical() ~ "{n} ({p}%)"
    ),
    missing = "ifany"
  ) |>
  add_n() |>
  add_p()

# Gini national avec intervalle de confiance par bootstrap
set.seed(123)
gini_estime <- gini_pondere(base$revenu_pc, base$poids_final)

gini_bootstrap <- replicate(200, {
  echantillon <- base |>
    slice_sample(n = nrow(base), replace = TRUE)

  gini_pondere(echantillon$revenu_pc, echantillon$poids_final)
})

gini_national <- tibble(
  region = "Ensemble national",
  gini = gini_estime,
  ic_inf = quantile(gini_bootstrap, 0.025),
  ic_sup = quantile(gini_bootstrap, 0.975)
)

# Gini par province
gini_regions <- tibble()

for (province in unique(base$region)) {
  donnees_region <- base |> filter(region == province)

  valeurs_boot <- replicate(200, {
    echantillon <- donnees_region |>
      slice_sample(n = nrow(donnees_region), replace = TRUE)

    gini_pondere(echantillon$revenu_pc, echantillon$poids_final)
  })

  ligne <- tibble(
    region = province,
    gini = gini_pondere(
      donnees_region$revenu_pc,
      donnees_region$poids_final
    ),
    ic_inf = quantile(valeurs_boot, 0.025),
    ic_sup = quantile(valeurs_boot, 0.975)
  )

  gini_regions <- bind_rows(gini_regions, ligne)
}

# Graphiques
theme_set(theme_minimal())

graphique_revenu <- base |>
  filter(revenu_pc > 0) |>
  ggplot(aes(revenu_pc, weight = poids_final)) +
  geom_density(fill = "steelblue", alpha = 0.5) +
  facet_wrap(~region) +
  scale_x_log10() +
  labs(
    title = "Distribution du revenu par tête",
    x = "Revenu par tête (échelle logarithmique)",
    y = "Densité"
  )

graphique_hdds <- synthese_region |>
  ggplot(aes(reorder(region, hdds_moyen), hdds_moyen)) +
  geom_col(fill = "steelblue") +
  coord_flip() +
  labs(title = "HDDS moyen par province", x = NULL, y = "HDDS moyen")

graphique_milieu <- synthese_milieu |>
  ggplot(aes(milieu, vulnerabilite_moyenne, fill = milieu)) +
  geom_col(show.legend = FALSE) +
  labs(
    title = "Vulnérabilité par milieu",
    x = NULL,
    y = "Indice moyen"
  )

prix_moyens <- prix |>
  mutate(mois = as.Date(mois)) |>
  group_by(mois, produit) |>
  summarise(prix = mean(prix_fcfa_kg), .groups = "drop")

graphique_prix <- prix_moyens |>
  ggplot(aes(mois, prix, color = produit)) +
  geom_line() +
  labs(
    title = "Évolution des prix des céréales",
    x = NULL,
    y = "Prix moyen (FCFA/kg)",
    color = "Produit"
  )

carte_finale <- carte |>
  left_join(
    synthese_region |> select(pcode, vulnerabilite_moyenne),
    by = c("adm1_pcode" = "pcode")
  )

carte_statique <- ggplot(carte_finale) +
  geom_sf(
    aes(fill = vulnerabilite_moyenne),
    color = "white"
  ) +
  geom_sf_text(
    aes(
      label = paste0(
        region,
        "\n",
        round(vulnerabilite_moyenne, 1)
      )
    ),
    size = 3,
    color = 
  ) +
  labs(
    title = "Vulnérabilité moyenne par province",
    fill = "Vulnérabilité moyenne"
  ) +
  theme_minimal()

graphique_carte <- ggplot(carte_finale) +
  geom_sf(aes(fill = vulnerabilite_moyenne), color = "white") +
  scale_fill_viridis_c(name = "Indice moyen") +
  theme_void() +
  labs(title = "Vulnérabilité moyenne par province")

figure_composee <- (graphique_hdds | graphique_milieu) /
  graphique_prix

# Export des figures
figures <- list(
  revenu_regions = graphique_revenu,
  hdds_regions = graphique_hdds,
  vulnerabilite_milieu = graphique_milieu,
  prix_cereales = graphique_prix,
  carte_vulnerabilite = graphique_carte,
  figure_composee = figure_composee
)

for (nom in names(figures)) {
  ggsave(
    paste0("output/figures/", nom, ".png"),
    figures[[nom]],
    width = 10,
    height = 7,
    dpi = 300
  )

  ggsave(
    paste0("output/figures/", nom, ".pdf"),
    figures[[nom]],
    width = 10,
    height = 7
  )
}

# Carte interactive
tmap_mode("view")
carte_interactive <- tm_shape(carte_finale) +
  tm_polygons(
    fill = "vulnerabilite_moyenne",
    fill.legend = tm_legend(title = "Indice moyen")
  )
tmap_save(
  carte_interactive,
  "output/figures/carte_vulnerabilite_interactive.html"
)

# Export des tableaux
write_csv(indicateurs_nationaux, "output/tables/indicateurs_nationaux.csv")
write_csv(synthese_milieu, "output/tables/synthese_milieu.csv")
write_csv(synthese_region, "output/tables/synthese_region.csv")
write_csv(gini_national, "output/tables/gini_national.csv")
write_csv(gini_regions, "output/tables/gini_regions.csv")
write_csv(as_tibble(tableau_1), "output/tables/tableau_1.csv")

saveRDS(base, "data/processed/menages_analyse.rds")
