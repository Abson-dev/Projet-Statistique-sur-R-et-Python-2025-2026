
# Importation des packages
pkgs <- c(
  "tidyverse", "haven", "labelled", "here", "scales",     # import / manipulation
  "patchwork", "naniar", "moments",                       # diagnostics / stats desc.
  "gtsummary", "gt", "flextable", "officer", "knitr",      # tableaux
  "srvyr", "survey", # plan de sondage pondéré
  "readr", "readxl","haven","mice","srvyr"
)

manquants <- pkgs[!pkgs %in% installed.packages()[, 1]]
if (length(manquants) > 0) {
  cat("Packages manquants :", paste(manquants, collapse = ", "), "\n")
  cat("Lancez renv::restore() puis relancez main.R\n")
  stop("Environnement non initialisé.")
}

invisible(lapply(pkgs, library, character.only = TRUE))
cat("Packages charges :", length(pkgs), "\n")

#Section 1. Import, structuration et nettoyage 
# 1 - Importation des base de données
## base csv
chocs_menages <- read_csv("data/raw/chocs_menages.csv")
View(chocs_menages)
ensan_individus <- read_csv("data/raw/ensan_individus.csv")
prix_marches <- read_csv("data/raw/prix_marches.csv")

## Base xlsx
ensan_consommation <- read_excel("data/raw/ensan_consommation.xlsx")
View(ensan_consommation)
## Base dta
ensan_menages <- read_dta("data/raw/ensan_menages.dta")

View(ensan_menages)
View(ensan_individus)


##Considerons l'extrait de ensan_individus ne comportant que le chef de menages
ensan_individus_chef <- ensan_individus |>  filter(ensan_individus$rang == 1)
View(ensan_individus_chef)
doublons <- ensan_individus_chef |> group_by(hhid,rang) |> filter(n() > 1) |> nrow()
print(doublons)
###il existe des doublons dans la base. Supprimons-les
ensan_individus_chef <- unique(ensan_individus_chef)
doublons <- ensan_individus_chef |> group_by(hhid,rang) |> filter(n() > 1) |> nrow()
print(doublons)

##Considerons l'extrait de ensan_consommation ne comportant que l'aggregation
### Comme les variables sont des indicatrices, on peut simplemet faire la somme pour savoir le nombre de ces aliments consommees dans chaque menages.
colnames(ensan_consommation)
ensan_consommation <- ensan_consommation |> mutate( 
  nbrAlim = rowSums (cbind(cons_cereales,cons_tubercules,cons_legumineuses,cons_legumes,cons_fruits,cons_viande,cons_poisson,cons_oeufs,cons_lait,cons_huile,cons_sucre,cons_condiments)))
###extrait de la base de donnees la partie aggregation
ensan_consommation_agg <- ensan_consommation |> select (hhid,nbrAlim)



##considerons les chocs
View(chocs_menages)
### nous allons le considerer comme il est.


## 2 - Fusion
###Procedons à la première fusion.
dim_desc(ensan_menages)
dim_desc(ensan_individus_chef)
fusion1 <- left_join(ensan_menages, ensan_individus_chef, by = "hhid")
dim_desc(fusion1)
#### la dimension de la fusion est bien la bonne.

###Procedons à la deuxième fusion.
dim_desc(ensan_consommation_agg)
fusion2 <- left_join(fusion1,ensan_consommation_agg, by = "hhid")
dim_desc(fusion2)
#### la dimension de la fusion est bien la bonne.


###Procedons à la troisième fusion.
dim_desc(chocs_menages)
Jointure <- left_join(fusion2,chocs_menages, by = "hhid")
dim_desc(Jointure)
View(Jointure)
#### la dimension de la fusion est bien la bonne.

## Sauvegarde
write_dta(fusion1,"data/processed/fusion1.dta")
write_dta(fusion2,"data/processed/fusion2.dta")
write_dta(Jointure,"output/Jointure.dta")


# 4 -Produire un diagnostic complet des valeurs manquantes avec naniar (résumé, visualisation, cooccurrences), en distinguant les valeurs manquantes standards des valeurs manquantes taguées Stata. 



fig00 <- vis_miss(Jointure, sort_miss = TRUE) +
  labs(
    title    = "Diagnostic des valeurs manquantes ",
  ) +
  theme_minimal(base_size = 10)
print(fig00)
ggsave(here("output", "figures", "fig00_diagnostic_NA.png"), fig00, width = 9, height = 5, dpi = 300)

## le graphique nous montre la presence de valeurs manquantes mais il pourrait etre plus clair.
## Ainsi on utilise une autre methode
fig01 <- gg_miss_var(Jointure) + theme_bw() 
print(fig01)
ggsave(here("output", "figures", "fig01_diagnostic_NA.png"), fig01, width = 9, height = 5, dpi = 300)



# 5 -Justifier, pour deux variables clés de votre choix, une hypothèse de mécanisme de non-réponse (MCAR, MAR ou MNAR) et appliquer une imputation multiple par équations chaînées adaptée avec mice. 
## Considerons les variables "taille" et "revenu"

### la variable taille ne peut avoir des valeurs manquantes que par hasard car aucune logique d'un questionnaire sur le ménages ne peut justifier que l'on ne recolte pas cette valeur.

### La variable "revenu" est plus nuance, car il est possible de survivre avec les transferts sociaux et les pensions. il est comorehensible qu'une personne retraitée ne percoivent pas de salaire.

## Imputation avec Mice 
imp <- mice( 
  Jointure |> select(revenu, age, niveau_educ, taille_menage), 
  m     = 5,          # Nombre de jeux imputés 
  maxit = 20,         # Itérations de convergence 
  method = "pmm",     
seed  = 42 
) 
# Vérifier la convergence 
plot(imp)


# 6 -  Recoder les variables catégorielles nécessaires à l’analyse (milieu, niveau d’éducation du chef de ménage, quintiles de revenu par tête)
## Comme pour les milieu ==1, la strate montre que c'est urbain, on va considérer que 1= urbqin et 2= rural
Jointure <- Jointure |> mutate(
  milieu = case_when(
    milieu == 1             ~ "Urbain",
    milieu == 2             ~ "Rural") ,
  revenu_tete = revenu/taille_menage
)
quantile(Jointure$revenu_tete, probs = seq(0, 1, 0.20), na.rm = TRUE,
         names = TRUE, type = 7, digits = 7)


Jointure <- Jointure |> mutate(
  quintiles_revenue_tete = ifelse(revenu_tete>24777.860,1,
                            ifelse(revenu_tete>15383.109,2,
                            ifelse(revenu_tete>10277.150,3,
                            ifelse(revenu_tete>6653.502,4,5)))))
Jointure <- Jointure |> mutate(
  milieu = case_when(
    quintiles_revenue_tete == 1             ~ "1",
    quintiles_revenue_tete == 2             ~ "2" ,
    quintiles_revenue_tete == 3             ~ "3",
    quintiles_revenue_tete == 4             ~ "4" ,
    quintiles_revenue_tete == 5             ~ "5"))


#Section 2. Statistiques descriptives pondérées et indices composites 

# 7 - Déclarer le plan de sondage complet (grappes, strates, poids finaux) avec srvyr. 

plan_sondage <- Jointure |> 
  as_survey_design( 
    ids     =  grappe,          # Identifiant des grappes (PSU) 
    strata  = strate,          # Variable de stratification 
    weights = poids_final,     # Poids de sondage finaux 
    nest    = TRUE 
  ) 

# 8 - Construire le score de diversité alimentaire des ménages (HDDS) et la classification FAO associée.
Jointure <- Jointure |> 
  mutate( 
    # Classification FAO 
    securite_alim = case_when( 
      aggregate() <= 3  ~ "Insécurité alimentaire sévère", 
      aggregate() <= 6  ~ "Insécurité alimentaire modérée", 
      aggregate() <= 9  ~ "Sécurité alimentaire acceptable", 
      TRUE       ~ "Bonne diversité alimentaire" 
    ) |> factor(levels = c("Insécurité alimentaire sévère", 
                           "Insécurité alimentaire modérée", 
                           "Sécurité alimentaire acceptable", "Bonne diversité alimentaire"), ordered = TRUE) 
  ) 

# 9 - Construire un indice composite de vulnérabilité aux chocs, combinant le nombre et la gravité des chocs subis avec l’intensité des stratégies d’adaptation mobilisées.

Jointure <- Jointure |> mutate( 
  ind_choc = rowSums(across(starts_with("choc_")), na.rm = TRUE),
  ind_strat = rowSums(across(starts_with("strat_")), na.rm = TRUE),
  efficience = ind_strat / ind_choc
)

## la variable efficience nous permet d'evaluer le no;bre de stategie utilise par problème.

Jointure |> 
  select(quintiles_revenue_tete, ind_choc, ind_strat,efficience,age,nbrAlim, milieu, 
         niveau_educ, strate, poids_final, region) |> 
  tbl_summary( 
    by         = milieu,                    # Comparer urbain vs rural 
    statistic  = list( 
      all_continuous()  ~ "{mean} ({sd})",  # Moyenne (écart-type) pour numériques 
      all_categorical() ~ "{n} ({p}%)"      # N (%) pour catégorielles 
    ), 
    digits     = all_continuous() ~ 1, 
    missing    = "ifany" 
  ) |> 
  add_p() |>                               # Tests de comparaison 
  add_overall() |>                         # Colonne totale 
  add_n() |> 
  bold_labels() |> 
  modify_header(label = "**Indice**") |> 
  modify_caption("**Tableau 1. Comparaison des indicateurs clés**")

