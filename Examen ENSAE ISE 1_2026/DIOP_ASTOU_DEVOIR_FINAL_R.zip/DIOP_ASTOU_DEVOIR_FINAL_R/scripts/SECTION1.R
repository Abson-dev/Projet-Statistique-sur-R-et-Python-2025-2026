## ============================================================
## SCRIPT 0 : INSTALLATION ET CHARGEMENT DES PACKAGES 
## Utilise une boucle : installe SEULEMENT les packages manquants
## ============================================================

## --- 1. Liste complete de tous les packages necessaires ---
packages <- c(
  # Import / export de donnees (Excel, CSV, SPSS, Stata, SAS...)
  "readxl", "writexl", "openxlsx", "readr", "haven", "foreign", "rio",
  
  # Manipulation de donnees
  "dplyr", "tidyr", "stringr", "lubridate", "forcats", "janitor",
  
  # Statistiques descriptives (univariee et bivariee)
  "summarytools", "psych", "gtsummary", "skimr", "Hmisc", "rstatix",
  
  # Tableaux "beaux" / mise en forme professionnelle
  "gt", "kableExtra", "flextable", "DT",
  
  # Graphiques
  "ggplot2", "ggpubr", "corrplot", "plotly", "scales",
  "patchwork", "viridis",
  
  # Gestion des labels de variables et des chemins de fichiers
  "labelled", "here",
  
  # Modelisation (regression lineaire, logistique, etc.)
  "car", "lmtest", "broom", "MASS", "margins", "pscl", "nnet",
  
  # Rapports et export de resultats
  "stargazer", "rmarkdown", "knitr"
)

## --- 2. Boucle d'installation optimisee ---
for (pkg in packages) {
  if (!require(pkg, character.only = TRUE)) {
    install.packages(pkg, dependencies = TRUE)
    library(pkg, character.only = TRUE)
  }
}

# Creation de la structure du dossier

ROOT <- here::here() 
ROOT
DATA_DIR   <- file.path(ROOT, "data")
RAW_DIR    <- file.path(DATA_DIR, "raw")
PROCESSED_DIR    <- file.path(DATA_DIR, "processed")
OUTPUT_DIR <- file.path(ROOT, "outputs")
FIG_DIR    <- file.path(OUTPUT_DIR, "figures")
TAB_DIR    <- file.path(OUTPUT_DIR, "tables")
SCRIPTS    <- file.path(ROOT, "scripts")
DOC_DIR   <- file.path(ROOT, "rapport")

dir.create(RAW_DIR, showWarnings = FALSE, recursive = TRUE)
dir.create(PROCESSED_DIR, showWarnings = FALSE, recursive = TRUE)
dir.create(FIG_DIR, showWarnings = FALSE, recursive = TRUE)
dir.create(TAB_DIR, showWarnings = FALSE, recursive = TRUE)
dir.create(SCRIPTS, showWarnings = FALSE, recursive = TRUE)
dir.create(DOC_DIR, showWarnings = FALSE, recursive = TRUE)


# Section 1 : import, structuration et nettoyaye

# base menage 
base_menage <- read_dta(file.path(RAW_DIR, "ensan_menages.dta"))
View(base_menage)

# base individus

guess_encoding(file.path(RAW_DIR, "ensan_individus.csv"))
# l'encodage est ASCII apres verification

base_individus <- read.csv(
  file.path(RAW_DIR, "ensan_individus.csv"),
  header = TRUE,
  sep = ";",
  dec = ".",
  fileEncoding = "ASCII"
)
View(base_individus)

# base prix_marches

guess_encoding(file.path(RAW_DIR, "ensan_individus.csv"))
# l'encodage est ASCII apres verification

base_prix <- read.csv(
  file.path(RAW_DIR, "prix_marches.csv"),
  header = TRUE,
  sep = ",",
  dec = ".",
  fileEncoding = "ASCII"
)
View(base_prix)

# base chocs_menages

guess_encoding(file.path(RAW_DIR, "chocs_menages.csv"))
# l'encodage est UTF-8 apres verification

base_chocs <- read.csv(
  file.path(RAW_DIR, "chocs_menages.csv"),
  header = TRUE,
  sep = ",",
  dec = ".",
  fileEncoding = "UTF-8"
)
View(base_chocs)


# base consommation 

guess_encoding(file.path(RAW_DIR, "ensan_consommation.xlsx"))
# l'encodage est ASCII apres verification

base_consommation <- base_excel <- read_excel(file.path(RAW_DIR, "ensan_consommation.xlsx"))
View(base_consommation)



# --- base consommation : LES DEUX feuilles, pas seulement la premiere ---
base_conso_groupes <- read_excel(
  file.path(RAW_DIR, "ensan_consommation.xlsx"),
  sheet = "Consommation_groupes")
View(base_conso_groupes)

base_depenses <- read_excel(
  file.path(RAW_DIR, "ensan_consommation.xlsx"),
  sheet = "Depenses_menage")
View(base_depenses)

# On fusionne les 2 feuilles 


base_consommation <- base_conso_groupes %>%
  left_join(base_depenses, by = "hhid") %>%
  mutate(
    nb_groupes_consommes = rowSums(across(starts_with("cons_"))),
    dep_totale  = dep_alimentaire + dep_sante + dep_education +
      dep_logement   + dep_autres
  )
View(base_consommation)



## ------------------------------------------------------------
## 2. FUSION EN UN JEU DE DONNEES MENAGES ENRICHI
##    avec verification du nb de lignes apres chaque jointure
## ------------------------------------------------------------

# --- caracteristiques du chef de menage (rang == 1)


base_CM <- base_individus %>% 
  filter(rang == 1) %>%
  mutate(across(c("hhid"), ~ sprintf("%05d",.x)))

base_CM <- base_CM %>%
  mutate(across(c("hhid"), as.character))

# --- Jointure 1 : menage + chef de menage ---
base_fusion <- base_menage %>%
  left_join(base_CM, by = "hhid")



# --- Jointure 2 : + consommation agregee ---

base_fusion <- base_fusion %>%
  left_join(base_consommation, by = "hhid")


# --- Jointure 3 : + chocs 
base_chocs <- base_chocs %>%
  mutate(across(c("hhid"), ~ sprintf("%05d",.x)))
base_chocs <- base_chocs %>%
  mutate(across(c("hhid"), as.character))


base_fusion <- base_fusion %>%
  left_join(base_chocs, by = "hhid")

View(base_fusion)


## ------------------------------------------------------------
## 3. HARMONISATION DES LIBELLES DE REGION
## ------------------------------------------------------------

# verifions toutes les noms des regions dans toutes les bases ainsi que dans le shapefile

# ouvrouns le shapefile

library(sf)

shp_regions <- st_read(file.path(RAW_DIR, "tcd_admin1.shp"))
sort(unique(shp_regions$adm1_name))

# regardons pour les autres bases
sort(unique(base_menage$region))
sort(unique(base_prix$region))
sort(unique(base_chocs$region_lib))


#   - base_menage$region / base_prix$region : "Barh El Gazel", "Guéra", "N'Djamena" (Title Case)
#   - base_chocs$region_lib                 : "BARH_EL_GAZEL", "GUERA"/"GUÉRA", "OUADAI"/"OUADDAÏ",
#                                              "TANDJILLE"/"TANDJILÉ", "NDJAMENA" (MAJUSCULES + underscores, parfois sans accent, parfois mal orthographie)
#   - shp_regions$adm1_name              : "BARH EL GAZEL", "GUÉRA", "N'DJAMENA" (MAJUSCULES + espaces)

# Fonction pour tout corriger 


corriger_region <- function(x) {
  x %>%
    str_to_upper() %>%
    str_replace_all("[' ]", "_") |>
    stringi::stri_trans_general("Latin-ASCII") |>          # retire les accents
    str_replace_all("^OUADAI$",   "OUADDAI")   |>           # corrige l'orthographe
    str_replace_all("^TANDJILLE$","TANDJILE")  |>
    str_replace_all("^NDJAMENA$", "N_DJAMENA")
}

# Table de correspondance region -> cle_region, construite depuis base_menage 
table_regions <- base_menage |>
  distinct(region) |>
  mutate(cle_region = corriger_region(region))
View(table_regions)
# Verification : chaque cle_region de base_chocs doit matcher une cle de table_regions
chocs_check <- base_fusion |>
  distinct(region_lib) |>
  mutate(cle_region = corriger_region(region_lib))
View(chocs_check)

# On applique la cle commune sur toutes les bases qui referencent une region
base_fusion <- base_fusion |>
  mutate(cle_region = corriger_region(region))   # "region" = celle de base_menage

base_prix <- base_prix |>
  mutate(cle_region = corriger_region(region))

# Correction sur le shapefile

shp_regions <- shp_regions |>
  mutate(cle_region = corriger_region(adm1_name))



## ------------------------------------------------------------
## 4. DIAGNOSTIC DES VALEURS MANQUANTES 
## ------------------------------------------------------------

## ============================================================
## DIAGNOSTIC DES VALEURS MANQUANTES -- TABLEAUX
## ============================================================


## Nombre et pourcentage de NA par variable
tableau_na <- base_fusion %>%
  summarise(across(everything(), ~ sum(is.na(.x)))) %>%
  pivot_longer(everything(), names_to = "variable", values_to = "nb_manquants") %>%
  mutate(
    pct_manquants = round(100 * nb_manquants / nrow(base_fusion), 2)
  ) %>%
  arrange(desc(nb_manquants))          # trie de la variable la plus incomplete a la plus complete

print(tableau_na)


## --- version avec {gt}) ---

tableau_rapport <- tableau_na %>%
  gt() %>%
  tab_header(
    title = "Valeurs manquantes par variable",
    subtitle = paste0("Base Tchad choc alimentaire (n = ", nrow(base_fusion), " menages)")
  ) %>%
  cols_label(
    variable = "Variable",
    nb_manquants = "Nombre de valeurs manquantes",
    pct_manquants = "% de valeurs manquantes"
  ) %>%
  fmt_number(columns = pct_manquants, decimals = 2) %>%
  cols_align(align = "center", columns = c(nb_manquants, pct_manquants)) %>%
  tab_style(
    style = cell_fill(color = "#f9e0e0"),
    locations = cells_body(rows = pct_manquants > 20)   
  ) %>%
  tab_source_note("Source : base fictive du devoir, calculs de l'auteure")

## --- Sauvegarde du tableau
gtsave(tableau_rapport, file.path(TAB_DIR, "tableau_valeurs_manquantes.html")) 
gtsave(tableau_rapport, file.path(TAB_DIR, "tableau_valeurs_manquantes.docx")) 

## ============================================================
## DIAGNOSTIC DES VALEURS MANQUANTES -- GRAPHIQUES
## ============================================================

## --- Graphique 1 : barres du % de NA par variable (uniquement celles concernees) ---


graphique_na_barres <- ggplot(tableau_na, aes(x = fct_reorder(variable, pct_manquants), y = pct_manquants, fill = variable)) +
  geom_col() +
  geom_text(aes(label = pct_manquants, hjust = -0.1))+   # affiche le texte 
  coord_flip() +
  labs(
    title = "Pourcentage de valeurs manquantes par variable",
    x = NULL,
    y = "% de valeurs manquantes"
  ) +
  theme_minimal() +
  theme(legend.position = "none")   # retire la legende (inutile, deja lisible via l'axe)

ggsave(
  filename = file.path(FIG_DIR, "graphique_valeurs_manquantes_barres.png"),
  plot = graphique_na_barres,
  width = 12, height = 5, dpi = 300
)


## --- Graphique 2 : carte des valeurs manquantes (heatmap), TOUTES variables, TOUTES lignes ---
## Utile pour voir si les NA sont repartis au hasard ou concentres sur certaines lignes/menages

base_na_long <- base_fusion %>%
  mutate(id_ligne = row_number()) %>%              # identifiant de ligne pour le graphique
  mutate(across(-id_ligne, as.character)) %>%       # uniformise tous les types (facteur+numerique) en texte
  pivot_longer(-id_ligne, names_to = "variable", values_to = "valeur") %>%
  mutate(est_manquant = is.na(valeur))
View(base_na_long)
graphique_na_heatmap <- ggplot(base_na_long, aes(x = variable, y = id_ligne, fill = est_manquant)) +
  geom_tile() +
  scale_fill_manual(values = c("FALSE" = "grey85", "TRUE" = "#c0392b"), labels = c("Present", "Manquant")) +
  labs(
    title = "Carte des valeurs manquantes (par menage et par variable)",
    x = NULL, y = "Menage (ligne)", fill = NULL
  ) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1, size = 7))

graphique_na_heatmap

ggsave(
  filename = file.path(FIG_DIR, "graphique_valeurs_manquantes_heatmap.png"),
  plot = graphique_na_heatmap,
  width = 10, height = 7, dpi = 300
)



## ------------------------------------------------------------
## 5. MECANISME DE NON-REPONSE ET IMPUTATION MULTIPLE (mice)
## ------------------------------------------------------------

# --- Variable 1 : revenu (369 NA sur 3540, ~10.4%) ---
base_fusion |>
  mutate(revenu_manquant = is.na(revenu)) |>
  group_by(milieu, revenu_manquant) |>
  summarise(n = n(), .groups = "drop") |>
  group_by(milieu) |>
  mutate(pct = n / sum(n) * 100)


# Le revenu manque plus probablement pour certains
# profils de menage observables (par exemple selon le milieu, la taille du menage, la region, niveau d'education du CM)
#c'est un motif classique de non-reponse selective dans les enquetes de revenu (menages ruraux / CM peu instruits declarent moins
# facilement un revenu monetaire precis).

# --- Variable 2 : taille_menage (150 NA sur 3540, ~4.2%) ---

base_fusion |>
  mutate(taille_manquant = is.na(taille_menage)) |>
  group_by(milieu, taille_manquant) |>
  summarise(n = n(), .groups = "drop") |>
  group_by(milieu) |>
  mutate(pct = n / sum(n) * 100)
#  ici par contre, on voit qu le taux de reponse pour la taille du menage est quasi identique dans les deux milieux.
# Donc on suppose qu'il s'agit d'un  simple oubli de saisie de l'enqueteur, sans lien avec la taille reelle du menage ni
# avec les autres variables observees. 

# --- Variable 3 : age (74 NA sur 3540, ~2.8%) ---
base_fusion |>
  mutate(age_manquant = is.na(age)) |>
  group_by(milieu, age_manquant) |>
  summarise(n = n(), .groups = "drop") |>
  group_by(milieu) |>
  mutate(pct = n / sum(n) * 100)
#  ici egalement, on a la meme remarque que sur la variable taille_menage.



# --- Imputation multiple par equations chainees ---
vars_imputation <- base_fusion[c("revenu", "taille_menage", "age")] 
vars_imputation

# methode par variable : pmm pour les continues
meth <- make.method(vars_imputation)
meth["revenu"]        <- "pmm"
meth["taille_menage"] <- "pmm"
meth["age"]        <- "pmm"


imp <- mice(vars_imputation, m = 20, method = meth, seed = 2026, printFlag = FALSE)


base_fusion <- base_fusion |>
  mutate(
    revenu        = base_imputee$revenu,
    taille_menage = base_imputee$taille_menage
  )


## ------------------------------------------------------------
## 6. RECODAGE DES VARIABLES CATEGORIELLES
## ------------------------------------------------------------

base_fusion <- base_fusion |>
  mutate(
    milieu = as_factor(milieu),
    niveau_educ = factor(
      niveau_educ,levels = c("Aucun", "Primaire", "Secondaire", "Superieur"),
      ordered = TRUE
    ),
    revenu_par_tete = revenu / taille_menage,
    
    # quintiles de revenu par tete (ponderes par poids_final -> quantile pondere)
    quintile_revenu = Hmisc::wtd.quantile(
      revenu_par_tete, weights = poids_final,
      probs = seq(0, 1, 0.2)
    ) |>
      cut(x = revenu_par_tete, breaks = _, labels = paste0("Q", 1:5),
          include.lowest = TRUE)
  )
View(base_fusion)
# Verification finale : jeu de donnees pret pour la Section 2
cat(sprintf("\nJeu de donnees menages enrichi final : %d lignes x %d colonnes\n",
            nrow(base_fusion), ncol(base_fusion)))

write_xlsx(base_fusion, file.path(PROCESSED_DIR, "base_menages_enrichie.xls"))

