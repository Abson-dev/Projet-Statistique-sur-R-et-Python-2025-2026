## ============================================================
## SECTION 2 & 3 : VISUALISATION
## ============================================================
library(srvyr)

base_fusion <- read_xlsx(file.path(PROCESSED_DIR, "base_menages_enrichie.xls"))

## ------------------------------------------------------------
## 7. PLAN DE SONDAGE (srvyr)
## ------------------------------------------------------------

plan_ensan <- base_fusion |>
  as_survey_design(
    ids     = grappe,       
    strata  = strate,       
    weights = poids_final,
    nest    = TRUE
  )

View(plan_ensan)
## ------------------------------------------------------------
## 8. SCORE DE DIVERSITE ALIMENTAIRE (HDDS) + CLASSIFICATION FAO
## ------------------------------------------------------------

base_fusion <- base_fusion |>
  mutate(
    hdds = rowSums(across(starts_with("cons_"))),   # 0 a 12 groupes FAO
    #   faible = 0-3 groupes ; moyenne = 4-5 groupes ; elevee = 6-12 groupes
    hdds_classe = case_when(
      hdds <= 3 ~ "Diversite faible",
      hdds <= 5 ~ "Diversite moyenne",
      TRUE      ~ "Diversite elevee"
    ) |> factor(levels = c("Diversite faible", "Diversite moyenne", "Diversite elevee"))
  )



# recharger le plan de sondage avec hdds ajoute
plan_ensan <- base_fusion |>
  as_survey_design(ids = grappe, strata = strate, weights = poids_final, nest = TRUE)

# HDDS moyen pondere, national et par region
plan_ensan |>
  group_by(region) |>
  summarise(hdds_moyen = survey_mean(hdds, vartype = "ci"))


## ------------------------------------------------------------
## 9. INDICE COMPOSITE DE VULNERABILITE AUX CHOCS
## ------------------------------------------------------------

# Justification des choix :
#  - nb_chocs (0-4) : nombre de chocs distincts subis (secheresse, hausse prix, conflit, maladie)
#  - la donnee ne renseigne que l'occurrence (0/1) du choc, pas sa gravite continue ; en l'absence
#    d'une mesure directe de severite, on utilise le NOMBRE de chocs cumules comme proxy de gravite
#    (hypothese : plus un menage cumule de chocs distincts, plus son exposition est severe)
#  - nb_strategies (0-4) : nombre de strategies d'adaptation mobilisees, comme proxy d'intensite
#    de la reponse (un menage qui mobilise plusieurs strategies signale une pression plus forte)
#  - ponderation : 60% chocs / 40% strategies -> on considere l'exposition (chocs) comme le
#    determinant premier de la vulnerabilite, les strategies etant une consequence adaptative
#    (poids arbitraire)

base_fusion <- base_fusion |>
  mutate(
    nb_chocs       = choc_secheresse + choc_hausse_prix + choc_conflit + choc_maladie,
    nb_strategies  = strat_vente_actifs + strat_reduction_repas + strat_migration + strat_endettement,
    indice_vulnerabilite = 100 * (0.6 * nb_chocs / 4 + 0.4 * nb_strategies / 4)   # 0-100
  )

plan_ensan <- base_fusion |>
  as_survey_design(ids = grappe, strata = strate, weights = poids_final, nest = TRUE)


## ------------------------------------------------------------
## 10. TABLEAU 1 PONDERE (gtsummary)
## ------------------------------------------------------------

tableau1 <- plan_ensan |>
  select(milieu, region, revenu_par_tete, taille_menage, hdds, hdds_classe,
         indice_vulnerabilite, nb_chocs) |>
  tbl_svysummary(
    by = milieu,
    statistic = list(
      all_continuous()  ~ "{mean} ({sd})",
      all_categorical() ~ "{n} ({p}%)"
    ),
    digits = all_continuous() ~ 1,
    label = list(
      revenu_par_tete       ~ "Revenu par tete (FCFA)",
      taille_menage          ~ "Taille du menage",
      hdds                    ~ "Score HDDS",
      hdds_classe            ~ "Classification FAO",
      indice_vulnerabilite ~ "Indice de vulnerabilite",
      nb_chocs                ~ "Nombre de chocs subis"
    )
  ) |>
  add_p() |>
  add_n() |>
  add_overall() |>
  modify_caption("**Tableau 1. Indicateurs cles par milieu de residence (ponderes)**")

tableau1
gtsummary::as_gt(tableau1) |> gt::gtsave(file.path(TAB_DIR, "tableau1_milieu.html"))

# meme tableau par region 
tableau1_region <- plan_ensan |>
  select(region, revenu_par_tete, hdds, indice_vulnerabilite) |>
  tbl_svysummary(by = region, statistic = all_continuous() ~ "{mean} ({sd})") |>
  add_n()

gtsummary::as_gt(tableau1_region) |> gt::gtsave(file.path(TAB_DIR, "tableau1_region.html"))


## ------------------------------------------------------------
## 11. COEFFICIENT DE GINI (revenu par tete) + IC BOOTSTRAP
## ------------------------------------------------------------

#### ne sait pas faire#########################
#################################################



## ============================================================
## SECTION 3 : VISUALISATION
## ============================================================

## ------------------------------------------------------------
## ANALYSE DESCRIPTIVE UNIVARIEE
## ------------------------------------------------------------


# diversite alimentaire

fig_hdds <- ggplot(base_fusion, aes(x = hdds_classe, fill = hdds_classe)) +
  geom_bar(aes(y = after_stat(count) / sum(after_stat(count)))) +
  scale_y_continuous(labels = percent) +
  scale_fill_viridis_d(option = "magma", direction = -1) +
  labs(title = "Classification FAO de la diversite alimentaire",
       x = NULL, y = "Part des menages") +
  theme(legend.position = "none")
ggsave(file.path(FIG_DIR, " lassification FAO de la deversite alimentaire.png"), fig_hdds,
       width = 12, height = 10, dpi = 300)

fig_chocs <- base_fusion |>
  summarise(across(c(choc_secheresse, choc_hausse_prix, choc_conflit, choc_maladie),
                   ~ weighted.mean(.x, poids_final))) |>
  pivot_longer(everything(), names_to = "choc", values_to = "prevalence") |>
  mutate(choc = str_remove(choc, "choc_") |> str_to_title()) |>
  ggplot(aes(x = fct_reorder(choc, prevalence), y = prevalence, fill = choc)) +
  geom_col() +
  coord_flip() +
  scale_y_continuous(labels = percent) +
  scale_fill_viridis_d(option = "magma", direction = -1) +
  labs(title = "Prevalence ponderee des chocs subis", x = NULL, y = "% des menages") +
  theme(legend.position = "none")
ggsave(file.path(FIG_DIR, "Determinants des chocs.png"), fig_chocs,
       width = 12, height = 10, dpi = 300)


## ============================================================
## ANALYSE DESCRIPTIVE BIVARIEE
## ============================================================

## ------------------------------------------------------------
## DEUX VARIABLES CATEGORIELLES 
## ------------------------------------------------------------
names(base_fusion)
var_cat1 <- "milieu"
var_cat2 <- "hdds_classe"

## Barres empilees, en PROPORTION (100% -> tres utile pour comparer des groupes de tailles differentes)
g_bivar_barres_pct <- ggplot(base_fusion, aes(x = .data[[var_cat1]], fill = .data[[var_cat2]])) +
  geom_bar(position = "fill") +
  scale_y_continuous(labels = percent) +
  labs(title = paste(var_cat1, "x", var_cat2, "- %"), x = NULL, y = "Pourcentage", fill = var_cat2) +
  theme_minimal()
ggsave(file.path(FIG_DIR, "bivarie_milieu_deversite_alimentaire_barres_pourcentage.png"), g_bivar_barres_pct, width = 7, height = 5, dpi = 300)


## ------------------------------------------------------------
## DEUX VARIABLES NUMERIQUES 
## ------------------------------------------------------------

var_num1 <- "revenu"
var_num2 <- "dep_alimentaire"

correlation <- cor(base_fusion[[var_num1]], base_fusion[[var_num2]])

g_scatter <- ggplot(base_fusion, aes(x = .data[[var_num1]], y = .data[[var_num2]])) +
  geom_point(alpha = 0.4, color = "#2980b9") +
  geom_smooth(method = "lm", color = "#c0392b", se = TRUE) +   # droite de regression + intervalle de confiance
  labs(
    title = paste(var_num1, "x", var_num2),
    subtitle = paste0("Correlation de Pearson : r = ", round(correlation, 3)),
    x = var_num1, y = var_num2
  ) +
  theme_minimal()
ggsave(file.path(FIG_DIR, "bivarie_revenu_depenses_scatter.png"), g_scatter, width = 8, height = 6, dpi = 300)

## ------------------------------------------------------------
## UNE VARIABLE NUMERIQUE + UNE CATEGORIELLE 
## ------------------------------------------------------------

var_num <- "revenu"
var_cat <- "region"

## a) Boxplot par groupe
g_box_groupe <- ggplot(base_fusion, aes(x = .data[[var_cat]], y = .data[[var_num]], fill = .data[[var_cat]])) +
  geom_boxplot() +
  labs(title = paste(var_num, "selon", var_cat), x = NULL, y = var_num) +
  coord_flip() +                                   # barres horizontales, plus lisible pour les noms de variables
  theme_minimal() +
  theme(legend.position = "none")
ggsave(file.path(FIG_DIR, "bivarie_revenu_region_boxplot.png"), g_box_groupe, width = 6, height = 5, dpi = 300)

var_num <- "dep_alimentaire"
var_cat <- "milieu"


## Violin plot (montre la FORME complete de la distribution, pas juste les quartiles)
g_violin <- ggplot(base_fusion, aes(x = .data[[var_cat]], y = .data[[var_num]], fill = .data[[var_cat]])) +
  geom_violin() +
  geom_boxplot(width = 0.1, fill = "white") +   # petit boxplot superpose, pour reperer la mediane
  labs(title = paste(var_num, "selon", var_cat, "(violin plot)"), x = NULL, y = var_num) +
  theme_minimal() +
  theme(legend.position = "none")
ggsave(file.path(FIG_DIR, "bivarie_depenses_milieu_violin.png"), g_violin, width = 6, height = 5, dpi = 300)


## ------------------------------------------------------------
## DENSITE DU REVENU PAR TETE PAR REGION
## ------------------------------------------------------------

fig_densite <- ggplot(base_fusion, aes(x = revenu_par_tete, fill = region)) +
  geom_density(alpha = 0.35, color = NA) +
  scale_x_log10(labels = label_comma()) +   # echelle log : variable tres asymetrique
  labs(
    title = "Distribution du revenu par tete par region",
    x = "Revenu par tete (FCFA, echelle log)", y = "Densite", fill = NULL
  ) +
  theme(legend.position = "none")   # 23 regions -> legende illisible, utiliser facet a la place

fig_densite_facet <- ggplot(base_fusion, aes(x = revenu_par_tete)) +
  geom_density(fill = "#2c7fb8", alpha = 0.5, color = NA) +
  scale_x_log10(labels = label_comma()) +
  facet_wrap(~ region, scales = "free_y") +
  labs(title = "Distribution du revenu par tete par region",
       x = "Revenu par tete (FCFA, echelle log)", y = "Densite")

ggsave(file.path(FIG_DIR, "densite_revenu_region.png"), fig_densite_facet,
       width = 12, height = 9, dpi = 300)
ggsave(file.path(FIG_DIR, "densite_revenu_region.pdf"), fig_densite_facet,
       width = 12, height = 9)



## ------------------------------------------------------------
## ANALYSE SPATIALE
## ------------------------------------------------------------

## CARTE CHOROPLETHE DE L'INDICE DE VULNERABILITE

vulnerabilite_region <- base_fusion |>
  group_by(cle_region) |>
  summarise(
    indice_vulnerabilite_moy = weighted.mean(indice_vulnerabilite, poids_final, na.rm = TRUE),
    .groups = "drop"
  )

shp_vulnerabilite <- shp_regions |>
  left_join(vulnerabilite_region, by = "cle_region")

# --- carte ---
fig_carte <- ggplot(shp_vulnerabilite) +
  geom_sf(aes(fill = indice_vulnerabilite_moy), color = "white", size = 0.2) +
  scale_fill_viridis_c(option = "magma", direction = -1, name = "Indice\nvulnerabilite") +
  labs(title = "Indice de vulnerabilite aux chocs par region") +
  theme_ensan() +
  theme(axis.text = element_blank(), panel.grid = element_blank())

ggsave(file.path(FIG_DIR, "carte_vulnerabilite.png"), fig_carte, width = 8, height = 8, dpi = 300)
ggsave(file.path(FIG_DIR, "carte_vulnerabilite.pdf"), fig_carte, width = 8, height = 8)


