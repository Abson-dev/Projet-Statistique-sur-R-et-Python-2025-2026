# importation des packages nécessaires

library(stringr)
library(haven)
library(tidyverse)
library(readxl)
library(ggplot2)
library(naniar)
library(openxlsx)
library(srvyr) 
library(survey)
#Section1 : Import, structuration et nettoyage

#1 Importation des cinq sources avec les packages appropriés

## Base menage 

menages <- read_dta("data/raw/ensan_menages.dta")

## Base individu

individus <- read.csv("data/raw/ensan_individus.csv",
                      header = TRUE,
                      sep = ",",
                      dec = "."
                      )

## Base chocs_menages

chocs_menages <- read.csv("data/raw/chocs_menages.csv",
                          header = TRUE,
                          sep = ",",
                          dec = "."
                          )
## Base prix_marches

prix_marches <- read.csv("data/raw/prix_marches.csv",
                         header = TRUE,
                         sep = ",",
                         dec = "."
                         )
## Base consommation

consommation <- read_excel("data/raw/ensan_consommation.xlsx")

#2 Fusionnons les modules en un jeu de données ménages enrichi

## Preparations pour jointures

### Modification des hhid des bases chocs_menages et individus

###  base chocs_menages 

chocs_menages <- chocs_menages |>
  mutate(hhid = str_pad(hhid, 5, pad = "0") )

###  base individus

individus <- individus |>
  mutate(hhid = str_pad(hhid, 5, pad = "0") )

###  base consommation

consommation <- consommation |>
  mutate(conso_agrege = cons_cereales + cons_tubercules + cons_legumineuses + cons_fruits + cons_viande + cons_poisson + cons_legumes +cons_oeufs + cons_lait + cons_huile +cons_sucre + cons_condiments )

consommation_agregee <- consommation |>
  select(hhid, conso_agrege)

### creaction de la base chefs de menage

chefs_menage <- individus |>
  filter(rang == 1) |> 
  select(hhid, sexe_cm = sexe, age_cm = age, educ_cm = niveau_educ)


### Enrichissement de la base

menages_enrichis <- menages |>
  left_join(chefs_menage, by = "hhid") |> 
  left_join(consommation_agregee, by = "hhid") |>
  left_join(chocs_menages, by = "hhid") 

#3 Identifions et corrigons les libellés de régions incohérents entre fichiers avant toute jointure spatiale

table(menages_enrichis$region)

#4 Produisons un diagnostic complet des valeurs manquantes avec naniar

## avec vis_miss

graph1_valeurs_manquantes <- vis_miss(menages_enrichis) +
  labs(
    title = "Carte des valeurs manquantes de la base enrichie",
    subtitle = "Les lignes représentent les les observations et les colonnes, les variables") +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 7),
    axis.text.y = element_text(size = 8),
    axis.ticks.y = element_blank(),
    plot.margin = margin(t = 50, r = 20, b = 20, l = 20, unit = "pt")
  ) +
  scale_y_continuous(
    breaks = c(1, 1000, 2000, 3000, 4000, 5000, 6000, 7000,8000, 9000, 10000, 11000),
    labels = c("1","1000","2000","3000","4000","5000","6000","7000","8000","9000","10000","11000")
  )

## Sauvegarde en PNG

ggsave(
  filename = "output/figures/valeurs_manquantes1.png",
  plot     = graph1_valeurs_manquantes,
  width    = 12,      # largeur en pouces
  height   = 6,       # hauteur en pouces
  dpi      = 300      # résolution (300 = qualité impression)
)



## gg_miss_var


graph2_valeurs_manquantes <- gg_miss_var(menages_enrichis) +
  labs(
    title    = "Valeurs manquantes — menages_enrichis",
    subtitle = "Les colonnes représentent les valeurs manquantes, chaque ligne une variable"
  )

##### sauvergarde en png

ggsave(
  filename = "output/figures/Valeurs_manquantes2.png",
  plot     = graph2_valeurs_manquantes,
  width    = 12,      # largeur en pouces — augmenter si libellés encore coupés
  height   = 6,       # hauteur en pouces
  dpi      = 300      # résolution (300 = qualité impression)
)

## tableau des valeurs manquantes avec miss_var_summury

valeurs_manquantes <- as.data.frame(miss_var_summary(menages_enrichis)) %>% 
  mutate(across(everything(), ~ as.vector(.x)))
write.xlsx(valeurs_manquantes,"output/tables/valeurs_manquantes.xlsx")

#6 Recodons les variables catégorielles nécessaires à l’analyse (milieu, niveau d’éducation du chef de ménage, quintiles de revenu par tête).

menages_enrichis <- menages_enrichis |>
  mutate(
    # Recodage avec case_when 
    milieu_label = case_when(
      milieu == 1 ~ "Urbain",
      milieu == 2 ~ "Rural",
      TRUE ~ NA_character_
    )
  )

# Section 2. Statistiques descriptives pondérées et indices composites

#7. Déclarons le plan de sondage complet (grappes, strates, poids finaux) avec srvyr

plan_sondage <- svydesign(ids= ~ grappe, strata = ~ strate, weights= ~ poids_final, data = menages_enrichis)

svy_sondage  <- as_survey_design(plan_sondage)

#8. Construire le score de diversité alimentaire des ménages (HDDS) et la classification FAO associée

menages_enrichis <- menages_enrichis |> 
  mutate(     # Score HDDS:somme des 12 groupes alimentaires     
    hdds = conso_agrege ,          
    # Classification FAO     
    securite_alim = case_when(       hdds <= 3  ~ "Insécurité alimentaire sévère",       
                                     hdds <= 6  ~ "Insécurité alimentaire modérée",       
                                     hdds <= 9  ~ "Sécurité alimentaire acceptable",       
                                     TRUE       ~ "Bonne diversité alimentaire"     
                                     ) |> factor(levels = c("Insécurité alimentaire sévère",                             
                                                            "Insécurité alimentaire modérée",
                                                            "Sécurité alimentaire acceptable",                             
                                                            "Bonne diversité alimentaire"), ordered = TRUE)   ) 
