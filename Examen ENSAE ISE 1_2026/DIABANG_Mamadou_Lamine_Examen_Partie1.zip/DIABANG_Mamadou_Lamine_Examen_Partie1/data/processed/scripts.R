library(readr)
library(utils)
library(haven)
library(readxl)
library(ggplot2)
library(sf)
library(tidyverse)
library(janitor)
library(gtsummary)
library(naniar)

# 1- Importations des  sources

chocs_menages <- read_csv("data/raw/chocs_menages.csv",show_col_types = FALSE)
ensan_individus <- read_csv("data/raw/ensan_individus.csv",show_col_types = FALSE)
prix_marches <- read_csv("data/raw/prix_marches.csv",show_col_types = FALSE)
dictionnaire_variables_Tchad <- read_excel("data/raw/dictionnaire_variables_ENSAN2026_Tchad.xlsx")
ensan_consommation <- read_excel("data/raw/ensan_consommation.xlsx")
ensan_menages <- read_dta("data/raw/ensan_menages.dta")
tchad_shp <- st_read("data/raw/tcd_admin1.shp")

#2- Fusionner les modules en un jeu de données ménages enrichi
# Vérifions d'abord l'unicité de hhid dans les ménages
n_distinct(ensan_menages$hhid) == nrow(ensan_menages)
# Jointure base individu + ménage sur hhid
menage_enrichi1 <- ensan_menages |>
  left_join(ensan_consommation, by = "hhid")

menage_enrichi <- menage_enrichi1 |>
  left_join(chocs_menages, by = "hhid")

# vérifions que le nombre de ligne reste inchangé

cat('Lignes base_indiv avant jointure :', nrow(ensan_menages), '\n')
cat('Lignes après left_join           :', nrow(menage_enrichi), '\n')

# 3- Identification et correction des libellés
# Nettoyage des noms de variables avec janitor

menage_enrichi <- menage_enrichi |>
  clean_names()

tchad_shp <- tchad_shp |>
  clean_names()

# Conversion des variables labellisées Stata en facteurs R
menage_enrichi <- menage_enrichi |>
  mutate(across(where(is.labelled), as_factor))

# 4- Produire un diagnostic complet des valeurs manquantes
vis_miss(menage_enrichi)              # Visualisation cartographique des NA 
ggsave("ouput/figures/pourcentage_NA.png")
miss_var_summary(menage_enrichi)      # % de NA par variable
gg_miss_var(menage_enrichi)          # Graphique des valeurs manquantes
ggsave("ouput/figures/hist_NA.png")
ggsave("output/figures/hist_NA.pdf")
# 5- Justifier, pour deux variables clés de votre choix
library(mice)
# Imputation multiple (M = 5 jeux de données imputés) 
imp <- mice( 
  menage_enrichi |> select(revenu,taille_menage), 
  m     = 5,          # Nombre de jeux imputés 
  maxit = 20,         # Itérations de convergence 
  method = "pmm",     # Predictive Mean Matching (recommandé pour variables continues) 
seed  = 42 )

# Vérifier la convergence 
plot(imp)
# Analyser sur les 5 jeux imputés et combiner (règles de Rubin) 
fit_imputed <- with(imp, lm(log(revenu) ~ taille_menage)) 
pool(fit_imputed) |> summary()

# 6- Recoder les variables catégorielles nécessaires à l’analyse

analyse_revenu <- menage_enrichi |> 
  filter(milieu != "Autre", revenu > 0, !is.na(revenu)) |> 
  select(hhid, region, milieu, revenu, taille_menage, poids_final) |> 
  mutate( 
    revenu_pc    = revenu / taille_menage,           # Revenu par tête 
    log_revenu   = log(revenu_pc),                   # Transformation log 
    quintile     = ntile(revenu_pc, 5),              # Quintiles de revenu 
    pauvre       = if_else(revenu_pc < 1.90 * 365, 1L, 0L)  # Seuil BM en USD 
  )

 menage_enrichi2 <- analyse_revenu|> 
  mutate( 
    milieu_label = case_when( 
      milieu == 1 ~ "Urbain", 
      milieu == 2 ~ "Rural", 
      TRUE        ~ NA_character_ 
    ), 
    
    # Création d'une variable catégorielle ordonnée 
    niveau_vie = case_when( 
      revenu_pc < 500  ~ "Très pauvre", 
      revenu_pc < 1000 ~ "Pauvre", 
      revenu_pc < 2000 ~ "Intermédiaire", 
      TRUE             ~ "Non pauvre" 
    ) |> factor(levels = c("Très pauvre", "Pauvre", "Intermédiaire", "Non pauvre"), 
                ordered = TRUE), 
    
    # Manipulation de chaînes avec stringr 
    region_clean = region |> 
      str_to_title() |>          # Première lettre en majuscule 
      str_replace_all("_", " ") |> 
      str_trim(), 
  ) 
 
 # jointure ménage indivdu pour les prochaines études
 menage_enrichi3 <- menage_enrichi2 |>
   left_join(ensan_individus, by = "hhid")
 
 menage_enrichi_final <- menage_enrichi3 |>
   left_join(menage_enrichi, by = "hhid")
 
 menage_enrichi_final <- menage_enrichi_final |> 
   rename(poids_final = poids_final.x) |> 
   select(-matches("\\.y$"))
 
 menage_enrichi_final <- menage_enrichi_final |> 
   rename( taille_menage =  taille_menage.x) |> 
   select(-matches("\\.y$"))
 
 menage_enrichi_final <- menage_enrichi_final |> 
   rename( milieu =  milieu.x) |> 
   select(-matches("\\.y$"))
 
 menage_enrichi_final <- menage_enrichi_final |> 
   rename( region =  region.x) |> 
   select(-matches("\\.y$"))
 
 # 7- Déclarer le plan de sondage complet
 library(srvyr) 
 
 # Déclaration du plan de sondage complet
 plan_sondage <- menage_enrichi_final |> 
   as_survey_design( 
     ids     = grappe,       # Grappes / Unités Primaires de Sondage (PSU)
     strata  = strate,       # Strates
     weights = poids_final,  # Poids de sondage ajustés
     nest    = TRUE          # Garantit que les grappes sont emboîtées dans les strates
   )
 
 # 2. Statistiques pondérées avec intervalles de confiance à 95% 
 plan_sondage |> 
   group_by(region.x, milieu.x) |> 
   summarise( 
     revenu_moyen    = survey_mean(revenu_pc, vartype = "ci"), 
     tx_pauvrete     = survey_mean(pauvre, vartype = "ci"), 
     effectif_estime = survey_total(vartype = "ci") 
   ) 
 
 # 3. Ratio pondéré 
 plan_sondage |> 
   summarise( 
     gini = survey_ratio( 
       numerator   = revenu_pc * (rank(revenu_pc) / n()), 
       denominator = revenu_pc))
# 8 - Score de diversité alimentaire des ménages (HDDS)
 menage_enrichi_final <- menage_enrichi_final |> 
   mutate( 
     hdds = rowSums(across(starts_with("cons_")), na.rm = TRUE), 
     
     # Classification FAO 
     securite_alim = case_when( 
       hdds <= 3  ~ "Insécurité alimentaire sévère", 
       hdds <= 6  ~ "Insécurité alimentaire modérée", 
       hdds <= 9  ~ "Sécurité alimentaire acceptable", 
       TRUE       ~ "Bonne diversité alimentaire" 
     ) |> factor(levels = c("Insécurité alimentaire sévère", 
                            "Insécurité alimentaire modérée", 
                            "Sécurité alimentaire acceptable", 
                            "Bonne diversité alimentaire"), ordered = TRUE) 
   )
 
 # 9 -  Construire un indice composite de vulnérabilité aux chocs
 menage_enrichi_final <- menage_enrichi_final |> 
   mutate(
     # 1. Score des chocs subis (Pondération par gravité)
     score_chocs = (choc_secheresse * 2) + 
       (choc_hausse_prix * 1) + 
       (choc_conflit * 3) + 
       (choc_maladie * 1))
    
# 10 - Tableau descriptif complet
 menage_enrichi_final |> 
   select(revenu_pc, taille_menage, sexe, age, milieu, 
          niveau_educ) |> 
   tbl_summary( 
     by         = milieu,                    # Comparer urbain vs rural 
     statistic  = list( 
       all_continuous()  ~ "{mean} ({sd})",  # Moyenne (écart-type) pour numériques 
       all_categorical() ~ "{n} ({p}%)"      # N (%) pour catégorielles 
     ), 
     digits     = all_continuous() ~ 1, 
     label      = list( 
       revenu_pc      ~ "Revenu par tête (FCFA/mois)", 
       taille_menage  ~ "Taille du ménage", 
       sexe        ~ "Sexe du chef de ménage", 
       age         ~ "Âge du chef de ménage" 
     ), 
     missing    = "ifany" 
   ) |> 
   add_p() |>                               # Tests de comparaison 
   add_overall() |>                         # Colonne totale 
   add_n() |> 
   bold_labels() |> 
   modify_header(label = "**Caractéristique**") |> 
   modify_caption("**Tableau 1. Caractéristiques des ménages par milieu de 
résidence**") 
 
 # 11 - .Calculer le coefficient de Gini du revenu par tête au niveau national et par région
 
 library(ineq) 
 
 # Coefficient de Gini 
 gini_national <- ineq(menage_enrichi_final$revenu_pc, type = "Gini", na.rm = TRUE) 
 
 # Gini par région 
 menage_enrichi_final |> 
   group_by(region) |> 
   summarise(gini = ineq(revenu_pc, type = "Gini", na.rm = TRUE)) |> 
   arrange(desc(gini)) 
 
 # Courbe de Lorenz 
 library(gglorenz) 
 ggplot(menage_enrichi_final, aes(revenu_pc)) + 
   stat_lorenz(color = "#2E75B6", size = 1.2) + 
   geom_abline(linetype = "dashed", color = "gray50") + 
   annotate("text", x = 0.25, y = 0.75, 
            label = paste0("Gini = ", round(gini_national, 3)), 
            size = 4, color = "#1F4E79") + 
   labs(title = "Courbe de Lorenz — Revenu par tête", 
        x = "Part cumulée de la population", 
        y = "Part cumulée du revenu") + 
   theme_minimal(base_size = 12) 
 
 ggsave("ouput/figures/Gini.png")
 ggsave("ouput/figures/Gini.pdf")
 
 # 12 - Représenter la distribution du revenu par tête par région
 library(ggplot2) 
 library(ggridges) 
 # Histogramme avec densité 
 ggplot(menage_enrichi_final, aes(x = revenu_pc)) + 
   geom_histogram(aes(y = after_stat(density)), 
                  fill = "#2E75B6", alpha = 0.7, bins = 40) + 
   geom_density(color = "#1F4E79", linewidth = 1) + 
   scale_x_log10(labels = scales::comma) + 
   labs(title = "Distribution du revenu par tête", 
        subtitle = "Échelle logarithmique — EHCVM 2021", 
        x = "Revenu par tête (FCFA/mois, log10)", 
        y = "Densité") + 
   theme_minimal(base_size = 12) + 
   theme(plot.title = element_text(face = "bold")) 
 
 ggsave("ouput/figures/histogramme_densité.png")
 ggsave("ouput/figures/histogramme_densité.pdf")
 # Graphique de densités par région (ridgeline plot) 
 ggplot(menage_enrichi_final, aes(x = revenu_pc, y = fct_reorder(region, revenu_pc, median), 
                     fill = after_stat(x))) + 
   geom_density_ridges_gradient(scale = 2, rel_min_height = 0.01) + 
   scale_x_log10() + 
   scale_fill_viridis_c(option = "plasma", name = "Revenu") + 
   labs(title = "Distribution du revenu par tête selon la région", 
        x = "Revenu par tête (log)", y = NULL) + 
   theme_ridges()
 ggsave("ouput/figures/densité_region.png")
 ggsave("ouput/figures/densité_region.pdf")
 # 13 - Produire une carte choroplèthe de l’indice de vulnérabilité par région avec sf et ggplot2
 library(sf) 
 library(tmap) 
 
 # 14 - Composer une figure unique regroupant au moins trois graphiques avec patchwork
 library(patchwork) 
 
 # Thème personnalisé réutilisable 
 theme_ensae <- function(base_size = 12) { 
   theme_minimal(base_size = base_size) %+replace% 
     theme( 
       text              = element_text(family = "Arial"), 
       plot.title        = element_text(size = rel(1.3), face = "bold", 
                                        color = "#1F4E79", hjust = 0), 
       plot.subtitle     = element_text(size = rel(1.0), color = "#555555", 
                                        hjust = 0, margin = margin(b = 10)), 
       plot.caption      = element_text(size = rel(0.8), color = "#888888", hjust = 1), 
       axis.title        = element_text(size = rel(0.95), color = "#444444"), 
       panel.grid.major  = element_line(color = "#EEEEEE", linewidth = 0.5), 
       panel.grid.minor  = element_blank(), 
       legend.position   = "bottom", 
       legend.title      = element_text(face = "bold") 
     ) 
 } 
 
 p1 <- ggplot(menage_enrichi_final, aes(x = milieu, y = revenu_pc)) + 
   geom_violin(fill = "#2E75B6", alpha = 0.7) + theme_ensae() + 
   labs(title = "A. Distribution des revenus", x = NULL, y = "Revenu/tête") 
 p2 <- ggplot(menage_enrichi_final, aes(x = revenu_pc, y = fct_reorder(region, revenu_pc, median), 
                                        fill = after_stat(x))) + 
   geom_density_ridges_gradient(scale = 2, rel_min_height = 0.01) + 
   scale_x_log10() + 
   scale_fill_viridis_c(option = "plasma", name = "Revenu") + 
   labs(title = "Distribution du revenu par tête selon la région", 
        x = "Revenu par tête (log)", y = NULL) + 
   theme_ensae()
 
 # 15- exportation
 
# Déja fait là haut, avec ggpsave option pdf.
 