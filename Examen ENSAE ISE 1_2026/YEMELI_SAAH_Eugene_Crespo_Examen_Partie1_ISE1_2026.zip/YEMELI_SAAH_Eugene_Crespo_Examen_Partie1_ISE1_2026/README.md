# Partie 1 

Cet examen est pour le compte du cours intitulé **Projet Statistique avec R & Python**, dispensé par M. Aboubacar HEMA qui est research scientist à IFPRI.

**Auteurs**: YEMELI SAAH eugène Crespo, ISE1 MATHS

## 1.Source de données

Les données mobilisées sont les bases  posées dans le git du professeur

Pour des soucis de légèreté, les données ont été placées dans le `gitignore`.

## 2.Objectifs de cet examen

Analyser la vulnérabilité aux chocs alimenataire des ménages du TCHAD
## 3.Reproductibilité
### Étape 1 : Cloner le dépôt

```bash
git clone <url-du-depot>
cd YEMELI_SAAH_Eugene_Crespo_Examen_Partie_ISE1_2026
```

### Étape 2 : Restaurer l'environnement R

Ouvrir `TP1_REPRISE.Rproj` dans RStudio, puis dans la console R, tapez:

```r
renv::restore()
```
Cette commande installe automatiquement **toutes les dépendances** avec les versions exactes utilisées au cours du travail et spécifiées dans `renv.lock`.Cela fait qu'aucune installation manuelle de packages n'est nécessaire.

### Étape 3 : Placer les données brutes
Télécharger les 2 fichiers `.dta` (voir section Données sources) et les placer dans :

```
data/raw/
```

### Étape 4 : Exécuter le pipeline complet

```r
source("main.R")
```
Ce script :
- Vérifie que tous les packages sont installés (sinon, demande de taper `renv::restore()`)
- Charge les 14 packages requis
- Fixe la graine aléatoire (`set.seed(2070)`) pour la reproductibilité
- Exécute `nettoyage.R` : import, exploration, nettoyage, construction des variables éducatives
- Exécute `analyses.R` : analyses statistiques, tests, visualisations
- Termine par Knit le `rapport.Rmd` en word complet et stylisé selon les conventions des instituts nationaux.

## 4.Structure locale du projet 
```
GROUPE16_TP1_LESLYE_NKWA_KEITA_LANCINA/
├── data/
│   ├── processed
│   ├── raw
├── docs/
│   ├── rapport.docx
│   ├── rapport.html
│   ├── rapport.Rmd
│   ├── la_ref.docx    # Styles prédéfinis
├── outputs/
│   ├── figures
│   ├── tables
├── renv/
├── scripts/
│   ├── analyses.R       #Toute la section 1
│   ├── nettoyage.R      # Toute la section 2 et 3
├── .gitignore
├── .RData
├── .Rhistory
├── .Rprofile
├── main.R
├── renv.lock
├── TP1_REPRISE.Rproj
├── README.md
```
## 5.Key Messages

Les résultats princpaux sont dans la section *Messages clés* du Rapport_FINAL.docx

## 6.Crédit

ENSAE de Dakar.
