# Section 1. Import, structuration et nettoyage 
#1. Importer les cinq sources avec les packages appropriés, en respectant les types de colonnes et les encodages. 
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


menages <- read_dta(here("data", "raw", "ensan_menages.dta")) |>
  mutate(milieu = as_factor(milieu))                      # 1=Urbain, 2=Rural -> facteur

individus <- read_csv(here("data", "raw", "ensan_individus.csv"), show_col_types = FALSE)

conso_groupes <- read_excel(here("data", "raw", "ensan_consommation.xlsx"), 
                            sheet = "Consommation_groupes")                   # Feuille 1 de la base
depenses      <- read_excel(here("data", "raw", "ensan_consommation.xlsx"), 
                            sheet = "Depenses_menage")                        # Feuille 2 de la même base

chocs <- read_csv(here("data", "raw", "chocs_menages.csv"), show_col_types = FALSE)

prix <- read_csv(here("data", "raw", "prix_marches.csv"), show_col_types = FALSE) |>
   mutate(mois = as.Date(mois))


cat(sprintf("menages       : %d observations x %d variables\n", nrow(menages),       ncol(menages)))
cat(sprintf("individus     : %d observations x %d variables\n", nrow(individus),     ncol(individus)))
cat(sprintf("conso_groupes : %d observations x %d variables\n", nrow(conso_groupes), ncol(conso_groupes)))
cat(sprintf("depenses      : %d observations x %d variables\n", nrow(depenses),      ncol(depenses)))
cat(sprintf("chocs         : %d observations x %d variables\n", nrow(chocs),         ncol(chocs)))
cat(sprintf("prix          : %d observations x %d variables\n", nrow(prix),          ncol(prix)))

#+++++++++++++++++++++++++++++++++++++++
#2. Fusionner les modules en un jeu de données ménages enrichi comportant les caractéristiques du chef de ménage, 
#la consommation alimentaire agrégée et les chocs subis, par des jointures adaptées
#+++++++++++++++++++++++++++++++++++++++

# 2.1 Vérifications des bases avant toute jointure

#  Doublons de hhid dans menages pour toute les bases (cle primaire attendue unique)
cat("Doublons hhid (menages) :", sum(duplicated(menages$hhid)), "\n")
cat("Doublons hhid (conso)   :", sum(duplicated(conso_groupes$hhid)), "\n")
cat("Doublons hhid (chocs)   :", sum(duplicated(chocs$hhid)), "\n")

# Coherence des effectifs entre bases : on veut voir si toutes les bases ont le même nombre de ménages
cat("Menages distincts       :", n_distinct(menages$hhid), "\n")
cat("Menages dans individus  :", n_distinct(individus$hhid), "\n")
cat("Menages dans conso      :", n_distinct(conso_groupes$hhid), "\n")
cat("Menages dans chocs      :", n_distinct(chocs$hhid), "\n")

# Valeurs manquantes sur les variables cles
vars_diag <- menages |> select(hhid, region, milieu, revenu, taille_menage, poids_final)
miss_summary <- miss_var_summary(vars_diag)
print(miss_summary)

fig00 <- vis_miss(vars_diag |> select(-hhid), sort_miss = TRUE) +
  labs(title = "Diagnostic des valeurs manquantes -- ensan_menages",
       caption = source_ghs)
ggsave(here("outputs", "figures", "fig00_diagnostic_NA.png"), fig00, width = 8, height = 4.5, dpi = 300)


# 2.2 Recupération des informations sur le chef de ménage

chef_menage <- individus |>
  filter(rang == 1) |>
  transmute(
    hhid,
    age_chef       = age,
    sexe_chef      = factor(sexe, levels = c(1, 2), labels = c("Homme", "Femme")),
    educ_chef      = factor(niveau_educ,
                            levels = c("Aucun", "Primaire", "Secondaire", "Superieur"))
  )

menage_indiv <- individus |>
  group_by(hhid) |>
  summarise(
    taille_observee = n(),
    n_hommes        = sum(sexe == 1, na.rm = TRUE),
    n_femmes        = sum(sexe == 2, na.rm = TRUE),
    age_moyen       = mean(age, na.rm = TRUE),
    n_moins15       = sum(age < 15, na.rm = TRUE),
    n_15_64         = sum(age >= 15 & age <= 64, na.rm = TRUE),
    n_plus65        = sum(age > 64, na.rm = TRUE),
    .groups = "drop"
  ) |>
  mutate(
    sex_ratio       = n_hommes / n_femmes,
    ratio_dependance = (n_moins15 + n_plus65) / pmax(n_15_64, 1)
  ) |>
  left_join(chef_menage, by = "hhid")

cat(sprintf("Menages agregés depuis individus : %d\n", nrow(menage_indiv)))
cat("Menages menages$taille_menage vs taille_observee -- ecarts :\n")
compar_taille <- menages |>
  select(hhid, taille_menage) |>
  inner_join(menage_indiv |> select(hhid, taille_observee), by = "hhid") |>
  mutate(ecart = taille_menage - taille_observee)
print(summary(compar_taille$ecart))

# Base de menage complete (jointures)

df_menage <- menages |>
  left_join(menage_indiv, by = "hhid") |>
  left_join(conso_groupes, by = "hhid") |>
  left_join(depenses,      by = "hhid") |>
  left_join(chocs |> select(-region_lib), by = "hhid")

cat(sprintf("df_menage : %d observations x %d variable\n", nrow(df_menage), ncol(df_menage)))


#++++++++++++++++++++++++++++++++++++++++++++++++++
#3. Identifier et corriger les libellés de régions incohérents entre fichiers avant toute jointure spatiale.
#+++++++++++++++++++++++++++++++++++++++++++++++++


#  Libelles region_lib (chocs) : Nous avons des orthographes multiples pour une meme region
#     -> 26 libelles bruts pour 23 regions (accents perdus + fautes de frappe
#        "OUADAI" pour Ouaddai, "TANDJILLE" pour Tandjile)
cat("\nLibelles distincts region (menages)    :", n_distinct(menages$region), "\n")
cat("Libelles distincts region_lib (chocs)   :", n_distinct(chocs$region_lib), "\n")
print(sort(unique(chocs$region_lib)))

# HARMONISATION DES IDENTIFIANTS ET DES LIBELLES DE REGION

# Re-padding de hhid (integer -> character 5 caracteres) pour individus/chocs
individus <- individus |> mutate(hhid = sprintf("%05s", hhid))
chocs     <- chocs     |> mutate(hhid = sprintf("%05s", hhid))

#  Table de correspondance region_lib (chocs, 26 libelles) -> region (menages,
#     23 regions). Construite a la main car deux libelles ("OUADAI",
#     "TANDJILLE") sont des fautes .
#     perdus -> Les suppressions d'accents ne  pas recoler.
New_region <- tribble(
  ~region_lib,          ~region,
  "BARH_EL_GAZEL",      "Barh El Gazel",
  "BATHA",              "Batha",
  "BORKOU",             "Borkou",
  "CHARI_BAGUIRMI",     "Chari Baguirmi",
  "ENNEDI_EST",         "Ennedi Est",
  "ENNEDI_OUEST",       "Ennedi Ouest",
  "GUERA",              "Guéra",
  "GUÉRA",         "Guéra",
  "HADJER_LAMIS",       "Hadjer Lamis",
  "KANEM",              "Kanem",
  "LAC",                "Lac",
  "LOGONE_OCCIDENTAL",  "Logone Occidental",
  "LOGONE_ORIENTAL",    "Logone Oriental",
  "MANDOUL",            "Mandoul",
  "MAYO_KEBBI_EST",     "Mayo Kebbi Est",
  "MAYO_KEBBI_OUEST",   "Mayo Kebbi Ouest",
  "MOYEN_CHARI",        "Moyen Chari",
  "NDJAMENA",           "N'Djamena",
  "OUADAI",             "Ouaddaï",   # faute de frappe (manque un "d")
  "OUADDAÏ",       "Ouaddaï",
  "SALAMAT",            "Salamat",
  "SILA",               "Sila",
  "TANDJILLE",          "Tandjilé",  # faute de frappe (double "l")
  "TANDJILÉ",      "Tandjilé",
  "TIBESTI",            "Tibesti",
  "WADI_FIRA",          "Wadi Fira"
)

stopifnot(n_distinct(New_region$region_lib) == n_distinct(chocs$region_lib))
stopifnot(all(New_region$region %in% unique(menages$region)))

chocs <- chocs |> left_join(New_region, by = "region_lib")
cat("region_lib non recodés apres jointure :", sum(is.na(chocs$region)), "\n")

#++++++++++++++++++++++++++++++++++++++++++++++++++
# 4. Produire un diagnostic complet des valeurs manquantes avec naniar 
#++++++++++++++++++++++++++++++++++++++++++++++++++

#  Doublons de hhid dans menages pour toute les bases (cle primaire attendue unique)
cat("Doublons hhid (df_menage) :", sum(duplicated(menages$hhid)), "\n")
cat("Doublons hhid (conso)   :", sum(duplicated(conso_groupes$hhid)), "\n")
cat("Doublons hhid (chocs)   :", sum(duplicated(chocs$hhid)), "\n")

# Coherence des effectifs entre bases : on veut voir si toutes les bases ont le même nombre de ménages
cat("Menages distincts       :", n_distinct(df_menage$hhid), "\n")
cat("Menages dans individus  :", n_distinct(individus$hhid), "\n")
cat("Menages dans conso      :", n_distinct(conso_groupes$hhid), "\n")
cat("Menages dans chocs      :", n_distinct(chocs$hhid), "\n")

# Valeurs manquantes sur les variables cles
vars_diag <- df_menage |> select(hhid, milieu, revenu, taille_menage, poids_final)
miss_summary <- miss_var_summary(vars_diag)
print(miss_summary)

fig01 <- vis_miss(vars_diag |> select(-hhid), sort_miss = TRUE) +
  labs(title = "Diagnostic des valeurs manquantes -- df_menage",
       caption = source_ghs)
ggsave(here("outputs", "figures", "fig01_diagnostic_NA.png"), fig01, width = 8, height = 4.5, dpi = 300)


#++++++++++++++++++++++++++++++++++++++++++++++++++
# 6. Recodage : (milieu, niveau d’éducation du chef de ménage, 
# quintiles de revenu par tête). 
#++++++++++++++++++++++++++++++++++++++++++++++++++

#   Milieu
df_menage <- df_menage |>
  mutate(milieu = as_factor(milieu))                      # 1=Urbain, 2=Rural -> facteur


#   Quintiles de revenu par tête
df_menage <- df_menage |>
  mutate(
    revenu_par_tete = revenu / taille_menage,
    quintile        = ntile(revenu_par_tete, 5),
    quintile_f      = factor(quintile, levels = 1:5,
                             labels = c("Q1 (plus pauvre)", "Q2", "Q3", "Q4",
                                        "Q5 (plus riche)"))
  )

