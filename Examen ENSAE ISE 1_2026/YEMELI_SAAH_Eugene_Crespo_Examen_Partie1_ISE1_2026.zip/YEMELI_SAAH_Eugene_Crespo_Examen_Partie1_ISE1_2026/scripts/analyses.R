# Section 2.  Statistiques descriptives pondérées et indices composites 
# 7.Déclarer le plan de sondage complet (grappes, strates, poids finaux) avec srvyr.
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

plan_svy <- df_menage |>
  filter(!is.na(poids_final)) |>
  as_survey_design(ids = grappe, strata = strate, weights = poids_final, nest = TRUE)

cat(sprintf("Menages dans le plan de sondage : %d / %d\n",
            nrow(df_menage |> filter(!is.na(poids_final))), nrow(df_menage)))

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 8. Construire le score de diversité alimentaire des ménages (HDDS) et la classification FAO associée.
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

df_menage <- df_menage |> 
  mutate( 
    # Score HDDS:somme des 12 groupes alimentaires 
    hdds = rowSums(across(starts_with("cons_")), na.rm = TRUE), 
    
    # Classification FAO 
    securite_alim = case_when( 
      hdds <= 3  ~ "Insécurité alimentaire sévère", 
      hdds <= 6  ~ "Insécurité alimentaire modérée", 
      hdds <= 9  ~ "Sécurité alimentaire acceptable", 
      TRUE       ~ "Bonne diversité alimentaire" 
    ) |> factor(levels = c("Insécurité alimentaire sévère", 
                           "Insécurité alimentaire modérée", 
                           "Sécurité alimentaire acceptable", 
                           "Bonne diversité alimentaire"), ordered = TRUE) 
  )


#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 9. Construire un indice composite de vulnérabilité aux chocs, combinant le nombre et la gravité des chocs subis avec l’intensité des stratégies d’adaptation mobilisées.
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Construction simplifiée de l'IPM (version PNUD) 
# Seuil de privation:un ménage est pauvre multidimensionnel si score >= 1/3 


#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 10. Produire un tableau descriptif pondéré de type Tableau 1 avec gtsummary, comparant les indicateurs clés par  milieu et par région, avec test de comparaison et colonne d’effectifs.
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# 11.. Calculer le coefficient de Gini du revenu par tête au niveau national et par région, avec un intervalle de confiance  obtenu par bootstrap.
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Section 3. Visualisation 
# 12. Représenter la distribution du revenu par tête par région (graphique de densités superposées ou équivalent), 
# avec une échelle adaptée à l’asymétrie de la variable. 
#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# Palette de couleurs (selon nos recherches sur les conventions des organisations internationales)
col_homme  <- "#0058AB"  # WHO/HMD
col_femme  <- "#E8416F"  # WHO/HMD
col_rural  <- "#80BD41"  # FAO/IFPRI   
col_urbain <- "#6C757D"  # ONU-HABITAT
col_bleu   <- "#1CABE2"  # UNICEF
