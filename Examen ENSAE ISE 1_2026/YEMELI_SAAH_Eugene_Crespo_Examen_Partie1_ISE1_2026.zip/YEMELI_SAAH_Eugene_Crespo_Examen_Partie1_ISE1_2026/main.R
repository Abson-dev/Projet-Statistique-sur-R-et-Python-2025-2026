# Partie 1 : Examen Projet Statistique sous R, Session 2025 2026
# Par : YEMELI SAAH Eugène Crespo, ENSAE ISE1 2025-2026
# Supervisé par : M. Aboubacar HEMA, IFPRI

rm(list = ls())

# Packages requis
pkgs <- c(
  "tidyverse", "haven", "labelled", "here", "scales",     # import / manipulation
  "patchwork", "naniar", "moments",                       # diagnostics / stats desc.
  "rstatix", "coin", "PropCIs",                            # tests statistiques
  "gtsummary", "gt", "flextable", "officer", "knitr",      # tableaux
  "srvyr", "survey",                                        # plan de sondage pondéré
  "forcats", "viridis",                                    # facteurs / couleurs
  "sf", "rnaturalearth", "rnaturalearthdata",               # cartographie (si le TP a une carte)
  "apyramid",                                                # pyramide des âges (si utile)
  "officer"                                                  # gestion de Rmarckdown .docx
)


manquants <- pkgs[!pkgs %in% installed.packages()[, 1]]
if (length(manquants) > 0) {
  cat("Packages manquants :", paste(manquants, collapse = ", "), "\n")
  cat("Lancez renv::restore() puis relancez main.R\n")
  stop("Environnement non initialisé.")
}

invisible(lapply(pkgs, library, character.only = TRUE)) 
cat("Packages chargés :", length(pkgs), "\n")

# Graine aléatoire,

set.seed(2070)                       # graine utilisée 
options(scipen = 999)                # désactive la notation scientifique dans les sorties

# Caption standard a coller en bas de CHAQUE figure ggplot (labs(caption = source_ghs))
source_ghs <- "Source :  Calculs de auteur."

#  Création de l'arborescence de dossiers

source(here("scripts", "nettoyage.R"),  encoding = "UTF-8")
source(here("scripts", "analyses.R"),   encoding = "UTF-8")

cat(sprintf("\nPipeline terminé"))
cat("Les figures sont dans : outputs/figures/\n")
cat("Les tableaux sont dans : outputs/tables/\n")

rmarkdown::render(
  here("docs", "rapport.Rmd"),
  output_format = "word_document",
  output_file   = here("docs", "rapport.docx")
)
cat("Tout foncionne bien. Pour le rapport  , ouvrez docs\n")