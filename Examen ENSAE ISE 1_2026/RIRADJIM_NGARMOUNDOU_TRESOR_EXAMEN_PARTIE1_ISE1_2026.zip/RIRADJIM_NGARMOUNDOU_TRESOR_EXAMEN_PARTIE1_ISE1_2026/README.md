# Projet ENSAN 2026

Analyse de la sécurité alimentaire

Projet reproductible sous R

Structure :
- data
- R
- output
- rapport
