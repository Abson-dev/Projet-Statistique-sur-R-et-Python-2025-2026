############################################################
# R/02_cleaning.R
############################################################

library(tidyverse)
library(janitor)
library(labelled)
library(stringr)
library(lubridate)

cat("=========================================\n")
cat("NETTOYAGE DES DONNEES\n")
cat("=========================================\n")

#----------------------------------------------------------
# Chargement
#----------------------------------------------------------

menages <- readRDS("data/processed/menages.rds")
individus <- readRDS("data/processed/individus.rds")
chocs <- readRDS("data/processed/chocs.rds")
prix <- readRDS("data/processed/prix.rds")
consommation <- readRDS("data/processed/consommation.rds")

############################################################
# MENAGES
############################################################

menages <- menages |>
  
  clean_names() |>
  
  mutate(
    
    hhid = as.integer(hhid),
    
    region_lib = str_to_title(region),
    
    milieu = factor(milieu),
    
    strate = factor(strate)
    
  )

############################################################
# INDIVIDUS
############################################################

individus <- individus |>
  
  clean_names() |>
  
  mutate(
    
    hhid = as.integer(hhid),
    
    rang = as.integer(rang),
    
    age = as.numeric(age),
    
    sexe = factor(
      sexe,
      levels = c(1,2),
      labels = c("Homme","Femme")
    ),
    
    niveau_educ = factor(
      niveau_educ,
      levels = c(
        "Aucun",
        "Primaire",
        "Secondaire",
        "Superieur"
      ),
      ordered = TRUE
    )
    
  )

############################################################
# CHOCS
############################################################

chocs <- chocs |>
  
  clean_names() |>
  
  mutate(
    
    hhid = as.integer(hhid),
    
    region_lib = str_to_title(region_lib)
    
  )

############################################################
# PRIX
############################################################

prix <- prix |>
  clean_names() |>
  mutate(
    region = str_to_title(region),
    marche = str_to_title(marche),
    produit = str_to_title(produit)
  )

############################################################
# CONSOMMATION
############################################################

consommation <-
  
  consommation |>
  
  map(
    
    ~ .x |>
      
      clean_names() |>
      
      mutate(
        
        hhid = as.integer(hhid)
        
      )
    
  )

############################################################
# Suppression doublons
############################################################

menages <- distinct(menages)

individus <- distinct(individus)

chocs <- distinct(chocs)

prix <- distinct(prix)

############################################################
# Vérification
############################################################

stopifnot(anyDuplicated(menages$hhid)==0)

stopifnot(anyDuplicated(chocs$hhid)==0)

############################################################
# Sauvegarde
############################################################

saveRDS(
  menages,
  "data/processed/menages_clean.rds"
)

saveRDS(
  individus,
  "data/processed/individus_clean.rds"
)

saveRDS(
  chocs,
  "data/processed/chocs_clean.rds"
)

saveRDS(
  prix,
  "data/processed/prix_clean.rds"
)

saveRDS(
  consommation,
  "data/processed/consommation_clean.rds"
)

cat("Nettoyage terminé.\n")


############################################################
# Reflexe de vérification
############################################################

summary(menages)

summary(individus)

summary(chocs)

summary(prix)

map(consommation, summary)