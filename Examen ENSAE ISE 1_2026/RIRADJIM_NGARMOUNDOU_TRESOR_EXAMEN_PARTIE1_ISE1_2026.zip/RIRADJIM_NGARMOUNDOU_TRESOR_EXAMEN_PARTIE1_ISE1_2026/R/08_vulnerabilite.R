############################################################
# R/08_vulnerabilite.R
############################################################
install.packages("scales")
library(tidyverse)
library(srvyr)
library(scales)
library(writexl)

cat("========================================\n")
cat("INDICE DE VULNERABILITE\n")
cat("========================================\n")

############################################################
# Chargement
############################################################

dir.create("data/processed", recursive = TRUE, showWarnings = FALSE)

saveRDS(
  base,
  "data/processed/base_hdds.rds"
)

#
vars_chocs <- c(
  
  "choc_secheresse",
  
  "choc_hausse_prix",
  
  "choc_conflit",
  
  "choc_maladie"
  
)

#
vars_strategies <- c(
  
  "strat_vente_actifs",
  
  "strat_reduction_repas",
  
  "strat_migration",
  
  "strat_endettement"
  
)

#
base <- base |>
  
  mutate(
    
    score_chocs =
      
      rowSums(
        
        across(all_of(vars_chocs)),
        
        na.rm=TRUE
        
      )
    
  )

#
base <- base |>
  
  mutate(
    
    score_strategies=
      
      rowSums(
        
        across(all_of(vars_strategies)),
        
        na.rm=TRUE
        
      )
    
  )

