############################################################
# R/04_diagnostic.R
############################################################
library(tidyverse)
library(naniar)
library(skimr)
library(gtsummary)
library(gt)
library(janitor)

cat("=========================================\n")
cat("DIAGNOSTIC QUALITE DES DONNEES\n")
cat("=========================================\n")

base <- readRDS("data/processed/base_analyse.rds")

dir.create("output/diagnostic",
           recursive = TRUE,
           showWarnings = FALSE)

############################################################
# Dimensions
############################################################

cat("Nombre de lignes :", nrow(base), "\n")
cat("Nombre de colonnes :", ncol(base), "\n")

############################################################
# Structure
############################################################

glimpse(base)

############################################################
# Résumé statistique
############################################################

skim(base)


############################################################
# Pourcentage de valeurs manquantes
############################################################

na_table <- tibble(
  variable = names(base),
  nb_na = colSums(is.na(base))
) |>
  mutate(
    pourcentage = round(100 * nb_na / nrow(base), 2)
  ) |>
  arrange(desc(pourcentage))

na_table

#

base |>
  summarise(
    nb_chocs = sum(!is.na(choc_secheresse)),
    nb_total = n()
  )

chocs <- readRDS("data/processed/chocs.rds")

nrow(chocs)
n_distinct(chocs$hhid)

# On revoie les jointures
menages <- menages |>
  mutate(
    hhid = str_pad(as.character(hhid), width = 5, pad = "0")
  )

individus <- individus |>
  mutate(
    hhid = str_pad(as.character(hhid), width = 5, pad = "0")
  )

chocs <- chocs |>
  mutate(
    hhid = str_pad(as.character(hhid), width = 5, pad = "0")
  )

# 
base <- menages |>
  left_join(individus, by = "hhid") |>
  left_join(chocs, by = "hhid")

#
saveRDS(base, "data/processed/base_analyse.rds")

base <- readRDS("data/processed/base_analyse.rds")

table(is.na(base$choc_secheresse))

############################################################
# Revision Jointiure
############################################################

menages <- readRDS("data/processed/menages.rds")
individus <- readRDS("data/processed/individus.rds")
chocs <- readRDS("data/processed/chocs.rds")

#
library(stringr)

menages <- menages |>
  mutate(hhid = str_pad(as.character(hhid), 5, pad = "0"))

individus <- individus |>
  mutate(hhid = str_pad(as.character(hhid), 5, pad = "0"))

chocs <- chocs |>
  mutate(hhid = str_pad(as.character(hhid), 5, pad = "0"))

#
individus_menage <- individus |>
  group_by(hhid) |>
  summarise(
    taille_menage = n(),
    age_moyen = mean(age, na.rm = TRUE),
    nb_hommes = sum(sexe == "Homme", na.rm = TRUE),
    nb_femmes = sum(sexe == "Femme", na.rm = TRUE)
  )
#
base <- menages |>
  left_join(individus_menage, by = "hhid") |>
  left_join(chocs, by = "hhid")

nrow(base)
n_distinct(base$hhid)
names(individus)

# Export
write.csv(
  
  na_table,
  
  "output/diagnostic/valeurs_manquantes.csv",
  
  row.names = FALSE
  
)

#
png(
  
  "output/diagnostic/missing_matrix.png",
  
  width=1800,
  
  height=900,
  
  res=200
  
)

vis_miss(base)

dev.off()

#
png(
  
  "output/diagnostic/na_barplot.png",
  
  width=1800,
  
  height=900,
  
  res=200
  
)

gg_miss_var(base)

dev.off()

#
install.packages("ggplot2")
library("ggplot2")

png(
  
  "output/diagnostic/heatmap_na.png",
  
  width=1800,
  
  height=900,
  
  res=200
  
)

gg_miss_upset(base)

dev.off()

#
num <-
  
  base |>
  
  select(where(is.numeric))

# 
outliers <-
  
  map_df(
    
    names(num),
    
    function(v){
      
      Q1 <- quantile(num[[v]],0.25,na.rm=TRUE)
      
      Q3 <- quantile(num[[v]],0.75,na.rm=TRUE)
      
      IQR <- Q3-Q1
      
      borne_inf <- Q1-1.5*IQR
      
      borne_sup <- Q3+1.5*IQR
      
      tibble(
        
        variable=v,
        
        nb_outliers=
          
          sum(
            
            num[[v]]<borne_inf |
              
              num[[v]]>borne_sup,
            
            na.rm=TRUE
            
          )
        
      )
      
    }
    
  )


#
write.csv(
  
  outliers,
  
  "output/diagnostic/outliers.csv",
  
  row.names=FALSE
  
)

#
doublons <-
  
  base |>
  
  count(hhid) |>
  
  filter(n>1)

doublons

#
tbl <-
  
  base |>
  
  tbl_summary(
    
    missing="ifany"
    
  )

tbl

#
gtsave(
  
  as_gt(tbl),
  
  "output/diagnostic/tableau_descriptif.html"
  
)

#
sink(
  
  "output/diagnostic/rapport_diagnostic.txt"
  
)

cat("=================================\n")

cat("DIAGNOSTIC DES DONNEES\n")

cat("=================================\n\n")

cat("Nombre de ménages : ",nrow(base),"\n\n")

cat("Nombre de variables : ",ncol(base),"\n\n")

cat("Valeurs manquantes\n\n")

print(na_table)

cat("\n\n")

cat("Valeurs extrêmes\n\n")

print(outliers)

cat("\n\n")

cat("Doublons\n\n")

print(doublons)

sink()

#

#
saveRDS(
  
  na_table,
  
  "data/processed/na_table.rds"
  
)

saveRDS(
  
  outliers,
  
  "data/processed/outliers.rds"
  
)

