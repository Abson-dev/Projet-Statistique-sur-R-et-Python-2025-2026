############################################################
# R/05_imputation.R
############################################################
install.packages("VIM")
library(tidyverse)
library(mice)
library(VIM)

cat("=====================================\n")
cat("IMPUTATION MULTIPLE\n")
cat("=====================================\n")

############################################################
# Chargement
############################################################

base <- readRDS("data/processed/base_analyse.rds")

############################################################
# Variables numériques
############################################################

num_var <- names(base)[sapply(base, is.numeric)]

############################################################
# Variables qualitatives
############################################################

cat_var <- names(base)[sapply(base, is.factor)]

############################################################
# Méthodes d'imputation
############################################################

meth <- make.method(base)

pred <- make.predictorMatrix(base)

############################################################
# Variables identifiantes / structurelles
############################################################

# identifiant ménage
meth["hhid"] <- ""

pred[, "hhid"] <- 0
pred["hhid", ] <- 0

# variables de sondage non utilisées pour l'imputation
meth["grappe"] <- ""
meth["poids_final"] <- ""

pred[, "grappe"] <- 0
pred["grappe", ] <- 0

pred[, "poids_final"] <- 0
pred["poids_final", ] <- 0

############################################################
# Numériques
############################################################

meth[num_var] <- "pmm"

############################################################
# Facteurs
############################################################

meth[cat_var] <- "polyreg"

############################################################
# Imputation
############################################################

set.seed(12345)

imp <- mice(
  
  base,
  
  m = 5,
  
  method = meth,
  
  predictorMatrix = pred,
  
  maxit = 10,
  
  printFlag = TRUE
  
)

############################################################
# Base complétée
############################################################

base_imp <- complete(imp)

############################################################
# Sauvegarde
############################################################

saveRDS(
  
  imp,
  
  "data/processed/imputation.rds"
  
)

saveRDS(
  
  base_imp,
  
  "data/processed/base_imputee.rds"
  
)

cat("Imputation terminée.\n")

# Vérification 

############################################################
# Convergence
############################################################

png(
  
  "output/diagnostic/convergence_mice.png",
  
  width = 1800,
  
  height = 1000,
  
  res = 200
  
)

plot(imp)

dev.off()

# Distribution (avant et après)
png(
  
  "output/diagnostic/density_imputation.png",
  
  width = 1800,
  
  height = 1000,
  
  res = 200
  
)

densityplot(imp)

dev.off()

# Stripplot
png(
  
  "output/diagnostic/stripplot.png",
  
  width = 1800,
  
  height = 1000,
  
  res = 200
  
)

stripplot(imp)

dev.off()

# On essaie de comparrer
compare <- tibble(
  
  variable = names(base),
  
  avant = colSums(is.na(base)),
  
  apres = colSums(is.na(base_imp))
  
)

compare

#sauvegarde
write.csv(
  
  compare,
  
  "output/diagnostic/comparaison_imputation.csv",
  
  row.names = FALSE
  
)

# Sauvegarde 
library(writexl)

write_xlsx(
  
  base_imp,
  
  "output/base_imputee.xlsx"
  
)

# Rapport
sink(
  
  "output/diagnostic/imputation.txt"
  
)

cat("=================================\n")

cat("IMPUTATION MULTIPLE\n")

cat("=================================\n\n")

summary(imp)

sink()

