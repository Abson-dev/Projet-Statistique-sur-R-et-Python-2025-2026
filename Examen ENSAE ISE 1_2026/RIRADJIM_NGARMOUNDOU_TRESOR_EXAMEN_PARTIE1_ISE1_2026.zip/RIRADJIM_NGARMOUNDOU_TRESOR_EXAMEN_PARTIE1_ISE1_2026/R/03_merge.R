############################################################
# R/03_merge.R
############################################################

library(tidyverse)

cat("====================================\n")
cat("CONSTRUCTION DE LA BASE ANALYTIQUE\n")
cat("====================================\n")

############################################################
# Chargement
############################################################

menages <- readRDS("data/processed/menages_clean.rds")
individus <- readRDS("data/processed/individus_clean.rds")
chocs <- readRDS("data/processed/chocs_clean.rds")
prix <- readRDS("data/processed/prix_clean.rds")
consommation <- readRDS("data/processed/consommation_clean.rds")

############################################################
# Feuille consommation
############################################################

conso <- consommation[[1]]

############################################################
# Chef de ménage
############################################################

chef <- individus |>
  
  filter(rang == 1) |>
  
  transmute(
    
    hhid,
    
    sexe_chef = sexe,
    
    age_chef = age,
    
    education_chef = niveau_educ
    
  )

############################################################
# Taille du ménage
############################################################

taille <- individus |>
  
  group_by(hhid) |>
  
  summarise(
    
    taille_menage = n(),
    
    age_moyen = mean(age, na.rm = TRUE),
    
    nb_hommes = sum(sexe == "Homme"),
    
    nb_femmes = sum(sexe == "Femme"),
    
    .groups = "drop"
    
  )

############################################################
# Fusion 1
############################################################

base <- menages |>
  
  left_join(
    chef,
    by = "hhid"
  )

############################################################
# Fusion 2
############################################################

base <- base |>
  
  left_join(
    taille,
    by = "hhid"
  )

############################################################
# Fusion 3
############################################################

base <- base |>
  
  left_join(
    chocs,
    by = c(
      "hhid",
      "region_lib"
    )
  )

############################################################
# Fusion 4
############################################################

base <- base |>
  
  left_join(
    conso,
    by = "hhid"
  )

############################################################
# Vérification
############################################################

cat(nrow(base), "\n")

cat(length(unique(base$hhid)), "\n")

############################################################
# Sauvegarde
############################################################

saveRDS(
  base,
  "data/processed/base_analyse.rds"
)

############################################################
# Vérification : Jointures, Clés et Doublons
############################################################


library(skimr)

base <- readRDS("data/processed/base_analyse.rds")

skim(base)

# Clés
sum(is.na(base$age_chef))

sum(is.na(base$taille_menage))

sum(is.na(base$cons_cereales))

# Doublons
base |>
  
  count(hhid) |>
  
  filter(n > 1)

# Dimensions
dim(base)



base <- base |>
  rename(taille_menage = taille_menage.y) |>
  select(-taille_menage.x)

############################################################
# Révision de taille ménage
############################################################

base <- base |>
  rename(taille_menage = taille_menage.y) |>
  select(-taille_menage.x)

names(base)[grepl("taille", names(base))]

sum(is.na(base$taille_menage))

saveRDS(base, "data/processed/base_analyse.rds")

############################################################
# Export
############################################################

library(writexl)

write_xlsx(
  base,
  "output/base_analyse.xlsx"
)