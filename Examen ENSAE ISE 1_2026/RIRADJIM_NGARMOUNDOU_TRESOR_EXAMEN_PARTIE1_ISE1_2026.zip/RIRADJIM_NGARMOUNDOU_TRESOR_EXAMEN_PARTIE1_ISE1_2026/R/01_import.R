############################################################
# R/01_import.R
############################################################

library(tidyverse)
library(readxl)
library(haven)
library(sf)
library(janitor)

cat("=====================================\n")
cat("IMPORTATION DES DONNEES\n")
cat("=====================================\n")

#-----------------------------------------------------------
# MENAGES
#-----------------------------------------------------------

menages <-
  read_dta("data/raw/ensan_menages.dta") |>
  clean_names()

#-----------------------------------------------------------
# INDIVIDUS
#-----------------------------------------------------------

individus <-
  read_csv(
    "data/raw/ensan_individus.csv",
    show_col_types = FALSE
  ) |>
  clean_names()

#-----------------------------------------------------------
# CHOCS
#-----------------------------------------------------------

chocs <-
  read_csv(
    "data/raw/chocs_menages.csv",
    show_col_types = FALSE
  ) |>
  clean_names()

#-----------------------------------------------------------
# PRIX
#-----------------------------------------------------------

prix <-
  read_csv(
    "data/raw/prix_marches.csv",
    show_col_types = FALSE
  ) |>
  clean_names()

#-----------------------------------------------------------
# CONSOMMATION
#-----------------------------------------------------------

feuilles <-
  excel_sheets("data/raw/ensan_consommation.xlsx")

consommation <-
  map(
    feuilles,
    \(x)
    read_excel(
      "data/raw/ensan_consommation.xlsx",
      sheet = x
    ) |>
      clean_names()
  )

names(consommation) <- feuilles

#-----------------------------------------------------------
# SHAPEFILE
#-----------------------------------------------------------

admin1 <-
  st_read(
    "data/raw/tcd_admin1.shp",
    quiet = TRUE
  )

cat("Importation terminée.\n")


saveRDS(
  menages,
  "data/processed/menages.rds"
)

saveRDS(
  individus,
  "data/processed/individus.rds"
)

saveRDS(
  chocs,
  "data/processed/chocs.rds"
)

saveRDS(
  prix,
  "data/processed/prix.rds"
)

saveRDS(
  consommation,
  "data/processed/consommation.rds"
)

saveRDS(
  admin1,
  "data/processed/admin1.rds"
)

#-----------------------------------------------------------
# CHEKING 
#-----------------------------------------------------------

glimpse(menages)

glimpse(individus)

glimpse(chocs)

glimpse(prix)

map(consommation, glimpse)