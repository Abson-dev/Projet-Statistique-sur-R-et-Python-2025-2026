############################################################
# R/07_hdds.R
############################################################

library(tidyverse)
library(srvyr)
library(gtsummary)
library(gt)
library(writexl)

cat("========================================\n")
cat("CALCUL DU HDDS\n")
cat("========================================\n")

############################################################
# Chargement
############################################################

base <- readRDS("data/processed/base_imputee.rds")

plan <- readRDS("data/processed/plan_sondage.rds")

# 
alim <- c(

"cons_cereales",

"cons_tubercules",

"cons_legumineuses",

"cons_legumes",

"cons_fruits",

"cons_viande",

"cons_poisson",

"cons_oeufs",

"cons_lait",

"cons_huile",

"cons_sucre",

"cons_condiments"

)

#
base <-
  
  base |>
  
  mutate(
    
    HDDS=
      
      rowSums(
        
        across(
          
          all_of(alim)
          
        ),
        
        na.rm=TRUE
        
      )
    
  )

#
conso |>
  count(hhid) |>
  filter(n > 1)

#
conso <- conso |>
  mutate(
    hhid = as.character(hhid)
  )

#
base <- base |>
  left_join(conso, by = "hhid")
#
grep("cons_", names(base), value = TRUE)


#
conso <- conso |>
  mutate(
    hhid = sprintf("%05d", as.numeric(hhid))
  )

#
base <- base |>
  select(-starts_with("cons_")) |>
  left_join(conso, by = "hhid")

#
base <- base |>
  mutate(
    HDDS = rowSums(
      across(all_of(alim)),
      na.rm = TRUE
    )
  )

#
table(base$HDDS, useNA = "ifany")

# Classifiction
base <-
  
  base |>
  
  mutate(
    
    classe_HDDS=
      
      case_when(
        
        HDDS<=3 ~ "Faible",
        
        HDDS<=6 ~ "Moyenne",
        
        TRUE ~ "Elevée"
        
      )
    
  )

# Les facteurs
base$classe_HDDS <-
  
  factor(
    
    base$classe_HDDS,
    
    levels=c(
      
      "Faible",
      
      "Moyenne",
      
      "Elevée"
      
    )
    
  )

# On revoie le plan 
plan <-
  
  as_survey_design(
    
    base,
    
    ids=grappe,
    
    strata=strate,
    
    weights=poids_final,
    
    nest=TRUE
    
  )

# Calculs
plan |>
  summarise(
    HDDS_moyen = survey_mean(
      HDDS,
      vartype = "se",
      na.rm = TRUE
    )
  )

#
plan |>
  group_by(region) |>
  summarise(
    HDDS_moyen = survey_mean(
      HDDS,
      vartype = "se",
      na.rm = TRUE
    )
  )
#
hdds_milieu <-
  
  plan |>
  
  group_by(milieu) |>
  
  summarise(
    
    HDDS=
      
      survey_mean(
        
        HDDS
        
      )
    
  )

hdds_milieu

#
classes <-
  
  plan |>
  
  group_by(classe_HDDS) |>
  
  summarise(
    
    Effectif=
      
      survey_total()
    
  )

classes

#
classes <-
  
  classes |>
  
  mutate(
    
    Pourcentage=
      
      100*
      
      Effectif/
      
      sum(Effectif)
    
  )

#
tbl_hdds <-
  
  base |>
  
  select(
    
    HDDS,
    
    classe_HDDS,
    
    region,
    
    milieu
    
  ) |>
  
  tbl_summary(
    
    by=classe_HDDS
    
  )
#
gtsave(
  
  as_gt(tbl_hdds),
  
  "output/hdds_tableau.html"
  
)
#
write_xlsx(
  
  list(
    
    HDDS_region=hdds_region,
    
    HDDS_milieu=hdds_milieu,
    
    Classes=classes
    
  ),
  
  "output/hdds_resultats.xlsx"
  
)

#
library(writexl)

dir.create("output", showWarnings = FALSE)

write_xlsx(
  list(
    HDDS_region = hdds_region,
    HDDS_milieu = hdds_milieu,
    Classes = classes
  ),
  "output/hdds_resultats.xlsx"
)


# Rapport
sink(
  "output/hdds.txt"
)

cat("=============================\n")
cat("HDDS\n")
cat("=============================\n\n")

cat("Moyenne nationale\n\n")

print(
  plan |>
    summarise(
      HDDS_moyen = survey_mean(
        HDDS,
        vartype = "se",
        na.rm = TRUE
      )
    )
)

sink()