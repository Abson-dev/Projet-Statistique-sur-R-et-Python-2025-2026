###############################################################
# R/01_exploration.R
###############################################################

library(tidyverse)
library(readxl)
library(haven)
library(sf)
library(janitor)

#--------------------------------------------------------------
# Import
#--------------------------------------------------------------

menages <- read_dta("data/raw/ensan_menages.dta") |> clean_names()

individus <- read_csv(
  "data/raw/ensan_individus.csv",
  show_col_types = FALSE
) |> clean_names()

chocs <- read_csv(
  "data/raw/chocs_menages.csv",
  show_col_types = FALSE
) |> clean_names()

prix <- read_csv(
  "data/raw/prix_marches.csv",
  show_col_types = FALSE
) |> clean_names()


carte <- st_read(
  "data/raw/tcd_admin1.shp",
  quiet = TRUE
)

#--------------------------------------------------------------
# Feuilles Excel
#--------------------------------------------------------------

sheets <- excel_sheets("data/raw/ensan_consommation.xlsx")

print(sheets)

consommation <- map(
  sheets,
  ~ read_excel(
    "data/raw/ensan_consommation.xlsx",
    sheet = .x
  ) |> clean_names()
)

names(consommation) <- sheets

#--------------------------------------------------------------
# Structure des bases
#--------------------------------------------------------------

cat("\n==============================\n")
cat("MENAGES\n")
cat("==============================\n")

glimpse(menages)

cat("\n==============================\n")
cat("INDIVIDUS\n")
cat("==============================\n")

glimpse(individus)

cat("\n==============================\n")
cat("CHOCS\n")
cat("==============================\n")

glimpse(chocs)

cat("\n==============================\n")
cat("PRIX\n")
cat("==============================\n")

glimpse(prix)

cat("\n==============================\n")
cat("CARTE\n")
cat("==============================\n")

glimpse(carte)

cat("\n==============================\n")
cat("NOMS DES VARIABLES\n")
cat("==============================\n")

list(
  menages = names(menages),
  individus = names(individus),
  chocs = names(chocs),
  prix = names(prix)
)

cat("\n==============================\n")
cat("EXCEL\n")
cat("==============================\n")

walk(consommation, glimpse)


