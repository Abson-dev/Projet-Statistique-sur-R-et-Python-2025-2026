# ============================================================
# R/00_packages.R
# Gestion des dépendances et initialisation renv
# ============================================================

required_packages <- c(
  "tidyverse",
  "haven",
  "readxl",
  "janitor",
  "labelled",
  "naniar",
  "mice",
  "srvyr",
  "survey",
  "gtsummary",
  "gt",
  "ineq",
  "boot",
  "sf",
  "tmap",
  "patchwork",
  "scales",
  "glue",
  "fs",
  "skimr",
  "quarto",
  "writexl",
  "arrow",
  "httr2",
  "jsonlite"
)

installed <- rownames(installed.packages())

to_install <- setdiff(required_packages, installed)

if(length(to_install) > 0){
  install.packages(to_install)
}

invisible(lapply(required_packages, library, character.only = TRUE))

if (!requireNamespace("renv", quietly = TRUE)) {
  install.packages("renv")
}

if (!file.exists("renv.lock")) {
  renv::init(bare = TRUE)
}

renv::snapshot(prompt = FALSE)

cat("Packages chargés et renv configuré.\\n")