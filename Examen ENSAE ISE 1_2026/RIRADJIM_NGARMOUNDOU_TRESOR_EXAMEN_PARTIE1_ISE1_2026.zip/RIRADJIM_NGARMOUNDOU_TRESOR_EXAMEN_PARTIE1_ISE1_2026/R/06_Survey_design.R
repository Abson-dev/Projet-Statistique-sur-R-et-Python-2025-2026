############################################################
# R/06_survey_design.R
############################################################
install.packages("survey")
install.packages("srvyr")
install.packages("dplyr")

library(tidyverse)
library(survey)
library(srvyr)
library(dplyr)

options(survey.lonely.psu = "adjust")

cat("========================================\n")
cat("PLAN DE SONDAGE\n")
cat("========================================\n")

############################################################
# Chargement
############################################################

base <- readRDS("data/processed/base_imputee.rds")

############################################################
# Vérification
############################################################

summary(base$poids_final)

summary(base$grappe)

summary(base$strate)

############################################################
# Plan de sondage
############################################################

plan <-
  
  as_survey_design(
    
    base,
    
    ids = grappe,
    
    strata = strate,
    
    weights = poids_final,
    
    nest = TRUE
    
  )

############################################################
# Sauvegarde
############################################################

saveRDS(
  
  plan,
  
  "data/processed/plan_sondage.rds"
  
)

cat("Plan créé avec succès.\n")

# Taille pondérée

plan |>
  summarise(
    taille_population = survey_total()
  )

# Taille non pondérée
nrow(base)

# Nombre monyen par ménnage 
plan |>
  summarise(
    taille_moyenne_menage = survey_mean(taille_menage, vartype = "se")
  )

# 
plan |>
  summarise(
    revenu_median = survey_median(revenu, na.rm = TRUE)
  )
#
plan |>
  summarise(
    revenu_quartiles = survey_quantile(
      revenu,
      quantiles = c(.25, .5, .75),
      na.rm = TRUE
    )
  )

#
revenu_region <-
  plan |>
  group_by(region) |>
  summarise(
    revenu_moyen = survey_mean(
      revenu,
      na.rm = TRUE
    )
  )

revenu_region

#
revenu_milieu <-
  plan |>
  group_by(milieu) |>
  summarise(
    revenu_moyen = survey_mean(
      revenu,
      na.rm = TRUE
    )
  )

revenu_milieu

#
taille_region <-
  plan |>
  group_by(region) |>
  summarise(
    taille_moyenne = survey_mean(
      taille_menage,
      na.rm = TRUE
    )
  )

taille_region

#
library(writexl)

write_xlsx(
  
  list(
    
    revenu_region=revenu_region,
    
    revenu_milieu=revenu_milieu,
    
    taille_region=taille_region
    
  ),
  
  "output/statistiques_ponderees.xlsx"
  
)
#
sink(
  
  "output/statistiques_ponderees.txt"
  
)

cat("==============================\n")

cat("PLAN DE SONDAGE\n")

cat("==============================\n\n")

print(summary(plan))

cat("\n")

print(revenu_region)

cat("\n")

print(revenu_milieu)

cat("\n")

print(taille_region)

sink()

#
saveRDS(
  
  revenu_region,
  
  "data/processed/revenu_region.rds"
  
)

saveRDS(
  
  revenu_milieu,
  
  "data/processed/revenu_milieu.rds"
  
)

saveRDS(
  
  taille_region,
  
  "data/processed/taille_region.rds"
  
)

#
