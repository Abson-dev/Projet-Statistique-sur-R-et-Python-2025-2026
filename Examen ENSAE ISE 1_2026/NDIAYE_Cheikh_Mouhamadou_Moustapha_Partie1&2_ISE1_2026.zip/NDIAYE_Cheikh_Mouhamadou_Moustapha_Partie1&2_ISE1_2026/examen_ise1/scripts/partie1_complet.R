# ============================================================================
# PARTIE 1 - ENSAN 2026 : Analyse de la sécurité alimentaire
# Script complet (Import, Nettoyage, Indices, Visualisations, Rapport)
# ============================================================================

# Création des dossiers nécessaires
dir.create("data/processed", recursive = TRUE, showWarnings = FALSE)
dir.create("outputs(partie1)/tables", recursive = TRUE, showWarnings = FALSE)
dir.create("outputs(partie1)/figures", recursive = TRUE, showWarnings = FALSE)
dir.create("Rapport", recursive = TRUE, showWarnings = FALSE)
dir.create("outputs(partie1)/notes_regionales", recursive = TRUE, showWarnings = FALSE)

# ============================================================================
# SECTION 1 : Import, structuration et nettoyage (Q1 à Q6)
# ============================================================================

library(tidyverse)
library(readxl)
library(sf)
library(naniar)
library(mice)
library(labelled)

# --- Q1 : Import des 5 sources

# 1.1 MENAGES (Excel)
menages <- read_xlsx("data/raw/ensan_menages.xlsx")

# 1.2 INDIVIDUS (CSV)
individus <- read_csv("data/raw/ensan_individus.csv",
                      locale = locale(encoding = "UTF-8"),
                      col_types = cols(hhid = col_character()))

# 1.3 CONSOMMATION (Excel) - feuille "Consommation_groupes"
conso <- read_xlsx("data/raw/ensan_consommation.xlsx", 
                   sheet = "Consommation_groupes")

# 1.4 CHOCS (CSV)
chocs <- read_csv("data/raw/chocs_menages.csv",
                  col_types = cols(hhid = col_character()))

# 1.5 SHAPEFILE (frontières)
frontieres <- st_read("data/raw/tcd_admin1.shp")

# --- Q2 : Fusion avec vérification des lignes
#
# EXPLICATION DE LA JOINTURE :
# - left_join() conserve tous les ménages de la table menages.
# - stopifnot() vérifie que le nombre de lignes ne change pas.
# - On récupère les caractéristiques du chef (rang == 1) depuis individus.
# - On agrège la consommation en un score HDDS (somme des 12 groupes).
# - On ajoute les chocs.

# 2.1 Chef de ménage (rang == 1)
chef <- individus |> 
  filter(rang == 1) |> 
  select(hhid, age_chef = age, sexe_chef = sexe, edu_chef = niveau_educ)

nrow(menages)  # Affichage du nombre initial
menages <- menages |> left_join(chef, by = "hhid")
stopifnot(nrow(menages) == nrow(menages))

# 2.2 Agrégation de la consommation (HDDS brut)
# HDDS = somme des 12 groupes alimentaires (0/1). Max = 12.
conso_agg <- conso |> 
  rowwise() |> 
  mutate(hdds_brut = sum(c_across(starts_with("cons_")), na.rm = TRUE)) |> 
  ungroup() |> 
  select(hhid, hdds_brut)

menages <- menages |> left_join(conso_agg, by = "hhid")
stopifnot(nrow(menages) == nrow(menages))

# 2.3 Ajout des chocs et stratégies d'adaptation
# On renomme region_lib en region pour harmonisation
chocs <- chocs |> rename(region = region_lib)
menages <- menages |> left_join(chocs, by = "hhid")
stopifnot(nrow(menages) == nrow(menages))

# --- Q3 : Correction des libellés de régions ------------------------------
# 
# EXPLICATION : Les régions sont écrites différemment selon les fichiers.
# On uniformise : majuscules, suppression des espaces inutiles, remplacement des "_" par " ".
# Exemples : "BATHA" -> "BATHA", "Chari Baguirmi" -> "CHARI BAGUIRMI", etc.

clean_region <- function(x) {
  x <- str_to_upper(str_trim(x))
  x <- str_replace_all(x, "_", " ")
  x
}

menages <- menages |> mutate(region = clean_region(region.x))

# Harmonisation du shapefile
frontieres <- frontieres |> 
  mutate(region = clean_region(adm1_name))

# --- Q4 : Diagnostic des valeurs manquantes
gg_miss_var(menages) + theme_minimal()
gg_miss_upset(menages, nsets = 10)

# Sauvegarde pour vérification
write_rds(menages, "data/processed/menages_brut.rds")

# --- Q5 : Imputation multiple (revenu et taille)
# 
# EXPLICATION DU MÉCANISME DE NON-RÉPONSE (MAR) :
# Hypothèse : les valeurs manquantes de "revenu" et "taille_menage" dépendent
# de la région (ex: certaines régions déclarent moins bien leur revenu).
# C'est un mécanisme Missing At Random (MAR) car la cause est observable (region).
# On utilise MICE avec la méthode "pmm" (Predictive Mean Matching) pour imputer.

vars_a_imputer <- c("revenu", "taille_menage")

# Initialisation pour détecter les méthodes par défaut
init <- mice(menages |> select(all_of(vars_a_imputer), region), 
             maxit = 0, method = "pmm")
meth <- init$method
meth[vars_a_imputer] <- "pmm"  # On force PMM pour les deux variables

# Lancement de l'imputation (5 jeux de données, 10 itérations)
imp <- mice(menages |> select(all_of(vars_a_imputer), region), 
            method = meth, m = 5, maxit = 10, seed = 123)
menages_impute <- complete(imp, action = 1)  

# On remplace les colonnes originales par les valeurs imputées
menages <- menages |> 
  select(-all_of(vars_a_imputer)) |> 
  bind_cols(menages_impute |> select(all_of(vars_a_imputer)))

# --- Q6 : Recodages des variables catégorielles
menages <- menages |> 
  mutate(
    # Milieu : 1 = Urbain, 2 = Rural
    milieu = factor(milieu, levels = c(1,2), labels = c("Urbain", "Rural")),
    # Niveau d'éducation du chef (déjà en caractère, on le met en facteur ordonné)
    edu_chef = factor(edu_chef, levels = c("Aucun", "Primaire", "Secondaire", "Superieur")),
    # Quintiles de revenu par tête (pour analyses transversales)
    revenu_quintile = factor(ntile(revenu, 5), levels = 1:5, labels = paste0("Q", 1:5))
  )

# Sauvegarde clean
write_rds(menages, "data/processed/menages_clean.rds")

# Nettoyage mémoire
rm(chef, conso_agg, conso, individus, chocs)


# ============================================================================
# SECTION 2 : Statistiques descriptives pondérées et indices (Q7 à Q11)
# ============================================================================

library(srvyr)
library(gtsummary)
library(DescTools)
library(flextable)

menages <- read_rds("data/processed/menages_clean.rds")

# --- Q8 : HDDS et classification FAO ---------------------------------------
menages <- menages |> 
  mutate(
    hdds = pmin(hdds_brut, 12),   # on plafonne à 12
    securite_alim = case_when(
      hdds <= 4 ~ "Sévère",
      hdds <= 6 ~ "Modérée",
      TRUE ~ "Acceptable"
    )
  )

# --- Q9 : Indice composite de vulnérabilité -------------------------------
menages <- menages |> 
  mutate(
    nb_chocs = rowSums(pick(starts_with("choc_")), na.rm = TRUE),
    nb_adapt = rowSums(pick(starts_with("strat_")), na.rm = TRUE)
  ) |> 
  mutate(
    std_chocs = scale(nb_chocs)[,1],
    std_adapt = scale(nb_adapt)[,1],
    indice_vuln = (std_chocs + std_adapt) / 2
  ) |> 
  mutate(
    classe_vuln = case_when(
      indice_vuln < -0.5 ~ "Faible",
      indice_vuln < 0.5 ~ "Moyenne",
      TRUE ~ "Élevée"
    )
  )

# --- Q7 : Déclaration du plan de sondage (après les mutations) ------------
# MAINtenant que toutes les colonnes sont créées, on déclare le design.
design <- menages |> 
  as_survey_design(id = grappe, strata = strate, weights = poids_final)

# --- Q10 : Tableau 1 (pondéré) avec gtsummary -----------------------------
tab1 <- design |> 
  tbl_svysummary(
    by = milieu,
    include = c(region, revenu, hdds, indice_vuln, securite_alim, classe_vuln),
    statistic = all_continuous() ~ "{mean} ({sd})",
    digits = all_continuous() ~ 2
  ) |> 
  add_p() |> 
  as_flex_table()

save_as_docx(tab1, path = "outputs(partie1)/tables/tableau1.docx")

# --- Q11 : Coefficient de Gini (national et par région) -------------------
# 
# EXPLICATION : Le coefficient de Gini mesure l'inégalité de répartition du revenu.
# Plus il est proche de 1, plus les inégalités sont fortes.
# On pondère par les poids de sondage pour avoir une estimation nationale juste.
# L'intervalle de confiance est obtenu par bootstrap (500 réplications).

calc_gini <- function(data, col, w) {
  DescTools::Gini(data[[col]], weights = data[[w]], na.rm = TRUE)
}

# National avec bootstrap
set.seed(42)
boot_gini <- replicate(500, {
  idx <- sample(1:nrow(menages), replace = TRUE)
  d <- menages[idx, ]
  calc_gini(d, "revenu", "poids_final")
})
gini_nat <- calc_gini(menages, "revenu", "poids_final")
ic_gini <- quantile(boot_gini, c(0.025, 0.975))

tibble(national = gini_nat, lower = ic_gini[1], upper = ic_gini[2]) |> 
  write_csv("outputs(partie1)/tables/gini_national.csv")

# Par région
menages |> 
  group_by(region) |> 
  summarise(gini = DescTools::Gini(revenu, weights = poids_final)) |> 
  write_csv("outputs(partie1)/tables/gini_regions.csv")


# ============================================================================
# SECTION 3 : Visualisation (Q12 à Q15)
# ============================================================================

library(sf)
library(tmap)
library(patchwork)
library(ggplot2)

# Recharger le shapefile
frontieres <- st_read("data/raw/tcd_admin1.shp") |> 
  mutate(region = clean_region(adm1_name))

# --- Q12 : Densités du revenu par région (échelle log)
# 
# EXPLICATION : Le revenu est très asymétrique (quelques ménages très riches).
# On utilise une échelle logarithmique (scale_x_log10) pour mieux visualiser
# la distribution de la majorité des ménages (partie basse de la distribution).

p_dens <- menages |> 
  ggplot(aes(x = revenu, fill = region, color = region)) +
  geom_density(alpha = 0.3, adjust = 1.5) +
  scale_x_log10(labels = scales::comma) +
  labs(title = "Distribution du revenu par tête (échelle log)") +
  theme_minimal(base_size = 12) +
  theme(legend.position = "bottom")

# --- Q13 : Carte choroplèthe (statique + interactive) ---------------------
data_carte <- menages |> 
  group_by(region) |> 
  summarise(vuln_moyen = mean(indice_vuln, na.rm = TRUE))

carte_sf <- frontieres |> left_join(data_carte, by = "region")

# Statique
p_map <- carte_sf |> 
  ggplot(aes(fill = vuln_moyen)) +
  geom_sf(color = "white", size = 0.2) +
  scale_fill_viridis_c(option = "plasma", na.value = "grey90") +
  labs(title = "Vulnérabilité moyenne par région") +
  theme_void()

# Interactive (tmap) - s'affiche dans le viewer RStudio
tmap_mode("view")
tm_shape(carte_sf) +
  tm_polygons(col = "vuln_moyen", palette = "plasma", 
              title = "Indice vulnérabilité") +
  tm_view(set.zoom.limits = c(5, 10))

# --- Q14 : Patchwork (3 graphiques) ---------------------------------------
p_bar <- menages |> 
  ggplot(aes(x = securite_alim, fill = milieu)) +
  geom_bar(position = "dodge") +
  labs(title = "Sécurité alimentaire par milieu") +
  theme_minimal()

composition <- (p_dens + p_map) / p_bar + 
  plot_annotation(title = "Synthèse ENSAN 2026", theme = theme_minimal())

# --- Q15 : Export en PNG et PDF -------------------------------------------
ggsave("outputs(partie1)/figures/composition.png", composition, width = 12, height = 10, dpi = 300)
ggsave("outputs(partie1)/figures/composition.pdf", composition, width = 12, height = 10)
ggsave("outputs(partie1)/figures/densite_revenu.png", p_dens, dpi = 300)
ggsave("outputs(partie1)/figures/carte_vuln.png", p_map, dpi = 300)


