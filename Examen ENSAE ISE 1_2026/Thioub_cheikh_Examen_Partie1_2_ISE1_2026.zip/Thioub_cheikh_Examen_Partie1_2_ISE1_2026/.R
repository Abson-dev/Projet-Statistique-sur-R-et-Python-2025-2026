library(tidyverse)
library(haven)      
library(readxl)     
library(sf)         
library(naniar)
library(mice)
library(dplyr)
# 1.Importqtion des 5 sources brutes



base_menage_brute <- haven::read_dta("data/raw/ensan_menages.dta")
names(base_menage_brute)

#colonne importqnte id_menage, region, milieu, grappe, strate, poids_final, revenu, taille_menage

base_individu_brute <- readr::read_csv(
  "data/raw/ensan_individus.csv",
  locale = locale(encoding = "UTF-8")
)
names(base_individu_brute)
# Colonnesimportante : id_menage, id_individu, age, sexe, niveau_education, rang_menage

feuilles_conso <- readxl::excel_sheets("data/raw/ensan_consommation.xlsx")
print(feuilles_conso) 




base_choc_brute <- readr::read_csv("data/raw/chocs_menages.csv")
                      
names(base_choc_brute)

admin1_sf <- sf::st_read("data/raw/tcd_admin1.shp")
#systeme de projection
sf::st_crs(admin1_sf)

base_prix_brute <- readr::read_csv("data/raw/prix_marches.csv")
names(base_prix_brute)


# 2.Fusion des bases

chef_menage <- base_individu_brute |>
  filter(rang == 1) |>
  distinct(hhid, .keep_all = TRUE) |>          # sécurité anti-doublon
  select(hhid, age_cm = age, sexe_cm = sexe, niveau_educ_cm = niveau_educ)

conso_groupes <- readxl::read_excel(
  "data/raw/ensan_consommation.xlsx",
  sheet = "Consommation_groupes"
)

names(conso_groupes)

# Les 12 groupes FAO
colonnes_groupes_fao <- c(
  "cons_cereales", "cons_tubercules", "cons_legumineuses", "cons_legumes",
  "cons_fruits", "cons_viande", "cons_poisson", "cons_oeufs",
  "cons_lait", "cons_huile", "cons_sucre", "cons_condiments"
)


conso_agregee <- conso_groupes |>
  rowwise() |>
  mutate(nb_groupes_consommes = sum(c_across(all_of(colonnes_groupes_fao)), na.rm = TRUE)) |>
  ungroup() |>
  select(hhid, nb_groupes_consommes)

n_avant <- nrow(menage_fusion)
verifier_lignes <- function(df) { stopifnot(nrow(df) == n_avant); df }

menages_enrichi <- menage_fusion |>
  left_join(chef_menage,   by = "hhid") |> verifier_lignes() |>
  left_join(conso_agregee, by = "hhid") |> verifier_lignes() |>
  left_join(
    base_choc_brute |> select(-region_lib),  
    by = "hhid"
  ) |> verifier_lignes()

message("Lignes avant : ", n_avant, " | Lignes après fusion : ", nrow(menages_enrichi))





# # verificqtion qvqnt toute jointure spatiale
# Regardons d'abord les valeurs distinctes dans chaque source concernant les regions:
base_menage_brute    |> distinct(region) |> print(n = 30)
head(admin1_sf |> distinct(adm1_name), 30)


# on voit que lq base menage region est en casse mixte avec accents ("Guéra", "N'Djamena", ...)
# alors que est le fichier shp est  en MAJUSCULES avec accents ("GUÉRA", "N'DJAMENA", ...)
# donc on standardise tout en MAJUSCULES, sans espaces superflus

menage_fusion <- base_menage_brute |>
  mutate(region_std = str_to_upper(str_squish(region)))

choc_fusion <- base_choc_brute |>
  mutate(region_lib_std = str_to_upper(str_squish(region_lib)))

admin1_sf <- admin1_sf |>
  mutate(region_std = str_to_upper(str_squish(adm1_name)))

# Vérification qu'il n'y a pas de région orpheline après standardisation
setdiff(menage_fusion$region_std, admin1_sf$region_std)  
setdiff(admin1_sf$region_std,   menage_fusion$region_std)

# Vérification cohérence base_choc_brute$region_lib vs base_menage_brute$region (doublon potentiel)
setdiff(choc_fusion$region_lib_std, menage_fusion$region_std)





# 4. Diagnostic des valeurs manquantes (naniar)

naniar::miss_var_summary(menages_enrichi) |> print(n = 30)
naniar::vis_miss(menages_enrichi)
naniar::gg_miss_upset(menages_enrichi)

# Distinction NA standards / valeurs taguées Stata
haven::is_tagged_na(menages_enrichi$revenu) |> table()   
haven::is_tagged_na(menages_enrichi$niveau_educ_cm) |> table()
haven::is_tagged_na(menages_enrichi$taille_menage) |> table()

# 5. Hypothèses de mécanisme de non-réponse et imputation multiple 


#  - `revenu` : hypothèse MAR -> la non-réponse semble liée au  milieu et
#    qu niveau d4education niveau_educ_cm, deux variables observées dans le jeu de données. Mais surtout a la culture , en afrique cèest culturel de ne pas declarer son revenu
#  - `age_cm` : hypothèse MCAR ->erreurs de saisie aléatoires supposées ou bien le chef de menage ne connait pas son age



vars_imputation <- menages_enrichi |>
  select(revenu, age_cm, niveau_educ_cm, milieu, region_std, taille_menage,
         nb_groupes_consommes)

imp <- mice::mice(vars_imputation, m = 5, method = "pmm", seed = 123, printFlag = FALSE)
menages_imp <- mice::complete(imp, 1)

menages_enrichi <- menages_enrichi |>
  mutate(revenu = menages_imp$revenu,
         age_cm = menages_imp$age_cm)

# -----------------------------------------------------------------
# 6. Recodage des variables catégorielles
# ----------eae-------------------------------------------------------
menages_final <- menages_enrichi |>
  mutate(
    milieu = factor(milieu, levels = c(1, 2), labels = c("Urbain", "Rural")), 
    niveau_educ_cm_cat = factor(milieu, levels = c(1, 2,3,4), labels = c("Aucun", "Primaire","Secondaire","Superieur")),  
    revenu_pc = revenu / taille_menage,
    quintile_revenu = ntile(revenu_pc, 5)
  )
unique(menages_enrichi$niveau_educ_cm)

# -----------------------------------------------------------------
# Sauvegardes
# -----------------------------------------------------------------

saveRDS(menages_final,     "data/processed/menages_final.rds")
saveRDS(admin1_sf,         "data/processed/admin1_sf.rds")
saveRDS(prix_marches_raw,  "data/processed/prix_marches_raw.rds")
saveRDS(conso_groupes,    "data/processed/conso_depenses.rds")
