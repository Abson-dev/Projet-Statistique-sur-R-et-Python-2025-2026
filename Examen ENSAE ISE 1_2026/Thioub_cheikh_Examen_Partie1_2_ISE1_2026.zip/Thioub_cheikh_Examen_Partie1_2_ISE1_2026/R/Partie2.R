library(httr)
library(jsonlite)
library(dplyr)
library(readr)

# Creons lq requete API
codes_des_series <- c(
  "SP_DYN_MRBF15",
  "SP_DYN_MRBF18",
  "SH_STA_MORT",
  "SL_TLF_NEET",
  "SP_DYN_ADKL",
  "SH_STA_BRTC"
)


base_url <- "https://unstats.un.org/SDGAPI/v1/sdg/Series/Data"


liste_data <- list()


for(code in codes_des_series){
  
  url <- paste0(
    base_url,
    "?seriesCode=",
    code
  )
  
  res <- GET(url)
  
  json <- fromJSON(
    content(res, as="text", encoding="UTF-8"),
    flatten = TRUE
  )
  
  
  # récupération brute
  data_code <- json$data
  
  
  
  colonnes_manquantes <- c(
    "attributes.Nature",
    "attributes.Units",
    "dimensions.Age",
    "dimensions.Sex",
    "dimensions.Reporting Type"
  )
  
  
  for(col in colonnes_manquantes){
    if(!col %in% names(data_code)){
      data_code[[col]] <- NA_character_
    }
  }
  
  
  data_code <- data_code |>
    transmute(
      
      serie = series,
      indicateur = seriesDescription,
      pays_code = geoAreaCode,
      pays = geoAreaName,
      annee = timePeriodStart,
      valeur = value,
      nature = `attributes.Nature`,
      unite = `attributes.Units`,
      age = `dimensions.Age`,
      sexe = `dimensions.Sex`,
      type_reporting = `dimensions.Reporting Type`
    )
  
  
  liste_data[[code]] <- data_code
}


base_extraite <- bind_rows(liste_data)

# 2  10  premieres lignes 
head(base_extraite)


# 3 sauvegarde
write_csv(
  base_extraite,
  "data/processed/ODD_indicateurs_mariage_mortalite.csv"
)

# 4 importation
df <- read_csv(
  "data/processed/ODD_indicateurs_mariage_mortalite.csv"
)





