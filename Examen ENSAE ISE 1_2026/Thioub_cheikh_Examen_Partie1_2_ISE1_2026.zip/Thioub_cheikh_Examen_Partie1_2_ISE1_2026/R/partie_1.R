library(tidyverse)
library(haven)      
library(readxl)     
library(sf)         
library(naniar)
library(mice)
library(dplyr)
library(srvyr)
library(gtsummary)
library(boot)
library(sf)
library(tmap)
library(patchwork)


# 1.Importqtion des 5 sources brutes



base_menage_brute <- haven::read_dta("data/raw/ensan_menages.dta")
names(base_menage_brute)



base_individu_brute <- readr::read_csv(
  "data/raw/ensan_individus.csv",
  locale = locale(encoding = "UTF-8")
)
names(base_individu_brute)


feuilles_conso <- readxl::excel_sheets("data/raw/ensan_consommation.xlsx")
print(feuilles_conso) 




base_choc_brute <- readr::read_csv("data/raw/chocs_menages.csv")

names(base_choc_brute)

admin1_sf <- sf::st_read("data/raw/tcd_admin1.shp")
#systeme de projection
sf::st_crs(admin1_sf)

base_prix_brute <- readr::read_csv("data/raw/prix_marches.csv")
names(base_prix_brute)


# 2.Fusion des bases

menage_fusion <- base_menage_brute |>
  mutate(region_std = str_to_upper(str_squish(region)))


chef_menage <- base_individu_brute |>
  filter(rang == 1) |>
  distinct(hhid, .keep_all = TRUE) |>          
  select(hhid, age_cm = age, sexe_cm = sexe, niveau_educ_cm = niveau_educ)

conso_groupes <- readxl::read_excel(
  "data/raw/ensan_consommation.xlsx",
  sheet = "Consommation_groupes"
)

names(conso_groupes)

# Les 12 groupes FAO
colonnes_groupes_fao <- c(
  "cons_cereales", "cons_tubercules", "cons_legumineuses", "cons_legumes",
  "cons_fruits", "cons_viande", "cons_poisson", "cons_oeufs",
  "cons_lait", "cons_huile", "cons_sucre", "cons_condiments"
)


conso_agregee <- conso_groupes |>
  rowwise() |>
  mutate(nb_groupes_consommes = sum(c_across(all_of(colonnes_groupes_fao)), na.rm = TRUE)) |>
  ungroup() |>
  select(hhid, nb_groupes_consommes)

n_avant <- nrow(menage_fusion)
verifier_lignes <- function(df) { stopifnot(nrow(df) == n_avant); df }

menages_enrichi <- menage_fusion |>
  left_join(chef_menage,   by = "hhid") |> verifier_lignes() |>
  left_join(conso_agregee, by = "hhid") |> verifier_lignes() |>
  left_join(
    base_choc_brute |> select(-region_lib),  
    by = "hhid"
  ) |> verifier_lignes()

message("Lignes avant : ", n_avant, " | Lignes après fusion : ", nrow(menages_enrichi))





# 3 verificqtion qvqnt toute jointure spatiale
# Regardons d'abord les valeurs distinctes dans chaque source concernant les regions:
base_menage_brute    |> distinct(region) |> print(n = 30)
head(admin1_sf |> distinct(adm1_name), 30)


# on voit que lq base menage region est en casse mixte avec accents ("Guéra", "N'Djamena", ...)
# alors que est le fichier shp est  en MAJUSCULES avec accents ("GUÉRA", "N'DJAMENA", ...)
# donc on standardise tout en MAJUSCULES, sans espaces superflus

menage_fusion <- base_menage_brute |>
  mutate(region_std = str_to_upper(str_squish(region)))

choc_fusion <- base_choc_brute |>
  mutate(region_lib_std = str_to_upper(str_squish(region_lib)))

admin1_sf <- admin1_sf |>
  mutate(region_std = str_to_upper(str_squish(adm1_name)))

# Vérification qu'il n'y a pas de région orpheline après standardisation
setdiff(menage_fusion$region_std, admin1_sf$region_std)  
setdiff(admin1_sf$region_std,   menage_fusion$region_std)


setdiff(choc_fusion$region_lib_std, menage_fusion$region_std)





# 4. Diagnostic des valeurs manquantes (naniar)

naniar::miss_var_summary(menages_enrichi) |> print(n = 30)
naniar::vis_miss(menages_enrichi)
naniar::gg_miss_upset(menages_enrichi)


haven::is_tagged_na(menages_enrichi$revenu) |> table()   
haven::is_tagged_na(menages_enrichi$niveau_educ_cm) |> table()
haven::is_tagged_na(menages_enrichi$taille_menage) |> table()

# 5. Hypothèses de mécanisme de non-réponse et imputation multiple 


#  - `revenu` : hypothèse MAR -> la non-réponse semble liée au  milieu et
#    qu niveau d4education niveau_educ_cm, deux variables observées dans le jeu de données. Mais surtout a la culture , en afrique cèest culturel de ne pas declarer son revenu
#  - `age_cm` : hypothèse MCAR ->erreurs de saisie aléatoires supposées ou bien le chef de menage ne connait pas son age



vars_imputation <- menages_enrichi |>
  select(revenu, age_cm, niveau_educ_cm, milieu, region_std, taille_menage,
         nb_groupes_consommes)

imp <- mice::mice(vars_imputation, m = 5, method = "pmm", seed = 123, printFlag = FALSE)
menages_imp <- mice::complete(imp, 1)

menages_enrichi <- menages_enrichi |>
  mutate(revenu = menages_imp$revenu,
         age_cm = menages_imp$age_cm)


# 6. Recodage des variables catégorielles

menages_final <- menages_enrichi |>
  mutate(
    milieu = factor(milieu, levels = c(1, 2), labels = c("Urbain", "Rural")), 
    niveau_educ_cm_cat = factor(milieu, levels = c(1, 2,3,4), labels = c("Aucun", "Primaire","Secondaire","Superieur")),  
    revenu_pc = revenu / taille_menage,
    quintile_revenu = ntile(revenu_pc, 5)
  )
unique(menages_enrichi$niveau_educ_cm)


# Sauvegardons 

saveRDS(menages_final,     "data/processed/menages_final.rds")
saveRDS(admin1_sf,         "data/processed/admin1_sf.rds")
saveRDS(base_prix_brute,  "data/processed/prix_marches_raw.rds")
saveRDS(conso_groupes,    "data/processed/conso_depenses.rds")



# Section 2

# 7. Déclarons le plan de sondage complet

design_menages <- menages_final |>
  as_survey_design(
    ids     = grappe,
    strata  = strate,
    weights = poids_final,
    nest    = TRUE
  )



# 8. Score de diversité alimentaire des ménages   classification FAO

menages_final <- menages_final |>
  mutate(
    hdds = nb_groupes_consommes,   
    classe_fao = case_when(
      hdds <= 3 ~ "Pauvre",
      hdds <= 5 ~ "Limite",
      hdds >= 6 ~ "Acceptable",
      
    )
  )

design_menages <- menages_final |>
  as_survey_design(ids = grappe, strata = strate, weights = poids_final, nest = TRUE)




# 9. Indice composite de vulnérabilité aux chocs

# Il est clair que la construction d'un indice composite est tres subjective cependant nous avons essaye de prendre en compte nombre de chocs distincts subis (0-4) parmi sécheresse,
#    hausse des prix, conflit, maladie -> mesure l'exposition et la somme somme pondérée des stratégies d'adaptation,
#    pondération croissante 
#  - l'indice final est ramené sur une échelle 0-100 (min-max) pour la lisibilité comme faut dans les TP en cours 

menages_final <- menages_final |>
  mutate(
    nb_chocs = choc_secheresse + choc_hausse_prix + choc_conflit + choc_maladie,
    intensite_strategies =
      1 * strat_reduction_repas +
      2 * strat_vente_actifs +
      2 * strat_endettement +
      3 * strat_migration,
    indice_vulnerabilite_brut = nb_chocs + intensite_strategies,
    indice_vulnerabilite = (indice_vulnerabilite_brut - min(indice_vulnerabilite_brut, na.rm = TRUE)) /
      diff(range(indice_vulnerabilite_brut, na.rm = TRUE)) * 100
  )

design_menages <- menages_final |>
  as_survey_design(ids = grappe, strata = strate, weights = poids_final, nest = TRUE)




# 10. Tableau 1 pondéré (gtsummary)

tableau1 <- design_menages |>
  select(milieu, region_std, hdds, indice_vulnerabilite, revenu_pc,
         niveau_educ_cm_cat, taille_menage) |>
  tbl_svysummary(
    by = milieu,
    statistic = list(all_continuous() ~ "{mean} ({sd})"),
    missing = "no"
  ) |>
  add_p() |>
  add_n() |>
  bold_labels()

tableau1


# 11. Coefficient de Gini pondéré du revenu par tête


# . Fonction Gini pondéré

gini_pondere <- function(data, indices, poids) {
  
  revenu <- data[indices]
  poids_boot <- poids[indices]
  
  # Tri par revenu
  ordre <- order(revenu)
  
  revenu <- revenu[ordre]
  poids_boot <- poids_boot[ordre]
  
  # Sécurité contre valeurs invalides
  if(sum(poids_boot) == 0 || sum(poids_boot * revenu) == 0){
    return(NA)
  }
  
  # Courbes cumulées pondérées
  cum_poids <- cumsum(poids_boot) / sum(poids_boot)
  cum_revenu <- cumsum(poids_boot * revenu) / sum(poids_boot * revenu)
  
  # Coefficient de Gini
  gini <- 1 - sum(
    (cum_revenu[-1] + cum_revenu[-length(cum_revenu)]) *
      diff(cum_poids)
  )
  
  return(gini)
}



# Préparation des données


gini_data <- menages_final %>%
  filter(
    !is.na(revenu_pc),
    !is.na(poids_final),
    revenu_pc >= 0,
    poids_final > 0
  )


# Vérification
cat("Nombre de ménages utilisés :", nrow(gini_data), "\n")


#  Gini national

gini_national <- gini_pondere(
  data = gini_data$revenu_pc,
  indices = seq_len(nrow(gini_data)),
  poids = gini_data$poids_final
)

cat("Gini national :", round(gini_national, 3), "\n")



# 4. Bootstrap national (1000 réplications)


set.seed(123)

boot_gini_national <- boot(
  data = gini_data$revenu_pc,
  statistic = function(data, i){
    gini_pondere(
      data = data,
      indices = i,
      poids = gini_data$poids_final[i]
    )
  },
  R = 1000
)


# Suppression éventuelle des réplications invalides
boot_values <- boot_gini_national$t[
  !is.na(boot_gini_national$t)
]


# Intervalle de confiance percentile
IC_gini <- quantile(
  boot_values,
  probs = c(0.025, 0.975)
)


cat(
  "IC 95% bootstrap :",
  round(IC_gini[1],3),
  "-",
  round(IC_gini[2],3),
  "\n"
)



#  Résultat final sous forme de tableau

resultat_gini <- data.frame(
  Niveau = "National",
  Gini = round(gini_national,3),
  IC_inf = round(IC_gini[1],3),
  IC_sup = round(IC_gini[2],3)
)

print(resultat_gini)



# . Gini régional 

gini_region <- gini_data %>%
  group_by(region) %>%
  group_modify(~{
    
    g <- gini_pondere(
      data = .x$revenu_pc,
      indices = seq_len(nrow(.x)),
      poids = .x$poids_final
    )
    
    data.frame(
      Gini = round(g,3)
    )
  })


print(gini_region)

# Sauvegardes

dir.create("outputs/tables", showWarnings = FALSE, recursive = TRUE)
saveRDS(menages_final,    "data/processed/menages_final.rds")
saveRDS(tableau1,         "outputs/tables/tableau1.rds")
saveRDS(gini_national,    "outputs/tables/gini_national.rds")
saveRDS(gini_region,  "outputs/tables/gini_region.rds")


# Section 3 

# On va essayer de creer un template de decoration que l'on va utiliser dans tout le projet 
palette <- c(
  "#4B3F72",  
  "#A45C40",  
  "#2F6B5E",  
  "#C08552",  
  "#5C7A99",  
  "#8E4162"   
)


pal_continue <- colorRampPalette(c("#2F4B5E", "#C08552", "#8E4162"))

theme_ensan <- function() {
  theme_minimal(base_family = "sans", base_size = 12) +
    theme(
      plot.title = element_text(face = "bold", size = 13),
      panel.grid.minor = element_blank(),
      legend.position = "bottom"
    )
}
theme_set(theme_ensan())





# 12. Distribution du revenu par tete par region 

g_densite <- menages_final |>
  ggplot(aes(x = revenu_pc, fill = region_std, color = region_std)) +
  geom_density(alpha = 0.25, linewidth = 0.4) +
  scale_x_continuous(trans = "log10", labels = scales::comma) +
  scale_fill_manual(values = rep(palette, length.out = n_distinct(menages_final$region_std))) +
  scale_color_manual(values = rep(palette, length.out = n_distinct(menages_final$region_std))) +
  guides(fill = "none", color = "none") +
  labs(
    title = "Distribution du revenu par tête selon la région",
    x = "Revenu par tête (FCFA, échelle log)", y = "Densité"
  )


# 13. Carte choroplèthe et interactive 

indice_region <- menages_final |>
  group_by(region_std) |>
  summarise(indice_vulnerabilite_moy = weighted.mean(indice_vulnerabilite, poids_final, na.rm = TRUE))

carte_data <- admin1_sf |>
  left_join(indice_region, by = "region_std")

carte_data |> st_drop_geometry() |> filter(is.na(indice_vulnerabilite_moy)) |> select(region_std)

g_carte <- ggplot(carte_data) +
  geom_sf(aes(fill = indice_vulnerabilite_moy), color = "white", linewidth = 0.2) +
  scale_fill_gradientn(colors = pal_continue(100)) +
  labs(title = "Indice de vulnérabilité moyen par région", fill = "Indice (0-100)") +
  theme_void() + theme(legend.position = "bottom")

ggsave("outputs/figures/carte_vulnerabilite.png", g_carte, width = 8, height = 6, dpi = 300)
ggsave("outputs/figures/carte_vulnerabilite.pdf", g_carte, width = 8, height = 6)


tmap_mode("view")
carte_interactive <- tm_shape(carte_data) +
  tm_polygons("indice_vulnerabilite_moy",
              palette = pal_continue(7), title = "Indice de vulnérabilité") +
  tm_layout(title = "Vulnérabilité par région (interactif)")
carte_interactive
tmap_save(carte_interactive, "outputs/figures/carte_vulnerabilite_interactive.html")

# 15. Export haute résolution


ggsave("outputs/figures/densite_revenu.png",   g_densite, width = 8, height = 5, dpi = 300)
ggsave("outputs/figures/densite_revenu.pdf",   g_densite, width = 8, height = 5)






