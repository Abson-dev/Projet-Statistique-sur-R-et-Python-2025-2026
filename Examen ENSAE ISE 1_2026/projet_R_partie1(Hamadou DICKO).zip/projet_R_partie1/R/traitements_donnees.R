library(dplyr)
library(haven)
library(readxl)
library(tidyverse)
library(naniar)
library(stringr)
library(gt)
#--------------------------------------------------------------------------------------------------------
# 1. Importations et observations des cinq (05) bases et 
#--------------------------------------------------------------------------------------------------------

chocs = read_csv("./data/raw/chocs_menages.csv")
consommation = read_excel("./data/raw/ensan_consommation.xlsx", col_names = TRUE, sheet = "Consommation_groupes")
individus = read_csv("./data/raw/ensan_individus.csv")
menages = read_dta("./data/raw/ensan_menages.dta")
prix = read_csv("./data/raw/prix_marches.csv")

View(menages)
View(chocs)
View(consommation)
View(individus)
View(prix)
#--------------------------------------------------------------------------------------------------------
# 2. Jointures des bases pour la base ménage enrichie
#--------------------------------------------------------------------------------------------------------

base_enrichi1 = left_join(menages, consommation, by = "hhid") |>
               left_join(chocs, by = "hhid")

base_intermediaire = individus |>
  filter(rang==1)

base_intermediaire = base_intermediaire[unique(base_intermediaire$hhid),]

base_enrichi = left_join(base_enrichi1, base_intermediaire, by = "hhid")

nrow(base_enrichi)
nrow(menages)
colnames(base_enrichi)

#--------------------------------------------------------------------------------------------------------
# 3. Identification et corrections des libellés de régions incohérents entre fichiers
#--------------------------------------------------------------------------------------------------------

chocs = chocs |>
       mutate(region_lib = region_lib |>
              str_to_lower() |>
              str_to_title() |>
              str_replace_all("_", " "))

menages = menages |>
  mutate(region = region |>
           str_replace_all(" ", "_")|>
           str_to_lower() |>
           str_to_title() |>
           str_replace_all("_", " "))

prix = prix |>
  mutate(region = region |>
           str_replace_all(" ", "_")|>
           str_to_lower() |>
           str_to_title() |>
           str_replace_all("_", " "))

base_enrichi = base_enrichi|>
  mutate(region = region |>
           str_replace_all(" ", "_")|>
           str_to_lower() |>
           str_to_title() |>
           str_replace_all("_", " "))

base_enrichi = base_enrichi |>
  mutate(region_lib = region_lib |>
           str_to_lower() |>
           str_to_title() |>
           str_replace_all("_", " "))
#--------------------------------------------------------------------------------------------------------
# 4. Diagnostics des valeurs manquantes
#--------------------------------------------------------------------------------------------------------

#----------------------------------------------------
# 4.1. Diagnostics de la base chocs
#----------------------------------------------------

#Résumé
miss_var_summary(chocs)
cat("Dans la base chocs_menages.csv, aucune variable ne compte de valeurs manquantes")

#Visualisation : heatmap et diagramme en barres des valeurs manquantes
vis_miss(chocs)
gg_miss_var(chocs)

#Les coocurrences ou duplications
chocs[duplicated(chocs$hhid),]

#----------------------------------------------------
# 4.2. Diagnostics de la base consommation
#----------------------------------------------------

#Résumé
miss_var_summary(consommation)
cat("Dans la base ensan_consommation.xlsx, aucune variable ne compte de valeurs manquantes")

#Visualisation : heatmap et diagramme en barres des valeurs manquantes
vis_miss(consommation)
gg_miss_var(consommation)

#Les coocurrences ou duplications
chocs[duplicated(consommation$hhid),]


#----------------------------------------------------
# 4.3. Diagnostics de la base individus
#----------------------------------------------------

#Résumé
miss_var_summary(individus)
cat("Dans la base individus, aucune variable ne compte de valeurs manquantes")

#Visualisation : heatmap et diagramme en barres des valeurs manquantes
vis_miss(individus)
gg_miss_var(individus)

#Les coocurrences ou duplications : construction d'un indentifiant unique pour chaque individus

individus$identifiant= paste(individus$hhid, individus$rang, sep = "_")
individus[duplicated(individus$identifiant),]
nombre = nrow(individus[duplicated(individus$identifiant),])

cat("Il y a dans la base individus", nombre, "coocurrences, uniquement des chefs de ménages qui se répètent")


#----------------------------------------------------
# 4.4. Diagnostics de la base menages
#----------------------------------------------------

#Résumé
tableau = miss_var_summary(menages)
tableau
cat("Dans la base ensan_menages.dta, les variables revenu et taille_menage compte des valeurs manquantes")

#Les valeurs manquantes tagguées
menages |> filter(is_tagged_na(revenu)) |> nrow() 
menages |> filter(is_tagged_na(taille_menage)) |> nrow() 

cat("Toutes les valeurs manquantes sont non tagguées")

#Visualisation : heatmap et diagramme en barres des valeurs manquantes
vis_miss(menages)
gg_miss_var(menages)
diagramme1 = gg_miss_var(menages)
#Les coocurrences ou duplications
menages[duplicated(menages$hhid),]

cat("Dans la base ensan_menages.dta, il n'y a pas de lignes dupliquées")

#----------------------------------------------------
# 4.5. Diagnostics de la base prix
#----------------------------------------------------

#Résumé
miss_var_summary(prix)
cat("Dans la base ensan_menages.dta, aucune variable ne compte de valeurs manquantes")

#Visualisation : heatmap et diagramme en barres des valeurs manquantes
vis_miss(prix)
gg_miss_var(prix)


#--------------------------------------------------------------------------------------------------------
# 6. Recodage les variables catégorielles 
#--------------------------------------------------------------------------------------------------------

base_enrichi = base_enrichi |>
  filter(!is.na(milieu))|>
  filter(!is.na(revenu))|>
  filter(!is.na(niveau_educ))
base_enrichi = base_enrichi |>
    mutate(milieu = factor(as.numeric(milieu), levels = c(1, 2), labels = c("Urbain", "Rural")),
           niveau_educ = factor(as.numeric(niveau_educ), levels = 1:4, labels = c("Aucun", "Primaire", "Secondaire", "Superieur")))
View(base_enrichi)

saveRDS(chocs,        "data/processed/data_chocs.rds")
saveRDS(consommation,  "data/processed/data_consommation.rds")
saveRDS(individus, "data/processed/base_individus.rds")
saveRDS(menages,        "data/processed/data_menages.rds")
saveRDS(prix,  "data/processed/data_prix.rds")
saveRDS(base_enrichi, "data/processed/base_enrichi.rds")


tableau2 = tableau |>
  gt() |>
  tab_header(
    title = "Tableau recapitulatif des valeurs manquantes"
  ) |>
  cols_label(
    "variable" = "variable",
    "n_miss" = "n_valeurs_manquantes",
    "pct_miss" = "pourcentage_manquant"
  ) |>
  fmt_percent(
    columns = "pct_miss",
    decimals = 1
  ) |>
  fmt_number(
    columns = "n_miss",
    decimals = 0
  ) 
tableau2
gtsave(tableau2, "./outputs/tables/tableau_valeursManquantes.png")

diagramme1 = diagramme1 +
             labs(title = "Diagramme en bâton des valeurs manquantes",
                  x = "Variables",
                  y ="Nombre de valeurs manquantes",
                  caption = "Source : Données du Tchad (Simulées)")+
             theme(plot.background = element_rect(fill = "#E8E0D5"),
                   panel.grid.minor = element_blank(),
                   panel.grid.major.y = element_blank(),
                   axis.text.x = element_text(face = "bold", size = 12),
                   plot.title = element_text(face = "bold", size = 14, color = "#3E2F25", hjust = .5),
                   plot.caption = element_text(face = "italic", size = 10, color = "#3E2F25", hjust = 0)
                   )

diagramme1
ggsave(filename = "./outputs/figures/diagramme_des_valeurs_manquantes.png", width = 18, height = 10, dpi = 300)