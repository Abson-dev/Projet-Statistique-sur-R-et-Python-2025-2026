# Chargement des packages nécessaires

library(haven)
library(openxlsx)
library(dplyr)
library(naniar)
library(ggplot2)

# Chargement des bases nécessaires

secta3i <- read_dta("secta3i_harvestw4.dta")
secta3ii <- read_dta("secta3ii_harvestw4.dta")
secta11c2 <- read_dta("secta11c2_harvestw4.dta")

# exploration des bases

## variables

### base secta3i

variables_secta3i <- data.frame(variable = names(secta3i),
                                libellé = sapply(secta3i, function(x) attr(x,"label")))
write.xlsx(variables_secta3i,"variables_secta3i.xlsx")

### base secta3ii

variables_secta3ii <- data.frame(variable = names(secta3ii),
                                 libellé = sapply(secta3ii, function(x) attr(x,"label")))
write.xlsx(variables_secta3ii,"variables_secta3ii.xlsx")

### base secta11c2

variables_secta11c2 <- data.frame(variable = names(secta11c2),
                                  libellé = sapply(secta11c2, function(x) attr(x,"label")))
write.xlsx(variables_secta11c2,"variables_secta11c2.xlsx")

## Donnons des noms explicites au variables de chaque base

### base secta3i

secta3i <- secta3i %>%
  rename(
    zone_geopoli = zone,
    etat = state,
    zone_gouvenmnt_loc = lga,
    milieu = sector,
    zone_denombre = ea,
    iden_menage = hhid,
    iden_parcelle = plotid,
    code_culture = cropcode,
    recolte_effectuee = sa3iq3,
    raison_non_recolte = sa3iq4,
    raison_non_recolte_autres = sa3iq4_os,
    mois_debut_recolte = sa3iq4a1,
    annee_debut_recolte = sa3iq4a2,
    surface_recoltee_inf_plantee = sa3iq4b,
    raison_surface_inf = sa3iq4c,
    pct_parcelle_recoltee = sa3iq5,
    qte_recoltee = sa3iq6i,
    unite_qte_recoltee = sa3iq6ii,
    taille_qte_recoltee = sa3iq6_4,
    etat_qte_recoltee = sa3iq6_2,
    facteur_conv_kg_recolte = sa3iq6_conv,
    valeur_estimee_recolte = sa3iq6a,
    recolte_complete = sa3iq6b,
    mois_fin_recolte = sa3iq6c1,
    annee_fin_recolte = sa3iq6c2,
    qte_recolte_prevue = sa3iq6d1,
    unite_recolte_prevue = sa3iq6d2,
    taille_recolte_prevue = sa3iq6d4,
    etat_recolte_prevue = sa3iq6d2a,
    facteur_conv_kg_prevu = sa3iq6d_conv,
    decideur_usage_recolte_1 = sa3iq6e_1,
    decideur_usage_recolte_2 = sa3iq6e_2,
    decideur_usage_recolte_3 = sa3iq6e_3,
    decideur_usage_recolte_4 = sa3iq6e_4,
    decideur_usage_recolte_5 = sa3iq6e_5,
    decideur_usage_recolte_6 = sa3iq6e_6,
    decideur_usage_recolte_7 = sa3iq6e_7,
    decideur_usage_recolte_8 = sa3iq6e_8
  )

### base secta3ii

secta3ii <- secta3ii %>%
  rename(
    zone_geopoli = zone,
    etat = state,
    zone_gouvenmnt_loc = lga,
    milieu = sector,
    zone_denombre = ea,
    iden_menage = hhid,
    code_culture = cropcode,
    qte_totale_recoltee = sa3iiq1a,
    unite_recolte_totale = sa3iiq1c,
    taille_recolte_totale = sa3iiq1d,
    etat_recolte_totale = sa3iiq1b,
    facteur_conv_kg = sa3iiq1_conv,
    vente_non_transformee = sa3iiq3,
    mois_vente_principale = sa3iiq4,
    annee_vente_principale = sa3iiq4b,
    qte_vendue = sa3iiq5a,
    valeur_ventes = sa3iiq6,
    lieu_vente_principal = sa3iiq7,
    lieu_vente_autres = sa3iiq7_os,
    responsable_vente_1 = sa3iiq8_1,
    responsable_vente_2 = sa3iiq8_2,
    responsable_vente_3 = sa3iiq8_3,
    responsable_vente_4 = sa3iiq8_4,
    responsable_vente_5 = sa3iiq8_5,
    decideur_revenus_vente_1 = sa3iiq9_1,
    decideur_revenus_vente_2 = sa3iiq9_2,
    delai_paiement_vente = sa3iiq10,
    usage_recolte_opt1 = sa3iiq10a_1,
    usage_recolte_opt2 = sa3iiq10a_2,
    usage_recolte_opt3 = sa3iiq10a_3,
    usage_recolte_opt4 = sa3iiq10a_4,
    usage_recolte_opt5 = sa3iiq10a_5,
    usage_recolte_opt6 = sa3iiq10a_6,
    usage_recolte_opt7 = sa3iiq10a_7,
    usage_recolte_opt8 = sa3iiq10a_8,
    usage_recolte_opt9 = sa3iiq10a_9,
    qte_stockee = sa3iiq11aa,
    qte_alimentation_animale = sa3iiq12a,
    qte_consommee_menage = sa3iiq13a,
    qte_paiement_travail = sa3iiq14a,
    qte_paiement_non_travail = sa3iiq15a,
    qte_metayage = sa3iiq16a,
    qte_dons = sa3iiq17a,
    qte_perdue = sa3iiq18a,
    qte_transformee_vendue = sa3iiq18aa,
    type_transformation = sa3iiq25,
    type_transformation_autres = sa3iiq25_os,
    qte_transf_vendue = sa3iiq20a,
    unite_transf_vendue = sa3iiq20b,
    unite_transf_autres = sa3iiq20b_os,
    taille_transf_vendue = sa3iiq20c,
    valeur_ventes_transf = sa3iiq21,
    responsable_vente_transf_1 = sa3iiq22_1,
    responsable_vente_transf_2 = sa3iiq22_2,
    responsable_vente_transf_3 = sa3iiq22_3,
    decideur_revenus_transf_1 = sa3iiq23_1,
    decideur_revenus_transf_2 = sa3iiq23_2,
    decideur_revenus_transf_3 = sa3iiq23_3,
    decideur_revenus_transf_4 = sa3iiq23_4,
    decideur_revenus_transf_5 = sa3iiq23_5,
    transformation_necessite_elec = sa3iiq26,
    source_electricite_transf = sa3iiq27
  )

### base secta11c2

secta11c2 <- secta11c2 %>%
  rename(
    zone_geopoli = zone,
    etat = state,
    zone_gouvenmnt_loc = lga,
    milieu = sector,
    zone_denombre = ea,
    iden_menage = hhid,
    iden_parcelle = plotid,
    utilisation_herbicides = s11c2q10,
    qte_herbicides = s11c2q11a,
    unite_herbicides = s11c2q11b,
    facteur_conv_herbicides = s11c2q11_conv,
    utilisation_pesticides = s11c2q1,
    qte_pesticides = s11c2q2a,
    unite_pesticides = s11c2q2b,
    facteur_conv_pesticides = s11c2q2_conv,
    utilisation_engrais_inorg = s11dq1a,
    type_engrais_npk = s11c2q36_1,
    type_engrais_uree = s11c2q36_2,
    type_engrais_autres = s11c2q36_99,
    type_engrais_autres_details = s11c2q36_os,
    qte_npk = s11c2q37a,
    unite_npk = s11c2q37b,
    facteur_conv_npk = s11c2q37a_conv,
    qte_uree = s11c2q38a,
    unite_uree = s11c2q38b,
    facteur_conv_uree = s11c2q38a_conv,
    qte_engrais_inorg_autres = s11c2q39a,
    unite_engrais_inorg_autres = s11c2q39b,
    facteur_conv_engrais_inorg_autres = s11c2q39a_conv,
    utilisation_engrais_org = s11dq36,
    qte_engrais_org = s11dq37a,
    unite_engrais_org = s11dq37b,
    facteur_conv_engrais_org = s11c2q37_conv,
    utilisation_traction_animale = s11c2q19,
    nb_jours_traction_propre = s11c2q20,
    nb_jours_traction_louee = s11c2q21,
    cout_location_traction = s11c2q23,
    cout_alimentation_animaux = s11c2q25,
    indisponibilite_animaux = s11c2q26,
    utilisation_machines = s11c2q27,
    indisponibilite_machines = s11c2q34
  )

## Sélection des variables d'intérêt pour chaque base

### base secta3i

secta3i <- secta3i %>%
  select(zone_geopoli, 
         etat, 
         zone_geopoli, 
         zone_gouvenmnt_loc, 
         zone_denombre,
         milieu,
         iden_menage,
         iden_parcelle,
         code_culture,
         recolte_effectuee,
         surface_recoltee_inf_plantee,
         pct_parcelle_recoltee,
         qte_recoltee,
         unite_qte_recoltee,
         taille_qte_recoltee, 
         etat_qte_recoltee,
         facteur_conv_kg_recolte,
         valeur_estimee_recolte,
         recolte_complete,
         qte_recolte_prevue,
         taille_recolte_prevue,
         etat_recolte_prevue,
         facteur_conv_kg_prevu
         )

### base secta3ii

secta3ii <- secta3ii %>%
  select(
    zone_geopoli,
    etat,
    zone_gouvenmnt_loc,
    milieu,
    zone_denombre,
    iden_menage,
    code_culture,
    qte_totale_recoltee,
    unite_recolte_totale,
    taille_recolte_totale,
    etat_recolte_totale,
    facteur_conv_kg 
  )

### base secta11c2

secta11c2 <- secta11c2 %>%
  select(
    zone_geopoli,
    etat,
    zone_gouvenmnt_loc,
    milieu,
    zone_denombre,
    iden_menage,
    iden_parcelle,
    utilisation_engrais_inorg,
    type_engrais_npk,
    type_engrais_uree,
    type_engrais_autres,
    type_engrais_autres_details,
    qte_npk,
    unite_npk,
    facteur_conv_npk,
    qte_uree,
    unite_uree,
    facteur_conv_uree,
    qte_engrais_inorg_autres,
    unite_engrais_inorg_autres,
    facteur_conv_engrais_inorg_autres,
    utilisation_engrais_org,
    qte_engrais_org,
    unite_engrais_org,
    facteur_conv_engrais_org
  )

## Valeurs manquantes

### base secta3i

#### vis_miss

graph1_valeurs_manquantes_secta3i <- vis_miss(secta3i) +
  labs(
    title = "Carte des valeurs manquantes de la base secta3i_harvestw4",
    subtitle = "Les lignes représentent les les observations et les colonnes, les variables") +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 7),
    axis.text.y = element_text(size = 8),
    axis.ticks.y = element_blank(),
    plot.margin = margin(t = 50, r = 20, b = 20, l = 20, unit = "pt")
  ) +
  scale_y_continuous(
    breaks = c(1, 1000, 2000, 3000, 4000, 5000, 6000, 7000,8000, 9000, 10000, 11000, 12000, 13000, 14000, 15000),
    labels = c("1","1000","2000","3000","4000","5000","6000","7000","8000","9000","10000","11000","12000","13000","14000","15000")
  )

##### Sauvegarde en PNG

ggsave(
  filename = "valeurs_manquantes1_secta3i.png",
  plot     = graph1_valeurs_manquantes_secta3i,
  width    = 12,      # largeur en pouces — augmenter si libellés encore coupés
  height   = 6,       # hauteur en pouces
  dpi      = 300      # résolution (300 = qualité impression)
)

#### gg_miss_var

graph2_valeurs_manquantes_secta3i <- gg_miss_var(secta3i) +
  labs(
    title    = "Valeurs manquantes — sect3i_harvestw4",
    subtitle = "Les colonnes représentent les valeurs manquantes, chaque ligne une variable"
  )

##### sauvergarde en png

ggsave(
  filename = "Valeurs_manquantes2_secta3i.png",
  plot     = graph2_valeurs_manquantes_secta3i,
  width    = 12,      # largeur en pouces — augmenter si libellés encore coupés
  height   = 6,       # hauteur en pouces
  dpi      = 300      # résolution (300 = qualité impression)
)


### base secta3ii

#### vis_miss

graph1_valeurs_manquantes_secta3ii <- vis_miss(secta3ii) +
  labs(
    title = "Carte des valeurs manquantes de la base secta3ii",
    subtitle = "Les lignes représentent les les observations et les colonnes, les variables") +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 7),
    axis.text.y = element_text(size = 8),
    axis.ticks.y = element_blank(),
    plot.margin = margin(t = 50, r = 20, b = 20, l = 20, unit = "pt")
  ) +
  scale_y_continuous(
    breaks = c(1, 1000, 2000, 3000, 4000, 5000, 6000, 7000,8000, 9000),
    labels = c("1","1000","2000","3000","4000","5000","6000","7000","8000","9000")
  )

##### Sauvegarde en PNG

ggsave(
  filename = "valeurs_manquantes1_secta3ii.png",
  plot     = graph1_valeurs_manquantes_secta3ii,
  width    = 12,      # largeur en pouces — augmenter si libellés encore coupés
  height   = 6,       # hauteur en pouces
  dpi      = 300      # résolution (300 = qualité impression)
)

#### gg_miss_var

graph2_valeurs_manquantes_secta3ii <- gg_miss_var(secta3ii) +
  labs(
    title    = "Valeurs manquantes — sect3ii_harvestw4",
    subtitle = "Les colonnes représentent les valeurs manquantes, chaque ligne une variable"
  )

##### sauvergarde en png

ggsave(
  filename = "Valeurs_manquantes2_secta3ii.png",
  plot     = graph2_valeurs_manquantes_secta3ii,
  width    = 12,      # largeur en pouces — augmenter si libellés encore coupés
  height   = 6,       # hauteur en pouces
  dpi      = 300      # résolution (300 = qualité impression)
)

### base secta11c2

#### vis_miss

graph1_valeurs_manquantes_secta11c2 <- vis_miss(secta11c2) +
  labs(
    title = "Carte des valeurs manquantes de la base secta11c2_harvestw4",
    subtitle = "Les lignes représentent les les observations et les colonnes, les variables") +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 7),
    axis.text.y = element_text(size = 8),
    axis.ticks.y = element_blank(),
    plot.margin = margin(t = 50, r = 20, b = 20, l = 20, unit = "pt")
  ) +
  scale_y_continuous(
    breaks = c(1, 1000, 2000, 3000, 4000, 5000, 6000, 7000,8000, 9000),
    labels = c("1","1000","2000","3000","4000","5000","6000","7000","8000","9000")
  )

##### Sauvegarde en PNG

ggsave(
  filename = "valeurs_manquantes1_secta11c2.png",
  plot     = graph1_valeurs_manquantes_secta11c2,
  width    = 12,      # largeur en pouces — augmenter si libellés encore coupés
  height   = 6,       # hauteur en pouces
  dpi      = 300      # résolution (300 = qualité impression)
)

#### gg_miss_var

graph2_valeurs_manquantes_secta11c2 <- gg_miss_var(secta11c2) +
  labs(
    title    = "Valeurs manquantes — secta11c2_harvestw4",
    subtitle = "Les colonnes représentent les valeurs manquantes, chaque ligne une variable"
  )

##### sauvergarde en png

ggsave(
  filename = "Valeurs_manquantes2_secta11c2.png",
  plot     = graph2_valeurs_manquantes_secta11c2,
  width    = 12,      # largeur en pouces — augmenter si libellés encore coupés
  height   = 6,       # hauteur en pouces
  dpi      = 300      # résolution (300 = qualité impression)
)

# Tâche 25 : 15 cultures les plus fréquentes 

## Explorons la variable code_culture

table(as_factor(secta3i$code_culture), useNA = "ifany")

## Calculons les fréquences et gardons les 15 premières
top15_cultures <- secta3i %>%
  filter(!is.na(code_culture)) %>%
  mutate(culture_lbl = as_factor(code_culture)) %>%
  count(culture_lbl, sort = TRUE) %>%
  slice_head(n = 15) %>%
  mutate(
    proportion = round(100 * n / sum(secta3i$code_culture %>% na.omit() %>% length()), 1),
    # Raccourcissons les libellés
    culture_court = recode(as.character(culture_lbl),
                           "1010. BEANS/COWPEA"         = "Haricot/Niébé",
                           "1020. CASSAVA"              = "Manioc",
                           "1040. COCOYAM"              = "Macabo",
                           "1060. GROUND NUT/PEANUTS"   = "Arachide",
                           "1070. GUINEA CORN (SORGHUM)"= "Sorgho",
                           "1080. MAIZE"                = "Maïs",
                           "1100. MILLET/MAIWA"         = "Mil",
                           "1110. RICE"                 = "Riz",
                           "1121. YAM, WHITE"           = "Igname blanche",
                           "1123. WATER YAM"            = "Igname d'eau",
                           "1124. YAM, THREE LEAVED"    = "Igname trois feuilles",
                           "2220. SOYA BEANS"           = "Soja",
                           "2040. BEENI-SEED/SESAME"    = "Sésame",
                           "2120. OKRO"                 = "Gombo",
                           "2190. PUMPKIN"              = "Citrouille"
    ),
    # Classons par type de culture
    type_culture = case_when(
      culture_lbl %in% c("1080. MAIZE", "1070. GUINEA CORN (SORGHUM)",
                         "1100. MILLET/MAIWA", "1110. RICE") ~ "Céréale",
      culture_lbl %in% c("1010. BEANS/COWPEA", "2220. SOYA BEANS",
                         "1060. GROUND NUT/PEANUTS")         ~ "Légumineuse",
      culture_lbl %in% c("1020. CASSAVA", "1121. YAM, WHITE",
                         "1123. WATER YAM", "1124. YAM, THREE LEAVED",
                         "1040. COCOYAM")                    ~ "Tubercule",
      TRUE                                                   ~ "Autre"
    ),
    type_culture = factor(type_culture,
                          levels = c("Céréale","Légumineuse","Tubercule","Autre")),
    culture_court = reorder(culture_court, n)
  )

## Barplot horizontal
p1_tp5 <- top15_cultures %>%
  ggplot(aes(x = n, y = culture_court, fill = type_culture)) +
  geom_bar(stat = "identity") +
  geom_text(aes(label = paste0(n, " (", proportion, "%)")),
            hjust = -0.1, size = 3) +
  scale_fill_manual(
    values = c("Céréale"     = "#2E86AB",
               "Légumineuse" = "#A23B72",
               "Tubercule"   = "#F18F01",
               "Autre"       = "#6B9E3C")
  ) +
  labs(
    title    = "Les 15 cultures les plus fréquentes au Nigeria",
    subtitle = "Wave 4 — Nigeria GHS Panel (2018-2019)",
    x        = "Nombre de parcelles",
    y        = "",
    fill     = "Type de culture"
  ) +
  xlim(0, 3500) +
  theme_minimal() +
  theme(legend.position = "bottom")

print(p1_tp5)

ggsave(
  filename = "top15_cultures.png",
  plot     = p1_tp5,
  width    = 12,
  height   = 7,
  dpi      = 300
)

# Tâche 26 : Indice de diversification culturale

## Nombre de cultures distinctes par ménage

diversification <- secta3i %>%
  filter(!is.na(code_culture)) %>%
  group_by(iden_menage) %>%
  summarise(
    nb_cultures = n_distinct(code_culture),
    .groups     = "drop"
  )

## Histogramme de la distribution

p2_tp5 <- diversification %>%
  ggplot(aes(x = nb_cultures)) +
  geom_histogram(binwidth = 1, fill = "#2E86AB", color = "white") +
  geom_vline(xintercept = median(diversification$nb_cultures),
             color = "red", linetype = "dashed", linewidth = 1) +
  annotate("text",
           x     = median(diversification$nb_cultures) + 0.3,
           y     = Inf,
           label = paste0("Médiane = ", median(diversification$nb_cultures)),
           hjust = 0, vjust = 1.5, size = 4, color = "red") +
  scale_x_continuous(breaks = 1:11) +
  labs(
    title    = "Distribution du nombre de cultures par ménage",
    subtitle = "Indice de diversification culturale — Wave 4",
    x        = "Nombre de cultures différentes",
    y        = "Nombre de ménages"
  ) +
  theme_minimal()

ggsave(
  filename = "histogramme_diversification.png",
  plot     = p2_tp5,
  width    = 10,
  height   = 6,
  dpi      = 300
)

## Jointure avec le milieu rural/urbain 

diversification <- diversification %>%
  left_join(
    secta3i %>% select(iden_menage, milieu) %>% distinct(),
    by = "iden_menage"
  ) %>%
  mutate(
    milieu_lbl = recode(as.character(as_factor(milieu)),
                        "1. Urban" = "Urbain",
                        "2. Rural" = "Rural"
    )
  )

## Test de Wilcoxon rural vs urbain

test_wilcoxon <- wilcox.test(
  nb_cultures ~ milieu_lbl,
  data = diversification
)

cat("Test de Wilcoxon — nb cultures rural vs urbain\n")
cat("W =", test_wilcoxon$statistic, "\n")
cat("p-valeur =", format(test_wilcoxon$p.value, scientific = TRUE), "\n")

## Violin plot 

p3_tp5 <- diversification %>%
  filter(!is.na(milieu_lbl)) %>%
  ggplot(aes(x = milieu_lbl, y = nb_cultures, fill = milieu_lbl)) +
  geom_violin(alpha = 0.7, trim = FALSE) +
  geom_boxplot(width = 0.15, fill = "white", outlier.shape = NA) +
  scale_fill_manual(values = c("Urbain" = "#2E86AB", "Rural" = "#A23B72")) +
  annotate("text",
           x     = 1.5, y = Inf,
           label = paste0("p-valeur = ",
                          format(test_wilcoxon$p.value, scientific = TRUE)),
           hjust = 0.5, vjust = 1.5, size = 4) +
  labs(
    title    = "Diversification culturale selon le milieu",
    subtitle = "Test de Wilcoxon — Wave 4",
    x        = "",
    y        = "Nombre de cultures différentes",
    fill     = "Milieu"
  ) +
  theme_minimal() +
  theme(legend.position = "none")

ggsave(
  filename = "violin_diversification_milieu.png",
  plot     = p3_tp5,
  width    = 8,
  height   = 6,
  dpi      = 300
)

# Tâche 27 : Taux d'utilisation des engrais par type et par zone 

## Explorons les variables d'utilisation des engrais 

cat("Engrais inorganique (utilisation_engrais_inorg)\n")
table(as_factor(secta11c2$utilisation_engrais_inorg), useNA = "ifany")

cat("\n Type NPK (type_engrais_npk) \n")
table(as_factor(secta11c2$type_engrais_npk), useNA = "ifany")

cat("\n Type Urée (type_engrais_uree)\n")
table(as_factor(secta11c2$type_engrais_uree), useNA = "ifany")

cat("\n Engrais organique (utilisation_engrais_org) \n")
table(as_factor(secta11c2$utilisation_engrais_org), useNA = "ifany")

## Préparons les variables

secta11c2 <- secta11c2 %>%
  mutate(
    milieu_lbl        = recode(as.character(as_factor(milieu)),
                               "1. Urban" = "Urbain",
                               "2. Rural" = "Rural"),
    engrais_inorg     = if_else(as_factor(utilisation_engrais_inorg) == "1. YES", 1, 0),
    engrais_org       = if_else(as_factor(utilisation_engrais_org)   == "1. YES", 1, 0),
    engrais_npk       = if_else(type_engrais_npk  == 1, 1, 0, missing = 0),
    engrais_uree      = if_else(type_engrais_uree == 1, 1, 0, missing = 0)
  )

## Taux d'utilisation par milieu avec IC à 95%

taux_engrais <- secta11c2 %>%
  filter(!is.na(milieu_lbl)) %>%
  group_by(milieu_lbl) %>%
  summarise(
    n               = n(),
    # Engrais inorganique
    n_inorg         = sum(engrais_inorg, na.rm = TRUE),
    taux_inorg      = round(100 * n_inorg / n, 1),
    ic_inf_inorg    = round(100 * (prop.test(n_inorg, n)$conf.int[1]), 1),
    ic_sup_inorg    = round(100 * (prop.test(n_inorg, n)$conf.int[2]), 1),
    # Engrais organique
    n_org           = sum(engrais_org, na.rm = TRUE),
    taux_org        = round(100 * n_org / n, 1),
    ic_inf_org      = round(100 * (prop.test(n_org, n)$conf.int[1]), 1),
    ic_sup_org      = round(100 * (prop.test(n_org, n)$conf.int[2]), 1),
    # NPK
    n_npk           = sum(engrais_npk, na.rm = TRUE),
    taux_npk        = round(100 * n_npk / n, 1),
    ic_inf_npk      = round(100 * (prop.test(n_npk, n)$conf.int[1]), 1),
    ic_sup_npk      = round(100 * (prop.test(n_npk, n)$conf.int[2]), 1),
    # Urée
    n_uree          = sum(engrais_uree, na.rm = TRUE),
    taux_uree       = round(100 * n_uree / n, 1),
    ic_inf_uree     = round(100 * (prop.test(n_uree, n)$conf.int[1]), 1),
    ic_sup_uree     = round(100 * (prop.test(n_uree, n)$conf.int[2]), 1),
    .groups         = "drop"
  )

## Mise en forme longue pour le barplot

taux_long <- taux_engrais %>%
  tidyr::pivot_longer(
    cols      = c(taux_inorg, taux_org, taux_npk, taux_uree),
    names_to  = "type_engrais",
    values_to = "taux"
  ) %>%
  mutate(
    ic_inf = case_when(
      type_engrais == "taux_inorg" ~ ic_inf_inorg,
      type_engrais == "taux_org"   ~ ic_inf_org,
      type_engrais == "taux_npk"   ~ ic_inf_npk,
      type_engrais == "taux_uree"  ~ ic_inf_uree
    ),
    ic_sup = case_when(
      type_engrais == "taux_inorg" ~ ic_sup_inorg,
      type_engrais == "taux_org"   ~ ic_sup_org,
      type_engrais == "taux_npk"   ~ ic_sup_npk,
      type_engrais == "taux_uree"  ~ ic_sup_uree
    ),
    type_engrais = recode(type_engrais,
                          "taux_inorg" = "Engrais inorganique",
                          "taux_org"   = "Engrais organique",
                          "taux_npk"   = "NPK",
                          "taux_uree"  = "Urée"
    )
  ) %>%
  select(milieu_lbl, type_engrais, taux, ic_inf, ic_sup)

## Barplot groupé avec IC à 95%

p4_tp5 <- taux_long %>%
  ggplot(aes(x = type_engrais, y = taux, fill = milieu_lbl)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8), width = 0.7) +
  geom_errorbar(aes(ymin = ic_inf, ymax = ic_sup),
                position = position_dodge(width = 0.8),
                width = 0.25, linewidth = 0.7) +
  geom_text(aes(label = paste0(taux, "%")),
            position = position_dodge(width = 0.8),
            vjust = -0.8, size = 3.5) +
  scale_fill_manual(values = c("Urbain" = "#2E86AB", "Rural" = "#A23B72")) +
  labs(
    title    = "Taux d'utilisation des intrants agricoles selon le milieu",
    subtitle = "Barres d'erreur = IC à 95% — Wave 4",
    x        = "Type d'intrant",
    y        = "Taux d'utilisation (%)",
    fill     = "Milieu"
  ) +
  ylim(0, 60) +
  theme_minimal() +
  theme(legend.position = "bottom")

print(p4_tp5)

ggsave(
  filename = "barplot_engrais_milieu.png",
  plot     = p4_tp5,
  width    = 10,
  height   = 6,
  dpi      = 300
)

## Test du chi-deux zone × utilisation engrais inorganique

table_chi2 <- table(
  as_factor(secta11c2$utilisation_engrais_inorg),
  as_factor(secta11c2$milieu)
)

test_chi2_engrais <- chisq.test(table_chi2)
print(test_chi2_engrais)

n_chi2 <- sum(table_chi2)
V_engrais <- sqrt(test_chi2_engrais$statistic /
                    (n_chi2 * (min(nrow(table_chi2), ncol(table_chi2)) - 1)))
cat("V de Cramér :", round(V_engrais, 3), "\n")

